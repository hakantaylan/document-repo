## Sample code for the blog article [Unit testing HTTP Retry Strategies](https://www.madhur.co.in/blog/2020/05/09/unit-testing-http-retry-strategies.html)
