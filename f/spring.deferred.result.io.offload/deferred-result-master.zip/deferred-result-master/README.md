### Sample code for using Deferred Result

Sample code for the blog article [Offload IO Intensive tasks to worker threads](https://www.madhur.co.in/blog/2021/11/20/offload-io-intensive-tasks-to-threads.html)