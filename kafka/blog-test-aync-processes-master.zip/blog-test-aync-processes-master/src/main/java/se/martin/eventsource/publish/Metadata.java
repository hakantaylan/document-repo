package se.martin.eventsource.publish;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@ToString
public class Metadata {

    private String traceId;

}
