package se.martin.eventsource;

import org.junit.jupiter.api.Test;

public class EventsourceApplicationTest {

    // This test is only intended as an example of the seperation of unit tests and integration tests
    // and does nothing at all.
    @Test
    void contextLoads() {
    }

}
