import SongsContainer from './songs_container';

export const Component = SongsContainer;