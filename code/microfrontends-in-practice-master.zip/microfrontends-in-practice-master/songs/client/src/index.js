import React from 'react';
import ReactDOM from 'react-dom';

import SongsContainer from './songs_container';

import './index.css';

ReactDOM.render(<SongsContainer />, document.getElementById('root'));
