#!/usr/bin/env bash

npm start --prefix ../client/ &
npm start --prefix ../server/
