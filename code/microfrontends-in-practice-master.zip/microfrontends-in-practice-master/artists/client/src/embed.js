import ArtistsContainer from './artists_container';

export const Component = ArtistsContainer;