import PlaylistContainer from './playlist_container';

export const Component = PlaylistContainer;