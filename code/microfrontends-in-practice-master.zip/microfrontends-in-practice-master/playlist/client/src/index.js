import React from 'react';
import ReactDOM from 'react-dom';

import PlaylistContainer from './playlist_container';

import './index.css';

ReactDOM.render(<PlaylistContainer />, document.getElementById('root'));
