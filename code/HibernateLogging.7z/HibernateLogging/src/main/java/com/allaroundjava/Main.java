package com.allaroundjava;

import com.allaroundjava.dao.ReceiptDao;
import com.allaroundjava.model.LineItem;
import com.allaroundjava.model.Receipt;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernateLogging");
		ReceiptDao receiptDao = new ReceiptDao(emf);

		LineItem strawberries = LineItem.getBuilder()
										.withItemName("strawberries")
										.withPrice(BigDecimal.TEN)
										.withQuantity(3)
										.build();
		LineItem yoghurt = LineItem.getBuilder()
								   .withItemName("yoghurt")
								   .withPrice(BigDecimal.ONE)
								   .withQuantity(2)
								   .build();

		Set<LineItem> lineItemsSet = new HashSet<>();
		lineItemsSet.add(strawberries);
		lineItemsSet.add(yoghurt);
		Receipt receipt = Receipt.newInstance(LocalDateTime.now(), lineItemsSet);
		receiptDao.persist(receipt);
	}

}
