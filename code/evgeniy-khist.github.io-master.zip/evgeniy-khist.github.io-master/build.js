(async function () {
  const fs = require('fs/promises');
  const glob = require("glob");
  const camelCase = require('camelcase');
  const Handlebars = require('handlebars');
  const md = require('markdown-it')({
    html: true,
    linkify: true
  });
  const moment = require('moment');
  const readingTime = require('reading-time');

  Handlebars.registerHelper('ifEquals', function (arg1, arg2, options) {
    return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
  });

  async function registerPartialFromFile(name) {
    console.log('Registering Handlebars partial', name);
    const html = await fs.readFile('templates/' + name + '.tpl.html', 'utf8');
    Handlebars.registerPartial(camelCase(name), html);
  }

  ['navbar-item', 'project-box', 'project', 'index', 'about']
    .forEach(async (partial) => await registerPartialFromFile(partial));

  async function compileTemplate(name) {
    console.log('Compiling template', name);
    const html = await fs.readFile('templates/' + name + '.tpl.html', 'utf8');
    return Handlebars.compile(html);
  }

  const layoutTemplate = await compileTemplate('layout');

  async function renderMarkdown(markdownFile) {
    console.log('Rendering a Markdown ', markdownFile);
    const markdown = await fs.readFile(markdownFile, 'utf8');
    return md.render(markdown);
  }

  async function renderTempate(template, path, context) {
    console.log('Rendering the template', path)
    context.whichPartial = () => template;
    await fs.writeFile(path, layoutTemplate(context));
  }

  async function renderProjectTempate(path, context) {
    await renderTempate('project', path.replace('README.md', 'index.html'), context);
  }

  async function renderIndexTempate(context) {
    await renderTempate('index', 'index.html', context);
  }

  async function renderAboutTempate(path, context) {
    await renderTempate('about', path.replace('README.md', 'index.html'), context);
  }

  const baseDir = process.argv[2];
  const author = process.argv[3];
  const projectNames = process.argv.slice(4);

  async function getGitHubProject(project) {
    console.log('Fetching metadata for project', project);
    return JSON.parse(await fs.readFile(`${baseDir}/${project}.json`, 'utf8'));
  }

  function formatDate(date) {
    return moment(date).format('D MMM YYYY');
  }

  function formatDateIso8601(date) {
    return moment(date).format('YYYY-MM-DD');
  }

  const projects = [];
  let aboutMe;

  for (const projectName of projectNames) {
    console.log('Processing the project', projectName);
    const content = await renderMarkdown(`${projectName}/README.md`);
    const titleFound = content.match(/<h1.*>(.+)<\/h1>/i);
    const title = titleFound ? titleFound[1] : null;
    const gitHubProject = await getGitHubProject(projectName);
    const readingTimeStats = readingTime(content);

    const project = {
      project: projectName,
      title: title,
      description: gitHubProject.description,
      topics: gitHubProject.topics,
      languages: Object.keys(gitHubProject.languages),
      updatedAt: formatDate(gitHubProject.lastModified),
      updatedAtIso8601: formatDateIso8601(gitHubProject.lastModified),
      readingTime: readingTimeStats.text,
      stars: gitHubProject.stars,
      content: content,
      author
    };

    if (projectName === author) {
      aboutMe = project;
    } else {
      projects.push(project);
    }
  }

  projects.sort((a, b) => b.stars - a.stars);

  for (const project of projects) {
    console.log(`Rendering the project ${project.project} page`);
    await renderProjectTempate(`${project.project}/README.md`, {
      title: project.title,
      project,
      projects,
      author
    });

    glob(`${project.project}/**/README.md`, async (err, files) => {
      if (err) {
        console.log('Error', err);
      } else {
        console.log(`Rendering project ${project.project} sub-pages`, files);
        for (const file of files) {
          console.log(`Rendering project ${project.project} sub-page`, file);
          const projectCopy = Object.assign({}, project);
          projectCopy.content = await renderMarkdown(file);
          projectCopy.title = projectCopy.content.match(/<h1.*>(.+)<\/h1>/i)[1] || projectCopy.title;
          renderProjectTempate(file, {
            title: projectCopy.title,
            project: projectCopy,
            projects,
            author
          });
        }
      }
    });
  }

  if (aboutMe) {
    console.log('Rendering the "About" page');
    const aboutMeFile = `${aboutMe.project}/README.md`;
    await renderAboutTempate(aboutMeFile, {
      title: "About Me",
      content: await renderMarkdown(aboutMeFile),
      projects,
      author
    });
  }

  console.log('Rendering the "Welcome" page');
  await renderIndexTempate({
    title: "Evgeniy Khyst's Tech Blog",
    projects: projects,
    author: author
  });
})();