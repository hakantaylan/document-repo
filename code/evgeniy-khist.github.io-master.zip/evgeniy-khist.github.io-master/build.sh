#!/bin/bash

echo "Rendering HTML pages"

baseDir=".projects"
author=$(git remote get-url origin | cut -d':' -f 2 | cut -d'/' -f 1)
mapfile -t projects < projects.txt

for project in ${projects[@]}; do
  echo "Copying raw files of '$project'"
  rm -rf "$project"
  cp -r "$baseDir/$project" "$project"
done

rm -f "index.html"

node build.js "$baseDir" "$author" "${projects[@]}"

for project in ${projects[@]}; do
  echo "Cleaing up $project"
  rm -rf "$project/src"
  find "$project" -type f ! -name '*.html' -and ! -name '*.js' -and ! -name '*.css' -and ! -name '*.jpg' -and ! -name '*.jpeg' -and ! -name '*.png' -and ! -name '*.gif' -and ! -name '*.sql' -delete
  find "$project" -type d -empty -delete
done