# Evgeniy Khyst's Tech Blog

A simple tool built with Bash and Node.js converting GitHub repositories into a simple GitHub Pages blog.

## Prerequisites

1. Install [Node.js](https://nodejs.org/en/download/) 12+
2. Install the `npm` dependencies
   ```bash
   npm i
   ```
3. Get [new GitHub personal access token](https://github.com/settings/tokens/new) and export it as `GITHUB_TOKEN` environment variable

## Updating

1. Configure GitHub repositories to be converted to blog posts in [`projects.txt`](./projects.txt)
2. Pull all projects
   ```bash
   ./pull.sh
   ```
   or ony specific projects
   ```bash
   ./pull.sh postgresql-performance-essentials spring-data-examples
   ```
3. Build the static HTML pages
   ```bash
   ./build.sh
   ```
4. Check the website locally
5. Push the changes to GitHub
   ```bash
   git push
   ```

## Serving website locally

1. To build the website and start a web server run
   ```bash
   ./serve.sh
   ```
2. To start a web server without re-building a website run
   ```bash
   ./server.sh -s
   ```
3. Open `http://localhost:8080` in browser
