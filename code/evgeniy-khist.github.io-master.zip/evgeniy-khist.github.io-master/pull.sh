#!/bin/bash

baseDir=".projects"
mkdir -p "$baseDir"

if [ $# -eq 0 ]; then
  mapfile -t projects < projects.txt
else
  projects=($*)
fi

for project in ${projects[@]}; do
  echo "Pulling $project"
  rm -rf "$baseDir/$project"

  branches=(main master)

  for branch in ${branches[@]}; do
    echo "Downloading $project GitHub repository (${branch} branch)"
    curl "https://github.com/evgeniy-khist/${project}/archive/${branch}.zip" -o "$baseDir/${project}.zip" -L --fail
    if [ $? -eq 0 ]; then
      break
    fi
  done

  echo "Unzipping ${project}.zip"
  unzip -q -d "$baseDir/" "$baseDir/${project}.zip"
  rm "$baseDir/${project}.zip"

  find "$baseDir" -maxdepth 1 -type d -name "${project}-*" -exec mv {} "$baseDir/$project" \;

  node pull.js "$baseDir" "$project"
done