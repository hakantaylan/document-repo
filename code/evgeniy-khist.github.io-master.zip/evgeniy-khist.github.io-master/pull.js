(async function () {
  const fs = require('fs/promises');
  const axios = require('axios');

  async function getGitHubProject(project) {
    console.log('Fetching repo info for', project);
    const response = await axios.get(`https://api.github.com/repos/evgeniy-khist/${project}`, {
      headers: { Authorization: `token ${process.env.GITHUB_TOKEN}` }
    });
    return response.data;
  }

  async function getGitHubProjectTopics(project) {
    console.log('Fetching repo topics for', project);
    const response = await axios.get(`https://api.github.com/repos/evgeniy-khist/${project}/topics`, {
      headers: {
        Authorization: `token ${process.env.GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.mercy-preview+json'
      }
    });
    return response.data.names;
  }

  async function getGitHubProjectLanguages(project) {
    console.log('Fetching repo languages for', project);
    const response = await axios.get(`https://api.github.com/repos/evgeniy-khist/${project}/languages`, {
      headers: {
        Authorization: `token ${process.env.GITHUB_TOKEN}`
      }
    });
    return response.data;
  }

  const baseDir = process.argv[2];
  const projects = process.argv.slice(3);

  for (const project of projects) {
    console.log('Fetching metadata from GitHub for project', project);
    const gitHubProject = await getGitHubProject(project);
    const topics = await getGitHubProjectTopics(project);
    const languages = await getGitHubProjectLanguages(project);
    await fs.writeFile(`${baseDir}/${project}.json`, JSON.stringify({
      project,
      description: gitHubProject.description,
      languages,
      topics,
      lastModified: gitHubProject.pushed_at,
      stars: gitHubProject.stargazers_count
    }));
  }
})();