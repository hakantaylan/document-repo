DROP TABLE book_category, 
           book_author, 
           book, 
           publisher,
           author, 
           category;