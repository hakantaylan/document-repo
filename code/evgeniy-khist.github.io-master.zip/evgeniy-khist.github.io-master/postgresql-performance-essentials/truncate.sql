TRUNCATE book_category, 
         book_author, 
         category, 
         author,
         publisher, 
         book;
