if [ "$1" != "-s" ]; then
  ./build.sh
fi
./node_modules/http-server/bin/http-server ./ -p 8080