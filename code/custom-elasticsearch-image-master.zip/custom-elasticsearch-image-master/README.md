# Create index-ready and data-ready Elasticsearch image with Docker Compose

## Using
- Clone the repo
- Open your favorite terminal app
- Write `docker-compose up`

**PS:** Pre-defined items can be modified from `elasticsearch/json-files/bulk-insert.json` file

**PS-2:** Pre-defined index template can be modified from `elasticsearch/json-files/create-index.json` file

