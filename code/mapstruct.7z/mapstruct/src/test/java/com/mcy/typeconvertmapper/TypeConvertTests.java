package com.mcy.typeconvertmapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TypeConvertTests {

	@Autowired
	ConvertMapper mapper;

	@Test
	public void contextLoads() {
		ConvertDTO dto = new ConvertDTO(Instant.now());
		ConvertObject obj = mapper.typeConvertDto2Object(dto);
		assertThat(obj.getStrVal()).isNotEmpty();
	}

}
