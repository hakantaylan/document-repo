package com.mcy.inheritmapper;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class InheritTests {

	@Autowired
	InheritMapper mapper;

	@Test
	public void contextLoads() {

		InheritDTO dto = new InheritDTO(2, 3);

		InheritObject obj = mapper.inheritDto2Object(dto);

		assertThat(obj.getStrVal()).isNull();
		assertThat(obj.getIntVal()).isEqualTo(2);
		assertThat(obj.getIntVal2()).isEqualTo(3);
		
	}

}
