package com.mcy.typeconvertmapper;

public class ConvertObject {

	private String strVal;

	public ConvertObject(String strVal) {
		super();
		this.strVal = strVal;
	}

	public ConvertObject() {
		super();
	}

	public String getStrVal() {
		return strVal;
	}

	public void setStrVal(String strVal) {
		this.strVal = strVal;
	}

}
