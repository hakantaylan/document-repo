package com.mcy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McySbMapstructApplication {

	public static void main(String[] args) {
		SpringApplication.run(McySbMapstructApplication.class, args);
	}

}
