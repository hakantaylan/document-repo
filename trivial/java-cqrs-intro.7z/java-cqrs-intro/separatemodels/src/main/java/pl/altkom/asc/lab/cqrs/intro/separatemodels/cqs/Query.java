package pl.altkom.asc.lab.cqrs.intro.separatemodels.cqs;


public interface Query<R> {
}
