package pl.altkom.asc.lab.cqrs.intro.cqrswithes.domain.policy;

public enum PolicyStatus {
    Active, Terminated
}
