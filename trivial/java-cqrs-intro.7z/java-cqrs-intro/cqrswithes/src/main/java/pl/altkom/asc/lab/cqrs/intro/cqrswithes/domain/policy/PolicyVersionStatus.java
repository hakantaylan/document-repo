package pl.altkom.asc.lab.cqrs.intro.cqrswithes.domain.policy;

public enum PolicyVersionStatus {
    Draft, Active, Cancelled
}
