package pl.altkom.asc.lab.cqrs.intro.cqrswithes.cqs;


public interface Query<R> {
}
