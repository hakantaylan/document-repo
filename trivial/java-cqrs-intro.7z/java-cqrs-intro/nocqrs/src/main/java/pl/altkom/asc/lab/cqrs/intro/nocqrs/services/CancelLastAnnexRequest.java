package pl.altkom.asc.lab.cqrs.intro.nocqrs.services;

import lombok.Getter;

@Getter
public class CancelLastAnnexRequest {
    private String policyNumber;
}
