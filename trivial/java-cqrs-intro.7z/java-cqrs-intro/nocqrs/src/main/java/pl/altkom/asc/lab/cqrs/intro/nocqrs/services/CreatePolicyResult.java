package pl.altkom.asc.lab.cqrs.intro.nocqrs.services;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreatePolicyResult {
    private String policyNumber;
}
