package com.example.kafkatxsynchronisation.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

@Service
public class MyService {

    private final JdbcTemplate jdbcTemplate;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final TransactionTemplate txTemplate;
    private final TransactionalHelperService customTransactionalService;

    public MyService(JdbcTemplate jdbcTemplate, KafkaTemplate<String, String> kafkaTemplate, TransactionTemplate txTemplate, TransactionalHelperService customTransactionalService) {
        this.jdbcTemplate = jdbcTemplate;
        this.kafkaTemplate = kafkaTemplate;
        this.txTemplate = txTemplate;
        this.customTransactionalService = customTransactionalService;
    }

    @Transactional("dstm")
    public void dbFirstKafkaLater(String in) {
        this.kafkaTemplate.send("topic2", in.toUpperCase());
        this.jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
    }

    @Transactional(transactionManager = "dstm")
    public void kafkaFirstDBLater(String in) {
        jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
//            myKafkaService.sendToKafka(in);
        sendToKafka(in);
    }

//        @Transactional(transactionManager = "platformTransactionManager")
//        public void kafkaFirstDBLaterWithChain(String in) {
//            this.jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
//            this.kafkaTemplate.send("topic2", in.toUpperCase());
//        }

//        public void sendToKafkaInTx(String in) {
//            try {
//                CompletableFuture<SendResult<String, String>> result = this.kafkaTemplate.executeInTransaction(kafkaOperations -> kafkaOperations.send("topic2", in.toUpperCase()));
//                System.out.println(result);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }

    @Transactional(transactionManager = "kafkaTransactionManager")
    public void sendToKafka(String in) {
        this.kafkaTemplate.send("topic2", in.toUpperCase());
    }

    public void DBFirstKafkaLater2(String in) {
        kafkaTemplate.executeInTransaction(kafkaOperations -> {
            kafkaOperations.send("topic2", in.toUpperCase());
            txTemplate.executeWithoutResult(new Consumer<>() {
                @Override
                public void accept(TransactionStatus transactionStatus) {
                    jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
                }
            });
            return null;
        });

    }

    public void kafkaFirstDBLater2(String in) {
        txTemplate.executeWithoutResult(new Consumer<>() {
            @Override
            public void accept(TransactionStatus transactionStatus) {
                CompletableFuture<SendResult<String, String>> topic2 = kafkaTemplate.executeInTransaction(kafkaOperations -> {
                    return kafkaOperations.send("topic2", in.toUpperCase());
                });
                jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
                try {
                    topic2.get();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void txDeneme(String data) {
        customTransactionalService.runInNewTransaction(() -> kafkaTemplate.send("topic2", data.toUpperCase()));
        customTransactionalService.runInNewTransaction(() -> jdbcTemplate.execute("insert into mytable (data) values ('" + data + "')"));
    }
}
