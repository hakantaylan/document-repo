package com.example.kafkatxsynchronisation.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.function.Supplier;

@Service
public class TransactionalHelperService {

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public <U> U runInNewTransaction(final Supplier<U> supplier) {
        return supplier.get();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void runInNewTransaction(final Runnable runnable) {
        runnable.run();
    }
}
