package com.example.kafkatxsynchronisation.service;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DBService {

    private final JdbcTemplate jdbcTemplate;

    @Transactional("dstm")
    public void saveToDBWithTx(String in) {
        this.jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
        this.jdbcTemplate.execute("insert into mytable (data) values ('Hakan')");
        throw new RuntimeException("Deneme");
    }

    public void saveToDBWithoutTx(String in) {
        this.jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
        this.jdbcTemplate.execute("insert into mytable (data) values ('Hakan')");
        throw new RuntimeException("Deneme");
    }

    public List<String> getResultsFromDB() {
        return jdbcTemplate.queryForList("select data from mytable", String.class);
    }
}
