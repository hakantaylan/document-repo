package com.example.kafkatxsynchronisation.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class DataSourceConfig {

//    @Bean
//    public PlatformTransactionManager platformTransactionManager(KafkaTransactionManager ktm, JpaTransactionManager dstm) {
//        return new ChainedTransactionManager(dstm, ktm);
//    }

    @Bean
    @Primary
    public JpaTransactionManager dstm(EntityManagerFactory entityManagerFactory, DataSource ds) {
        JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
        jpaTransactionManager.setDataSource(ds);
        jpaTransactionManager.setEntityManagerFactory(entityManagerFactory);
        return jpaTransactionManager;
    }

//    @Bean
//    @Primary
//    public DataSourceTransactionManager dstm(DataSource dataSource) {
//        return new DataSourceTransactionManager(dataSource);
//    }
}
