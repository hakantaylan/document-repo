package com.example.kafkatxsynchronisation;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class Consumer {

    private final JdbcTemplate jdbcTemplate;
    private final KafkaTemplate<String, String> kafkaTemplate;

//        @KafkaListener(id = "group1", topics = "topic1")
//        @Transactional("dstm")
//        public void listen1(String in) {
//            this.kafkaTemplate.send("topic2", in.toUpperCase());
//            this.jdbcTemplate.execute("insert into mytable (data) values ('" + in + "')");
//        }
//
//        @KafkaListener(id = "group2", topics = "topic2")
//        public void listen2(String in) {
//            System.out.println(in);
//        }
}
