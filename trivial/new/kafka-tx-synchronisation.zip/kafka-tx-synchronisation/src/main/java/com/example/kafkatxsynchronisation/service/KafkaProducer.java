package com.example.kafkatxsynchronisation.service;

import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class KafkaProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Transactional("kafkaTransactionManager")
    public void sendToKafka(String in) {
        this.kafkaTemplate.send("topic2", in.toUpperCase());
//            CompletableFuture<SendResult<String, String>> topic2 = this.kafkaTemplate.send("topic2", in.toUpperCase());
//            SendResult<String, String> result = topic2.get();
//            System.out.println(result);

    }
}
