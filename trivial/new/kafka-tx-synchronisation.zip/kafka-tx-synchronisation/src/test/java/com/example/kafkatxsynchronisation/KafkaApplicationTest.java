package com.example.kafkatxsynchronisation;

import com.example.kafkatxsynchronisation.service.DBService;
import com.example.kafkatxsynchronisation.service.MyService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;

import java.util.Arrays;

@EmbeddedKafka(
//        ports = 9092,
        partitions = 1,
        topics = {
                "topic-1.v1",
                "topic-2.v1",
                "topic-3.v1",
                "topic-4.v1",
                "topic-5.v1",
                "topic-6.v1",
        },
        brokerProperties = {"transaction.state.log.replication.factor=1", "transaction.state.log.min.isr=1",
//                "log.dir=/tmp/embedded-kafka"
        }
)
//@SpringBootTest(classes = properties = {"spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}", "spring.kafka.consumer.auto-offset-reset=earliest", "spring.kafka.consumer.enable-auto-commit=false", "spring.kafka.consumer.properties.isolation.level=read_committed",
//        "spring.kafka.producer.transaction-id-prefix=txx-", "logging.level.org.springframework.transaction=trace", "logging.level.org.springframework.kafka.transaction=debug", "logging.level.org.springframework.jdbc=debug"})
@SpringBootTest(properties = {"spring.kafka.bootstrap-servers=${spring.embedded.kafka.brokers}"})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class KafkaApplicationTest {

    @Autowired
    private MyService myService;
    @Autowired
    private DBService dbService;


    @Autowired
    EmbeddedKafkaBroker kafkaBroker;
//    You can get the broker addresses by calling this.kafkaBroker.getBrokersAsString()

    @Test
    public void dbFirstKafkaLater() throws InterruptedException {
        myService.dbFirstKafkaLater("aaa");
        Thread.sleep(2_000);
    }

    @Test
    public void kafkaFirstDBLater() throws InterruptedException {
        myService.kafkaFirstDBLater("aaa");
        Thread.sleep(2_000);
    }

//    @Test
//    public void kafkaFirstDBLaterWithChain() throws InterruptedException {
//        myService.kafkaFirstDBLaterWithChain("aaa");
//        Thread.sleep(2_000);
//    }

    @Test
    public void dbFirstKafkaLater2() throws InterruptedException {
        myService.DBFirstKafkaLater2("aaa");
        Thread.sleep(2_000);
    }

    @Test
    public void kafkaFirstDBLater2() throws InterruptedException {
        myService.kafkaFirstDBLater2("aaa");
        Thread.sleep(2_000);
    }

    @Test
    public void testJdbcWithTx() {
        try {
            dbService.saveToDBWithTx("aaa");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(Arrays.toString(dbService.getResultsFromDB().toArray()));
    }

    @Test
    public void testJdbcWithoutTx() {
        try {
            dbService.saveToDBWithoutTx("aaa");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(Arrays.toString(dbService.getResultsFromDB().toArray()));
    }

    @Test
    public void testTxDBFirst() {
        myService.txDeneme("aaa");
    }
}