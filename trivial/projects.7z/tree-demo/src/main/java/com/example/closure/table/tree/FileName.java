package com.example.closure.table.tree;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "file_name")
@DynamicUpdate
@Getter
@Setter
@NoArgsConstructor
public class FileName implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull
    private String name;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "descendant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<TreePath> parents = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "ancestor")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<TreePath> children = new ArrayList<>();
    
    @Transient
    private String delimiter = "\\";

    public FileName(String name) {
        this.name = name;
    }

    public void addParent(TreePath p) {
        parents.add(p);
    }

    public void addChild(TreePath ch) {
        children.add(ch);
    }

    public void addParents(List<TreePath> p) {
        parents.addAll(p);
    }

    @Override
    public String toString() {
        return "FileName{" + "id=" + id + ", name=" + name + '}';
    }
}
