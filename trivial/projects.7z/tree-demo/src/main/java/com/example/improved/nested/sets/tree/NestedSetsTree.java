package com.example.improved.nested.sets.tree;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;

import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "nested_sets2", indexes = {
    @Index(name = "IDX_LFT2", columnList = "lft"),
    @Index(name = "IDX_RGT2", columnList = "rgt")})
@DynamicUpdate
@Getter
@Setter
@NoArgsConstructor
public class NestedSetsTree implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull
    private String name;
    @NotNull
    @Column(name = "lft")
    private long left;
    @NotNull
    @Column(name = "rgt")
    private long right;

    private int level;
    @Transient
    private String delimiter = "\\";

    public NestedSetsTree(String name, long left, long right) {
        this.name = name;
        this.left = left;
        this.right = right;
    }

    public long getAllChildrenSize() {
        return (right - left - 1) / 2;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + (int) (this.id ^ (this.id >>> 32));
        hash = 89 * hash + Objects.hashCode(this.name);
        hash = 89 * hash + (int) (this.left ^ (this.left >>> 32));
        hash = 89 * hash + (int) (this.right ^ (this.right >>> 32));
        hash = 89 * hash + this.level;
        return hash;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NestedSetsTree that = (NestedSetsTree) o;
        return getId() == that.getId() && getLeft() == that.getLeft() && getRight() == that.getRight() && getLevel() == that.getLevel() && Objects.equals(getName(), that.getName());
    }

    @Override
    public String toString() {
        return "NestedSetsTree{" + "id=" + id + ", name=" + name + ", left=" + left + ", right=" + right + ", level=" + level + ", delimiter=" + delimiter + '}';
    }

}
