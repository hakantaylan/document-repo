package com.example.nested.sets.tree;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;

import java.io.Serializable;
import java.util.Objects;


@Entity
@Table(name = "nested_sets", indexes = {
    @Index(name = "IDX_LFT", columnList = "lft"),
    @Index(name = "IDX_RGT", columnList = "rgt")})
@DynamicUpdate
@Getter
@Setter
@NoArgsConstructor
public class NestedSetsTree implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull
    private String name;
    @NotNull
    @Column(name = "lft")
    private long left;
    @NotNull
    @Column(name = "rgt")
    private long right;
    @Transient
    private String delimiter = "\\";

    public NestedSetsTree(String name, long left, long right) {
        this.name = name;
        this.left = left;
        this.right = right;
    }
    
    public long getAllChildrenSize(){
        return (right - left - 1)/2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NestedSetsTree that = (NestedSetsTree) o;
        return id == that.id &&
                left == that.left &&
                right == that.right &&
                name.equals(that.name) &&
                delimiter.equals(that.delimiter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, left, right, delimiter);
    }

    @Override
    public String toString() {
        return "NestedSetsTree{" + "id=" + id + ", name=" + name + ", left=" + left + ", right=" + right + ", delimiter=" + delimiter + '}';
    }
}
