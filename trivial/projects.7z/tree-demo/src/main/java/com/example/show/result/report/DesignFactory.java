package com.example.show.result.report;

import com.example.adjacency.list.tree.NodeDao;
import com.example.closure.table.tree.FileNameDao;
import com.example.nested.sets.tree.NestedSetsDao;
import com.example.path.enumeration.tree.FilesDao;
import com.example.tree.initialization.AdjacencyTreeInitialization;
import com.example.tree.initialization.ClosureTreeInitialization;
import com.example.tree.initialization.NestedSetsInitialization;
import com.example.tree.initialization.PathTreeInitialization;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author ivan.yuriev
 */
public class DesignFactory {

    private File folder;

    public DesignFactory(File folder) {
        this.folder = folder;
    }

    public DesignModel getDesignModel(DesignType type) {
        DesignModel toReturn = null;
        MeasureModel measureModel = new MeasureModel(type);
        switch (type) {
            case ADJACENCY_LIST:
                toReturn = new DesignModel.Builder()
                        .measureModel(measureModel)
                        .dao(new NodeDao())
                        .treeInitialization(new AdjacencyTreeInitialization(folder))
                        .build();
                break;
            case CLOSURE_TABLE:
                toReturn = new DesignModel.Builder()
                        .measureModel(measureModel)
                        .dao(new FileNameDao())
                        .treeInitialization(new ClosureTreeInitialization(folder))
                        .build();
                break;
            case IMPROVED_CLOSURE_TABLE:
                toReturn = new DesignModel.Builder()
                        .measureModel(measureModel)
                        .dao(new com.example.improved.closure.table.tree.FileNameDao())
                        .treeInitialization(new com.example.improved.closure.table.tree.ClosureTreeInitialization(folder))
                        .build();
                break;
            case NESTED_SETS:
                toReturn = new DesignModel.Builder()
                        .measureModel(measureModel)
                        .dao(new NestedSetsDao())
                        .treeInitialization(new NestedSetsInitialization(folder))
                        .build();
                break;
            case IMPROVED_NESTED_SETS:
                toReturn = new DesignModel.Builder()
                        .measureModel(measureModel)
                        .dao(new com.example.improved.nested.sets.tree.NestedSetsDao())
                        .treeInitialization(new com.example.improved.nested.sets.tree.NestedSetsInitialization(folder))
                        .build();
                break;
            case PATH_ENUMERATION:
                toReturn = new DesignModel.Builder()
                        .measureModel(measureModel)
                        .dao(new FilesDao())
                        .treeInitialization(new PathTreeInitialization(folder))
                        .build();
                break;
            default:
                throw new IllegalArgumentException("Wrong design type:" + type);
        }
        return toReturn;
    }

    public List<DesignModel> getAllDesignModels() {
        return Stream.of(DesignType.values()).map(this::getDesignModel).collect(Collectors.toList());
    }
}
