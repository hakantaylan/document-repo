package com.example.show.result.report;

import com.example.data.storage.DataStorage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;


public class Main {

    private static final Logger LOG = LogManager.getLogger(Main.class);

    public static void main(String... args) {
        try {
            File folder = new File(DataStorage.INIT.getValue());
            TimeMeasurement tm = new TimeMeasurement(folder);
            tm.initTree();
            tm.runGetChildren(DataStorage.GET_CHILDREN.getValue());
            tm.runGetParents(DataStorage.GET_PARENTS.getValue());
            runMove(tm);
            runAdd(tm);
            tm.runDelete(DataStorage.DELETE.getValue());
            Report ct = new ConsoleReport(tm.getMeasurementResults());
            LOG.info(ct);
        } finally {
            close();
        }
    }

    private static void runMove(TimeMeasurement tm) {
        String moveProp = DataStorage.MOVE.getValue();
        String moveParentNodeName = moveProp.split(DataStorage.DELIMITER)[0];
        String moveSubNodeName = moveProp.split(DataStorage.DELIMITER)[1];
        tm.runMove(moveParentNodeName, moveSubNodeName);
    }

    private static void runAdd(TimeMeasurement tm) {
        String addProp = DataStorage.ADD.getValue();
        String addNodeName = addProp.split(DataStorage.DELIMITER)[0];
        File addFolder = new File(addProp.split(DataStorage.DELIMITER)[1]);
        tm.runAdd(addNodeName, addFolder);
    }

    private static void close() {
        com.example.adjacency.list.tree.HibernateUtil.close();
        com.example.closure.table.tree.HibernateUtil.close();
        com.example.improved.closure.table.tree.HibernateUtil.close();
        com.example.nested.sets.tree.HibernateUtil.close();
        com.example.improved.nested.sets.tree.HibernateUtil.close();
        com.example.path.enumeration.tree.HibernateUtil.close();
    }
}
