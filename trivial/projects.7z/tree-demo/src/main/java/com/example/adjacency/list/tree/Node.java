package com.example.adjacency.list.tree;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "tree", indexes = @Index(name = "IDX_PARENT_ID", columnList = "parent_id"))
@Getter
@Setter
@NoArgsConstructor
@DynamicUpdate
public class Node implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id", foreignKey = @ForeignKey(name = "FK_PARENT_ID"))
    private Node parent;

    @NotNull
    private String name;

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<Node> children = new ArrayList<>();

    @Transient
    private String delimiter = "\\";


    public Node(Node parent, String name) {
        this.name = name;
        this.parent = parent;
    }


    @Override
    public String toString() {
        return "Node{" + "id=" + id + ", name=" + name + ", children=" + children + '}';
    }

}
