package com.example.path.enumeration.tree;

import com.example.tree.dao.TreeDao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.*;

@Component
@Transactional
public class FilesDao implements TreeDao<Files> {

    @Autowired
    FilesRepository repository;

    @Autowired
    EntityManager entityManager;

    @Override
    public Optional<Files> get(long id) {
        return repository.findById(id);
    }

    @Override
    public void save(Files data) {
        repository.save(data);
    }

    @Override
    public void save(List<Files> files) {
//        int batchSize = HibernateUtil.getBatchSize();
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction transaction = session.getTransaction();
//        transaction.begin();
//        for (int i = 0; i < files.size(); i++) {
//            session.persist(files.get(i));
//            if ((i + 1) % batchSize == 0) {
//                // Flush and clear the cache every batch
//                session.flush();
//                session.clear();
//            }
//        }
//        transaction.commit();
        repository.saveAll(files);
    }

    @Override
    public void delete(Files files) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
//        session.createNamedMutationQuery("delete")
//                .setParameter("path", files.getPath())
//                .setParameter("delimiter", File.separator)
//                .executeUpdate();
//        session.getTransaction().commit();
        repository.deleteByPathAndDelimiter(files.getPath(), File.separator);
    }

    @Override
    public List<Files> getAll() {
        return repository.findAll();
    }

    @Override
    public List<Files> getByName(String name) {
        return repository.findByName(name);
    }

    @Override
    public Map<Integer, List<Files>> getAllChildren(Files files) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        List<Object[]> children = entityManager.createNamedQuery("getAllChildren", Object[].class)
                .setParameter("delimiter", File.separator)
                .setParameter("parentPath", files.getPath())
                .getResultList();
//        session.getTransaction().commit();
//        List<Object[]> children = repository.getAllChildren(files.getPath(), File.separator);
        Map<Integer, List<Files>> result = new HashMap<>();
        children.forEach(rec -> {
            Files child = (Files) rec[0];
            Integer level = (Integer) rec[1];
            List<Files> list = result.computeIfAbsent(level, k -> new ArrayList<>());
            list.add(child);
        });
        return result;
    }

    @Override
    public Map<Integer, Files> getAllParents(Files files) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
//        List<Object[]> parents = session.createNamedQuery("getAllParents", Object[].class)
//                .setParameter("delimiter", File.separator)
//                .setParameter("id", files.getId())
//                .getResultList();
//        session.getTransaction().commit();
        List<Object[]> parents = repository.getAllParents(files.getId(), File.separator);
        Map<Integer, Files> result = new HashMap<>();
        parents.forEach(rec -> {
            Files parent = (Files) rec[0];
            Integer level = (Integer) rec[1];
            result.put(level, parent);
        });
        return result;
    }

    @Override
    public void add(Files parentNode, List<Files> nodes) {
        if (parentNode == null || CollectionUtils.isEmpty(nodes)) {
            return;
        }
        nodes.forEach(n -> {
            String newPath = String.join(File.separator, parentNode.getPath(), n.getName());
            n.setPath(newPath);
        });
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        nodes.forEach(repository::save);
//        session.getTransaction().commit();
    }

    @Override
    public void move(Files parentNode, Files subNode) {
        if (parentNode == null || subNode == null) {
            return;
        }
        String subNodeParentPath = StringUtils.removeEnd(subNode.getPath(), File.separator + subNode.getName());
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        entityManager.createNamedQuery("move")
                .setParameter("subNodeParentPath", subNodeParentPath)
                .setParameter("parentPath", parentNode.getPath())
                .setParameter("delimiter", File.separator)
                .executeUpdate();
//        session.getTransaction().commit();
    }

    @Override
    public String getPath(Files files) {
        return files.getPath();
    }

    @Override
    public Files getRoot(Files files) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        TypedQuery<Files> result = entityManager.createNamedQuery("getRoot", Files.class)
                .setParameter("path", files.getPath())
                .setParameter("delimiter", File.separator);
        Files root = result.getSingleResult();
//        session.getTransaction().commit();
        return root;
    }
}
