package com.example.improved.closure.table.tree;

import com.example.tree.dao.TreeDao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class FileNameDao implements TreeDao<FileName> {

    @Autowired
    FileNameRepository repository;

    @Autowired
    EntityManager entityManager;

    @Override
    public Optional<FileName> get(long id) {
        return repository.findById(id);
    }

    @Override
    public void save(FileName fileName) {
        repository.save(fileName);
    }

    @Override
    public void save(List<FileName> fileNames) {
//        int batchSize = HibernateUtil.getBatchSize();
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction transaction = session.getTransaction();
//        transaction.begin();
//        for (int i = 0; i < fileNames.size(); i++) {
//            session.persist(fileNames.get(i));
//            if ((i + 1) % batchSize == 0) {
//                // Flush and clear the cache every batch
//                session.flush();
//                session.clear();
//            }
//        }
//        transaction.commit();
        repository.saveAll(fileNames);
    }

    @Override
    public void delete(FileName fileName) {
        repository.deleteById(fileName.getId());
    }

    @Override
    public List<FileName> getAll() {
        return repository.findAll();
    }

    @Override
    public Map<Integer, List<FileName>> getAllChildren(FileName fileName) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        List<FileName> children = entityManager.createNamedQuery("getAllChildren", FileName.class)
                .setParameter("id", fileName.getId())
                .setParameter("parentLevel", fileName.getLevel())
                .getResultList();
//        session.getTransaction().commit();
//        List<FileName> children = repository.getAllChildren(fileName.getId(), fileName.getLevel());
        Map<Integer, List<FileName>> result = new HashMap<>();
        children.forEach(child -> {
            List<FileName> list = result.computeIfAbsent(child.getLevel(), k -> new ArrayList<>());
            list.add(child);
        });
        return result;
    }

    @Override
    public Map<Integer, FileName> getAllParents(FileName fileName) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
//        List<FileName> parents = session.createNamedQuery("getAllParents", FileName.class).setParameter("id", fileName.getId()).getResultList();
//        session.getTransaction().commit();
        List<FileName> parents = repository.getAllParents(fileName.getId());
        return parents.stream().collect(Collectors.toMap(FileName::getLevel, Function.identity()));
    }

    @Override
    public void add(FileName parentNode, List<FileName> nodes) {
        if (parentNode == null || CollectionUtils.isEmpty(nodes)) {
            return;
        }
        nodes.forEach(n -> n.setLevel(parentNode.getLevel() + 1));
        nodes.forEach(this::save);
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        nodes.forEach(n -> entityManager.createNamedQuery("addChildren")
                .setParameter("parentId", parentNode.getId())
                .setParameter("childId", n.getId())
                .executeUpdate()
        );
//        session.getTransaction().commit();
        nodes.forEach(this::updateLevelByParentId);
    }

    @Override
    public void move(FileName parentNode, FileName subNode) {
        if (parentNode == null || subNode == null) {
            return;
        }
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        entityManager.createNamedQuery("move-deleteParents")
                .setParameter("parentId", parentNode.getId())
                .setParameter("childId", subNode.getId())
                .executeUpdate();
        entityManager.createNamedQuery("move-addChildren")
                .setParameter("parentId", parentNode.getId())
                .setParameter("childId", subNode.getId())
                .executeUpdate();
        entityManager.createNamedQuery("update-level-by-parentId")
                .setParameter("id", parentNode.getId())
                .executeUpdate();
//        session.getTransaction().commit();
    }

    @Override
    public String getPath(FileName fileName) {
        String delimiter = fileName.getDelimiter();
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        TypedQuery typedQuery = entityManager.createNamedQuery("getPath", Object[].class)
                .setParameter("id", fileName.getId())
                .setParameter("delimiter", delimiter);
        String path = (String) typedQuery.getSingleResult();
//        session.getTransaction().commit();
        return path;
    }

    @Override
    public FileName getRoot(FileName fileName) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        TypedQuery<FileName> result = entityManager.createNamedQuery("getRoot", FileName.class).setParameter("id", fileName.getId());
        FileName root = result.getResultList().isEmpty() ? null : result.getSingleResult();
//        session.getTransaction().commit();
        return root;
    }

    @Override
    public List<FileName> getByName(String name) {
        return repository.findByName(name);
    }

    public void updateNestingLevel() {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        entityManager.createNamedQuery("update-nesting-level").executeUpdate();
//        session.getTransaction().commit();
    }

    private void updateLevelByParentId(FileName parent) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
        entityManager.createNamedQuery("update-level-by-parentId").setParameter("id", parent.getId()).executeUpdate();
//        session.getTransaction().commit();
    }
}
