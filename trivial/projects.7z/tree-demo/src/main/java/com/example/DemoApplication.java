package com.example;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    CommandLineRunner runner2() {
        return args -> {
//			Entity1 entity = Entity1.builder().name("Hakan").build();
//			repo1.save(entity);
//
//			Entity2 entity2 = Entity2.builder().name("Taylan").build();
//			repo2.save(entity2);
//
//			Test test = new Test();
//			Annotation[] annotations = test.getClass().getAnnotations();
//			System.out.println("List of annotations at runtime - " + Arrays.toString(annotations));
        };
    }

}
