package com.example.adjacency.list.tree;

import com.example.data.storage.DataStorage;
import com.example.tree.initialization.AdjacencyTreeInitialization;
import com.example.tree.initialization.TreeInitialization;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.List;


public class App {

    private static final Logger LOG = LogManager.getLogger(App.class);

    public static void main(String... args) {
        try {
            NodeDao dao = new NodeDao();
            File file = new File(DataStorage.INIT.getValue());
            TreeInitialization<Node> treeInit = new AdjacencyTreeInitialization(file);
            treeInit.initTree();
            dao.save(treeInit.getTree());
            List<Node> nodes = dao.getAll();
            nodes.forEach(node -> LOG.info(dao.getPath(node)));
        } finally {
            HibernateUtil.close();
        }
    }
}
