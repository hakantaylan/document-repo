package com.example.closure.table.tree;

import jakarta.persistence.*;
import org.hibernate.annotations.DynamicUpdate;

import java.io.Serializable;


@Entity
@Table(name = "tree_path", indexes = {
    @Index(name = "IDX_ANCESTOR", columnList = "ancestor"),
    @Index(name = "IDX_DESCENDANT", columnList = "descendant")})
@DynamicUpdate
@IdClass(TreePathId.class)
public class TreePath implements Serializable {

    @Id
    @ManyToOne(targetEntity = FileName.class)
    @JoinColumn(name = "ancestor", nullable = false, foreignKey = @ForeignKey(name = "FK_ANCESTOR"))
    private FileName ancestor;

    @Id
    @ManyToOne(targetEntity = FileName.class)
    @JoinColumn(name = "descendant", nullable = false, foreignKey = @ForeignKey(name = "FK_DESCENDANT"))
    private FileName descendant;

    public TreePath() {

    }

    public TreePath(FileName ancestor, FileName descendant) {
        this.ancestor = ancestor;
        this.descendant = descendant;
    }

    public FileName getAncestor() {
        return ancestor;
    }

    public void setAncestor(FileName ancestor) {
        this.ancestor = ancestor;
    }

    public FileName getDescendant() {
        return descendant;
    }

    public void setDescendant(FileName descendant) {
        this.descendant = descendant;
    }

    @Override
    public String toString() {
        return "TreePath{" + "ancestor=" + ancestor + ", descendant=" + descendant + '}';
    }
}
