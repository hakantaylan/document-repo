package com.example.path.enumeration.tree;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FilesRepository extends JpaRepository<Files, Long> {

    List<Files> findByName(String name);

    @Query(name = "delete", nativeQuery = true)
    void deleteByPathAndDelimiter(String path, String delimiter);

    @Query(name = "getAllParents")
    List<Object[]> getAllParents(Long id, String delimiter);

//    @Query(name = "getAllChildren", nativeQuery = true)
//    List<Object[]> getAllChildren(String parentPath, String delimiter);
}
