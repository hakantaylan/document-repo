package com.example.nested.sets.tree;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NestedSetsTreeRepository extends JpaRepository<NestedSetsTree, Long> {
    List<NestedSetsTree> findByName(String name);

    @Query(name = "getAllParents")
    List<Object[]> getAllParents(Long id);

    @Query(name = "getAllChildren")
    List<Object[]> getAllChildren(Long id);

}
