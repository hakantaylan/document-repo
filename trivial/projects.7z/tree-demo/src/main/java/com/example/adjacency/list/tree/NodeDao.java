package com.example.adjacency.list.tree;

import com.example.tree.dao.TreeDao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * @author ivan.yuriev
 */
@Component
public class NodeDao implements TreeDao<Node> {

    @Autowired
    private NodeRepository repository;

    @Autowired
    EntityManager entityManager;

    @Override
    public Optional<Node> get(long id) {
        return repository.findById(id);
    }

    @Override
    public void save(Node node) {
        repository.save(node);
    }

    @Override
    public void save(List<Node> nodes) {
//        int batchSize = HibernateUtil.getBatchSize();
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction transaction = session.getTransaction();
//        transaction.begin();
//        for (int i = 0; i < nodes.size(); i++) {
//            session.persist(nodes.get(i));
//            if ((i + 1) % batchSize == 0) {
//                // Flush and clear the cache every batch
//                session.flush();
//                session.clear();
//            }
//        }
//        transaction.commit();
        repository.saveAll(nodes);
    }

    @Override
    public void delete(Node node) {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
//        session.createNamedMutationQuery("delete").setParameter("id", node.getId()).executeUpdate();
//        session.getTransaction().commit();
        repository.delete(node);
    }

    @Override
    public List<Node> getAll() {
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        session.beginTransaction();
//        List<Node> nodes = session.createQuery("from Node", Node.class).list();
//        session.getTransaction().commit();
//        return nodes;
        return repository.findAll();
    }

    @Override
    public Map<Integer, List<Node>> getAllChildren(Node node) {

        List<Object[]> children = entityManager.createNamedQuery("getAllChildren", Object[].class).setParameter("id", node.getId()).getResultList();
        Map<Integer, List<Node>> result = new HashMap<>();
        children.forEach(rec -> {
            Node child = (Node) rec[0];
            Integer level = (Integer) rec[1];
            List<Node> list = result.computeIfAbsent(level, k -> new ArrayList<>());
            list.add(child);
        });
        return result;
    }

    @Override
    public Map<Integer, Node> getAllParents(Node node) {
        List<Object[]> parents = entityManager.createNamedQuery("getAllParents", Object[].class).setParameter("id", node.getId()).getResultList();
        Map<Integer, Node> result = new HashMap<>();
        parents.forEach(rec -> {
            Node parent = (Node) rec[0];
            Integer level = (Integer) rec[1];
            result.put(level, parent);
        });
        return result;
    }

    @Override
    public String getPath(Node node) {
        if (node.getParent() == null) {
            return node.getName();
        }
        String delimiter = node.getDelimiter();
        TypedQuery typedQuery = entityManager.createNamedQuery("getPath", Object[].class)
                .setParameter("id", node.getId())
                .setParameter("delimiter", delimiter);
        String path = (String) typedQuery.getSingleResult();
        return path;
    }

    @Override
    public void add(Node parentNode, List<Node> nodes) {
        if (parentNode == null || CollectionUtils.isEmpty(nodes)) {
            return;
        }
        nodes.forEach(n -> n.setParent(parentNode));
        nodes.forEach(repository::save);
    }

    @Override
    public void move(Node parentNode, Node subNode) {
        add(parentNode, Collections.singletonList(subNode));
    }

    @Override
    public Node getRoot(Node node) {
        if (node.getParent() == null) {
            return node;
        }
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        TypedQuery<Node> typedQuery = entityManager.createNamedQuery("getRoot", Node.class).setParameter("id", node.getId());
        Node root = typedQuery.getSingleResult();
        session.getTransaction().commit();
        return root;
    }

    @Override
    public List<Node> getByName(String name) {
        return repository.findByName(name);
    }
}
