package com.example.path.enumeration.tree;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;

import java.io.Serializable;


@Entity
@Table(name = "files", indexes = @Index(name = "IDX_PATH", columnList = "path"))
@DynamicUpdate
@Getter
@Setter
@NoArgsConstructor
public class Files implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull
    @Column(length = 1000)
    private String path;
    @NotNull
    private String name;

    public Files(String path, String name) {
        this.path = path;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Files{" + "id=" + id + ", path=" + path + ", name=" + name + '}';
    }

}
