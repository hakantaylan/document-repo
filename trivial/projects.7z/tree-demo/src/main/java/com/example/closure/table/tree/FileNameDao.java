package com.example.closure.table.tree;

import com.example.tree.dao.TreeDao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class FileNameDao implements TreeDao<FileName> {

    @Autowired
    FileNameRepository repository;

    @Autowired
    EntityManager entityManager;

    @Override
    public Optional<FileName> get(long id) {
        return repository.findById(id);
    }

    @Override
    public void save(FileName fileName) {
        repository.save(fileName);
    }

    @Override
    public void save(List<FileName> fileNames) {
//        int batchSize = HibernateUtil.getBatchSize();
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction transaction = session.getTransaction();
//        transaction.begin();
//        for (int i = 0; i < fileNames.size(); i++) {
//            session.persist(fileNames.get(i));
//            if ((i + 1) % batchSize == 0) {
//                // Flush and clear the cache every batch
//                session.flush();
//                session.clear();
//            }
//        }
//        transaction.commit();
        repository.saveAll(fileNames);
    }

    @Override
    public void delete(FileName fileName) {
        repository.deleteById(fileName.getId());
    }

    @Override
    public List<FileName> getAll() {
        return repository.findAll();
    }

    @Override
    public Map<Integer, List<FileName>> getAllChildren(FileName fileName) {

        List<Object[]> children = entityManager.createNamedQuery("getAllChildren", Object[].class).setParameter("id", fileName.getId()).getResultList();
        Map<Integer, List<FileName>> result = new HashMap<>();
        children.forEach(rec -> {
            FileName child = (FileName) rec[0];
            Integer level = (Integer) rec[1];
            List<FileName> list = result.computeIfAbsent(level, k -> new ArrayList<>());
            list.add(child);
        });
        return result;
    }

    @Override
    public Map<Integer, FileName> getAllParents(FileName fileName) {
        List<Object[]> parents = repository.getAllParents(fileName.getId());
//        List<Object[]> parents = entityManager.createNamedQuery("getAllParents", Object[].class).setParameter("id", fileName.getId()).getResultList();
        Map<Integer, FileName> result = new HashMap<>();
        parents.forEach(rec -> {
            FileName parent = (FileName) rec[0];
            Integer level = (Integer) rec[1];
            result.put(level, parent);
        });
        return result;
    }

    @Override
    public void add(FileName parentNode, List<FileName> nodes) {
        if (parentNode == null || CollectionUtils.isEmpty(nodes)) {
            return;
        }
        nodes.forEach(this::save);

        nodes.forEach(n -> entityManager.createNamedQuery("addChildren")
                .setParameter("parentId", parentNode.getId())
                .setParameter("childId", n.getId())
                .executeUpdate()
        );
    }

    @Override
    public void move(FileName parentNode, FileName subNode) {
        if (parentNode == null || subNode == null) {
            return;
        }

        entityManager.createNamedQuery("move-deleteParents")
                .setParameter("parentId", parentNode.getId())
                .setParameter("childId", subNode.getId())
                .executeUpdate();
        entityManager.createNamedQuery("move-addChildren")
                .setParameter("parentId", parentNode.getId())
                .setParameter("childId", subNode.getId())
                .executeUpdate();
    }

    @Override
    public String getPath(FileName fileName) {
        String delimiter = fileName.getDelimiter();
        TypedQuery query = entityManager.createNamedQuery("getPath", Object[].class);
        query
                .setParameter("id", fileName.getId())
                .setParameter("delimiter", delimiter);
        String path = (String) query.getSingleResult();
        return path;
    }

    @Override
    public FileName getRoot(FileName fileName) {
        TypedQuery<FileName> result = entityManager.createNamedQuery("getRoot", FileName.class).setParameter("id", fileName.getId());
        FileName root = result.getResultList().isEmpty() ? null : result.getSingleResult();
        return root;
    }

    @Override
    public List<FileName> getByName(String name) {
        return repository.findByName(name);
    }
}
