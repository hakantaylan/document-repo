package com.example.improved.closure.table.tree;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "file_name2")
@DynamicUpdate
@Getter
@Setter
@NoArgsConstructor
public class FileName implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull
    private String name;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "descendant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<TreePath> parents = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "ancestor")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<TreePath> children = new ArrayList<>();

    private int level;

    @Transient
    private String delimiter = "\\";

    public FileName(String name, int level) {
        this.name = name;
        this.level = level;
    }


    public void addParent(TreePath p) {
        parents.add(p);
    }

    public void addChild(TreePath ch) {
        children.add(ch);
    }

    public void addParents(List<TreePath> p) {
        parents.addAll(p);
    }

    public void addChildren(List<TreePath> ch) {
        children.addAll(ch);
    }


    @Override
    public String toString() {
        return "FileName{" + "id=" + id + ", name=" + name + ", level=" + level + '}';
    }
}