package com.example.improved.nested.sets.tree;


import com.example.data.storage.DataStorage;
import com.example.tree.initialization.TreeInitialization;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.File;
import java.util.List;

@SpringBootApplication
@Slf4j
public class App2 {

    public static void main(String[] args) {
        SpringApplication.run(App2.class, args);
    }

    @Bean
    CommandLineRunner runner2(NestedSetsDao dao) {
        return args -> {
            File file = new File(DataStorage.INIT.getValue());
            TreeInitialization<NestedSetsTree> treeInit = new NestedSetsInitialization(file);
            treeInit.initTree();
            dao.save(treeInit.getTree());
            List<NestedSetsTree> nodes = dao.getAll();
            nodes.forEach(node -> log.info(dao.getPath(node)));
        };
    }

}
