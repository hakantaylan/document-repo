# PoiSamples
Experiments with Apache POI and study Office Open XML File Formats ISO/IEC 29500-1
