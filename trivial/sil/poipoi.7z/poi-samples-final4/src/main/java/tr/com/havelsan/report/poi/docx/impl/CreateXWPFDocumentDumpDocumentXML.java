package tr.com.havelsan.report.poi.docx.impl;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.*;

public class CreateXWPFDocumentDumpDocumentXML {

    static void printDocumentXML(XWPFDocument docx) throws Exception {

        String xml;

        System.out.println("Contents of org.openxmlformats.schemas.wordprocessingml.x2006.main.CTDocument1:");
        org.apache.xmlbeans.XmlObject documentXmlObject = docx.getDocument();
        xml = documentXmlObject.toString();
        System.out.println(xml);

        System.out.println("Contents of whole DocumentDocument:");
        org.openxmlformats.schemas.wordprocessingml.x2006.main.CTDocument1 ctDocument1 = docx.getDocument();
        org.openxmlformats.schemas.wordprocessingml.x2006.main.DocumentDocument documentDocument = org.openxmlformats.schemas.wordprocessingml.x2006.main.DocumentDocument.Factory.newInstance();
        documentDocument.setDocument(ctDocument1);
        xml = documentDocument.toString();
        System.out.println(xml);

    }

    public static void main(String[] args) throws Exception {

//        XWPFDocument docx = new XWPFDocument(new FileOutputStream(".test3.docx"));
//        XWPFParagraph paragraph = docx.createParagraph();
//        XWPFRun run=paragraph.createRun();
//        run.setBold(true);
//        run.setFontSize(22);
//        run.setText("The paragraph content ...");
//        paragraph = docx.createParagraph();
//
//        printDocumentXML(docx);

        try (FileInputStream in = new FileInputStream("test3.docx")) {
            XWPFDocument docx = new XWPFDocument(in);
            printDocumentXML(docx);
        }


    }
}