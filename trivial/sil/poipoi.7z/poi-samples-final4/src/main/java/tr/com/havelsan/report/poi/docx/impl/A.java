package tr.com.havelsan.report.poi.docx.impl;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFPicture;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.xmlbeans.XmlCursor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTP;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPicture;

import java.io.FileOutputStream;
import java.util.List;

public class A {

    public static void main(String[] args) throws Exception {
        A a = new A();
        a.copyParagraph();
    }

    public void copyParagraph() throws Exception {
        XWPFDocument document = new XWPFDocument(OPCPackage.open("test3.docx"));
        List<XWPFParagraph> paragraphs = document.getParagraphs();
        int currentParagraphIndex = 1;
        XWPFParagraph paragraph = document.getParagraphArray(1);
//        paragraph.setPageBreak(true);
//        for (XWPFParagraph paragraph : paragraphs) {
        for(int i = 1; i< 5; i++) {
            XmlCursor cursor = paragraph.getCTP().newCursor();
            //inserts a blank paragraph before the original one
        XWPFParagraph xwpfParagraph = paragraph.getDocument().insertNewParagraph(cursor);
        int idx = document.getParagraphs().indexOf(xwpfParagraph);
//        document.setParagraph(paragraph, 1);
//        document.setParagraph(xwpfParagraph, 2);
        //make a fully parsed copy of the old paragraph
            XWPFParagraph newParagraph = new XWPFParagraph((CTP) paragraph.getCTP().copy(), document);
            //update the document with our now paragraph replacing the blank one with our new one and cause the document to reparse it.
            //Not sure why, but any modification to the new paragraph must be performed prior to setting it.
            document.setParagraph(newParagraph, i);
            currentParagraphIndex++;
        }
        document.write(new FileOutputStream("dddd.docx"));
    }
}
