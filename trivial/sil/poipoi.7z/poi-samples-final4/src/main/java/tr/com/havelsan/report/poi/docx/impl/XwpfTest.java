package tr.com.havelsan.report.poi.docx.impl;

//import org.apache.poi.ooxml.POIXMLProperties;
import org.apache.poi.ooxml.POIXMLDocumentPart;
import org.apache.poi.ooxml.POIXMLProperties;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.*;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlToken;
import org.openxmlformats.schemas.drawingml.x2006.main.CTNonVisualDrawingProps;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPositiveSize2D;
import org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTInline;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;
import java.io.*;
import java.math.BigInteger;
import java.util.*;
/**
 * Created By: hdx
 * Date: 2020-04-09 09:13
 */
public class XwpfTest {
    protected static List<XWPFPictureData> pictures = new ArrayList<XWPFPictureData>();
    /**
     * Access the contents of XWPFDocument through XWPFWordExtractor
     * @throws Exception
     */
    public static void main(String[] args) throws Exception{
//testReadByExtractor();
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("${apple}", "College 1");
        param.put("${data}", "2020-04-09");
        param.put("${banana}", "Professional 1");
        Map<String, Object> header = new HashMap<String, Object>();
        header.put("width", 100);
        header.put("height", 50);
        header.put("type", "png");
        header.put("content", "D:\\silll\\poi-samples-final4\\g.png");
        param.put("${aaa}", header);
        XWPFDocument doc = testReadByDoc2(param);
        FileOutputStream fopts = new FileOutputStream("2.docx");
        doc.write(fopts);
        fopts.close();
testReadByDoc();
testSimpleWrite();
testWriteTable();
    }
    public static XWPFDocument testReadByDoc2(Map<String, Object> param) throws Exception {
        InputStream is = new FileInputStream("test.docx");
        XWPFDocument doc = new XWPFDocument(is);
        try {
            if (param != null && param.size() > 0) {
//Processing paragraphs
                List<XWPFParagraph> paragraphList = doc.getParagraphs();
                processParagraphs(paragraphList, param, doc);
//Process the table
                Iterator<XWPFTable> it = doc.getTablesIterator();
                while (it.hasNext()) {
                    XWPFTable table = it.next();
                    List<XWPFTableRow> rows = table.getRows();
                    for (XWPFTableRow row : rows) {
                        List<XWPFTableCell> cells = row.getTableCells();
                        for (XWPFTableCell cell : cells) {
                            List<XWPFParagraph> paragraphListTable = cell.getParagraphs();
                            processParagraphs(paragraphListTable, param, doc);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return doc;
    }
    /**
     * Processing paragraphs
     * @param paragraphList
     * @throws FileNotFoundException
     * @throws InvalidFormatException
     */
    public static void processParagraphs(List<XWPFParagraph> paragraphList,Map<String, Object> param,XWPFDocument doc) throws Exception{
        if(paragraphList != null && paragraphList.size() > 0){
            for(XWPFParagraph paragraph:paragraphList){
                List<XWPFRun> runs = paragraph.getRuns();
                for (XWPFRun run : runs) {
                    String text = run.getText(0);
                    System.out.println("text=="+text);
                    if(text != null){
                        boolean isSetText = false;
                        for (Map.Entry<String, Object> entry : param.entrySet()) {
                            String key = entry.getKey();
                            if(text.indexOf(key) != -1){
                                isSetText = true;
                                Object value = entry.getValue();
                                if (value instanceof String) {//text replacement
                                    System.out.println("key=="+key);
                                    text = text.replace(key, value.toString());
                                } else if (value instanceof Map) { //Image replacement
                                    text = text.replace(key, "");
                                    Map pic = (Map)value;
                                    int width = Integer.parseInt(pic.get("width").toString());
                                    int height = Integer.parseInt(pic.get("height").toString());
                                    int picType = getPictureType(pic.get("type").toString());
                                    String byteArray = (String) pic.get("content");
                                    System.out.println("=="+byteArray);
//ByteArrayInputStream byteInputStream = new ByteArrayInputStream(byteArray);
//int ind = doc.getAllPictures().size() - 1;
//doc.createPicture(ind, width, height,paragraph, doc);
                                    CTInline inline = run.getCTR().addNewDrawing().addNewInline();
                                    insertPicture(doc,byteArray,inline, width, height);
                                }
                            }
                        }
                        if(isSetText){
                            run.setText(text,0);
                        }
                    }
                }
            }
        }
    }
    /**
     * insert Picture
     * @param document
     * @param filePath
     * @param inline
     * @param width
     * @param height
     * @throws InvalidFormatException
     * @throws FileNotFoundException
     */
    private static void insertPicture(XWPFDocument document, String filePath,
                                      CTInline inline, int width,
                                      int height) throws InvalidFormatException,
            FileNotFoundException {
        document.addPictureData(new FileInputStream(filePath),XWPFDocument.PICTURE_TYPE_PNG);
        int id = document.getAllPictures().size() - 1;
        final int EMU = 9525;
        width *= EMU;
        height *= EMU;
//        String blipId = document.getAllPictures().get(id).getPackageRelationship().getId();
        String blipId = "";
        XWPFPictureData pictureData = document.getAllPictures().get(id);
        List<POIXMLDocumentPart.RelationPart> relationParts = document.getRelationParts();
        for (POIXMLDocumentPart.RelationPart relPart : relationParts) {
            if(relPart.getDocumentPart().equals(pictureData)) {
                blipId = relPart.getRelationship().getId();
                break;
            };
        }

        String picXml = getPicXml(blipId, width, height);
        XmlToken xmlToken = null;
        try {
            xmlToken = XmlToken.Factory.parse(picXml);
        } catch (XmlException xe) {
            xe.printStackTrace();
        }
        inline.set(xmlToken);
        inline.setDistT(0);
        inline.setDistB(0);
        inline.setDistL(0);
        inline.setDistR(0);
        CTPositiveSize2D extent = inline.addNewExtent();
        extent.setCx(width);
        extent.setCy(height);
        CTNonVisualDrawingProps docPr = inline.addNewDocPr();
        docPr.setId(id);
        docPr.setName("IMG_" + id);
        docPr.setDescr("IMG_" + id);
    }
    /**
     * get the xml of the picture
     * @param blipId
     * @param width
     * @param height
     * @return
     */
    private static String getPicXml(String blipId, int width, int height) {
        String picXml =
                "" + "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">" +
                        " <a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                        " <pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                        " <pic:nvPicPr>" + " <pic:cNvPr id=\"" + 0 +
                        "\" name=\"Generated\"/>" + " <pic:cNvPicPr/>" +
                        " </pic:nvPicPr>" + " <pic:blipFill>" +
                        " <a:blip r:embed=\"" + blipId +
                        "\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"/>" +
                        " <a:stretch>" + " <a:fillRect/>" +
                        " </a:stretch>" + " </pic:blipFill>" +
                        " <pic:spPr>" + " <a:xfrm>" +
                        " <a:off x=\"0\" y=\"0\"/>" +
                        " <a:ext cx=\"" + width + "\" cy=\"" + height +
                        "\"/>" + " </a:xfrm>" +
                        " <a:prstGeom prst=\"rect\">" +
                        " <a:avLst/>" + " </a:prstGeom>" +
                        " </pic:spPr>" + " </pic:pic>" +
                        " </a:graphicData>" + "</a:graphic>";
        return picXml;
    }
    public static List<XWPFPictureData> getAllPictures() {
        return Collections.unmodifiableList(pictures);
    }
    /**
     * @param id
     * @param width width
     * @param height
     * @param paragraph paragraph
     */
    public static void createPicture(int id, int width, int height,XWPFParagraph paragraph, XWPFDocument doc) {
        final int EMU = 9525;
        width *= EMU;
        height *= EMU;
//        String blipId = getAllPictures().get(id).getPackageRelationship().getId();
        String blipId = "";
        XWPFPictureData pictureData = getAllPictures().get(id);
        List<POIXMLDocumentPart.RelationPart> relationParts = doc.getRelationParts();
        for (POIXMLDocumentPart.RelationPart relPart : relationParts) {
            if(relPart.getDocumentPart().equals(pictureData)) {
                blipId = relPart.getRelationship().getId();
                break;
            };
        }
        CTInline inline = paragraph.createRun().getCTR().addNewDrawing().addNewInline();
        System.out.println(blipId+":"+inline);
        String picXml = ""
                + "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">"
                + " <a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">"
                + " <pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">"
                + " <pic:nvPicPr>" + " <pic:cNvPr id=\""
                + id
                + "\" name=\"Generated\"/>"
                + " <pic:cNvPicPr/>"
                + " </pic:nvPicPr>"
                + " <pic:blipFill>"
                + " <a:blip r:embed=\""
                + blipId
                + "\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"/>"
                + " <a:stretch>"
                + " <a:fillRect/>"
                + " </a:stretch>"
                + " </pic:blipFill>"
                + " <pic:spPr>"
                + " <a:xfrm>"
                + " <a:off x=\"0\" y=\"0\"/>"
                + " <a:ext cx=\""
                + width
                + "\" cy=\""
                + height
                + "\"/>"
                + " </a:xfrm>"
                + " <a:prstGeom prst=\"rect\">"
                + " <a:avLst/>"
                + " </a:prstGeom>"
                + " </pic:spPr>"
                + " </pic:pic>"
                + " </a:graphicData>" + "</a:graphic>";
        inline.addNewGraphic().addNewGraphicData();
        XmlToken xmlToken = null;
        try {
            xmlToken = XmlToken.Factory.parse(picXml);
        } catch (XmlException xe) {
            xe.printStackTrace();
        }
        inline.set(xmlToken);
        inline.setDistT(0);
        inline.setDistB(0);
        inline.setDistL(0);
        inline.setDistR(0);
        CTPositiveSize2D extent = inline.addNewExtent();
        extent.setCx(width);
        extent.setCy(height);
        CTNonVisualDrawingProps docPr = inline.addNewDocPr();
        docPr.setId(id);
        docPr.setName("picture" + id);
        docPr.setDescr("test");
    }
    /**
     * According to the image type, get the corresponding image type code
     * @param picType
     * @return int
     */
    private static int getPictureType(String picType){
        int res = XWPFDocument.PICTURE_TYPE_PICT;
        if(picType != null){
            if(picType.equalsIgnoreCase("png")){
                res = XWPFDocument.PICTURE_TYPE_PNG;
            }else if(picType.equalsIgnoreCase("dib")){
                res = XWPFDocument.PICTURE_TYPE_DIB;
            }else if(picType.equalsIgnoreCase("emf")){
                res = XWPFDocument.PICTURE_TYPE_EMF;
            }else if(picType.equalsIgnoreCase("jpg") || picType.equalsIgnoreCase("jpeg")){
                res = XWPFDocument.PICTURE_TYPE_JPEG;
            }else if(picType.equalsIgnoreCase("wmf")){
                res = XWPFDocument.PICTURE_TYPE_WMF;
            }
        }
        return res;
    }
    /**
     * Match the incoming information set with the template
     * @param value The area of the template that needs to be replaced
     * @param textMap incoming information collection
     * @return The template needs to replace the corresponding value of the regional information set
     */
    public static Object changeValue(String value, Map<String, Object> textMap){
        Set<Map.Entry<String, Object>> textSets = textMap.entrySet();
        Object valu = "";
        for (Map.Entry<String, Object> textSet : textSets) {
//Match template and replacement value format ${key}
            String key = textSet.getKey();
            if (value.indexOf(key)!= -1){
                valu = textSet.getValue();
            }
        }
        return valu;
    }
    /**
     * Check if the text contains $
     * @param text text
     * @return includes return true, does not include return false
     */
    public static boolean checkText(String text){
        boolean check = false;
        if(text.indexOf("$")!= -1){
            check = true;
        }
        return check;
    }
    // Read the file
    public static void testReadByExtractor() throws Exception {
        InputStream is = new FileInputStream("test.docx");
        XWPFDocument doc = new XWPFDocument(is);
        XWPFWordExtractor extractor = new XWPFWordExtractor(doc);
        String text = extractor.getText();
        System.out.println(text);
        POIXMLProperties.CoreProperties coreProps = extractor.getCoreProperties();
        printCoreProperties1(coreProps);
        close1(is);
    }
    /**
     * Output CoreProperties information
     * @param coreProps
     */
    private static void printCoreProperties1(POIXMLProperties.CoreProperties coreProps) {
        System.out.println(coreProps.getCategory()); //Category
        System.out.println(coreProps.getCreator()); //Creator
        System.out.println(coreProps.getCreated()); //Creation time
        System.out.println(coreProps.getTitle()); //Title
    }
    /**
     * Close the input stream
     * @param is
     */
    private static void close1(InputStream is) {
        if (is != null) {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * Access the content through XWPFDocument. For XWPF documents, this is the best way to read.
     * @throws Exception
     */
    public static void testReadByDoc() throws Exception {
        InputStream is = new FileInputStream("test.docx");
        XWPFDocument doc = new XWPFDocument(is);
        List<XWPFParagraph> paras = doc.getParagraphs();
        for (XWPFParagraph para : paras) {
// Properties of the current paragraph
// CTPPr pr = para.getCTP().getPPr();
            System.out.println(para.getText());
        }
//Get all the tables in the document
        List<XWPFTable> tables = doc.getTables();
        List<XWPFTableRow> rows;
        List<XWPFTableCell> cells;
        for (XWPFTable table : tables) {
//Table properties
// CTTblPr pr = table.getCTTbl().getTblPr();
//Get the corresponding row of the table
            rows = table.getRows();
            for (XWPFTableRow row : rows) {
//Get the cell corresponding to the row
                cells = row.getTableCells();
                for (XWPFTableCell cell : cells) {
                    System.out.println(cell.getText());
                }
            }
        }
        close1(is);
    }
    /**
     * Basic write operations
     * @throws Exception
     */
    public static void testSimpleWrite() throws Exception {
//Create a new document
        XWPFDocument doc = new XWPFDocument();
//Create a paragraph
        XWPFParagraph para = doc.createParagraph();
//An XWPFRun represents an area with the same properties.
        XWPFRun run = para.createRun();
        run.setBold(true); // bold
        run.setText("bold content");
        run = para.createRun();
        run.setColor("FF0000");
        run.setText("Red words.");
        OutputStream os = new FileOutputStream("simpleWrite.docx");
// Output doc to the output stream
        doc.write(os);
        close(os);
    }
    /***
     * Write a table
     * @throws Exception
     */
    public static void testWriteTable() throws Exception {
        XWPFDocument doc = new XWPFDocument();
//Create a table with 5 rows and 5 columns
        XWPFTable table = doc.createTable(5, 5);
//The 5 rows originally created by the added columns here cannot be obtained when using the getTableCells() method, but can be obtained rows.
// table.addNewCol(); //Add a column to the table, making it 6 columns
        table.createRow(); //Add a new row to the table, making it 6 rows
        List<XWPFTableRow> rows = table.getRows();
//Table properties
        CTTblPr tablePr = table.getCTTbl().addNewTblPr();
//Table width
        CTTblWidth width = tablePr.addNewTblW();
        width.setW(BigInteger.valueOf(8000));
        XWPFTableRow row;
        List<XWPFTableCell> cells;
        XWPFTableCell cell;
        int rowSize = rows.size();
        int cellSize;
        for (int i=0; i<rowSize; i++) {
            row = rows.get(i);
//Add new cell
            row.addNewTableCell();
//Set the row height
            row.setHeight(500);
// Row attributes
// CTTrPr rowPr = row.getCtRow().addNewTrPr();
//This method can get the newly added cell.
// List<CTTc> list = row.getCtRow().getTcList();
            cells = row.getTableCells();
            cellSize = cells.size();
            for (int j=0; j<cellSize; j++) {
                cell = cells.get(j);
                if ((i+j)%2==0) {
//Set the color of the cell
                    cell.setColor("ff0000"); //red
                } else {
                    cell.setColor("0000ff"); //blue
                }
//Cell properties
                CTTcPr cellPr = cell.getCTTc().addNewTcPr();
                cellPr.addNewVAlign().setVal(STVerticalJc.CENTER);
                if (j == 3) {
//Set the width
                    cellPr.addNewTcW().setW(BigInteger.valueOf(3000));
                }
                cell.setText(i + ", " + j);
            }
        }
//If the file does not exist, it will be created automatically
        OutputStream os = new FileOutputStream("table.docx");
//Write to file
        doc.write(os);
        close(os);
    }
    /**
     * Close the output stream
     pom.xml:
     * @param os
     */
    private static void close(OutputStream os) {
        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}