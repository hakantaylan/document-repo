package tr.com.havelsan.report.poi.docx;

import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Test;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class SDPOIDocxViewTest2 {

	@Test
	public void printDoc() throws Exception {
		POIDocxView
				.openTemplate("docx/template.docx")
				.headers()
					.withIdentifier("TASNİF DIŞI")
					.delete()
//					.replace("TASNİF DIŞI", "TOP SECRET")
//					.delete()
					.create("TOP SECRET")
				.and()
					.footers()
				.clearAll()
				.create("FOOTER TOP SECRET")
					.insertPageNumber()
				.and()
				.replaceRuns(Map.of("${Hello}", "bbb", "${world}", "zzz"))
				.fillTable(0, List.of(List.of("aaaaaa", "bbb"), List.of("cccccc", "ddddd")))
				.replaceInTable(1, Map.of("${Table cell}", "TTT", "${together2}", "aaa"))
				.deleteTable(1)
				.and()
				.imageByIdentifier("ddd").delete()
				.and()
				.writeAndClose("hkhkhk.docx");
		InputStream fis = POIDocxView.class
				.getClassLoader()
				.getResourceAsStream("docx/template-emre.docx");
		XWPFDocument doc = new XWPFDocument(OPCPackage.open(fis));
		OutputStream out = new FileOutputStream("emre-doc.pdf");
		PdfOptions options = PdfOptions.create();
		PdfConverter.getInstance().convert(doc, out, null);
		out.close();
	}


//	@Test
//	public void replaceParagraphTest() throws Exception {
//
//		XWPFDocument document = new XWPFDocument(new FileInputStream("result.docx"));
//
//		Assertions.assertTrue(POIDocxView.hasText(document, "Lorem"));
//		Assertions.assertTrue(POIDocxView.hasText(document, "Inside table"));
//		Assertions.assertTrue(POIDocxView.hasText(document, "ipsum"));
//		Assertions.assertTrue(POIDocxView.hasText(document, "ipsum"));
//		Assertions.assertFalse(POIDocxView.hasText(document, "world"));
//		Assertions.assertTrue(POIDocxView.hasText(document, "replaced2"));
//
//		document.close();
//	}

	@Test
	public void uniCodeTest(){
		String s = "Hi, 你好, おはよう, α-Ω\uD834\uDD1E"; // last real character is "𝄞", that takes 2 code unit,
		assertEquals(s.length(), s.toCharArray().length); // length() is based on char (aka code unit), not code point,

		System.out.printf("input string:\t\"%s\"%n%n", s);

		System.out.println("------ as code point (aka. real character) ------");
		// code point,
		s.codePoints().forEach(cp -> System.out.println(Character.toChars(cp)));
		assertEquals(s.codePoints().count(), s.length() - 1); // last read character takes 2 unit code,
		assertEquals(s.codePoints().count(), s.codePointCount(0, s.length())); // there is a method codePointCount() on String to get code point count on given char range,

		System.out.println("\n------ as char (aka. code unit) ------");
		// chars (aka. code unit),
		s.chars().forEach(c -> System.out.println(Character.toChars(c)));
		assertEquals(s.chars().count(), s.length()); // string length is the count of code unit, not code point,

		System.out.println("ARcZguv".hashCode());
		System.out.println("rounibuf".hashCode());
		System.out.println("pollinating sandboxes".hashCode());
	}
}