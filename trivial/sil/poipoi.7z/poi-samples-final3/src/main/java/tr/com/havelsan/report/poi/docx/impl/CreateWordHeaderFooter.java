package tr.com.havelsan.report.poi.docx.impl;

import java.awt.*;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.util.Units;

import org.apache.poi.xwpf.usermodel.*;

import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;

import org.openxmlformats.schemas.drawingml.x2006.main.CTLineProperties;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSectPr;

import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTabStop;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTabJc;

import java.math.BigInteger;

public class CreateWordHeaderFooter {

    public static void main(String[] args) throws Exception {

        XWPFDocument doc= new XWPFDocument();

        // the body content
        XWPFParagraph paragraph = doc.createParagraph();
        XWPFRun run=paragraph.createRun();
        run.setText("The Body:");

        paragraph = doc.createParagraph();
        run=paragraph.createRun();
        run.setText("Lorem ipsum....");

        // create header start
        CTSectPr sectPr = doc.getDocument().getBody().addNewSectPr();
        XWPFHeaderFooterPolicy headerFooterPolicy = new XWPFHeaderFooterPolicy(doc, sectPr);

        XWPFHeader header = headerFooterPolicy.createHeader(XWPFHeaderFooterPolicy.DEFAULT);

        paragraph = header.createParagraph();
        paragraph.setAlignment(ParagraphAlignment.LEFT);

        CTTabStop tabStop = paragraph.getCTP().getPPr().addNewTabs().addNewTab();
        tabStop.setVal(STTabJc.RIGHT);
        int twipsPerInch =  1440;
        tabStop.setPos(BigInteger.valueOf(6 * twipsPerInch));

        run = paragraph.createRun();
        run.setText("The Header:");
//        run.addBreak();
        run.addTab();

        run = paragraph.createRun();
//        run.setText("a");
//        run.addBreak();
        String imgFile="samplePict.jpg";
//        XWPFPicture picture = run.addPicture(new FileInputStream(imgFile), XWPFDocument.PICTURE_TYPE_PNG, imgFile, Units.toEMU(50), Units.toEMU(50));
//        String embedId = doc.addPictureData(new FileInputStream(imgFile), XWPFDocument.PICTURE_TYPE_JPEG);
        XWPFPicture picture = run.addPicture(new FileInputStream(imgFile), XWPFDocument.PICTURE_TYPE_PNG, imgFile, 630936, 630936);
//        run.getCTR().getDrawingArray(0).getInlineArray(0).addNewCNvGraphicFramePr().addNewGraphicFrameLocks().setNoChangeAspect(true);
//        System.out.println(picture.getCTPicture());
        long a = Units.toEMU(50) - Units.toEMU(2.25);
//
        picture.getCTPicture().getSpPr().addNewLn().setW(Units.toEMU(2.25));
        String embed = picture.getCTPicture().getBlipFill().getBlip().getEmbed();
        CTLineProperties ln = picture.getCTPicture().getSpPr().getLn();
        ln.addNewSolidFill().addNewSrgbClr().setVal(new byte[]{(byte)255,0,0});
        System.out.println(picture.getCTPicture());
//
        // create footer start
        XWPFFooter footer = headerFooterPolicy.createFooter(XWPFHeaderFooterPolicy.DEFAULT);

        paragraph = footer.createParagraph();
        paragraph.setAlignment(ParagraphAlignment.CENTER);

        run = paragraph.createRun();
        run.setText("The Footer:");


        doc.write(new FileOutputStream("test.docx"));

    }
}