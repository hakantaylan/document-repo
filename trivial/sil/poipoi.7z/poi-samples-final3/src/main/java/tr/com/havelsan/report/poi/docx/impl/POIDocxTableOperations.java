package tr.com.havelsan.report.poi.docx.impl;

import tr.com.havelsan.report.poi.docx.IPOIDocxTableOperations;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRow;

import java.util.List;
import java.util.Map;

import static tr.com.havelsan.report.poi.docx.impl.POIDocxCommons.replaceTextSegment;

public class POIDocxTableOperations implements IPOIDocxTableOperations {

    private final POIDocxView docView;
    private final XWPFDocument document;

    protected POIDocxTableOperations(POIDocxView docView, XWPFDocument document) {
        this.docView = docView;
        this.document = document;
    }

    @Override
    public IPOIDocxTableOperations fillTable(int tblIdx, List<List<String>> tableData) {
        XWPFTable table = document.getTableArray(tblIdx);
        int templateRowId = 1;
        XWPFTableRow rowTemplate = table.getRow(templateRowId);
        for(int row = 0; row < tableData.size(); row++) {
            List<String> rowDataList = tableData.get(row);
            CTRow ctrow = getCtRow(rowTemplate);
            XWPFTableRow newRow = new XWPFTableRow(ctrow, table);
            for(int i = 0; i < rowDataList.size(); i++) {
                List<XWPFRun> runs = newRow.getCell(i).getParagraphArray(0).getRuns();
                XWPFRun run = null;
                if(runs.isEmpty())
                    run = newRow.getCell(i).getParagraphArray(0).createRun();
                else
                    run = runs.get(0);
                run.setText(rowDataList.get(i) == null ? "": rowDataList.get(i));
            }
            table.addRow(newRow);
        }
        table.removeRow(templateRowId);
//        tableData.forEach((Integer row, List<String> lst) -> {
//            CTRow ctrow = getCtRow(rowTemplate);
//
//            XWPFTableRow newRow = new XWPFTableRow(ctrow, table);
//            for (int i = 0; i < lst.size(); i++) {
//                newRow.getCell(i).getParagraphArray(0).getRuns().get(0).setText(lst.get(i), 0);
//            }
//            table.addRow(newRow);
//        });

        return this;
    }

    private CTRow getCtRow(XWPFTableRow rowTemplate) {
        try {
            return CTRow.Factory.parse(rowTemplate.getCtRow().newInputStream());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public POIDocxView and() {
        return docView;
    }

    @Override
    public POIDocxTableOperations deleteTable(int tblIdx) {
        XWPFTable table = document.getTableArray(tblIdx);
        int index = document.getBodyElements().indexOf(table);
        document.removeBodyElement(index);
        return this;
    }

    @Override
    public POIDocxTableOperations replaceInTable(int tblIdx, Map<String, String> tableData) {
        XWPFTable table = document.getTableArray(tblIdx);
        tableData.forEach((String key, String value) -> {
            replaceTable(table, key, value);
        });
        return this;
    }

    private void replaceTable(XWPFTable table, String placeHolder, String replaceText) {
        auterlooplabel:
        for (XWPFTableRow row : table.getRows()) {
            for (XWPFTableCell cell : row.getTableCells()) {
                for (IBodyElement bodyElement : cell.getBodyElements()) {
                    if (bodyElement.getElementType().equals(BodyElementType.PARAGRAPH)) {
                        boolean isReplacementMade = replaceTextSegment((XWPFParagraph) bodyElement, placeHolder, replaceText);
                        if(isReplacementMade)
                            break auterlooplabel;
                    }
                    if (bodyElement.getElementType().equals(BodyElementType.TABLE)) {
                        replaceTable((XWPFTable) bodyElement, placeHolder, replaceText);
                    }
                }
            }
        }
    }
}
