//package tr.com.havelsan.report.poi.docx.impl;
//
//import java.io.FileOutputStream;
//import java.io.FileInputStream;
//import java.io.InputStream;
//
//import org.apache.poi.xwpf.usermodel.*;
//import org.openxmlformats.schemas.wordprocessingml.x2006.main.*;
//
//public class CreateWordPageBackground {
//
//    static XWPFSettings getSettings(XWPFDocument document) throws Exception {
//        java.lang.reflect.Field settings = XWPFDocument.class.getDeclaredField("settings");
//        settings.setAccessible(true);
//        return (XWPFSettings)settings.get(document);
//    }
//
//    static void setDisplayBackgroundShape(XWPFSettings settings, boolean booleanOnOff) throws Exception {
//        java.lang.reflect.Field _ctSettings = XWPFSettings.class.getDeclaredField("ctSettings");
//        _ctSettings.setAccessible(true);
//        CTSettings ctSettings = (CTSettings )_ctSettings.get(settings);
//        CTOnOff onOff = CTOnOff.Factory.newInstance();
//        onOff.setVal(STOnOff.Enum.forInt(booleanOnOff ?1: 0));
//        ctSettings.setDisplayBackgroundShape(onOff);
//    }
//
//    static void setBackgroundPictureId(CTBackground background, String rId) throws Exception {
//        String vmlBackgroundXML = ""
//                + "<v:background xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" "
//                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
//                + "id=\"_x0000_s1025\" o:bwmode=\"white\" o:targetscreensize=\"1024,768\">"
//                + "<v:fill r:id=\"" + rId + "\" recolor=\"t\" type=\"frame\"/>"
//                + "</v:background>"
//                ;
//        org.apache.xmlbeans.XmlObject vmlBackgroundXmlObject = org.apache.xmlbeans.XmlObject.Factory.parse(vmlBackgroundXML);
//        background.set(vmlBackgroundXmlObject);
//    }
//
//    public static void main(String[] args) throws Exception {
//
//        XWPFDocument document = new XWPFDocument();
//
//        // we need document settings to set display-background-shape
//        XWPFSettings settings = getSettings(document);
//        setDisplayBackgroundShape(settings, true);
//
//        // set a background color
//        CTBackground background = document.getDocument().addNewBackground();
//        background.setColor("FF0000");
//
//        // crate a picture reference in document
//        InputStream is = new FileInputStream("./samplePict.jpg");
//        String rId = document.addPictureData(is, Document.PICTURE_TYPE_JPEG);
//        // set a background picture
//        setBackgroundPictureId(background, rId);
//        background.setColor("FFFFFF");
//
//        XWPFParagraph paragraph = document.createParagraph();
//        XWPFRun run = paragraph.createRun();
//        run.setText("Text in Body ...");
//
//        paragraph = document.createParagraph();
//        run = paragraph.createRun();
//        run.setText("dsasadsaddsadsa" +
//                "dsa" +
//                "dasdsa in Body ...");
//
//        FileOutputStream out = new FileOutputStream("./CreateWordPageBackground.docx");
//        document.write(out);
//        out.close();
//        document.close();
//    }
//}
