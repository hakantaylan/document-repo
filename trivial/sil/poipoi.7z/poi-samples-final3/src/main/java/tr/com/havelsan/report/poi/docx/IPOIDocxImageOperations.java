package tr.com.havelsan.report.poi.docx;

import tr.com.havelsan.report.poi.docx.impl.POIDocxView;
import org.apache.poi.xwpf.usermodel.XWPFPicture;

import java.io.IOException;
import java.io.InputStream;
import java.util.function.Consumer;

public interface IPOIDocxImageOperations {
    ISingleImageOperations imageByIdentifier(String identifier);
    POIDocxView and();

    interface ISingleImageOperations {
        IPOIDocxImageOperations delete();
//        @todo input tsream olarak almak iyi fikir değil. İmaj'ları geel geçer formatları destekleyen hangi parametre ile alalım ????
        IPOIDocxImageOperations replace(InputStream in) throws IOException;
        IPOIDocxImageOperations customize(Consumer<XWPFPicture> consumer);
        //@todo n tane imajı parametre olarak alıp arka arkaya rapora yerleştiren bir yetenek eklenmeli!!!!!!!!
    }
}
