package tr.com.havelsan.report.poi.docx;

import java.io.FileInputStream;

import org.apache.poi.xwpf.usermodel.*;

import java.util.List;

public class WordReadAllContent {

    static org.apache.xmlbeans.XmlObject getInlineOrAnchor(org.openxmlformats.schemas.drawingml.x2006.picture.CTPicture ctPictureToFind, org.apache.xmlbeans.XmlObject inlineOrAnchor) {
        String declareNameSpaces = "declare namespace pic='http://schemas.openxmlformats.org/drawingml/2006/picture'; ";
        org.apache.xmlbeans.XmlObject[] selectedObjects = inlineOrAnchor.selectPath(
                declareNameSpaces
                        + "$this//pic:pic");
        for (org.apache.xmlbeans.XmlObject selectedObject : selectedObjects) {
            if (selectedObject instanceof org.openxmlformats.schemas.drawingml.x2006.picture.CTPicture) {
                org.openxmlformats.schemas.drawingml.x2006.picture.CTPicture ctPicture = (org.openxmlformats.schemas.drawingml.x2006.picture.CTPicture)selectedObject;
                if (ctPictureToFind.equals(ctPicture)) {
                    // this is the inlineOrAnchor for that picture
                    return inlineOrAnchor;
                }
            }
        }
        return null;
    }

    static org.apache.xmlbeans.XmlObject getInlineOrAnchor(XWPFRun run, XWPFPicture picture) {
        org.openxmlformats.schemas.drawingml.x2006.picture.CTPicture ctPictureToFind = picture.getCTPicture();
        for (org.openxmlformats.schemas.wordprocessingml.x2006.main.CTDrawing drawing : run.getCTR().getDrawingList()) {
            for (org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTInline inline : drawing.getInlineList()) {
                org.apache.xmlbeans.XmlObject inlineOrAnchor = getInlineOrAnchor(ctPictureToFind, inline);
                // if inlineOrAnchor is not null, then this is the inline for that picture
                if (inlineOrAnchor != null) return inlineOrAnchor;
            }
            for (org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTAnchor anchor : drawing.getAnchorList()) {
                org.apache.xmlbeans.XmlObject inlineOrAnchor = getInlineOrAnchor(ctPictureToFind, anchor);
                // if inlineOrAnchor is not null, then this is the anchor for that picture
                if (inlineOrAnchor != null) return inlineOrAnchor;
            }
        }
        return null;
    }

    static org.openxmlformats.schemas.drawingml.x2006.main.CTNonVisualDrawingProps getNonVisualDrawingProps(org.apache.xmlbeans.XmlObject inlineOrAnchor) {
        if (inlineOrAnchor == null) return null;
        if (inlineOrAnchor instanceof org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTInline) {
            org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTInline inline = (org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTInline)inlineOrAnchor;
            return inline.getDocPr();
        } else if (inlineOrAnchor instanceof org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTAnchor) {
            org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTAnchor anchor = (org.openxmlformats.schemas.drawingml.x2006.wordprocessingDrawing.CTAnchor)inlineOrAnchor;
            return anchor.getDocPr();
        }
        return null;
    }

    static String getSummary(org.openxmlformats.schemas.drawingml.x2006.main.CTNonVisualDrawingProps nonVisualDrawingProps) {
        if (nonVisualDrawingProps == null) return "";
        String summary = "Id:=" + nonVisualDrawingProps.getId();
        summary += " Name:=" + nonVisualDrawingProps.getName();
//        summary += " Title:=" + nonVisualDrawingProps.getTitle();
        summary += " Descr:=" + nonVisualDrawingProps.getDescr();
        return summary;
    }

    static void traversePictures(XWPFRun run, List<XWPFPicture> pictures) throws Exception {
        for (XWPFPicture picture : pictures) {
//            System.out.println(picture);

            String picturesNonVisualDrawingProps = getSummary(getNonVisualDrawingProps(getInlineOrAnchor(run, picture)));
            System.out.println(picturesNonVisualDrawingProps);

            XWPFPictureData pictureData = picture.getPictureData();
            System.out.println(picture.getCTPicture());
        }
    }

    static void traverseRunElements(List<IRunElement> runElements) throws Exception {
        for (IRunElement runElement : runElements) {
            if (runElement instanceof XWPFFieldRun) {
                XWPFFieldRun fieldRun = (XWPFFieldRun)runElement;
                //System.out.println(fieldRun.getClass().getName());
                //System.out.println(fieldRun);
                traversePictures(fieldRun, fieldRun.getEmbeddedPictures());
            } else if (runElement instanceof XWPFHyperlinkRun) {
                XWPFHyperlinkRun hyperlinkRun = (XWPFHyperlinkRun)runElement;
                //System.out.println(hyperlinkRun.getClass().getName());
                //System.out.println(hyperlinkRun);
                traversePictures(hyperlinkRun, hyperlinkRun.getEmbeddedPictures());
            } else if (runElement instanceof XWPFRun) {
                XWPFRun run = (XWPFRun)runElement;
                //System.out.println(run.getClass().getName());
                //System.out.println(run);
                traversePictures(run, run.getEmbeddedPictures());
            } else if (runElement instanceof XWPFSDT) {
                XWPFSDT sDT = (XWPFSDT)runElement;
                //System.out.println(sDT);
                //System.out.println(sDT.getContent());
                //ToDo: The SDT may have traversable content too.
            }
        }
    }

    static void traverseTableCells(List<ICell> tableICells) throws Exception {
        for (ICell tableICell : tableICells) {
            if (tableICell instanceof XWPFSDTCell) {
                XWPFSDTCell sDTCell = (XWPFSDTCell)tableICell;
                //System.out.println(sDTCell);
                //ToDo: The SDTCell may have traversable content too.
            } else if (tableICell instanceof XWPFTableCell) {
                XWPFTableCell tableCell = (XWPFTableCell)tableICell;
                //System.out.println(tableCell);
                traverseBodyElements(tableCell.getBodyElements());
            }
        }
    }

    static void traverseTableRows(List<XWPFTableRow> tableRows) throws Exception {
        for (XWPFTableRow tableRow : tableRows) {
            //System.out.println(tableRow);
            traverseTableCells(tableRow.getTableICells());
        }
    }

    static void traverseBodyElements(List<IBodyElement> bodyElements) throws Exception {
        for (IBodyElement bodyElement : bodyElements) {
            if (bodyElement instanceof XWPFParagraph) {
                XWPFParagraph paragraph = (XWPFParagraph)bodyElement;
                //System.out.println(paragraph);
                traverseRunElements(paragraph.getIRuns());
            } else if (bodyElement instanceof XWPFSDT) {
                XWPFSDT sDT = (XWPFSDT)bodyElement;
                //System.out.println(sDT);
                //System.out.println(sDT.getContent());
                //ToDo: The SDT may have traversable content too.
            } else if (bodyElement instanceof XWPFTable) {
                XWPFTable table = (XWPFTable)bodyElement;
                //System.out.println(table);
                traverseTableRows(table.getRows());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        String inFilePath = "test3.docx";
        XWPFDocument document = new XWPFDocument(new FileInputStream(inFilePath));
        traverseBodyElements(document.getBodyElements());
        document.close();
    }

}