package tr.com.havelsan.report.poi.docx.impl;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.drawingml.x2006.main.CTLineProperties;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class CreateWordHeaderFooter4 {

    public static void main(String[] args) throws Exception {

        XWPFDocument doc= new XWPFDocument();

        // the body content
        XWPFParagraph paragraph = doc.createParagraph();
        paragraph.setSpacingBefore(0);
        paragraph.setSpacingAfter(0);
        XWPFRun run=paragraph.createRun();
        run.setText("The Body:");
        for(int i = 0; i < 5; i++) {
            paragraph = doc.createParagraph();
            paragraph.setSpacingBefore(5 * 20);
//            paragraph.setSpacingBeforeLines(5 * 20);
            paragraph.setSpacingAfter(5*20);
//            paragraph.setSpacingAfterLines(5*20);
//        paragraph.setBorderTop(Borders.BASIC_BLACK_DASHES);
//        paragraph.setBorderBottom(Borders.BASIC_BLACK_DASHES);
//        paragraph.setBorderLeft(Borders.BASIC_BLACK_DASHES);
//        paragraph.setBorderRight(Borders.BASIC_BLACK_DASHES);

//        run.setCharacterSpacing(200);
//        CTPPr ppr = paragraph.getCTP().getPPr();
//        if (ppr == null) ppr = paragraph.getCTP().addNewPPr();
//        CTSpacing spacing = ppr.isSetSpacing()? ppr.getSpacing() : ppr.addNewSpacing();
//        spacing.setAfter(BigInteger.valueOf(3*20));
//        spacing.setBefore(BigInteger.valueOf(3*20));
//        spacing.setLineRule(STLineSpacingRule.AUTO);
            run = paragraph.createRun();
//            run.setCharacterSpacing(0);
//        spacing.setLine(BigInteger.valueOf(240));
//        run.setText("Hakan");
//        run.addBreak();
            String imgFile = "samplePict.jpg";
            try(FileInputStream pictureData = new FileInputStream(imgFile)) {

                XWPFPicture picture = run.addPicture(pictureData, XWPFDocument.PICTURE_TYPE_PNG, imgFile, Units.toEMU(500), Units.toEMU(500));
//        String embedId = doc.addPictureData(new FileInputStream(imgFile), XWPFDocument.PICTURE_TYPE_JPEG);
//        XWPFPicture picture = run.addPicture(new FileInputStream(imgFile), XWPFDocument.PICTURE_TYPE_PNG, imgFile, 630936, 630936);
//        run.getCTR().getDrawingArray(0).getInlineArray(0).addNewCNvGraphicFramePr().addNewGraphicFrameLocks().setNoChangeAspect(true);
//        System.out.println(picture.getCTPicture());
//
                picture.getCTPicture().getSpPr().addNewLn().setW(Units.toEMU(2.25));
                String embed = picture.getCTPicture().getBlipFill().getBlip().getEmbed();
                CTLineProperties ln = picture.getCTPicture().getSpPr().getLn();
                ln.addNewSolidFill().addNewSrgbClr().setVal(new byte[]{(byte) 255, 0, 0});
                System.out.println(picture.getCTPicture());
            }
//            XWPFRun run1 = paragraph.createRun();
//            run1.addBreak(BreakType.valueOf(1));
        }
//        run.getCTR().removeBr(0);
//        run.setText("", 0);
//
        doc.write(new FileOutputStream("test3.docx"));

    }
}