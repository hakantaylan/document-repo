package tr.com.havelsan.report.poi.docx;

import tr.com.havelsan.report.poi.docx.impl.POIDocxView;
import org.apache.poi.xwpf.usermodel.XWPFFooter;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.util.function.Consumer;

public interface IPOIDocxFooterOperations {

    IPOIDocxFooterOperations clearAll();
    IPOIDocxFooterOperations insertPageNumber();
    IPOIDocxFooterOperations insertPageNumberInPageOfPageFormat();
    IPOIDocxFooterOperations removeParagraphWithText(String text);
    IPOIDocxFooterOperations replaceText(String placeHolder, String replaceText);
    IFooterSingleOps withIdentifier(String identifier);
    IPOIDocxFooterOperations create(String footerText);
    IPOIDocxFooterOperations create(Consumer<XWPFParagraph> footerParagraphCustomizer);
    POIDocxView and();

    interface IFooterSingleOps {
        IPOIDocxFooterOperations delete();
        IPOIDocxFooterOperations replace(String textToFind, String replace);
        IPOIDocxFooterOperations customize(Consumer<XWPFFooter> footerParagraphCustomizer);
        POIDocxView and();
    }
}
