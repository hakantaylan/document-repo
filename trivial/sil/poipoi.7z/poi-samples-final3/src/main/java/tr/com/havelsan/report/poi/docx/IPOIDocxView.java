package tr.com.havelsan.report.poi.docx;

public interface IPOIDocxView {
}
