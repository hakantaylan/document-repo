package tr.com.havelsan.report.poi.docx.impl;

import tr.com.havelsan.report.poi.docx.IPOIDocxFooterOperations;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import static tr.com.havelsan.report.poi.docx.impl.POIDocxCommons.replaceTextSegment;

public class POIDocxFooterOperations implements IPOIDocxFooterOperations {

    private final POIDocxView docView;
    private final XWPFDocument document;

    public POIDocxFooterOperations(POIDocxView docView, XWPFDocument document) {
        this.docView = docView;
        this.document = document;
    }

    @Override
    public IPOIDocxFooterOperations insertPageNumber() {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        XWPFParagraph paragraph = policy.getFooter(XWPFHeaderFooterPolicy.DEFAULT).createParagraph();
        XWPFRun run = paragraph.createRun();
        run.setText("-");
        paragraph.getCTP().addNewFldSimple().setInstr("PAGE \\* MERGEFORMAT");
        run = paragraph.createRun();
        run.setText("-");
//        paragraph.getCTP().addNewFldSimple().setInstr("NUMPAGES \\* MERGEFORMAT");
        paragraph.setAlignment(ParagraphAlignment.CENTER);
        return this;
    }

    @Override
    public IPOIDocxFooterOperations insertPageNumberInPageOfPageFormat() {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        XWPFParagraph paragraph = policy.getFooter(XWPFHeaderFooterPolicy.DEFAULT).createParagraph();
        XWPFRun run = paragraph.createRun();
        run.setText("Page ");
        paragraph.getCTP().addNewFldSimple().setInstr("PAGE \\* MERGEFORMAT");
        run = paragraph.createRun();
        run.setText(" of ");
        paragraph.getCTP().addNewFldSimple().setInstr("NUMPAGES \\* MERGEFORMAT");
        paragraph.setAlignment(ParagraphAlignment.CENTER);
        return this;
    }

    @Override
    public IPOIDocxFooterOperations.IFooterSingleOps withIdentifier(String identifier) {
        return new FooterSingleOps(this, identifier);
    }

    @Override
    public IPOIDocxFooterOperations removeParagraphWithText(String text) {
        document.getFooterList().forEach(footer -> {
            List<XWPFParagraph> paragraphsToRemove = footer.getParagraphs().stream()
                    .filter(p -> p.getParagraphText().equals(text))
                    .toList();
            paragraphsToRemove.forEach(footer::removeParagraph);
        });
        return this;
    }

    @Override
    public IPOIDocxFooterOperations replaceText(String placeHolder, String replaceText) {
//        document.getFooterList().forEach(footer -> {
//            Optional<XWPFParagraph> paragraph = footer.getParagraphs().stream()
//                    .filter(p -> p.getParagraphText().equals(placeHolder))
//                    .findFirst();
//            if(paragraph.isPresent()) {
//                for (XWPFRun run : paragraph.get().getRuns()) {
//                    String text = run.getText(run.getTextPosition());
//                    if(text != null && text.contains(placeHolder)) {
//                        text = text.replace(placeHolder, replaceText == null ? "" : replaceText);
//                        run.setText(text, 0);
//                    }
//                }
//            }
//        });
        document.getFooterList().forEach(footer -> {
            Optional<XWPFParagraph> paragraph = footer.getParagraphs().stream()
                    .filter(p -> p.getParagraphText().equals(placeHolder))
                    .findFirst();
            paragraph.ifPresent(xwpfParagraph -> replaceTextSegment(xwpfParagraph, placeHolder, replaceText));
        });
        return this;
    }

    @Override
    public IPOIDocxFooterOperations clearAll() {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        policy.getFooter(XWPFHeaderFooterPolicy.DEFAULT).clearHeaderFooter();
        policy.getFooter(XWPFHeaderFooterPolicy.FIRST).clearHeaderFooter();
        policy.getFooter(XWPFHeaderFooterPolicy.EVEN).clearHeaderFooter();
        return this;
    }

    @Override
    public IPOIDocxFooterOperations create(String footerText) {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        if (policy.getDefaultFooter() == null && policy.getFirstPageFooter() == null
                && policy.getDefaultFooter() == null) {
            // Need to create some new headers
            // The easy way, gives a single empty paragraph
            XWPFFooter footerD = policy.createFooter(XWPFHeaderFooterPolicy.DEFAULT);
            footerD.getParagraphArray(0).createRun().setText(footerText);

            // Or the full control way
//                CTP ctP1 = CTP.Factory.newInstance();
//                CTR ctR1 = ctP1.addNewR();
//                CTText t = ctR1.addNewT();
//                t.setStringValue("Paragraph in header");
//
//                XWPFParagraph p1 = new XWPFParagraph(ctP1, sampleDoc);
//                XWPFParagraph[] pars = new XWPFParagraph[1];
//                pars[0] = p1;
//
//                policy.createHeader(policy.FIRST, pars);
        } else {
            // Already has a header, change it
            if (policy.getDefaultFooter().getParagraphs().isEmpty()) {
                XWPFParagraph footerParagraph = policy.getDefaultFooter().createParagraph();
                footerParagraph.setAlignment(ParagraphAlignment.RIGHT);
                footerParagraph.createRun().setText(footerText, 0);
            } else
                policy.getDefaultFooter().getParagraphArray(0).getRuns().get(0).setText(footerText, 0);
        }
        return this;
    }

    @Override
    public IPOIDocxFooterOperations create(Consumer<XWPFParagraph> footerParagraphCustomizer) {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        if (policy.getDefaultFooter() == null && policy.getFirstPageFooter() == null
                && policy.getDefaultFooter() == null) {
            // Need to create some new headers
            // The easy way, gives a single empty paragraph
            XWPFFooter footerD = policy.createFooter(XWPFHeaderFooterPolicy.DEFAULT);
            footerParagraphCustomizer.accept(footerD.getParagraphArray(0));

            // Or the full control way
//                CTP ctP1 = CTP.Factory.newInstance();
//                CTR ctR1 = ctP1.addNewR();
//                CTText t = ctR1.addNewT();
//                t.setStringValue("Paragraph in header");
//
//                XWPFParagraph p1 = new XWPFParagraph(ctP1, sampleDoc);
//                XWPFParagraph[] pars = new XWPFParagraph[1];
//                pars[0] = p1;
//
//                policy.createHeader(policy.FIRST, pars);
        } else {
            // Already has a header, change it
            XWPFParagraph footerParagraph;
            if (policy.getDefaultFooter().getParagraphs().isEmpty()) {
                footerParagraph = policy.getDefaultFooter().createParagraph();
            } else
                footerParagraph = policy.getDefaultFooter().getParagraphArray(0);
            footerParagraphCustomizer.accept(footerParagraph);
        }
        return this;
    }

    @Override
    public POIDocxView and() {
        return docView;
    }

    private class FooterSingleOps implements IPOIDocxFooterOperations.IFooterSingleOps {
        private final String identifier;
        private final POIDocxFooterOperations poiDocxFooterOperations;

        public FooterSingleOps(POIDocxFooterOperations poiDocxFooterOperations, String identifier) {
            this.poiDocxFooterOperations = poiDocxFooterOperations;
            this.identifier = identifier;
        }

        @Override
        public IPOIDocxFooterOperations delete() {
            document.getFooterList().stream().filter(footer -> {
                Optional<XWPFParagraph> isFound = footer.getParagraphs().stream()
                        .filter(p -> p.getParagraphText().equals(identifier))
                        .findFirst();
                return isFound.isPresent();
            }).forEach(XWPFHeaderFooter::clearHeaderFooter);
            return poiDocxFooterOperations;
        }

        @Override
        public IPOIDocxFooterOperations replace(String textToFind, String replace) {
//            document.getFooterList().stream()
//                    .map(XWPFHeaderFooter::getParagraphs)
//                    .flatMap(Collection::stream)
//                    .map(XWPFParagraph::getRuns)
//                    .flatMap(Collection::stream)
//                    .filter(r -> r.text().equals(textToFind))
//                    .forEach(r -> r.setText(replace, 0));
            List<XWPFParagraph> paragraphs = document.getFooterList().stream()
                    .map(XWPFHeaderFooter::getParagraphs)
                    .flatMap(Collection::stream)
                    .toList();
            paragraphs.forEach(p -> replaceTextSegment(p, textToFind, replace));
            return poiDocxFooterOperations;
        }

        @Override
        public IPOIDocxFooterOperations customize(Consumer<XWPFFooter> footerCustomizer) {
            document.getFooterList().stream().filter(footer -> {
                Optional<XWPFParagraph> isFound = footer.getParagraphs().stream()
                        .filter(p -> p.getParagraphText().equals(identifier))
                        .findFirst();
                return isFound.isPresent();
            }).forEach(XWPFHeaderFooter::clearHeaderFooter);
            return poiDocxFooterOperations;
        }

        @Override
        public POIDocxView and() {
            return docView;
        }

    }
}
