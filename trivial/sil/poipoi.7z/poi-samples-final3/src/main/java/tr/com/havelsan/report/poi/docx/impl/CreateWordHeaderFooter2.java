package tr.com.havelsan.report.poi.docx.impl;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSectPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTabStop;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTabJc;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.util.List;

public class CreateWordHeaderFooter2 {

    public static void main(String[] args) throws Exception {

        XWPFDocument doc= new XWPFDocument(OPCPackage.open("test3.docx"));

        List<XWPFParagraph> paragraphs = doc.getParagraphs();
        for (XWPFParagraph paragraph : paragraphs) {
            for (XWPFRun run : paragraph.getRuns()) {
                run.getEmbeddedPictures().forEach(i ->
                        System.out.println(i.getCTPicture()));
            }
        }


        doc.close();

    }
}