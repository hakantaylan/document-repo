package tr.com.havelsan.report.poi.docx.impl;

import java.io.FileOutputStream;
import java.io.FileInputStream;

import org.apache.poi.util.Units;

import org.apache.poi.xwpf.usermodel.*;

import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;

import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSectPr;

import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTabStop;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTabJc;

import java.math.BigInteger;

public class CreateWordHeaderFooter3 {

    public static void main(String[] args) throws Exception {

        XWPFDocument doc= new XWPFDocument();

        // the body content
        XWPFParagraph paragraph = doc.createParagraph();
        XWPFRun run=paragraph.createRun();
        run.setText("The Body:");

        paragraph = doc.createParagraph();
        run=paragraph.createRun();
        run.setText("Lorem ipsum....");

        // create header start
        CTSectPr sectPr = doc.getDocument().getBody().addNewSectPr();
        XWPFHeaderFooterPolicy headerFooterPolicy = new XWPFHeaderFooterPolicy(doc, sectPr);

        XWPFHeader header = headerFooterPolicy.createHeader(XWPFHeaderFooterPolicy.DEFAULT);

        paragraph = header.createParagraph();
        paragraph.setAlignment(ParagraphAlignment.LEFT);

        CTTabStop tabStop = paragraph.getCTP().getPPr().addNewTabs().addNewTab();
        tabStop.setVal(STTabJc.RIGHT);
        int twipsPerInch =  1440;
        tabStop.setPos(BigInteger.valueOf(6 * twipsPerInch));

        run = paragraph.createRun();
        run.setText("The Header:");
        run.addTab();

        run = paragraph.createRun();
        String imgFile="samplePict.jpg";
        XWPFPicture picture = run.addPicture(new FileInputStream(imgFile), XWPFDocument.PICTURE_TYPE_JPEG, imgFile, Units.toEMU(50), Units.toEMU(50));
        System.out.println(picture); //XWPFPicture is added
        System.out.println(picture.getPictureData()); //but without access to XWPFPictureData (no blipID)

        String blipID = "";
        for(XWPFPictureData picturedata : header.getAllPackagePictures()) {
            blipID = header.getRelationId(picturedata);
            System.out.println(blipID); //the XWPFPictureData are already there
        }
        picture.getCTPicture().getBlipFill().getBlip().setEmbed(blipID); //now they have a blipID also
        picture.getCTPicture().getSpPr().addNewLn().setW(Units.toEMU(2.25));
//        String embed = picture.getCTPicture().getBlipFill().getBlip().getEmbed();
        picture.getCTPicture().getSpPr().getLn().addNewSolidFill().addNewSrgbClr().setVal(new byte[]{(byte)255,0,0});
        System.out.println(picture.getCTPicture());
        System.out.println(picture.getPictureData());

        // create footer start
        XWPFFooter footer = headerFooterPolicy.createFooter(XWPFHeaderFooterPolicy.DEFAULT);

        paragraph = footer.createParagraph();
        paragraph.setAlignment(ParagraphAlignment.CENTER);

        run = paragraph.createRun();
        run.setText("The Footer:");


        doc.write(new FileOutputStream("test.docx"));

    }
}
