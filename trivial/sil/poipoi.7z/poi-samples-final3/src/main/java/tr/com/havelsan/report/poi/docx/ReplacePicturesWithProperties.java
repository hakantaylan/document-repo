//package tr.com.havelsan.report.poi.docx;
//
//import org.apache.poi.common.usermodel.PictureType;
//import org.apache.poi.xwpf.usermodel.*;
//import org.apache.poi.util.IOUtils;
//import org.apache.xmlbeans.XmlCursor;
//import org.openxmlformats.schemas.wordprocessingml.x2006.main.*;
//import org.apache.poi.xwpf.usermodel.XWPFPictureData;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.util.List;
//
//public class ReplacePicturesWithProperties {
//    public static void main(String[] args) throws Exception {
//        // Path to your DOCX template
//        String templatePath = "template.docx";
//        // Paths to your new images
//        String[] imagePaths = {
//                "image1.png",
//                "image2.jpg",
//                "image3.png",
//                "image4.jpg"
//        };
//
//        // Load the DOCX template
//        XWPFDocument document = new XWPFDocument(new FileInputStream(templatePath));
//
//        String s = document.addPictureData((byte[]) null, PictureType.PNG);
//
//        // Get all pictures in the template (using picture data)
//        List<XWPFPictureData> pictures = document.getAllPictures();
//
//        if (pictures.size() < imagePaths.length) {
//            System.out.println("Not enough pictures in the template to replace.");
//            return;
//        }
//
//        // Replace the pictures with the new ones
//        for (int i = 0; i < imagePaths.length; i++) {
//            // Read the new image
//            FileInputStream imageStream = new FileInputStream(new File(imagePaths[i]));
//            byte[] imageBytes = IOUtils.toByteArray(imageStream);
//            imageStream.close();
//
//            // Get the picture to replace (this assumes you're replacing the first 4 pictures)
//            XWPFPictureData pictureData = pictures.get(i);
//            XWPFPicture originalPicture = pictureData.getParent();  // Get the original picture
//
//            // Retrieve the original picture properties (borders, alignment, etc.)
//            CTPicture originalCTPicture = originalPicture.getCTPicture();
//
//            // Create a new picture with the same picture type
//            XWPFPicture newPicture = document.createPicture(imageBytes, pictureData.getPictureType());
//
//            // Clone and apply picture properties
//            if (originalCTPicture != null) {
//                // Clone properties such as borders and alignment
//                XmlCursor cursor = originalCTPicture.newCursor();
//                cursor.selectPath("./*");
//
//                // Example: Clone picture's border and alignment settings
//                cursor.toFirstChild();  // Navigate to the first child element
//                cursor.copyXml(newPicture.getCTPicture().newCursor());  // Copy properties to the new picture
//            }
//
//            // Save the modified document with the new image and properties
//            try (FileOutputStream out = new FileOutputStream("output.docx")) {
//                document.write(out);
//            }
//
//            System.out.println("Image replaced successfully with properties!");
//        }
//    }
//}
//
