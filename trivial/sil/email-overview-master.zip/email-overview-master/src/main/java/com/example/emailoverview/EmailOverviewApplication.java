package com.example.emailoverview;

import com.example.emailoverview.config.EmailSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import jakarta.mail.MessagingException;

@SpringBootApplication
public class EmailOverviewApplication {

	@Autowired
	public ApplicationContext applicationContext;

	public static void main(String[] args) {
				SpringApplication.run(EmailOverviewApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(){
		return args -> {
			System.out.println("Preparing to send mail");
			EmailSender emailSender = applicationContext.getBean(EmailSender.class);
			emailSender.sendEmail();
//			emailSender.sendMailWithAttachment();
//			emailSender.sendMailWithTemplate();
//		emailSender.sendMailWithLocalInlineImg();
        };
    }

}
