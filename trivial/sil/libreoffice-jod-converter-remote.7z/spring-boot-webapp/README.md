## JODConverter - Sample - Spring Boot

This is a sample application that uses the spring boot integration module of the Java OpenDocument Converter (JODConverter) project.

### Running the Project using gradle

First, build the project:

```Shell
gradlew :samples:spring-boot-webapp:build
```

Then, run:

```Shell
gradlew :samples:spring-boot-webapp:bootRun
```

Once started, use your favorite browser and visit this page:

```
http://localhost:8080/
```

Happy conversions!!

```
docker run --memory 512m  --rm -p 8090:8080 ghcr.io/jodconverter/jodconverter-examples:rest
```
jodconverter provides a remote service interface. We can run it directly in docker.
```
docker run -d -p 8100:8100 --privileged=true -v /usr/share/fonts:/usr/share/fonts -v /opt/application.properties:/etc/app/application.properties ghcr.io/jodconverter/jodconverter-examples:rest
```
Mount the corresponding fonts, otherwise Chinese will not be displayed
-v /usr/share/