package org.jodconverter.sample.springboot;

import org.jodconverter.core.DocumentConverter;
import org.jodconverter.core.office.OfficeManager;
import org.jodconverter.remote.RemoteConverter;
import org.jodconverter.remote.office.RemoteOfficeManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class LibreofficeConfig {

    @Value("${jodconverter.remote.url:''}")
    private String jodconverterUrl;

    @Bean(
            initMethod = "start",
            destroyMethod = "stop"
    )
    @Primary
    public OfficeManager officeManager() {
        RemoteOfficeManager.Builder builder = RemoteOfficeManager.builder();
        builder.urlConnection(jodconverterUrl);
        builder.poolSize(10);
        builder.taskExecutionTimeout(60000L);
        builder.taskQueueTimeout(60000L);
        return builder.build();
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnBean({OfficeManager.class})
    @Primary
    public DocumentConverter jodConverter(OfficeManager officeManager) {
        return RemoteConverter.make(officeManager);
    }

}