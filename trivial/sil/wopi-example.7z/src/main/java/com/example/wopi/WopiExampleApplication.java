package com.example.wopi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WopiExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(WopiExampleApplication.class, args);
    }
}
