package com.example.wopi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WopiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
