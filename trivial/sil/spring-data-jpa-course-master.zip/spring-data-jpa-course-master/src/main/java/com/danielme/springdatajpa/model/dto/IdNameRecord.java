package com.danielme.springdatajpa.model.dto;

public record IdNameRecord(Long id, String name) {
}
