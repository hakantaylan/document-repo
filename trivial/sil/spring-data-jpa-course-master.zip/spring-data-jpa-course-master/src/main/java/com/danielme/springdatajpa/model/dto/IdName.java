package com.danielme.springdatajpa.model.dto;

public interface IdName {

    Long getId();

    String getName();

}
