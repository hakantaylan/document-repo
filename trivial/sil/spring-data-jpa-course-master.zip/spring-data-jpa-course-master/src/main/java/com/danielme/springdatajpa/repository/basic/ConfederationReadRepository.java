package com.danielme.springdatajpa.repository.basic;

import com.danielme.springdatajpa.model.entity.Confederation;

public interface ConfederationReadRepository extends ReadCommonRepository<Confederation, Long> {
}
