package com.danielme.springdatajpa.model.dto;

public record ConfederationSummaryRecord (Long id, String name, Long countries){
}
