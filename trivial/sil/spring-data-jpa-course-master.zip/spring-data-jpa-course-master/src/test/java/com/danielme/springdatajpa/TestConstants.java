package com.danielme.springdatajpa;

public final class TestConstants {

    private TestConstants(){}

    public static final String CITY_STRING = "City";
    public static final String REPUBLIC_STRING = "Republic";

}
