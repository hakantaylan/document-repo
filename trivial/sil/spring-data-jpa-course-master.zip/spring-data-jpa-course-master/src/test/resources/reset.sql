TRUNCATE TABLE countries;
TRUNCATE TABLE confederations;