package tr.com.havelsan.report.poi.docx;

//@todo implement edilecek
public interface IPOIDocxChartOperations {
}
