package tr.com.havelsan.report.poi.docx;

import tr.com.havelsan.report.poi.docx.impl.POIDocxView;
import org.apache.poi.xwpf.usermodel.XWPFHeader;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.util.function.Consumer;

public interface IPOIDocxHeaderOperations {
    IHeaderSingleOps withIdentifier(String identifier);
    IPOIDocxHeaderOperations removeParagraphWithText(String text);
    IPOIDocxHeaderOperations replaceText(String placeHolder, String replaceText);
    IPOIDocxHeaderOperations clearAll();
    IPOIDocxHeaderOperations create(String headerText);
    IPOIDocxHeaderOperations create(Consumer<XWPFParagraph> headerParagraphCustomizer);
    POIDocxView and();

    interface IHeaderSingleOps {
        IPOIDocxHeaderOperations delete();
        IPOIDocxHeaderOperations replace(String textToFind, String replace);
        IPOIDocxHeaderOperations customize(Consumer<XWPFHeader> headerCustomizer);
    }
}
