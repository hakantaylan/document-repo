package tr.com.havelsan.report.poi.docx;

import tr.com.havelsan.report.poi.docx.impl.POIDocxView;

import java.util.List;
import java.util.Map;

public interface IPOIDocxTableOperations {
    IPOIDocxTableOperations fillTable(int tblIdx, List<List<String>> tableData);

    IPOIDocxTableOperations replaceInTable(int tblIdx, Map<String, String> tableData);

    IPOIDocxTableOperations deleteTable(int tblIdx);

    POIDocxView and();
}
