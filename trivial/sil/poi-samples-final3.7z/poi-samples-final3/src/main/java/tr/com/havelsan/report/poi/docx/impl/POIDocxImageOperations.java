package tr.com.havelsan.report.poi.docx.impl;

import tr.com.havelsan.report.poi.docx.IPOIDocxImageOperations;
import org.apache.poi.xwpf.usermodel.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.function.Consumer;

public class POIDocxImageOperations implements IPOIDocxImageOperations {

    private final POIDocxView docView;
    private final XWPFDocument document;

    public POIDocxImageOperations(POIDocxView docView, XWPFDocument document) {
        this.docView = docView;
        this.document = document;
    }

    @Override
    public ISingleImageOperations imageByIdentifier(String identifier){
        for (IBodyElement bodyElement : document.getBodyElements()) {
            if (bodyElement instanceof XWPFParagraph) {
                XWPFParagraph paragraph = (XWPFParagraph)bodyElement;
                for (XWPFRun run : paragraph.getRuns()) {
                    XWPFPicture picture = getPictureByIdentifier(run, identifier);
                    if (picture != null) {
                        return new SingeImageOps(document, picture, run);
                    }
                }
            }
        }
        throw new RuntimeException(MessageFormat.format("Dokümanda {0} adlı tanımlayıcıya ait imaj bulunamadı!", identifier));
    }


    private  XWPFPicture getPictureByIdentifier(XWPFRun run, String pictureIdentifier) {
        if (pictureIdentifier == null)
            return null;
        for (XWPFPicture picture : run.getEmbeddedPictures()) {
            if (pictureIdentifier.equals(picture.getDescription())) {
                return picture;
            }
        }
        return null;
    }

    @Override
    public POIDocxView and() {
        return docView;
    }

    private class SingeImageOps implements ISingleImageOperations{
        private final XWPFDocument document;
        private final XWPFPicture picture;
        private final XWPFRun run;

        public SingeImageOps(XWPFDocument document) {
            this.document = document;
            picture = null;
            run = null;
        }

        protected SingeImageOps(XWPFDocument document, XWPFPicture picture, XWPFRun run) {
            this.document = document;
            this.picture = picture;
            this.run = run;
        }

        @Override
        public POIDocxImageOperations delete(){
            if(picture == null)
                throw new RuntimeException("Silinecek imaj bulunamadı!");
            int index = document.getBodyElements().indexOf(run);
            document.removeBodyElement(index);
            return POIDocxImageOperations.this;
        }

        @Override
        public IPOIDocxImageOperations replace(InputStream in) throws IOException{
            replacePicture(picture.getPictureData(), in);
            return POIDocxImageOperations.this;
        }

        private void replacePicture(XWPFPictureData source, InputStream in) throws IOException {
            try (
                    OutputStream out = source.getPackagePart().getOutputStream();
            ) {
//            byte[] buffer = new byte[2048];
//            int length;
//            while ((length = in.read(buffer)) > 0) {
//                out.write(buffer, 0, length);
//            }
                in.transferTo(out);
//            URL resource = WordReplacePictureData.class.getClassLoader().getResource(pictureResultPath);
//            Files.copy(Path.of(resource.toURI()), out);
            }
            finally {
                if(in != null)
                    in.close();
            }
        }

        @Override
        public IPOIDocxImageOperations customize(Consumer<XWPFPicture> consumer) {
            consumer.accept(picture);
            return POIDocxImageOperations.this;
        }
    }
}
