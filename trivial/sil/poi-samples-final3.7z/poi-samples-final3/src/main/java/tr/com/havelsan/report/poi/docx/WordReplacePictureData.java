package tr.com.havelsan.report.poi.docx;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;

import org.apache.poi.xwpf.usermodel.*;

public class WordReplacePictureData {

    static XWPFPicture getPictureByName(XWPFRun run, String pictureName) {
        if (pictureName == null) return null;
        for (XWPFPicture picture : run.getEmbeddedPictures()) {
            String nonVisualPictureName = picture.getDescription();
            if (pictureName.equals(nonVisualPictureName)) {
                return picture;
            }
        }
        return null;
    }

    static void replacePictureData(XWPFPictureData source, String pictureResultPath) {
        try (
//                InputStream in = WordReplacePictureData.class.getClassLoader().getResourceAsStream(pictureResultPath);
              OutputStream out = source.getPackagePart().getOutputStream();
        ) {
//            byte[] buffer = new byte[2048];
//            int length;
//            while ((length = in.read(buffer)) > 0) {
//                out.write(buffer, 0, length);
//            }
//            in.transferTo(out);
            URL resource = WordReplacePictureData.class.getClassLoader().getResource(pictureResultPath);
            Files.copy(Path.of(resource.toURI()), out);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    static void replacePicture(XWPFRun run, String pictureName, String pictureResultPath) {
        XWPFPicture picture = getPictureByName(run, pictureName);
        if (picture != null) {
            XWPFPictureData source = picture.getPictureData();
            replacePictureData(source, pictureResultPath);
        }
    }

    public static void main(String[] args) throws Exception {
        String templatePath = "./deneme.docx";
        String resultPath = "./deneme2.docx";
        String pictureTemplateName = "ddd";
        String pictureResultPath = "a.simple.man.png";
        InputStream resourceAsStream = WordReplacePictureData.class.getClassLoader().getResourceAsStream("docx/deneme.docx");
        try ( XWPFDocument document = new XWPFDocument(resourceAsStream);
              FileOutputStream out = new FileOutputStream(resultPath);
        ) {

            for (IBodyElement bodyElement : document.getBodyElements()) {
                if (bodyElement instanceof XWPFParagraph) {
                    XWPFParagraph paragraph = (XWPFParagraph)bodyElement;
                    for (XWPFRun run : paragraph.getRuns()) {
                        replacePicture(run, pictureTemplateName, pictureResultPath);
                    }
                }
            }
            document.write(out);
        }
    }
}