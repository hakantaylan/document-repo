package tr.com.havelsan.report.poi.docx.impl;

import tr.com.havelsan.report.poi.docx.IPOIDocxFooterOperations;
import tr.com.havelsan.report.poi.docx.IPOIDocxHeaderOperations;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import static tr.com.havelsan.report.poi.docx.impl.POIDocxCommons.replaceTextSegment;

public class POIDocxHeaderOperations implements IPOIDocxHeaderOperations {
    private final POIDocxView docView;
    private final XWPFDocument document;

    public POIDocxHeaderOperations(POIDocxView docView, XWPFDocument document) {
        this.docView = docView;
        this.document = document;
    }

    @Override
    public IHeaderSingleOps withIdentifier(String identifier) {
        return new HeaderSingleOps(this, identifier);
    }

    @Override
    public IPOIDocxHeaderOperations removeParagraphWithText(String text) {
        document.getHeaderList().forEach(header -> {
            List<XWPFParagraph> paragraphsToRemove = header.getParagraphs().stream()
                    .filter(p -> p.getParagraphText().equals(text))
                    .toList();
            paragraphsToRemove.forEach(header::removeParagraph);
        });
        return this;
    }

    @Override
    public IPOIDocxHeaderOperations replaceText(String placeHolder, String replaceText) {
//        document.getHeaderList().forEach(header -> {
//            Optional<XWPFParagraph> paragraph = header.getParagraphs().stream()
//                    .filter(p -> p.getParagraphText().equals(placeHolder))
//                    .findFirst();
//            if(paragraph.isPresent()) {
//                for (XWPFRun run : paragraph.get().getRuns()) {
//                    String text = run.getText(run.getTextPosition());
//                    if(text != null && text.contains(placeHolder)) {
//                        text = text.replace(placeHolder, replaceText == null ? "" : replaceText);
//                        run.setText(text, 0);
//                    }
//                }
//            }
//        });
        document.getHeaderList().forEach(header -> {
            Optional<XWPFParagraph> paragraph = header.getParagraphs().stream()
                    .filter(p -> p.getParagraphText().equals(placeHolder))
                    .findFirst();
            paragraph.ifPresent(xwpfParagraph -> replaceTextSegment(xwpfParagraph, placeHolder, replaceText));
        });
        return this;
    }

    @Override
    public IPOIDocxHeaderOperations clearAll() {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        policy.getHeader(XWPFHeaderFooterPolicy.DEFAULT).clearHeaderFooter();
        policy.getHeader(XWPFHeaderFooterPolicy.FIRST).clearHeaderFooter();
        policy.getHeader(XWPFHeaderFooterPolicy.EVEN).clearHeaderFooter();
        return this;
    }

    @Override
    public IPOIDocxHeaderOperations create(String headerText) {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        if (policy.getDefaultHeader() == null && policy.getFirstPageHeader() == null
                && policy.getDefaultFooter() == null) {
            // Need to create some new headers
            // The easy way, gives a single empty paragraph
            XWPFHeader headerD = policy.createHeader(XWPFHeaderFooterPolicy.DEFAULT);
            headerD.getParagraphArray(0).createRun().setText(headerText);

            // Or the full control way
//                CTP ctP1 = CTP.Factory.newInstance();
//                CTR ctR1 = ctP1.addNewR();
//                CTText t = ctR1.addNewT();
//                t.setStringValue("Paragraph in header");
//
//                XWPFParagraph p1 = new XWPFParagraph(ctP1, sampleDoc);
//                XWPFParagraph[] pars = new XWPFParagraph[1];
//                pars[0] = p1;
//
//                policy.createHeader(policy.FIRST, pars);
        } else {
            // Already has a header, change it
            if (policy.getDefaultHeader().getParagraphs().isEmpty()) {
                XWPFParagraph headerParagraph = policy.getDefaultHeader().createParagraph();
                headerParagraph.setAlignment(ParagraphAlignment.RIGHT);
                headerParagraph.createRun().setText(headerText, 0);
            } else
                policy.getDefaultHeader().getParagraphArray(0).getRuns().get(0).setText(headerText, 0);
        }
        return this;
    }

    @Override
    public IPOIDocxHeaderOperations create(Consumer<XWPFParagraph> headerParagraphCustomizer) {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        if (policy.getDefaultHeader() == null && policy.getFirstPageHeader() == null
                && policy.getDefaultFooter() == null) {
            // Need to create some new headers
            // The easy way, gives a single empty paragraph
            XWPFHeader headerD = policy.createHeader(XWPFHeaderFooterPolicy.DEFAULT);
            headerParagraphCustomizer.accept(headerD.getParagraphArray(0));

            // Or the full control way
//                CTP ctP1 = CTP.Factory.newInstance();
//                CTR ctR1 = ctP1.addNewR();
//                CTText t = ctR1.addNewT();
//                t.setStringValue("Paragraph in header");
//
//                XWPFParagraph p1 = new XWPFParagraph(ctP1, sampleDoc);
//                XWPFParagraph[] pars = new XWPFParagraph[1];
//                pars[0] = p1;
//
//                policy.createHeader(policy.FIRST, pars);
        } else {
            // Already has a header, change it
            XWPFParagraph headerParagraph;
            if (policy.getDefaultHeader().getParagraphs().isEmpty()) {
                headerParagraph = policy.getDefaultHeader().createParagraph();
            } else
                headerParagraph = policy.getDefaultHeader().getParagraphArray(0);
            headerParagraphCustomizer.accept(headerParagraph);
        }
        return this;
    }

    @Override
    public POIDocxView and() {
        return docView;
    }

    private class HeaderSingleOps implements IHeaderSingleOps {
        private final String identifier;
        private final POIDocxHeaderOperations poiDocxHeaderOperations;

        public HeaderSingleOps(POIDocxHeaderOperations poiDocxHeaderOperations, String identifier) {
            this.poiDocxHeaderOperations = poiDocxHeaderOperations;
            this.identifier = identifier;
        }

        @Override
        public IPOIDocxHeaderOperations delete() {
            document.getHeaderList().stream().filter(header -> {
                Optional<XWPFParagraph> isFound = header.getParagraphs().stream()
                        .filter(p -> p.getParagraphText().equals(identifier))
                        .findFirst();
                return isFound.isPresent();
            }).forEach(XWPFHeaderFooter::clearHeaderFooter);
            return poiDocxHeaderOperations;
        }

        @Override
        public IPOIDocxHeaderOperations replace(String textToFind, String replace) {
//            document.getHeaderList().stream()
//                    .map(XWPFHeaderFooter::getParagraphs)
//                    .flatMap(Collection::stream)
//                    .map(XWPFParagraph::getRuns)
//                    .flatMap(Collection::stream)
//                    .filter(r -> r.text().equals(textToFind))
//                    .forEach(r -> r.setText(replace, 0));
            List<XWPFParagraph> paragraphs = document.getHeaderList().stream()
                    .map(XWPFHeaderFooter::getParagraphs)
                    .flatMap(Collection::stream)
                    .toList();
            paragraphs.forEach(p -> replaceTextSegment(p, textToFind, replace));
            return poiDocxHeaderOperations;
        }

        @Override
        public IPOIDocxHeaderOperations customize(Consumer<XWPFHeader> headerCustomizer) {
            document.getHeaderList().stream().filter(header -> {
                Optional<XWPFParagraph> isFound = header.getParagraphs().stream()
                        .filter(p -> p.getParagraphText().equals(identifier))
                        .findFirst();
                return isFound.isPresent();
            }).forEach(headerCustomizer);
            return poiDocxHeaderOperations;
        }

    }
}
