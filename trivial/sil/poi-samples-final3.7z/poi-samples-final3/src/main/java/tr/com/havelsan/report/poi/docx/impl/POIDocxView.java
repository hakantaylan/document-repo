package tr.com.havelsan.report.poi.docx.impl;

import tr.com.havelsan.report.poi.docx.IPOIDocxHeaderOperations;
import tr.com.havelsan.report.poi.docx.IPOIDocxImageOperations;
import tr.com.havelsan.report.poi.docx.IPOIDocxTableOperations;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.*;

import java.io.*;
import java.net.URI;
import java.net.URL;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

import static tr.com.havelsan.report.poi.docx.impl.POIDocxCommons.replaceTextSegment;

public class POIDocxView {

    private final XWPFDocument document;
    private final FileInputStream fis;

    private POIDocxView(String templatePath) throws IOException, InvalidFormatException {
        fis = new FileInputStream(new File(URI.create(templatePath)));
        document = new XWPFDocument(OPCPackage.open(fis));
    }

    public static POIDocxView openTemplate(String templatePath) throws Exception {
        URL resource = POIDocxView.class.getClassLoader().getResource(templatePath);
//        File file = new File(resource.getFile());
        return new POIDocxView(resource.toURI().toString());
    }

    private XWPFDocument openDocument(String filePath) throws InvalidFormatException, IOException {
        InputStream fis = POIDocxView.class
                .getClassLoader()
                .getResourceAsStream(filePath);
        return new XWPFDocument(OPCPackage.open(fis));
    }

    public void writeAndClose(String fileResult) throws IOException {
        try (FileOutputStream stream = new FileOutputStream(fileResult)) {
            document.write(stream);
            close();
        }
    }

    public void writeToFile(String filePath) throws IOException {
        try (FileOutputStream stream = new FileOutputStream(filePath)) {
            document.write(stream);
        }
    }

    public void close() throws IOException {
        try {
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        document.close();
    }

    public XWPFDocument getDocument() {
        return document;
    }

    public void print() throws IOException {
        XWPFWordExtractor ext = new XWPFWordExtractor(document);
// display text
        System.out.println(ext.getText());
        close();
    }

    public void createWaterMark() {
        XWPFHeaderFooterPolicy headerFooterPolicy = document.getHeaderFooterPolicy();
        headerFooterPolicy.createWatermark("Watermark");
        // get the default header
        // Note: createWatermark also sets FIRST and EVEN headers
        // but this code does not updating those other headers
        XWPFHeader header = headerFooterPolicy.getHeader(XWPFHeaderFooterPolicy.DEFAULT);
        XWPFParagraph paragraph = header.getParagraphArray(0);

        // get com.microsoft.schemas.vml.CTShape where fill color and rotation is set
        org.apache.xmlbeans.XmlObject[] xmlobjects = paragraph.getCTP().getRArray(0).getPictArray(0).selectChildren(
                new javax.xml.namespace.QName("urn:schemas-microsoft-com:vml", "shape"));

        if (xmlobjects.length > 0) {
            com.microsoft.schemas.vml.CTShape ctshape = (com.microsoft.schemas.vml.CTShape) xmlobjects[0];
            // set fill color
            ctshape.setFillcolor("#d8d8d8");
            // set rotation
            ctshape.setStyle(ctshape.getStyle() + ";rotation:315");
            //System.out.println(ctshape);
        }

//		for (XWPFHeader xwpfHeader : document.getHeaderList()) {
//			xwpfHeader.getParagraphs().forEach(graph -> {
//				String paraText = graph.getCTP().xmlText();
//				if(paraText != null &&  paraText.contains("{WATERMARK}")) {
//					String replace = paraText.replace("{WATERMARK}", "jksdajksdajkdajkdasdajksdajkdajkdasjkdsjkdasdajkd");
//					try {
//						XmlToken token = XmlToken.Factory.parse(replace);
//						graph.getCTP().set(token);
//					} catch (XmlException e) {
//						throw new RuntimeException(e);
//					}
//				}
//			});
//		}
    }

    public void removeHeadersAndFooters() {
        XWPFHeaderFooterPolicy policy = document.getHeaderFooterPolicy();
        policy.getHeader(XWPFHeaderFooterPolicy.DEFAULT).clearHeaderFooter();
        policy.getHeader(XWPFHeaderFooterPolicy.FIRST).clearHeaderFooter();
        policy.getHeader(XWPFHeaderFooterPolicy.EVEN).clearHeaderFooter();
        policy.getFooter(XWPFHeaderFooterPolicy.DEFAULT).clearHeaderFooter();
        policy.getFooter(XWPFHeaderFooterPolicy.FIRST).clearHeaderFooter();
        policy.getFooter(XWPFHeaderFooterPolicy.EVEN).clearHeaderFooter();
//		XWPFHeader defaultHeader = document.getHeaderFooterPolicy().getDefaultHeader();
//		XWPFHeader firstPageHeader = document.getHeaderFooterPolicy().getFirstPageHeader();
//		XWPFHeader evenPageHeader = document.getHeaderFooterPolicy().getEvenPageHeader();
        XWPFHeader oddPageHeader = document.getHeaderFooterPolicy().getOddPageHeader();  // oddPageHeader is the same as DefaultPage Header
//
//		for (XWPFHeader header : document.getHeaderList()) {
//			header.setHeaderFooter(org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHdrFtr.Factory.newInstance());
//		}
//		for (XWPFFooter footer : document.getFooterList()) {
//			footer.setHeaderFooter(org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHdrFtr.Factory.newInstance());
//		}
    }

    private void replaceTable(XWPFTable table, String placeHolder, String replaceText) {
        for (XWPFTableRow row : table.getRows()) {
            for (XWPFTableCell cell : row.getTableCells()) {
                for (IBodyElement bodyElement : cell.getBodyElements()) {
                    if (bodyElement.getElementType().equals(BodyElementType.PARAGRAPH)) {
                        replaceParagraph((XWPFParagraph) bodyElement, placeHolder, replaceText);
                    }
                    if (bodyElement.getElementType().equals(BodyElementType.TABLE)) {
                        replaceTable((XWPFTable) bodyElement, placeHolder, replaceText);
                    }
                }
            }
        }
    }

    private boolean replaceParagraph(XWPFParagraph paragraph, String placeHolder, String replaceText) {
        for (XWPFRun r : paragraph.getRuns()) {
            String text = r.getText(r.getTextPosition());
            if (text != null && text.contains(placeHolder)) {
                text = text.replace(placeHolder, replaceText);
                r.setText(text, 0);
                return true;
            }
        }
        return false;
    }

    public IPOIDocxHeaderOperations headers() {
        return new POIDocxHeaderOperations(this, document);
    }

    public POIDocxFooterOperations footers() {
        return new POIDocxFooterOperations(this, document);
    }

    public POIDocxView replaceRuns(Map<String, String> values) {
        values.forEach((key, value) -> {
            boolean replacementFound = false;
            for (XWPFParagraph paragraph : document.getParagraphs()) {
//                replacementFound = replaceParagraph(paragraph, key, value);
                replacementFound = replaceTextSegment(paragraph, key, value);
                if (replacementFound)
                    break;
            }
            if (!replacementFound)
                throw new RuntimeException(String.format("%s isimli text dokümanda bulunamadı!", key));
        });
        return this;
    }

    public POIDocxView customizeRun(String text, Consumer<XWPFRun> consumer) {
        Optional<XWPFRun> first = document.getParagraphs()
                .stream()
                .map(XWPFParagraph::getRuns)
                .flatMap(Collection::stream)
                .filter(r -> r.text().equals(text))
                .findFirst();
        first.ifPresent(consumer);
        return this;
    }

    public IPOIDocxTableOperations fillTable(int idx, List<List<String>> tableData) {
        POIDocxTableOperations tableOperations = new POIDocxTableOperations(this, document);
        return tableOperations.fillTable(idx, tableData);
    }

    public IPOIDocxImageOperations.ISingleImageOperations imageByIdentifier(String identifier) {
        POIDocxImageOperations imageOperations = new POIDocxImageOperations(this, document);
        return imageOperations.imageByIdentifier(identifier);
    }
}
