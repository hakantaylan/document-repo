package com.example.outbox.integration;


import com.example.outbox.TestOrder;
import com.example.outbox.TestOrderLine;
import com.example.outbox.TestOrderLineRepository;
import com.example.outbox.TestOrderRepository;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.outbox.model.OutboxRepository;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
//@Transactional
public class OutboxIntegrationTest {

    @Autowired
    TestOrderRepository orderRepo;
    @Autowired
    TestOrderLineRepository lineRepo;
    @Autowired
    OutboxRepository outboxRepo;

    @Test
    void testOutboxFiresOncePerAggregate() {
        var order = new TestOrder();
        order.setStatus("NEW");
        orderRepo.save(order);

        order.setStatus("SHIPPED");
        orderRepo.save(order);

        var line = new TestOrderLine();
        line.setOrder(order);
        line.setProduct("Widget");
        lineRepo.save(line); // should NOT create outbox

        outboxRepo.flush();

        assertThat(outboxRepo.findAll())
                .hasSize(1)
                .allMatch(m -> m.getAggregateType().equals(TestOrder.class.getName()));
    }
}
