//package com.example.outbox.integration;
//
//import com.example.outbox.annotation.AggregateRepository;
//import jakarta.persistence.*;
//import lombok.Getter;
//import lombok.Setter;
//import org.hibernate.annotations.UuidGenerator;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.UUID;
//
//public class TestEntities {
//    @Entity
//    @Getter
//    @Setter
//    public static class TestOrder {
//        @Id
//        @GeneratedValue(strategy = GenerationType.UUID)
//        @UuidGenerator(style = UuidGenerator.Style.VERSION_7)
//        private UUID id;
//        private String status;
//    }
//
//    @Entity
//    @Getter
//    @Setter
//    public static class TestOrderLine {
//        @Id
//        @GeneratedValue(strategy = GenerationType.UUID)
//        @UuidGenerator(style = UuidGenerator.Style.VERSION_7)
//        private UUID id;
//        private String product;
//        @ManyToOne
//        private TestOrder order;
//    }
//
//    @AggregateRepository
//    public interface TestOrderRepository extends JpaRepository<TestOrder, Long> {}
//
//    public interface TestOrderLineRepository extends JpaRepository<TestOrderLine, Long> {}
//}
