package com.example.outbox_spring_boot_starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutboxSpringBootStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
