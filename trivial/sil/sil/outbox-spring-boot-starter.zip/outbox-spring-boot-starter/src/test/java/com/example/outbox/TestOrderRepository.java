package com.example.outbox;

import com.example.outbox.annotation.AggregateRepository;
import org.springframework.data.jpa.repository.JpaRepository;

@AggregateRepository
public interface TestOrderRepository extends JpaRepository<TestOrder, Long> {

}