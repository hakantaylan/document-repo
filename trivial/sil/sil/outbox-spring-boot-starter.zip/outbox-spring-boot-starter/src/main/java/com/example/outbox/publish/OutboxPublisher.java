package com.example.outbox.publish;

import com.example.outbox.tracker.AggregateChange;
import com.example.outbox.tracker.AggregateChangeTracker;
import com.example.outbox.model.OutboxMessage;
import com.example.outbox.model.OutboxRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.event.TransactionPhase;

import java.time.Instant;

@Component
public class OutboxPublisher {

    private final AggregateChangeTracker tracker;
    private final OutboxRepository repo;
    private final OutboxMapper mapper;

    public OutboxPublisher(AggregateChangeTracker tracker,
                           OutboxRepository repo,
                           OutboxMapper mapper) {
        this.tracker = tracker;
        this.repo = repo;
        this.mapper = mapper;
    }

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void publish(Object ignored) {
        for (AggregateChange change : tracker.drain()) {
            OutboxMessage msg = new OutboxMessage();
            msg.setAggregateType(change.aggregateType().getName());
            msg.setAggregateId(String.valueOf(change.aggregateId()));
            msg.setEventType(change.changeType().name());
            msg.setPayload(mapper.toJson(change));
            msg.setOccurredAt(Instant.now());
            repo.save(msg);
        }
    }
}
