package com.example.outbox.publish;

import com.example.outbox.tracker.AggregateChange;
import org.springframework.stereotype.Component;
import tools.jackson.databind.json.JsonMapper;

@Component
public class OutboxMapper {

    private final JsonMapper mapper;

    public OutboxMapper(JsonMapper mapper) {
        this.mapper = mapper;
    }

    public String toJson(AggregateChange change) {
        try { return mapper.writeValueAsString(change); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
}