package com.example.outbox.tracker;

public enum ChangeType {
    CREATE,
    UPDATE,
    DELETE
}
