package com.example.outbox.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "outbox")
public record OutboxProperties(
        boolean enabled,
        boolean failIfNoAggregates,
        int batchSize
) {
    public OutboxProperties {
        if (batchSize <= 0) batchSize = 100;
    }
}
