package com.example.outbox.hibernate;

import com.example.outbox.tracker.AggregateChange;

import java.util.Collection;

public record EntitiesFlushedEvent(Collection<AggregateChange> changes) {
}
