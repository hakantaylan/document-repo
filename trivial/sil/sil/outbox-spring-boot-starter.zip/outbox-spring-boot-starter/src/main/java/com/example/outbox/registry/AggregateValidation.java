package com.example.outbox.registry;

import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@Component
public class AggregateValidation {

    private final AggregateRootRegistry registry;

    @Autowired
    public AggregateValidation(AggregateRootRegistry registry) {
        this.registry = registry;
    }

    @EventListener
    public void onApplicationReady(ApplicationReadyEvent event) {
        if (registry.all().isEmpty()) {
            throw new IllegalStateException("No @AggregateRepository found — Outbox cannot function.");
        }
    }
}
