package com.example.outbox.tracker;

import com.example.outbox.hibernate.EntitiesFlushedEvent;
import org.hibernate.Hibernate;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Collection;

@Component
public class AggregateChangeTracker {

    // key for binding transaction-scoped state
    private static final String RESOURCE_KEY = "com.example.outbox.AggregateChangeTracker.TX";

    private static class TxState {
        final Map<Object, AggregateChange> changes = new LinkedHashMap<>();
        boolean syncRegistered = false;
    }

    private final ApplicationEventPublisher publisher;

    public AggregateChangeTracker(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    public void record(Object entity, ChangeType type, EntityPersister persister) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            throw new IllegalStateException("Attempt to record aggregate change outside of transaction");
        }

        TxState state = (TxState) TransactionSynchronizationManager.getResource(RESOURCE_KEY);
        if (state == null) {
            state = new TxState();
            TransactionSynchronizationManager.bindResource(RESOURCE_KEY, state);
        }

        Object id = persister.getIdentifier(entity, (SharedSessionContractImplementor) null);
        Class<?> entityClass = Hibernate.getClass(entity);

        AggregateChange newChange = new AggregateChange(entityClass, id, type);
        state.changes.merge(entity, newChange, this::merge);

        if (!state.syncRegistered) {
            state.syncRegistered = true;
            TxState finalState = state;
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void beforeCommit(boolean readOnly) {
                    // snapshot current changes and publish inside the transaction.
                    Collection<AggregateChange> snapshot = List.copyOf(finalState.changes.values());
                    publisher.publishEvent(new EntitiesFlushedEvent(snapshot));
                }

                @Override
                public void afterCompletion(int status) {
                    // cleanup bound resource
                    try {
                        TransactionSynchronizationManager.unbindResource(RESOURCE_KEY);
                    } catch (IllegalStateException ignore) {
                        // already unbound/cleaned, ignore
                    }
                }
            });
        }
    }

    private AggregateChange merge(AggregateChange oldC, AggregateChange newC) {
        // existing logic: CREATE wins, DELETE overwrites others
        if (oldC.changeType() == ChangeType.CREATE) return oldC;
        if (newC.changeType() == ChangeType.DELETE) return newC;
        return oldC;
    }

    public Collection<AggregateChange> drain() {
//        Collection<AggregateChange> result = List.copyOf(TxState.changes.values());
//        changes.clear();
        return null;
    }
}