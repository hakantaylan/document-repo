package com.example.outbox.hibernate;

import com.example.outbox.registry.AggregateRootRegistry;
import com.example.outbox.tracker.AggregateChangeTracker;
import com.example.outbox.tracker.ChangeType;
import org.hibernate.event.spi.*;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;

@Component
public class AggregateInsertListener implements PostInsertEventListener {

    private final AggregateRootRegistry registry;
    private final AggregateChangeTracker tracker;

    public AggregateInsertListener(AggregateRootRegistry registry, AggregateChangeTracker tracker) {
        this.registry = registry;
        this.tracker = tracker;
    }

    @Override
    public void onPostInsert(PostInsertEvent event) {
        Object entity = event.getEntity();
        if (!registry.isAggregateRoot(Hibernate.getClass(entity)))
            return;
        tracker.record(entity, ChangeType.CREATE, event.getPersister());
    }
}
