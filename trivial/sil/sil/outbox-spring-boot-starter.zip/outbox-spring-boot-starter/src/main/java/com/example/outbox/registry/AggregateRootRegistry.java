package com.example.outbox.registry;


import com.example.outbox.annotation.AggregateRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.ResolvableType;
import org.springframework.data.repository.Repository;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Slf4j
public class AggregateRootRegistry implements ApplicationContextAware {

    private final Set<Class<?>> roots = ConcurrentHashMap.newKeySet();

    @Override
    public void setApplicationContext(ApplicationContext ctx) {
        Map<String, Object> beans = ctx.getBeansWithAnnotation(AggregateRepository.class);

        beans.forEach((name, repo) -> {
            System.out.println(name);
            Class<?> domainType = resolveDomainType(repo);
            roots.add(domainType);
        });
    }

    private Class<?> resolveDomainType(Object repoBean) {
        Class<?>[] interfaces = AopProxyUtils.proxiedUserInterfaces(repoBean);
        for (Class<?> repositoryInterface : interfaces) {
            ResolvableType repositoryType = ResolvableType.forClass(repositoryInterface).as(Repository.class);
            if (repositoryType != ResolvableType.NONE) {
                return repositoryType.getGeneric(0).resolve(); // domain type
            }

        }
        return null;
    }

//    private Class<?> resolveDomainType(Object repo) {
//        ResolvableType type =
//                ResolvableType.forClass(AopUtils.getTargetClass(repo))
//                        .as(JpaRepository.class);
//        Class<?> domain = type.getGeneric(0).resolve();
//        if (domain == null)
//            throw new IllegalStateException("Cannot resolve domain type");
//        return domain;
//    }

    public boolean isAggregateRoot(Class<?> type) {
        return roots.contains(type);
    }

    public Set<Class<?>> all() {
        return Set.copyOf(roots);
    }

}