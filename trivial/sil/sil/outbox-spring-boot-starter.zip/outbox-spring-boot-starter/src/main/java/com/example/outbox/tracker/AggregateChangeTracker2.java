package com.example.outbox.tracker;

import org.hibernate.Hibernate;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class AggregateChangeTracker2 {

    private final Map<Object, AggregateChange> changes = new LinkedHashMap<>();

    public void record(Object entity, ChangeType type, EntityPersister persister) {
        Object id = persister.getIdentifier(entity, (SharedSessionContractImplementor)null);
        Class<?> entityClass = Hibernate.getClass(entity);

        AggregateChange newChange = new AggregateChange(entityClass, id, type);
        changes.merge(entity, newChange, this::merge);
    }

    private AggregateChange merge(AggregateChange oldC, AggregateChange newC) {
        if (oldC.changeType() == ChangeType.CREATE) return oldC;
        if (newC.changeType() == ChangeType.DELETE) return newC;
        return oldC;
    }

    public Collection<AggregateChange> drain() {
        Collection<AggregateChange> result = List.copyOf(changes.values());
        changes.clear();
        return result;
    }
}