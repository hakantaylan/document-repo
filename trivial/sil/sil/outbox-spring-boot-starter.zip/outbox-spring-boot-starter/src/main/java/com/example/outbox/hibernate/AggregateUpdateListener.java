package com.example.outbox.hibernate;

import com.example.outbox.registry.AggregateRootRegistry;
import com.example.outbox.tracker.AggregateChangeTracker;
import com.example.outbox.tracker.ChangeType;
import org.hibernate.Hibernate;
import org.hibernate.event.spi.PostUpdateEvent;
import org.hibernate.event.spi.PostUpdateEventListener;
import org.springframework.stereotype.Component;

@Component
public class AggregateUpdateListener implements PostUpdateEventListener {

    private final AggregateRootRegistry registry;
    private final AggregateChangeTracker tracker;

    public AggregateUpdateListener(AggregateRootRegistry registry, AggregateChangeTracker tracker) {
        this.registry = registry;
        this.tracker = tracker;
    }

    @Override
    public void onPostUpdate(PostUpdateEvent event) {
        int[] dirty = event.getDirtyProperties();
        if (dirty == null || dirty.length == 0) {
            return;
        }

        Object entity = event.getEntity();
        Class<?> type = Hibernate.getClass(entity);

        if (!registry.isAggregateRoot(type)) return;

        tracker.record(entity, ChangeType.UPDATE, event.getPersister());
    }
}
