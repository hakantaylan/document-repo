package com.example.outbox_spring_boot_starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutboxSpringBootStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutboxSpringBootStarterApplication.class, args);
	}

}
