package com.example.outbox.hibernate;

import com.example.outbox.registry.AggregateRootRegistry;
import com.example.outbox.tracker.AggregateChangeTracker;
import com.example.outbox.tracker.ChangeType;
import org.hibernate.Hibernate;
import org.hibernate.event.spi.PostDeleteEvent;
import org.hibernate.event.spi.PostDeleteEventListener;
import org.springframework.stereotype.Component;

@Component
public class AggregateDeleteListener implements PostDeleteEventListener {

    private final AggregateRootRegistry registry;
    private final AggregateChangeTracker tracker;

    public AggregateDeleteListener(AggregateRootRegistry registry, AggregateChangeTracker tracker) {
        this.registry = registry;
        this.tracker = tracker;
    }

    @Override
    public void onPostDelete(PostDeleteEvent event) {
        Object entity = event.getEntity();
        Class<?> type = Hibernate.getClass(entity);

        if (!registry.isAggregateRoot(type)) return;

        tracker.record(entity, ChangeType.DELETE, event.getPersister());
    }
}