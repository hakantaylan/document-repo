package com.example.outbox.tracker;

public record AggregateChange(
        Class<?> aggregateType,
        Object aggregateId,
        ChangeType changeType
) {}
