package com.example.outbox.hibernate;

import org.springframework.stereotype.Component;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.hibernate.internal.SessionFactoryImpl;
import jakarta.persistence.EntityManagerFactory;

@Component
public class HibernateListenerRegistrar {

    public HibernateListenerRegistrar(EntityManagerFactory emf,
                                      AggregateInsertListener insert,
                                      AggregateUpdateListener update,
                                      AggregateDeleteListener delete) {
        var sessionFactory = emf.unwrap(SessionFactoryImpl.class);
        EventListenerRegistry registry = sessionFactory.getServiceRegistry().getService(EventListenerRegistry.class);

        registry.getEventListenerGroup(EventType.POST_INSERT).appendListener(insert);
        registry.getEventListenerGroup(EventType.POST_UPDATE).appendListener(update);
        registry.getEventListenerGroup(EventType.POST_DELETE).appendListener(delete);
    }
}