package com.example.repo.poc.repository;

import com.example.repo.poc.outbox.data.OutboxEventType;
import com.example.repo.poc.outbox.OutboxPublisher;
import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.domain.DeleteSpecification;
import org.springframework.data.jpa.domain.PredicateSpecification;
import org.springframework.data.jpa.domain.UpdateSpecification;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public class OutboxSenderRepositoryImpl<T, ID> extends BaseRepositoryImpl<T, ID> {

    private final EntityManager em;
    private final OutboxPublisher<T> publisher;

    @SuppressWarnings("unchecked")
    public OutboxSenderRepositoryImpl(JpaEntityInformation<T, ID> entityInformation,
                                      EntityManager em,
                                      OutboxPublisher<?> publisher) {
        super(entityInformation, em);
        this.em = em;
        this.publisher = (OutboxPublisher<T>) publisher;
    }

    @Override
    @Transactional
    public <S extends T> S save(S entity) {
        S saved = super.save(entity);
        publisher.publish(saved, OutboxEventType.UPDATE);
        return saved;
    }

    @Override
    @Transactional
    public void deleteById(ID id) {
        Optional<T> entity = findById(id);
        super.deleteById(id);
        publisher.publish(entity.get(), OutboxEventType.DELETE);
    }

    @Override
    @Transactional
    public void delete(T entity) {
        super.delete(entity);
        publisher.publish(entity, OutboxEventType.DELETE);
    }


    @Override
    @Transactional
    public void deleteAllByIdInBatch(Iterable<ID> ids) {
        super.deleteAllByIdInBatch(ids);
    }


    @Override
    @Transactional
    public void deleteAllInBatch(Iterable<T> entities) {
        super.deleteAllInBatch(entities);
    }


    @Override
    @Transactional
    public void deleteAllInBatch() {
        super.deleteAllInBatch();
    }

    @Override
    @Transactional
    public long update(UpdateSpecification<T> spec) {
        return super.update(spec);
    }

    @Override
    @Transactional
    public long delete(DeleteSpecification<T> spec) {
        return super.delete(spec);
    }

    @Override
    @Transactional
    public long delete(PredicateSpecification<T> spec) {
        return super.delete(spec);
    }
}