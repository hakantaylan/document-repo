package com.example.repo.poc.repository.exception;

public class LockExpiredException extends RuntimeException{

    public LockExpiredException() {
        super("Lock expired or not owned by current user");
    }

    public LockExpiredException(String message) {
        super(message);
    }

    public LockExpiredException(String entityName, Object id) {
        super("Lock expired on " + entityName + " with ID " + id);
    }
}
