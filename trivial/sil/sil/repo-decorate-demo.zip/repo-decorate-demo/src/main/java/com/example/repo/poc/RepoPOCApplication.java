package com.example.repo.poc;

import com.example.repo.poc.data.Order;
import com.example.repo.poc.data.OrderItem;
import com.example.repo.poc.repository.OrderRepository;
import com.example.repo.poc.repository.factory.ConditionalRepositoryFactoryBean;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.math.BigDecimal;
import java.time.LocalDate;

@SpringBootApplication
@EnableJpaRepositories(
//        basePackages = "com.example.repo.poc.repository",
//        repositoryBaseClass = BaseRepository.class, // Base marker
//        repositoryBaseClass = BaseRepositoryImpl.class, // Base marker
        repositoryFactoryBeanClass = ConditionalRepositoryFactoryBean.class
)
public class RepoPOCApplication {

    public static void main(String[] args) {
        SpringApplication.run(RepoPOCApplication.class, args);
    }

//    @Bean
    public ApplicationRunner init(OrderRepository repository) {
        return args -> {
            for(int j = 0; j < 100; j++){
                Order order = Order.builder().customer("customer" + j).orderDate(LocalDate.now()).build();
                for (int i = 0; i < 5; i++) {
                    order.addOrderItem(OrderItem.builder().price(BigDecimal.valueOf(i + 1)).build());
                }
                repository.save(order);
            }
            Page<Order> all = repository.findAll(Pageable.ofSize(10));
            Page<Order> all2 = repository.findAllBy(Pageable.ofSize(10));
            System.out.println("--------------------------------------------");
        };
    }


}
