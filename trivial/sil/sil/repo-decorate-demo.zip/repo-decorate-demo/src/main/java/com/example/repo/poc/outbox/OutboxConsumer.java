package com.example.repo.poc.outbox;

import com.example.repo.poc.data.BaseEntity;
import com.example.repo.poc.outbox.data.OutboxEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ObjectNode;

import java.util.Map;

@Component
public class OutboxConsumer {

    private final JsonMapper mapper;
//    private final TargetEntityRepository targetRepo;

    public OutboxConsumer(JsonMapper mapper) {
        this.mapper = mapper;
//        this.targetRepo = targetRepo;
    }

    @Transactional
    public void process(OutboxEvent event) {
        JsonNode delta;
        try {
            delta = mapper.readTree(event.getPayload());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        System.out.println(delta);
//        targetRepo.findById(event.aggregateId()).ifPresent(entity -> applyDelta(entity, delta));
    }

    private void applyDelta(BaseEntity entity, ObjectNode delta) {
        try { // Convert delta
            Map<String, JsonNode> map = mapper.convertValue(delta, new TypeReference<>() {
            });
            for (Map.Entry<String, JsonNode> e : map.entrySet()) {
                String fieldName = e.getKey();
                JsonNode valueNode = e.getValue();
                try {
                    var f = entity.getClass().getDeclaredField(fieldName);
                    f.setAccessible(true); // may require module opens in Java 25
                    Object value = mapper.convertValue(valueNode, f.getType());
                    f.set(entity, value);
                } catch (NoSuchFieldException nsf) {
                    throw new RuntimeException("No such field: " + fieldName, nsf);
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

//    private void applyDelta(BaseEntity entity, ObjectNode delta) {
//        delta.fieldNames().forEachRemaining(field -> {
//            try {
//                var f = entity.getClass().getDeclaredField(field);
//                f.setAccessible(true);
//                f.set(entity, mapper.treeToValue(delta.get(field), f.getType()));
//            } catch (Exception e) {
//                throw new RuntimeException(e);
//            }
//        });
//    }
}