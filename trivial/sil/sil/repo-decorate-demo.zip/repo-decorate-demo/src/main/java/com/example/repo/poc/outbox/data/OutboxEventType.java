package com.example.repo.poc.outbox.data;

public enum OutboxEventType {
    INSERT,
    UPDATE,
    DELETE
}
