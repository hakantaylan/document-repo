//package com.example.repo.poc.config;
//
//import com.example.repo.poc.outbox.JpaOutboxPublisher;
//import com.example.repo.poc.repository.BaseRepositoryImpl;
//import com.example.repo.poc.repository.factory.ConditionalRepositoryFactoryBean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//
//@Configuration
////@EnableJpaRepositories(
////        basePackages = "com.example.repo.poc.repository",
//////        repositoryBaseClass = BaseRepository.class, // Base marker
//////        repositoryBaseClass = BaseRepositoryImpl.class, // Base marker
////        repositoryFactoryBeanClass = ConditionalRepositoryFactoryBean.class
////)
//public class RepositoryConfig {
//
//    private final JpaOutboxPublisher publisher;
//
//    public RepositoryConfig(JpaOutboxPublisher publisher) {
//        this.publisher = publisher;
//    }
//
//    // Bean post-processing: inject publisher into factory beans
//    @SuppressWarnings("rawtypes")
//    public void configureFactoryBeans(org.springframework.beans.factory.config.ConfigurableListableBeanFactory beanFactory) {
//        String[] factoryBeans = beanFactory.getBeanNamesForType(ConditionalRepositoryFactoryBean.class);
//        for (String name : factoryBeans) {
//            ConditionalRepositoryFactoryBean factoryBean = (ConditionalRepositoryFactoryBean) beanFactory.getBean(name);
////            factoryBean.setPublisher(publisher);
//        }
//    }
//}