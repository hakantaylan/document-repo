package com.example.repo.poc.repository.factory;

import com.example.repo.poc.data.IEmptySpec;
import com.example.repo.poc.data.IOutbox;
import com.example.repo.poc.outbox.OutboxPublisher;
import com.example.repo.poc.repository.*;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.*;
import org.springframework.data.repository.core.RepositoryInformation;
import org.springframework.data.repository.core.RepositoryMetadata;

public class ConditionalRepositoryFactory<T, ID> extends JpaRepositoryFactory {

    private final EntityManager em;
    private OutboxPublisher<T> publisher;
    private FencingLockService lockService;

    public ConditionalRepositoryFactory(EntityManager em) {
        super(em);
        this.em = em;
    }

    @Autowired
    public void setPublisher(OutboxPublisher<T> publisher) {
        this.publisher = publisher;
    }

    @Autowired
    public void setLockService(FencingLockService lockService) {
        this.lockService = lockService;
    }


    @Override
    protected JpaRepositoryImplementation<?, ?> getTargetRepository(RepositoryInformation information, EntityManager em) {
        Class<?> repoInterface = information.getRepositoryInterface();
        JpaEntityInformation<?, ?> entityInformation = JpaEntityInformationSupport.getEntityInformation(information.getDomainType(), em);
        if(LockAwareRepository.class.isAssignableFrom(repoInterface))
            return new LockAwareRepositoryImpl2<>(entityInformation,lockService, em);
        // If repository didn't opt-in to custom behavior, let Spring create the default
        if (!BaseJpaRepository.class.isAssignableFrom(repoInterface)) {
            return super.getTargetRepository(information, em);
        }
        Class<?> domainClass = information.getDomainType();
        if (IEmptySpec.class.isAssignableFrom(domainClass) && IOutbox.class.isAssignableFrom(domainClass)) {
            return new EmptySpecOutboxRepositoryImpl<>(entityInformation, em, publisher);
        } else if (IEmptySpec.class.isAssignableFrom(domainClass)) {
            return new EmptySpecRepositoryImpl<>(entityInformation, em);
        } else if (IOutbox.class.isAssignableFrom(domainClass)) {
            return new OutboxSenderRepositoryImpl<>(entityInformation, em, publisher);
        } else {
            return new BaseRepositoryImpl<>(entityInformation, em);
        }
    }

    @Override
    protected Class<?> getRepositoryBaseClass(RepositoryMetadata metadata) {
        if(LockAwareRepository.class.isAssignableFrom(metadata.getRepositoryInterface()))
            return LockAwareRepositoryImpl2.class;

        // If the repo didn't opt-in, delegate to Spring's default to preserve default behavior
        if (!BaseJpaRepository.class.isAssignableFrom(metadata.getRepositoryInterface())) {
            return super.getRepositoryBaseClass(metadata);
        }

        Class<?> domainClass = metadata.getDomainType();
        if (IEmptySpec.class.isAssignableFrom(domainClass) && IOutbox.class.isAssignableFrom(domainClass)) {
            return EmptySpecOutboxRepositoryImpl.class;
        } else if (IEmptySpec.class.isAssignableFrom(domainClass)) {
            return EmptySpecRepositoryImpl.class;
        } else if (IOutbox.class.isAssignableFrom(domainClass)) {
            return OutboxSenderRepositoryImpl.class;
        } else {
            return BaseRepositoryImpl.class;
        }
    }
}
