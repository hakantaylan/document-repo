package com.example.repo.poc.outbox;

import com.example.repo.poc.data.BaseEntity;
import com.example.repo.poc.outbox.data.OutboxEvent;
import com.example.repo.poc.outbox.data.OutboxEventType;
import com.example.repo.poc.outbox.repository.OutboxEventRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.json.JsonMapper;

@Service
public class JpaOutboxPublisher<T extends BaseEntity> implements OutboxPublisher<T> {

    @PersistenceContext
    private EntityManager em;
    private final JsonMapper jsonMapper;
    private OutboxEventRepository repository;

    public JpaOutboxPublisher(JsonMapper jsonMapper, OutboxEventRepository repository) {
        this.jsonMapper = jsonMapper;
        this.repository = repository;
    }

    @Override
    @Transactional
    public void publish(T entity, OutboxEventType eventType) {
        var event = new OutboxEvent();
        event.setAggregateType(entity.getClass().getSimpleName());
        event.setAggregateId(entity.getId());
        event.setEventType(eventType);
        if (eventType != OutboxEventType.DELETE) {
            String payload = jsonMapper.writeValueAsString(entity);
            event.setPayload(payload);
        }
//        em.persist(event);
        repository.save(event);
    }
}
