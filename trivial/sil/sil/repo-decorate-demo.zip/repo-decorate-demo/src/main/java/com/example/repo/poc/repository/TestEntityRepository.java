package com.example.repo.poc.repository;

import com.example.repo.poc.data.TestEntity;

public interface TestEntityRepository extends BaseJpaRepository<TestEntity, Long> {
}
