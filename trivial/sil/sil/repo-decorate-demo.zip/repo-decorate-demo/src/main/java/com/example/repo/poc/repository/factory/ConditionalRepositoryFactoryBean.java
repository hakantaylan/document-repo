package com.example.repo.poc.repository.factory;

import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;

public class ConditionalRepositoryFactoryBean<R extends JpaRepository<T, I>, T, I>
        extends JpaRepositoryFactoryBean<R, T, I> {

    public ConditionalRepositoryFactoryBean(Class<? extends R> repositoryInterface) {
        super(repositoryInterface);
    }

    @Override
    protected RepositoryFactorySupport createRepositoryFactory(EntityManager em) {
        return new ConditionalRepositoryFactory<>(em);
    }
}
