package com.example.repo.poc.repository;

import com.example.repo.poc.data.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;

public interface OrderRepository extends BaseJpaRepository<Order, Long> {

//    @EntityGraph(attributePaths = {"customer"})
    Page<Order> findAll(Pageable pageable);
    Page<Order> findAllBy(Pageable pageable);
}