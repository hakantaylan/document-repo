package com.example.repo.poc.repository.exception;

public class LockLostException extends RuntimeException {

    public LockLostException(String entity, Object id) {
        super("Lock lost on " + entity + " with ID " + id);
    }
}