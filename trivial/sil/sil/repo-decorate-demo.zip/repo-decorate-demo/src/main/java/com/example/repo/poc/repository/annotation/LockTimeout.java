package com.example.repo.poc.repository.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface LockTimeout {
    /**
     * Lock duration in seconds
     */
    long value() default 900; // default 15 minutes
}