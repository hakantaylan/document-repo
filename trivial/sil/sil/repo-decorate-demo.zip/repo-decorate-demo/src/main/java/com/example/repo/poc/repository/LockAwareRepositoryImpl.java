package com.example.repo.poc.repository;

import com.example.repo.poc.repository.annotation.LockTimeout;
import com.example.repo.poc.repository.exception.LockExpiredException;
import jakarta.persistence.EntityManager;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

public class LockAwareRepositoryImpl<T, ID> extends SimpleJpaRepository<T, ID> implements LockAwareRepository<ID>{

    private final EntityManager em;
    private final JpaEntityInformation<T, ?> entityInfo;

    public LockAwareRepositoryImpl(JpaEntityInformation<T, ?> entityInfo, EntityManager em) {
        super(entityInfo, em);
        this.em = em;
        this.entityInfo = entityInfo;
    }

    @Override
    @Transactional
    public UUID acquireLock(ID id, Duration duration) {
        LocalDateTime now = LocalDateTime.now();
        int updated = em.createQuery("""
            UPDATE %s e
               SET e.lockUser = :user,
                   e.lockExpireDate = :until
             WHERE e.id = :id
               AND (
                    e.lockExpireDate IS NULL
                 OR e.lockExpireDate < :now
                 OR e.lockUser = :user
               )
        """.formatted(entityInfo.getEntityName()))
                .setParameter("id", id)
                .setParameter("user", getCurrentUser())
                .setParameter("now", now)
                .setParameter("until", now.plus(duration))
                .executeUpdate();
//        return updated == 1;
        return UUID.randomUUID();    }

    @Override
    @Transactional
    public UUID acquireLock(ID id) {
        return acquireLock(id, getLockDuration());
    }


    @Override
    @Transactional
    public void releaseLock(ID id, UUID token) {
        int updatedRowCount = em.createQuery("""
            UPDATE %s e
               SET e.lockUser = NULL,
                   e.lockExpireDate = NULL
             WHERE e.id = :id
               AND e.lockUser = :user
               AND e.lockExpireDate < :now
        """.formatted(entityInfo.getEntityName()))
                .setParameter("id", id)
                .setParameter("user", getCurrentUser())
                .setParameter("now", LocalDateTime.now())
                .executeUpdate();
        if(updatedRowCount != 1) {
            throw new LockExpiredException();
        }
    }

    @Transactional
    @Override
    public <R> R executeWithLock(ID id, Duration duration, Supplier<R> action) {
        UUID token = acquireLock(id, duration);
        try {
            // business logic (find/save/delete) runs here
            return action.get();
        } finally {
            releaseLock(id, token);
        }
    }

    // --- Override mutating methods ---
    @Override
    @Transactional
    public <S extends T> S save(S entity) {
        validateLock(entity);
        return super.save(entity);
    }

    @Override
    @Transactional
    public <S extends T> List<S> saveAll(Iterable<S> entities) {
        for (S e : entities) validateLock(e);
        return super.saveAll(entities);
    }

    @Override
    @Transactional
    public void delete(T entity) {
        validateLock(entity);
        super.delete(entity);
    }

    @Override
    @Transactional
    public void deleteAll(Iterable<? extends T> entities) {
        for (T e : entities) validateLock(e);
        super.deleteAll(entities);
    }

    private Duration getLockDuration() {
        LockTimeout lockAnnotation = AnnotatedElementUtils.findMergedAnnotation(entityInfo.getJavaType(), LockTimeout.class);
        if (lockAnnotation != null) {
            return Duration.ofSeconds(lockAnnotation.value());
        }
        return Duration.ofMinutes(15); // default fallback
    }

    private void validateLock(T entity) {
        String currentUser = getCurrentUser();
//        if (!entity.isLockValid(currentUser)) {
//            throw new LockExpiredException();
//        }
    }

    private String getCurrentUser() {
        return "Hakan";
//        return SecurityContextHolder.getContext().getAuthentication().getName();
    }

    @Override
    public LockInfo currentLockHolder(ID id) {
        return new LockInfo(UUID.randomUUID(), "User1", Instant.now().plus(15, ChronoUnit.MINUTES));
    }
}
