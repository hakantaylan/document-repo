package com.example.repo.poc.repository;

import org.springframework.data.repository.NoRepositoryBean;

import java.time.Duration;
import java.util.UUID;
import java.util.function.Supplier;

@NoRepositoryBean
public interface LockAwareRepository<ID> {

    UUID acquireLock(ID id);

    UUID acquireLock(ID id, Duration duration);

    void releaseLock(ID id, UUID token);

    LockInfo currentLockHolder(ID id);

    <R> R executeWithLock(ID id, Duration duration, Supplier<R> action);
}
