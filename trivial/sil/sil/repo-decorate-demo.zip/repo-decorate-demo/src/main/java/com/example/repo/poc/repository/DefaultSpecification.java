package com.example.repo.poc.repository;

import org.springframework.data.jpa.domain.Specification;

public class DefaultSpecification {

    public static <T> Specification<T> always() {
        return (root, query, cb) -> cb.conjunction();
    }

//    public static <T> Specification<T> withDefault2(Specification<T> spec) {
//        return spec == null ? always() : always().and(spec);
//    }

    public static <T> Specification<T> withDefault(Specification<T> spec) {
        return spec == null ? always() : DefaultSpecification.<T>always().and(spec);
    }
}
