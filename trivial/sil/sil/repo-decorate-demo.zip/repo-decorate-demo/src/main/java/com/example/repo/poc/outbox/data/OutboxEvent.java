package com.example.repo.poc.outbox.data;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "outbox")
@Getter
@Setter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class OutboxEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID )
    @UuidGenerator(style = UuidGenerator.Style.VERSION_7)
    private UUID id;

    private String aggregateType;
    private Long aggregateId;

    @Enumerated(EnumType.STRING)
    @Column(length = 6)
    private OutboxEventType eventType;

    @Column(columnDefinition = "json")
    private String payload;
    @Builder.Default
    private Instant occurredAt = Instant.now();
}