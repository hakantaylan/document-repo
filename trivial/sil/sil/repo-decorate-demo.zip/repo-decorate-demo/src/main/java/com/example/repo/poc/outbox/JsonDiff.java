package com.example.repo.poc.outbox;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.JsonNodeFactory;
import tools.jackson.databind.node.MissingNode;
import tools.jackson.databind.node.NullNode;
import tools.jackson.databind.node.ObjectNode;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

public final class JsonDiff {

    private JsonDiff() {
    }

    private static final JsonNode MISSING = MissingNode.getInstance();

    /**
     * Returns a JsonNode that contains only fields that differ between source and target.
     * If nothing changed, returns MissingNode.
     */
    public static JsonNode diff(JsonNode source, JsonNode target) {
        if (Objects.equals(source, target)) {
            return MISSING;
        }

        if (source == null || source.isMissingNode()) {
            return target == null ? NullNode.getInstance() : target;
        }
        if (target == null || target.isMissingNode()) {
            return NullNode.getInstance(); // explicit replace with null
        }

        if (source.isObject() && target.isObject()) {
            ObjectNode patch = JsonNodeFactory.instance.objectNode();

            // union of field names
            Set<String> names = new LinkedHashSet<>(source.propertyNames());
//            Iterator<String> itSrc = source.propfieldNames();
//            while (itSrc != null && itSrc.hasNext()) {
//                names.add(itSrc.next());
//            }
//            Iterator<String> itTgt = target.fieldNames();
//            while (itTgt != null && itTgt.hasNext()) {
//                names.add(itTgt.next());
//            }
            names.addAll(target.propertyNames());

            for (String field : names) {
                JsonNode s = source.get(field);
                JsonNode t = target.get(field);
                JsonNode childPatch = diff(s == null ? MISSING : s, t == null ? MISSING : t);
                if (childPatch != null && !childPatch.isMissingNode()) {
                    patch.set(field, childPatch);
                }
            }
            return patch.size() == 0 ? MISSING : patch;
        }

        if (source.isArray() && target.isArray()) {
            return source.equals(target) ? MISSING : target;
        }

        // primitives / different types -> replace with target
        return target;
    }
}
