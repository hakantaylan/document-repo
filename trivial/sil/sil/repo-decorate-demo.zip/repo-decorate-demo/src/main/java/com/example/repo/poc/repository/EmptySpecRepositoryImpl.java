package com.example.repo.poc.repository;

import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

import java.util.List;

public class EmptySpecRepositoryImpl<T, ID> extends BaseRepositoryImpl<T, ID> {

    public EmptySpecRepositoryImpl(JpaEntityInformation<T, ID> entityInformation, EntityManager em) {
        super(entityInformation, em);
    }

    @Override
    public List<T> findAll() {
        return super.findAll(DefaultSpecification.always());
    }

    @Override
    public List<T> findAll(Sort sort) {
        return super.findAll(DefaultSpecification.always(), sort);
    }

    @Override
    public Page<T> findAll(Pageable pageable) {
        // HHH000104 safe: use Specification with countQuery handled by Spring Data
        return super.findAll(DefaultSpecification.always(), pageable);
    }

    @Override
    public long count() {
        return super.count(DefaultSpecification.always());
    }
}
