package com.example.repo.poc.repository;

import com.example.repo.poc.repository.exception.LockAlreadyHeldException;
import com.example.repo.poc.repository.exception.LockLostException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.Optional;
import java.util.UUID;

@Service
public class GenericLockService {

    @PersistenceContext
    private EntityManager em;

    /**
     * Acquire a lock on any entity row.
     *
     * @param entityName Table or JPA entity name
     * @param id         Primary key
     * @param ttl        Lock TTL
     * @return fencing token
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public UUID acquireLock(String entityName, Object id, Duration ttl) {
        UUID token = UUID.randomUUID();

        int updated = em.createQuery("""
            UPDATE %s e
               SET e.lock_token = :token,
                   e.lock_user = :lockUser,
                   e.lock_expires_at = %s
             WHERE e.id = :id
               AND (e.lock_token IS NULL OR e.lock_expires_at < CURRENT_TIMESTAMP)
        """.formatted(entityName, dbExpirationExpression(ttl)))
                .setParameter("id", id)
                .setParameter("token", token)
                .setParameter("lockUser", "User")
                .executeUpdate();

        if (updated != 1) {
            throw new LockAlreadyHeldException(entityName, id);
        }

        return token;
    }

    /**
     * Release lock if fencing token matches.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void releaseLock(String entityName, Object id, UUID token) {
        int updated = em.createQuery("""
            UPDATE %s e
               SET e.lock_token = NULL,
                   e.lock_expires_at = NULL,
                   e.lock_user = NULL
             WHERE e.id = :id
               AND e.lock_token = :token
        """.formatted(entityName))
                .setParameter("id", id)
                .setParameter("token", token)
                .executeUpdate();

        if (updated != 1) {
            throw new LockLostException(entityName, id);
        }
    }

    @Transactional(readOnly = true)
    public LockInfo currentLockHolder(String entityName, Object id) {
        return em.createQuery("""
            SELECT new com.example.repo.poc.repository.LockInfo(
                e.lock_token,
                e.lock_user,
                e.lock_expires_at
            )
            FROM %s e
            WHERE e.id = :id
              AND e.lock_token IS NOT NULL
              AND e.lock_expires_at > CURRENT_TIMESTAMP
        """.formatted(entityName), LockInfo.class)
                .setParameter("id", id)
//                .setParameter("now", Instant.now())
                .getSingleResult();
    }

    /**
     * Database-agnostic TTL expression.
     */
    private String dbExpirationExpression(Duration ttl) {
        long seconds = ttl.getSeconds();
        String dialect = getHibernateDialect();

        return switch (dialect) {
            case "org.hibernate.dialect.PostgreSQLDialect",
                 "org.hibernate.dialect.PostgreSQL95Dialect" ->
                    "CURRENT_TIMESTAMP + interval '" + seconds + " seconds'";
            case "org.hibernate.dialect.MySQLDialect",
                 "org.hibernate.dialect.MySQL57Dialect",
                 "org.hibernate.dialect.MySQL8Dialect" ->
                    "CURRENT_TIMESTAMP + INTERVAL " + seconds + " SECOND";
            case "org.hibernate.dialect.OracleDialect",
                 "org.hibernate.dialect.Oracle12cDialect" ->
                    "CURRENT_TIMESTAMP + NUMTODSINTERVAL(" + seconds + ", 'SECOND')";
            case "org.hibernate.dialect.H2Dialect" ->
                    "CURRENT_TIMESTAMP + INTERVAL '" + seconds + "' SECOND";
            default -> throw new UnsupportedOperationException("Unsupported Hibernate dialect: " + dialect);
        };
    }

    private String getHibernateDialect() {
        try {
//            return em.getEntityManagerFactory()
//                    .unwrap(org.hibernate.SessionFactory.class)
//                    .getJdbcServices()
//                    .getDialect()
//                    .getClass()
//                    .getName();
            SessionFactoryImplementor sfi = em.getEntityManagerFactory().unwrap(SessionFactoryImplementor.class);
            return sfi.getJdbcServices().getDialect().getClass().getName();
        } catch (Exception e) {
            throw new IllegalStateException("Cannot determine Hibernate dialect", e);
        }
    }
}
