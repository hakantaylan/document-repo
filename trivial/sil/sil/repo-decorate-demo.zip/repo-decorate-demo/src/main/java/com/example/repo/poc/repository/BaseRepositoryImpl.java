package com.example.repo.poc.repository;

import jakarta.annotation.Nullable;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.metamodel.Attribute;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.query.QueryUtils;
import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class BaseRepositoryImpl<T, ID> extends SimpleJpaRepository<T, ID> implements BaseJpaRepository<T, ID> {

    private final JpaEntityInformation<T, ID> entityInfo;
    private CrudMethodMetadata methodMetadata;
    private final JpaSpecificationExecutor<T> delegate;
    private final EntityManager em;

    public BaseRepositoryImpl(JpaEntityInformation<T, ID> entityInformation, EntityManager entityManager) {
        super(entityInformation, entityManager);
        this.entityInfo = entityInformation;
        this.delegate = this;
        this.em = entityManager;
    }


    @Override
    public void setRepositoryMethodMetadata(CrudMethodMetadata metadata) {
        super.setRepositoryMethodMetadata(metadata);
        this.methodMetadata = metadata;
    }

    private boolean hasEntityGraph() {
        return methodMetadata != null  && methodMetadata.getEntityGraph() != null;
    }

    private EntityGraph getCurrentEntityGraph() {
        return methodMetadata != null  ? methodMetadata.getEntityGraph() : null;
    }


//    @Override
//    public Page<T> findAll(Pageable pageable) {
//        if(checkEntityGraph())
//            return twoPhaseFetch(Specification.unrestricted(), pageable);
//        else
//            return super.findAll(pageable);
//    }
//
//    @Override
//    public Page<T> findAll(@Nullable Specification<T> spec, Pageable pageable) {
//        if(checkEntityGraph())
//            return twoPhaseFetch(spec, pageable);
//        else
//            return super.findAll(spec, pageable);
//    }

    @Override
    public Page<T> findAll(@Nullable Specification<T> spec, Pageable pageable) {
        if (!pageable.isPaged() || !requiresTwoPhaseFetch()) {
            // ✅ Safe path: let Spring/Hibernate handle it
            return super.findAll(spec, pageable);
        }
        // ⚠️ Risky path: HHH-9965 protection
        return findAllTwoPhase(spec, pageable);
//        // 1️⃣ Let Spring compute count & page boundaries
//        Page<T> page = super.findAll(withoutFetchJoins(spec), pageable);
//
//        if (page.isEmpty()) {
//            return page;
//        }
//
//        // 2️⃣ Extract IDs from managed entities
//        List<ID> ids = page.stream().map(entityInfo::getId).toList();
//
////        6. Step 2 – Re-fetch entities using Spring (no pagination)
//        // 3️⃣ Fetch full entities with fetch joins / EntityGraph
//        List<T> fetched = super.findAll(byIds(ids), Sort.unsorted());
//
//        return new PageImpl<>(reorder(fetched, ids), pageable, page.getTotalElements());
    }

    private Page<T> findAllTwoPhase(Specification<T> spec, Pageable pageable) {
        long total = count(spec);
        if (total == 0) {
            return Page.empty(pageable);
        }

        List<ID> ids = findIds(spec, pageable);
        List<T> content = fetchByIds(ids);

        return new PageImpl<>(content, pageable, total);
    }

    private boolean requiresTwoPhaseFetch() {
        EntityGraph graph = getCurrentEntityGraph();
        return graph != null && containsCollectionAttributes(graph);
    }

    private boolean containsCollectionAttributes(EntityGraph graph) {
        return Arrays.stream(graph.attributePaths())
                .map(this::getAttribute)
                .anyMatch(this::isCollectionAttribute);
    }

    private Attribute<?, ?> getAttribute(String name) {

        return em.getMetamodel()
                .entity(entityInfo.getJavaType())
                .getAttribute(name);
    }

    private boolean isCollectionAttribute(Attribute<?, ?> attr) {
        return attr.isCollection();
    }

    private long getCount(Specification<T> spec) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<T> root = cq.from(entityInfo.getJavaType());

        cq.select(cb.countDistinct(root));

        if (spec != null) {
            cq.where(spec.toPredicate(root, cq, cb));
        }

        return em.createQuery(cq).getSingleResult();
    }

    @SuppressWarnings("unchecked")
    private List<ID> findIds(Specification<T> spec, Pageable pageable) {

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<ID> cq = (CriteriaQuery<ID>) cb.createQuery();

        Root<T> root = cq.from(entityInfo.getJavaType());
        cq.select((Expression<ID>) root.get(entityInfo.getIdAttribute()));

        if (spec != null) {
            cq.where(spec.toPredicate(root, cq, cb));
        }

        // Apply sorting
        if (pageable.getSort().isSorted()) {
            cq.orderBy(QueryUtils.toOrders(
                    pageable.getSort(), root, cb));
        }

        TypedQuery<ID> query = em.createQuery(cq);
        query.setFirstResult((int) pageable.getOffset());
        query.setMaxResults(pageable.getPageSize());

        return query.getResultList();
    }

    private List<T> fetchByIds(List<ID> ids) {

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<T> cq = cb.createQuery(entityInfo.getJavaType());
        Root<T> root = cq.from(entityInfo.getJavaType());

        // Apply fetch graph dynamically
//        applyFetches(root);

        cq.select(root).distinct(true);
        cq.where(root.get(entityInfo.getIdAttribute()).in(ids));

        List<T> result = em.createQuery(cq).getResultList();

        // Preserve original order
        Map<ID, T> map = result.stream()
                .collect(Collectors.toMap(
                        entityInfo::getId, Function.identity()));

        return ids.stream()
                .map(map::get)
                .filter(Objects::nonNull)
                .toList();
    }
    //    7. Supporting Specifications (Spring-native)
//    Remove fetch joins (critical)
    private Specification<T> withoutFetchJoins(@Nullable Specification<T> spec) {

        return (root, query, cb) -> {
            query.distinct(true);

            // Disable fetch joins
            root.getFetches().clear();

            return spec == null ? null : spec.toPredicate(root, query, cb);
        };
    }

//    Fetch by IDs
    private Specification<T> byIds(List<ID> ids) {
        return (root, query, cb) -> {
            query.distinct(true);
            return root
                    .get(entityInfo.getIdAttribute())
                    .in(ids);
        };
    }

//8. Order preservation (still required)
    private List<T> reorder(List<T> fetched, List<ID> ids) {

        Map<ID, T> map = fetched.stream()
                .collect(Collectors.toMap(
                        entityInfo::getId,
                        Function.identity()));

        return ids.stream()
                .map(map::get)
                .toList();
    }

    /* -------------------------------------------------
     * TWO-PHASE ENGINE
     * ------------------------------------------------- */
    private Page<T> twoPhaseFetch(@Nullable Specification<T> spec, Pageable pageable) {
        Page<ID> idPage = fetchIdPage(spec, pageable);
        if (idPage.isEmpty()) {
            return Page.empty(pageable);
        }

        List<T> entities = super.findAllById(idPage.getContent());

        Map<ID, T> entityMap = entities.stream()
                .collect(Collectors.toMap(
                        entityInfo::getId,
                        Function.identity()
                ));

        List<T> ordered = idPage.getContent().stream()
                .map(entityMap::get)
                .toList();

        return new PageImpl<>(ordered, pageable, idPage.getTotalElements());
    }

    private boolean checkEntityGraph(){
//        PART 5 — Fail-Fast Mode (Optional but Recommended)
//        if (hasEntityGraph() && failOnFetchGraphPagination) {
//            throw new IllegalStateException("""
//        Pageable + EntityGraph detected.
//        Two-phase pagination enforced.
//        Disable failOnFetchGraphPagination to allow.
//    """);
//        }
        boolean hasEntityGraph = hasEntityGraph();
        if (hasEntityGraph) {
            log.warn("""
                Pageable + EntityGraph detected.
                Applying two-phase pagination to avoid HHH-9965.
                Repository method: {}
            """, methodMetadata.getMethod().toGenericString());
        }
        return hasEntityGraph;
    }

    /* -------------------------------------------------
     * PHASE 1 — SAFE ID PAGE
     * ------------------------------------------------- */
    private Page<ID> fetchIdPage(@Nullable Specification<T> spec, Pageable pageable) {
        TypedQuery<T> query = getQuery(spec, pageable);

        query.setFirstResult((int) pageable.getOffset());
        query.setMaxResults(pageable.getPageSize());

        List<T> content = query.getResultList();

        List<ID> ids = content.stream()
                .map(entityInfo::getId)
                .toList();

        long total = count(spec);

        return new PageImpl<>(ids, pageable, total);
    }

    // Optional: intercept any attempt to use LockModeType.PESSIMISTIC_* via AOP
    public void checkLockMode() {
        //Diğer pesimistic lock mode'lar da buraya eklenebilir.
        if(methodMetadata != null && methodMetadata.getLockModeType() == LockModeType.PESSIMISTIC_WRITE)
//        if (lockMode != null && lockMode != LockModeType.NONE) {
            throw new UnsupportedOperationException("Pessimistic locks are forbidden due to replication issues.");
    }

//    @Override
    public boolean tryLock(T id, String username) {
        int updated = em.createQuery("""
                UPDATE Order o
                SET o.lockedBy = :username, o.lockTime = :now
                WHERE o.id = :id
                  AND (o.lockedBy IS NULL OR o.lockTime < :expiry)
                """)
                .setParameter("username", username)
                .setParameter("now", Instant.now())
                .setParameter("id", id)
                .setParameter("expiry", Instant.now().minusSeconds(15 * 60))
                .executeUpdate();

        return updated > 0;
    }

//    @Override
    public void unlock(T id, String username) {
        em.createQuery("""
                UPDATE Order o
                SET o.lockedBy = NULL, o.lockTime = NULL
                WHERE o.id = :id AND o.lockedBy = :username
                """)
                .setParameter("id", id)
                .setParameter("username", username)
                .executeUpdate();
    }


}
