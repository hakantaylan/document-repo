//package com.example.repo.poc.outbox;
//
//
//import tools.jackson.core.type.TypeReference;
//import tools.jackson.databind.JsonNode;
//import tools.jackson.databind.json.JsonMapper;
//import tools.jackson.databind.node.ObjectNode;
//
//import java.util.Collection;
//import java.util.Map;
//import java.util.Objects;
//
//public class JsonDeltaUtil {
//
//    private static final JsonMapper mapper = new JsonMapper();
//
//    public static String computeDelta2(Object oldObj, Object newObj) {
//        if (oldObj == null) {
//            try {
//                return mapper.writeValueAsString(newObj);
//            } catch (Exception e) {
//                throw new RuntimeException(e);
//            }
//        }
//        try {
//            JsonNode oldNode = mapper.valueToTree(oldObj);
//            JsonNode newNode = mapper.valueToTree(newObj);
//            ObjectNode delta = mapper.createObjectNode();
//            Collection<String> propertyNames = newNode.propertyNames();
//            for (String field : propertyNames) {
//                if (!oldNode.has(field) || !oldNode.get(field).equals(newNode.get(field))) {
//                    delta.set(field, newNode.get(field));
//                }
//            }
//            return mapper.writeValueAsString(delta);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//    public static String computeDelta(Object oldObj, Object newObj) {
//        try {
//            if (oldObj == null) {
//                return mapper.writeValueAsString(newObj);
//            }
//            JsonNode oldNode = mapper.valueToTree(oldObj);
//            JsonNode newNode = mapper.valueToTree(newObj);
//            ObjectNode delta = mapper.createObjectNode();
//
//            // Convert the ObjectNode (or any JsonNode) to a Map so we can iterate keys/values
//            Map<String, JsonNode> newMap = mapper.convertValue(newNode, new TypeReference<>() {
//            });
//
//            for (Map.Entry<String, JsonNode> e : newMap.entrySet()) {
//                String field = e.getKey();
//                JsonNode newVal = e.getValue();
//                JsonNode oldVal = oldNode.get(field); // null if missing
//                if (!Objects.equals(oldVal, newVal)) {
//                    // Jackson 3: prefer replace(...) if set(...) does not compile
//                    delta.replace(field, newVal);
//                }
//            }
//
//            return mapper.writeValueAsString(delta);
//        } catch (Exception ex) {
//            throw new RuntimeException(ex);
//        }
//    }
//}