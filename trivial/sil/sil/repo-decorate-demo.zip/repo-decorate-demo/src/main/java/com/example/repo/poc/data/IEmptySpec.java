package com.example.repo.poc.data;

public interface IEmptySpec {
}
