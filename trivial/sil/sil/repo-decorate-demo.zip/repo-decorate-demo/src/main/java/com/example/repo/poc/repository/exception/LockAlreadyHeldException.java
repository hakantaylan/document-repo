package com.example.repo.poc.repository.exception;

public class LockAlreadyHeldException extends RuntimeException {

    public LockAlreadyHeldException(String entity, Object id) {
        super("Lock already held on " + entity + " with ID " + id);
    }
}
