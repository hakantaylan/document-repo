package com.example.repo.poc.repository;

import com.example.repo.poc.outbox.data.OutboxEventType;
import com.example.repo.poc.outbox.OutboxPublisher;
import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public class EmptySpecOutboxRepositoryImpl<T, ID> extends BaseRepositoryImpl<T, ID> {


    private final OutboxPublisher<T> publisher;

    @SuppressWarnings("unchecked")
    public EmptySpecOutboxRepositoryImpl(JpaEntityInformation<T, ID> entityInformation,
                                         EntityManager em,
                                         OutboxPublisher<?> publisher) {
        super(entityInformation, em);
        this.publisher = (OutboxPublisher<T>) publisher;
    }

    @Override
    public List<T> findAll() {
        return super.findAll(DefaultSpecification.always());
    }

    @Override
    @Transactional
    public <S extends T> S save(S entity) {
        S saved = super.save(entity);
        publisher.publish(saved, OutboxEventType.UPDATE);
        return saved;
    }

    @Override
    @Transactional
    public <S extends T> List<S> saveAll(Iterable<S> entities) {
        List<S> savedList = super.saveAll(entities);
        savedList.forEach(e -> publisher.publish(e, OutboxEventType.UPDATE));
        return savedList;
    }
}