package com.example.repo.poc.outbox;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.time.temporal.TemporalAccessor;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

@Service
public class PatchService {
    private final ObjectMapper objectMapper;
    @PersistenceContext // optional: set in Spring context to enable id-based loads
    private EntityManager em;

    public PatchService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Transactional
    public <T> T applyPatchToEntity(T entity, JsonNode patch) {
        try {
            mergeObject(entity, patch);
            return entity;
        } catch (ReflectiveOperationException ex) {
            throw new RuntimeException("Failed to apply patch", ex);
        }
    }

    private void mergeObject(Object target, JsonNode patch) throws ReflectiveOperationException {
        if (patch == null || patch.isMissingNode() || !patch.isObject()) return;

        Class<?> clazz = target.getClass();
        Iterator<String> fieldNames = patch.propertyNames().iterator();
        while (fieldNames.hasNext()) {
            String fieldName = fieldNames.next();
            JsonNode valueNode = patch.get(fieldName);

            Field field = findField(clazz, fieldName);
            if (field == null) {
                // unknown field: ignore or log
                continue;
            }
            field.setAccessible(true);
            Class<?> fieldType = field.getType();
            if (valueNode == null || valueNode.isNull()) {
                field.set(target, null);
                continue;
            }

            // Simple value types -> convert and set
            if (isSimpleValue(fieldType)) {
                Object converted = objectMapper.convertValue(valueNode, objectMapper.getTypeFactory().constructType(field.getGenericType()));
                field.set(target, converted);
                continue;
            }

            // Collections / Maps -> convert whole collection and set (replace policy)
            if (Collection.class.isAssignableFrom(fieldType) || Map.class.isAssignableFrom(fieldType)) {
                Object converted = objectMapper.convertValue(valueNode, objectMapper.getTypeFactory().constructType(field.getGenericType()));
                field.set(target, converted);
                continue;
            }

            // Nested object/entity:
            Object currentChild = field.get(target);

            // If patch provides an "id", try to load managed entity from EntityManager
            if (valueNode.isObject() && valueNode.has("id") && em != null) {
                JsonNode idNode = valueNode.get("id");
                Object idVal = null;
                if (idNode.isNumber()) {
                    idVal = idNode.longValue(); // common case; adjust if PK type differs
                } else if (idNode.isTextual()) {
                    idVal = idNode.asText();
                }
                if (idVal != null) {
                    try {
                        Object loaded = em.find(fieldType, idVal);
                        if (loaded != null) {
                            // set and then merge into that managed entity
                            field.set(target, loaded);
                            mergeObject(loaded, valueNode);
                            continue;
                        }
                    } catch (IllegalArgumentException ignored) {
                        // em.find may throw if id type mismatches; fall back to instance creation below
                    }
                }
            }

            if (currentChild == null) {
                // create new instance if possible
                try {
                    Constructor<?> ctor = fieldType.getDeclaredConstructor();
                    ctor.setAccessible(true);
                    currentChild = ctor.newInstance();
                    field.set(target, currentChild);
                } catch (NoSuchMethodException e) {
                    // cannot create instance; fallback: convert valueNode to fieldType and set
                    Object converted = objectMapper.convertValue(valueNode, fieldType);
                    field.set(target, converted);
                    continue;
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }

            // merge recursively
            mergeObject(currentChild, valueNode);
        }
    }

    private boolean isSimpleValue(Class<?> cls) {
        return cls.isPrimitive()
                || Number.class.isAssignableFrom(cls)
                || CharSequence.class.isAssignableFrom(cls)
                || Boolean.class.isAssignableFrom(cls)
                || Date.class.isAssignableFrom(cls)
                || TemporalAccessor.class.isAssignableFrom(cls)
                || cls.isEnum();
    }

    private Field findField(Class<?> clazz, String name) {
        Class<?> cur = clazz;
        while (cur != null && cur != Object.class) {
            try {
                return cur.getDeclaredField(name);
            } catch (NoSuchFieldException ex) {
                cur = cur.getSuperclass();
            }
        }
        return null;
    }
}
