package com.example.repo.poc.data;

import jakarta.persistence.*;
import lombok.Getter;

import java.io.Serializable;

@MappedSuperclass
@Getter
public abstract class BaseEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Version
    private Long version;
}
