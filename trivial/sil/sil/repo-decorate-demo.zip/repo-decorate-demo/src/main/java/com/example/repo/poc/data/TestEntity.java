package com.example.repo.poc.data;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class TestEntity extends BaseEntity implements IEmptySpec, IOutbox {

    private String name;
    private int quantity;

}