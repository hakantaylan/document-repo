package com.example.repo.poc.repository;

import com.example.repo.poc.repository.annotation.LockTimeout;
import jakarta.persistence.EntityManager;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.UUID;
import java.util.function.Supplier;

public class LockAwareRepositoryImpl2<T, ID> extends SimpleJpaRepository<T, ID> implements LockAwareRepository<ID> {

    private final JpaEntityInformation<T, ?> entityInfo;
    private final FencingLockService lockService;

    public LockAwareRepositoryImpl2(JpaEntityInformation<T, ID> entityInfo, FencingLockService lockService, EntityManager em) {
        super(entityInfo, em);
        this.entityInfo = entityInfo;
        this.lockService = lockService;
    }

    @Override
    public UUID acquireLock(ID id, Duration duration) {
        return lockService.acquireLock(entityInfo.getEntityName(), id, duration);
    }

    @Override
    public UUID acquireLock(ID id) {
        return acquireLock(id, getLockDuration());
    }

    @Override
    public void releaseLock(ID id, UUID token) {
        lockService.releaseLock(entityInfo.getEntityName(), id, token);
    }

    @Transactional
    @Override
    public <R> R executeWithLock(ID id, Duration duration, Supplier<R> action) {
        UUID token = acquireLock(id, duration);
        try {
            // business logic (find/save/delete) runs here
            return action.get();
        } finally {
            releaseLock(id, token);
        }
    }

    private Duration getLockDuration() {
        LockTimeout lockAnnotation = AnnotatedElementUtils.findMergedAnnotation(entityInfo.getJavaType(), LockTimeout.class);
        if (lockAnnotation != null) {
            return Duration.ofSeconds(lockAnnotation.value());
        }
        return Duration.ofMinutes(15); // default fallback
    }

    @Override
    public LockInfo currentLockHolder(ID id) {
        return lockService.currentLockHolder(entityInfo.getEntityName(), id);
    }
}
