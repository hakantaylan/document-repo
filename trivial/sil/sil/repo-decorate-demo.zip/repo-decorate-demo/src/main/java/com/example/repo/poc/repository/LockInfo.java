package com.example.repo.poc.repository;

import java.time.Instant;
import java.util.UUID;

public record LockInfo(UUID fencingToken, String owner, Instant expiresAt) {}
