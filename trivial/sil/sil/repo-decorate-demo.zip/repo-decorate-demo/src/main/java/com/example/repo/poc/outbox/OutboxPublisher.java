package com.example.repo.poc.outbox;

import com.example.repo.poc.outbox.data.OutboxEventType;

public interface OutboxPublisher<T> {

    void publish(T entity, OutboxEventType eventType);
}
