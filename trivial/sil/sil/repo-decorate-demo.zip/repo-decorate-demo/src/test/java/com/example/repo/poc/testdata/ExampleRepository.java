package com.example.repo.poc.testdata;

import com.example.repo.poc.repository.BaseJpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;

import java.util.List;

public interface ExampleRepository extends BaseJpaRepository<Person, Long> {
    @EntityGraph(attributePaths = "addresses")
        // spring-data-jpa annotation
    List<Person> findByLastName(String lastName);
}
