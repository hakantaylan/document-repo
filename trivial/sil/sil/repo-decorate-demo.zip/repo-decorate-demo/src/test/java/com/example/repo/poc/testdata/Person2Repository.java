package com.example.repo.poc.testdata;

import org.jspecify.annotations.Nullable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Person2Repository extends JpaRepository<Person, Long>, JpaSpecificationExecutor<Person> {
    @EntityGraph(attributePaths = "addresses")
        // spring-data-jpa annotation
    List<Person> findByLastName(String lastName);

    @Override
    @EntityGraph(attributePaths = "addresses")
    Page<Person> findAll(@Nullable Specification<Person> spec, Pageable pageable);
}
