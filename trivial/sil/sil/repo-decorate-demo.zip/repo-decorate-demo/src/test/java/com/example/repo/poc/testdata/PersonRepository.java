package com.example.repo.poc.testdata;

import com.example.repo.poc.repository.BaseJpaRepository;
import org.jspecify.annotations.Nullable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PersonRepository extends BaseJpaRepository<Person, Long> {
    @EntityGraph(attributePaths = "addresses")
        // spring-data-jpa annotation
    List<Person> findByLastName(String lastName);

    @Override
    @EntityGraph(attributePaths = "lastName")
    Page<Person> findAll(@Nullable Specification<Person> spec, Pageable pageable);
}
