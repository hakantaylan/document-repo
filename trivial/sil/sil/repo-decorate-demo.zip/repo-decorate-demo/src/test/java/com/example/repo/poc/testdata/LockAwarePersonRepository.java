package com.example.repo.poc.testdata;

import com.example.repo.poc.repository.LockAwareRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LockAwarePersonRepository extends JpaRepository<Person, Long>, LockAwareRepository<Long> {
}
