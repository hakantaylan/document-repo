package com.example.repo.poc;

import com.example.repo.poc.outbox.JsonDiff;
import com.example.repo.poc.outbox.PatchService;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import static org.junit.jupiter.api.Assertions.*;

public class PatchServiceTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void diffAndApply_updatesOnlyChangedFields() {
        // create original
        Parent original = new Parent();
        original.setId(1L);
        original.setName("Alice");
        Child child = new Child();
        child.setId(2L);
        child.setChildField("origChild");
        GrandChild gc = new GrandChild();
        gc.setId(3L);
        gc.setGcField("origGC");
        child.setGrandChild(gc);
        original.setChild(child);

        // create updated with changes in child and grandchild
        Parent updated = new Parent();
        updated.setId(1L);
        updated.setName("Alice"); // unchanged
        Child updatedChild = new Child();
        updatedChild.setId(2L);
        updatedChild.setChildField("updatedChild"); // changed
        GrandChild updatedGc = new GrandChild();
        updatedGc.setId(3L);
        updatedGc.setGcField("newGC"); // changed
        updatedChild.setGrandChild(updatedGc);
        updated.setChild(updatedChild);

        JsonNode origNode = mapper.valueToTree(original);
        JsonNode updatedNode = mapper.valueToTree(updated);

        JsonNode patch = JsonDiff.diff(origNode, updatedNode);
        assertNotNull(patch);
        assertFalse(patch.isMissingNode(), "patch should not be MissingNode when changes exist");

        // basic checks that patch contains expected fields
        assertTrue(patch.has("child"));
        JsonNode childPatch = patch.get("child");
        assertTrue(childPatch.has("childField"), "child childField should be in patch");
        assertEquals("updatedChild", childPatch.get("childField").asText());
        assertTrue(childPatch.has("grandChild"));
        assertEquals("newGC", childPatch.get("grandChild").get("gcField").asText());

        // Apply patch
        PatchService patchService = new PatchService(mapper); // em will be null, that's fine for this test
        patchService.applyPatchToEntity(original, patch);

        // verify original was updated in-place
        assertEquals("Alice", original.getName()); // unchanged
        assertNotNull(original.getChild());
        assertEquals("updatedChild", original.getChild().getChildField());
        assertNotNull(original.getChild().getGrandChild());
        assertEquals("newGC", original.getChild().getGrandChild().getGcField());
    }

    @Test
    void diffAndApply_nullsOutNestedObjectWhenRequested() {
        // original with nested grandchild
        Parent original = new Parent();
        original.setId(10L);
        original.setName("Bob");
        Child child = new Child();
        child.setId(20L);
        child.setChildField("childVal");
        GrandChild gc = new GrandChild();
        gc.setId(30L);
        gc.setGcField("gcVal");
        child.setGrandChild(gc);
        original.setChild(child);

        // updated where grandChild is explicitly null
        Parent updated = new Parent();
        updated.setId(10L);
        updated.setName("Bob");
        Child updatedChild = new Child();
        updatedChild.setId(20L);
        updatedChild.setChildField("childVal"); // unchanged
        updatedChild.setGrandChild(null); // explicit null -> should remove
        updated.setChild(updatedChild);

        JsonNode patch = JsonDiff.diff(mapper.valueToTree(original), mapper.valueToTree(updated));
        assertNotNull(patch);
        assertFalse(patch.isMissingNode());
        assertTrue(patch.has("child"));
        JsonNode childPatch = patch.get("child");
        assertTrue(childPatch.has("grandChild"));
        assertTrue(childPatch.get("grandChild").isNull(), "patch should explicitly contain null for grandChild");

        PatchService patchService = new PatchService(mapper);
        patchService.applyPatchToEntity(original, patch);

        // after applying, grandChild must be null
        assertNotNull(original.getChild());
        assertNull(original.getChild().getGrandChild(), "grandChild should be nulled by patch");
    }

    // --- simple POJOs used only for tests (inner classes) ---
    public static class Parent {
        private Long id;
        private String name;
        private Child child;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public Child getChild() { return child; }
        public void setChild(Child child) { this.child = child; }
    }

    public static class Child {
        private Long id;
        private String childField;
        private GrandChild grandChild;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }

        public String getChildField() { return childField; }
        public void setChildField(String childField) { this.childField = childField; }

        public GrandChild getGrandChild() { return grandChild; }
        public void setGrandChild(GrandChild grandChild) { this.grandChild = grandChild; }
    }

    public static class GrandChild {
        private Long id;
        private String gcField;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }

        public String getGcField() { return gcField; }
        public void setGcField(String gcField) { this.gcField = gcField; }
    }
}
