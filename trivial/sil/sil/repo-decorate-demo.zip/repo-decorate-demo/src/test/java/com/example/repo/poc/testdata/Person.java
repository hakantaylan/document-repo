package com.example.repo.poc.testdata;

import jakarta.persistence.*;

import java.util.LinkedList;
import java.util.List;

@Entity
public class Person {
    @Id
    @GeneratedValue
    Long id;
    String lastName;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    List<Address> addresses = new LinkedList<>();
}