package com.example.repo.poc;

import com.example.repo.poc.testdata.ExampleRepository;
import com.example.repo.poc.testdata.Person;
import com.example.repo.poc.testdata.Person2Repository;
import com.example.repo.poc.testdata.PersonRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

@SpringBootTest
class EntityGraphSpringBootTest {

    @Autowired
    PersonRepository personRepository;

    @Autowired
    Person2Repository personRepository2;

    @Autowired
    ExampleRepository exampleRepository;

    @Test
    void obtainCrudMethodMetadataFromRepositoryMethod() {
        Page<Person> all = personRepository.findAll(Specification.unrestricted(), Pageable.ofSize(100));
        System.out.println("----------------------");
        personRepository2.findAll();
        exampleRepository.findAll();
    }

//    @TestConfiguration
//    @EnableAutoConfiguration
//    @EnableJpaRepositories(
//            basePackageClasses = EntityGraphSpringBootTest.ExampleRepository.class,
//            repositoryFactoryBeanClass = ConditionalRepositoryFactoryBean.class
//    )
//    @EntityScan(basePackageClasses = {
//            EntityGraphSpringBootTest.ExamplePerson.class,
//            EntityGraphSpringBootTest.ExampleAddress.class
//    })
//    static class TestConfig {
//        // if your ConditionalRepositoryFactoryBean depends on an OutboxPublisher, provide a test bean:
//        // @Bean OutboxPublisher<?> outboxPublisher() { return ...; }
//    }


}
