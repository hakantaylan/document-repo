package com.example.repo.poc;

import com.example.repo.poc.data.TestEntity;
import com.example.repo.poc.outbox.OutboxConsumer;
import com.example.repo.poc.outbox.data.OutboxEvent;
import com.example.repo.poc.outbox.repository.OutboxEventRepository;
import com.example.repo.poc.repository.TestEntityRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class EndToEndPipelineTest {

    @Autowired
    private TestEntityRepository repository;

    @Autowired
    private OutboxConsumer consumer;

    @Autowired
    private OutboxEventRepository outboxRepository;

    @Test
    @Transactional
    void testPaginationAndJsonDelta() {
        for (int i = 0; i < 25; i++) {
            TestEntity e = new TestEntity();
            e.setName("Item-" + i);
            e.setQuantity(i);
            repository.save(e);
        }

        // Pagination test
        var page = repository.findAll(PageRequest.of(0, 10));
        assertEquals(10, page.getContent().size());

        // Check that outbox events were published
        List<OutboxEvent> events = outboxRepository.findAll();
        assertEquals(25, events.size());
        assertTrue(events.get(0).getPayload().contains("Item-"));
    }

    @Test
    @Transactional
    void testOutboxConsumerAppliesDelta() {
        TestEntity e = new TestEntity();
        e.setName("Original");
        e.setQuantity(5);
        repository.save(e);

        Long entityId = e.getId();
        OutboxEvent event = outboxRepository.findAll().get(0);

        // Simulate a downstream change: update name
        TestEntity modified = repository.findById(entityId).orElseThrow();
        modified.setName("Updated");
        repository.save(modified);

        OutboxEvent deltaEvent = outboxRepository.findAll().get(1);

        // Consumer applies only changed fields
        consumer.process(deltaEvent);

        TestEntity updated = repository.findById(entityId).orElseThrow();
        assertEquals("Updated", updated.getName());
        assertEquals(5, updated.getQuantity()); // quantity unchanged
    }

    @Test
//    @Transactional
    void testConcurrentUpdates() throws Exception {
        TestEntity e = new TestEntity();
        e.setName("Concurrent");
        e.setQuantity(10);
        e = repository.save(e);

        Long entityId = e.getId();

        ExecutorService executor = Executors.newFixedThreadPool(2);

        Callable<Void> task1 = () -> {
            TestEntity t1 = repository.findById(entityId).orElseThrow();
            t1.setQuantity(t1.getQuantity() + 1);
            repository.save(t1);
            return null;
        };

        Callable<Void> task2 = () -> {
            TestEntity t2 = repository.findById(entityId).orElseThrow();
            t2.setQuantity(t2.getQuantity() + 2);
            repository.save(t2);
            return null;
        };

        Future<Void> f1 = executor.submit(task1);
        Future<Void> f2 = executor.submit(task2);

        f1.get();
        f2.get();

        executor.shutdown();

        TestEntity finalEntity = repository.findById(entityId).orElseThrow();
        // Final quantity should be 13 (10 +1+2)
        assertEquals(13, finalEntity.getQuantity());
    }
}