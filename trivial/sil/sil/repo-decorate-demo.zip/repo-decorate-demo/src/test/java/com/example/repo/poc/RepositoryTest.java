package com.example.repo.poc;

import com.example.repo.poc.repository.*;
import com.example.repo.poc.testdata.LockAwarePersonRepository;
import com.example.repo.poc.testdata.Person2Repository;
import org.junit.jupiter.api.Test;
import org.springframework.aop.support.AopUtils;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.Repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class RepositoryTest {

    @Test
    public void test_Repositories_Constructed_Correctly(ApplicationContext ctx) {
        OrderRepository orderRepository = ctx.getBean(OrderRepository.class);
        assertEquals(BaseRepositoryImpl.class, AopUtils.getTargetClass(orderRepository));

        Person2Repository person2Repository = ctx.getBean(Person2Repository.class);
        assertEquals(SimpleJpaRepository.class, AopUtils.getTargetClass(person2Repository));

        TestEntityRepository testEntityRepository = ctx.getBean(TestEntityRepository.class);
        assertEquals(EmptySpecOutboxRepositoryImpl.class, AopUtils.getTargetClass(testEntityRepository));

        LockAwarePersonRepository lockAwarePersonRepository = ctx.getBean(LockAwarePersonRepository.class);
        assertEquals(LockAwareRepositoryImpl2.class, AopUtils.getTargetClass(lockAwarePersonRepository));

        ctx.getBeansOfType(Repository.class)
                .forEach((name, repo) ->
                        System.out.println(name + " -> " + AopUtils.getTargetClass(repo).getName())
                );
    }
}
