package com.example.common.persistence.starter.repository;

import com.example.common.persistence.model.BaseEntity;
import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.support.*;

import java.util.List;

public class CommonJpaRepository<T extends BaseEntity, ID>
        extends SimpleJpaRepository<T, ID> {

    private static final Logger log =
            LoggerFactory.getLogger(CommonJpaRepository.class);

    public CommonJpaRepository(
            JpaEntityInformation<T, ID> info,
            EntityManager em) {
        super(info, em);
    }

    @Override
    public List<T> findAll() {
        log.debug("CommonJpaRepository.findAll()");
        return super.findAll();
    }
}
