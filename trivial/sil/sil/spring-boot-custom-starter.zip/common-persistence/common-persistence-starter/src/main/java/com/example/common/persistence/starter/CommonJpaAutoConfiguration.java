package com.example.common.persistence.starter;

import com.example.common.persistence.starter.repository.CommonJpaRepositoryFactoryBean;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.boot.autoconfigure.*;
import org.springframework.boot.autoconfigure.condition.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@AutoConfiguration
@ConditionalOnClass({ JpaRepository.class, EntityManager.class })
@ConditionalOnBean(EntityManagerFactory.class)
@ConditionalOnProperty(
    prefix = "common.persistence.jpa",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true
)
@EnableJpaRepositories(
    repositoryFactoryBeanClass =
            CommonJpaRepositoryFactoryBean.class
)
public class CommonJpaAutoConfiguration {
}
