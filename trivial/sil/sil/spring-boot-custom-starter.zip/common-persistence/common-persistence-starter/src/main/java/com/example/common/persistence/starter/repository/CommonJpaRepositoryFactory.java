package com.example.common.persistence.starter.repository;

import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.repository.support.*;
import org.springframework.data.repository.core.*;

public class CommonJpaRepositoryFactory extends JpaRepositoryFactory {

    private final EntityManager em;

    public CommonJpaRepositoryFactory(EntityManager em) {
        super(em);
        this.em = em;
    }

    @Override
    protected Object getTargetRepository(RepositoryInformation info) {
        var entityInfo = getEntityInformation(info.getDomainType());
        return new CommonJpaRepository<>(entityInfo, em);
    }

    @Override
    protected Class<?> getRepositoryBaseClass(RepositoryMetadata metadata) {
        return CommonJpaRepository.class;
    }
}
