package com.example.common.persistence.starter.repository;

import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.repository.support.*;

public class CommonJpaRepositoryFactoryBean<T, S, ID>
        extends JpaRepositoryFactoryBean<T, S, ID> {

    public CommonJpaRepositoryFactoryBean(Class<? extends T> repoInterface) {
        super(repoInterface);
    }

    @Override
    protected JpaRepositoryFactory createRepositoryFactory(EntityManager em) {
        return new CommonJpaRepositoryFactory(em);
    }
}
