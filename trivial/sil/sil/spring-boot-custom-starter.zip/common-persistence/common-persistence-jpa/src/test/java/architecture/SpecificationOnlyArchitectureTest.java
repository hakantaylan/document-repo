package architecture;

import com.example.common.persistence.jpa.annotation.AllowedJpaEscapeHatch;
import com.tngtech.archunit.junit5.*;
import jakarta.persistence.EntityManager;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.domain.Specification;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.*;

@AnalyzeClasses(packages = "com.example")
class SpecificationOnlyArchitectureTest {

    @ArchTest
    static final ArchRule repositories_must_support_specifications =
        classes()
            .that().areInterfaces()
            .and().areAssignableTo(JpaRepository.class)
            .should().beAssignableTo(
                org.springframework.data.jpa.repository.JpaSpecificationExecutor.class
            );

    @ArchTest
    static final ArchRule no_derived_queries =
        noMethods()
            .that().haveNameMatching("findBy.*|readBy.*|getBy.*")
            .should().exist();

    @ArchTest
    static final ArchRule query_requires_escape_hatch =
        methods()
            .that().areAnnotatedWith(Query.class)
            .should().beAnnotatedWith(AllowedJpaEscapeHatch.class);

    @ArchTest
    static final ArchRule specifications_must_live_in_spec_package =
        classes()
            .that().areAssignableTo(Specification.class)
            .should().resideInAPackage("..specification..");

    @ArchTest
    static final ArchRule no_entity_manager_usage =
        noClasses()
            .should().dependOnClassesThat()
            .areAssignableTo(EntityManager.class);
}
