package com.example.common.persistence.jpa.repository;

import com.example.common.persistence.model.BaseEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface BaseRepository<T extends BaseEntity, ID>
        extends JpaRepository<T, ID>,
                JpaSpecificationExecutor<T> {
}
