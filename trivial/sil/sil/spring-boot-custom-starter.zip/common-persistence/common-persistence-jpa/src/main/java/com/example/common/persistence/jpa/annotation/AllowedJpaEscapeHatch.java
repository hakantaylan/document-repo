package com.example.common.persistence.jpa.annotation;

import java.lang.annotation.*;

@Target({ ElementType.METHOD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AllowedJpaEscapeHatch {
    String reason();
}
