package com.example.common.persistence.jpa.specification;

import com.example.common.persistence.model.*;
import org.springframework.data.jpa.domain.Specification;

import java.time.Instant;

public final class CommonSpecifications {

    private CommonSpecifications() {}

    public static <T extends TenantAwareEntity>
    Specification<T> hasTenant(String tenantId) {
        return (root, query, cb) ->
                cb.equal(root.get("tenantId"), tenantId);
    }

    public static <T extends AuditableEntity>
    Specification<T> createdAfter(Instant instant) {
        return (root, query, cb) ->
                cb.greaterThan(root.get("createdAt"), instant);
    }
}
