package com.example.common.persistence.model;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class TenantAwareEntity extends AuditableEntity {

    @Column(nullable = false, updatable = false)
    private String tenantId;

    protected void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getTenantId() {
        return tenantId;
    }
}
