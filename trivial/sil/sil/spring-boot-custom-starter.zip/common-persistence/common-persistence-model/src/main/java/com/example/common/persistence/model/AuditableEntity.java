package com.example.common.persistence.model;

import jakarta.persistence.*;
import java.time.Instant;

@MappedSuperclass
public abstract class AuditableEntity extends BaseEntity {

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant lastModifiedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.lastModifiedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        this.lastModifiedAt = Instant.now();
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getLastModifiedAt() {
        return lastModifiedAt;
    }
}
