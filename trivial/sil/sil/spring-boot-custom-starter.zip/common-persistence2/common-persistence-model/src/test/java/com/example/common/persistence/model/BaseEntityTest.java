package com.example.common.persistence.model;

import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class BaseEntityTest {

    static class TestEntity extends BaseEntity {}

    @Test
    void baseEntityId_shouldBeNullInitially() {
        TestEntity e = new TestEntity();
        assertNull(e.getId());
    }
}
