package com.example.common.persistence.jpa.repository;

import com.example.common.persistence.model.BaseEntity;
import org.junit.jupiter.api.Test;
import org.springframework.data.jpa.repository.support.*;
import org.springframework.data.repository.core.RepositoryMetadata;
import jakarta.persistence.EntityManager;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BaseRepositoryTest {

    interface TestRepo extends BaseRepository<BaseEntity, String> {}

    @Test
    void canInstantiateRepository() {
        EntityManager em = mock(EntityManager.class);
        JpaEntityInformation<BaseEntity, String> info =
                mock(JpaEntityInformation.class);
        SimpleJpaRepository<BaseEntity, String> repo =
                new SimpleJpaRepository<>(info, em);

        assertNotNull(repo);
    }
}
