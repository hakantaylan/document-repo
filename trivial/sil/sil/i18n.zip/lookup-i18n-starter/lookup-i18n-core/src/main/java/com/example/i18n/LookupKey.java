package com.example.i18n;

public interface LookupKey {
    String key();
}
