package com.example.i18n;

import org.springframework.context.MessageSource;

import java.util.Locale;
import java.util.Map;

public class LocalLookupTranslator {

    private final Map<String, LookupKey> registry;
    private final MessageSource messageSource;

    public LocalLookupTranslator(
            Map<String, LookupKey> registry,
            MessageSource messageSource
    ) {
        this.registry = registry;
        this.messageSource = messageSource;
    }

    public String translate(String key, Locale locale) {
        if (!registry.containsKey(key)) {
            throw new IllegalArgumentException(
                    "Lookup key not owned by this service: " + key
            );
        }

        return messageSource.getMessage(key, null, key, locale);
    }

    public String translate(LookupKey key, Locale locale) {
        return translate(key.key(), locale);
    }
}
