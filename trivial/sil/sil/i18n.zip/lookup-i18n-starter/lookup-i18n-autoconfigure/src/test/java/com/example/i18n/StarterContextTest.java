package com.example.i18n;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;

class StarterContextTest {

    @Test
    void autoConfiguresTranslator() {
        new ApplicationContextRunner()
                .run(ctx ->
                        assertThat(ctx)
                                .hasSingleBean(LocalLookupTranslator.class)
                );
    }
}
