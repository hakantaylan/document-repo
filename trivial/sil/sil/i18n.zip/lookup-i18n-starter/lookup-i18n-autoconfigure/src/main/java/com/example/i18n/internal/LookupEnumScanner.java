package com.example.i18n.internal;

import com.example.i18n.LookupKey;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;

import java.util.HashMap;
import java.util.Map;

public final class LookupEnumScanner {

    public static Map<String, LookupKey> scan(
            ClassLoader classLoader,
            String... basePackages
    ) {
        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AssignableTypeFilter(LookupKey.class));

        Map<String, LookupKey> registry = new HashMap<>();

        for (String basePackage : basePackages) {
            scanner.findCandidateComponents(basePackage).forEach(def -> {
                try {
                    Class<?> clazz = Class.forName(
                            def.getBeanClassName(), false, classLoader);

                    if (!clazz.isEnum()) return;

                    for (Object constant : clazz.getEnumConstants()) {
                        LookupKey key = (LookupKey) constant;
                        registry.put(key.key(), key);
                    }
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                }
            });
        }
        return Map.copyOf(registry);
    }
}
