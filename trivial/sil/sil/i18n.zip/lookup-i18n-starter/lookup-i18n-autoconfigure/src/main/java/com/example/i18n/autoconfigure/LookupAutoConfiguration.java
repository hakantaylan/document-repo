package com.example.i18n.autoconfigure;

import com.example.i18n.LocalLookupTranslator;
import com.example.i18n.internal.LookupEnumScanner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.util.Map;

@AutoConfiguration
public class LookupAutoConfiguration {

    @Bean
    LocalLookupTranslator localLookupTranslator() {
        var registry = LookupEnumScanner.scan(
                getClass().getClassLoader(),
                "com.example"
        );

        ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
        ms.setBasename("messages");
        ms.setDefaultEncoding("UTF-8");

        return new LocalLookupTranslator(registry, ms);
    }
}
