#!/usr/bin/env bash
set -e

PROJECT=lookup-i18n-starter
GROUP_ID=com.example.i18n
VERSION=1.0.0-SNAPSHOT
JAVA_VERSION=25
SPRING_BOOT_VERSION=4.0.0-M1

mkdir -p $PROJECT
cd $PROJECT

################################
# Parent pom.xml
################################
cat > pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         https://maven.apache.org/xsd/maven-4.0.0.xsd">

  <modelVersion>4.0.0</modelVersion>

  <groupId>${GROUP_ID}</groupId>
  <artifactId>lookup-i18n-starter</artifactId>
  <version>${VERSION}</version>
  <packaging>pom</packaging>

  <modules>
    <module>lookup-i18n-core</module>
    <module>lookup-i18n-autoconfigure</module>
  </modules>

  <properties>
    <java.version>${JAVA_VERSION}</java.version>
    <spring.boot.version>${SPRING_BOOT_VERSION}</spring.boot.version>
  </properties>

  <dependencyManagement>
    <dependencies>
      <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-dependencies</artifactId>
        <version>\${spring.boot.version}</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
    </dependencies>
  </dependencyManagement>

</project>
EOF

################################
# lookup-i18n-core
################################
mkdir -p lookup-i18n-core/src/main/java/com/example/i18n
cat > lookup-i18n-core/pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>

  <parent>
    <groupId>${GROUP_ID}</groupId>
    <artifactId>lookup-i18n-starter</artifactId>
    <version>${VERSION}</version>
  </parent>

  <artifactId>lookup-i18n-core</artifactId>

</project>
EOF

cat > lookup-i18n-core/src/main/java/com/example/i18n/LookupKey.java <<EOF
package com.example.i18n;

public interface LookupKey {
    String key();
}
EOF

cat > lookup-i18n-core/src/main/java/com/example/i18n/LocalLookupTranslator.java <<EOF
package com.example.i18n;

import org.springframework.context.MessageSource;

import java.util.Locale;
import java.util.Map;

public class LocalLookupTranslator {

    private final Map<String, LookupKey> registry;
    private final MessageSource messageSource;

    public LocalLookupTranslator(
            Map<String, LookupKey> registry,
            MessageSource messageSource
    ) {
        this.registry = registry;
        this.messageSource = messageSource;
    }

    public String translate(String key, Locale locale) {
        if (!registry.containsKey(key)) {
            throw new IllegalArgumentException(
                    "Lookup key not owned by this service: " + key
            );
        }

        return messageSource.getMessage(key, null, key, locale);
    }

    public String translate(LookupKey key, Locale locale) {
        return translate(key.key(), locale);
    }
}
EOF

################################
# lookup-i18n-autoconfigure
################################
mkdir -p lookup-i18n-autoconfigure/src/main/java/com/example/i18n/autoconfigure
mkdir -p lookup-i18n-autoconfigure/src/main/java/com/example/i18n/internal
mkdir -p lookup-i18n-autoconfigure/src/main/resources/META-INF/spring
mkdir -p lookup-i18n-autoconfigure/src/test/java/com/example/i18n

cat > lookup-i18n-autoconfigure/pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>

  <parent>
    <groupId>${GROUP_ID}</groupId>
    <artifactId>lookup-i18n-starter</artifactId>
    <version>${VERSION}</version>
  </parent>

  <artifactId>lookup-i18n-autoconfigure</artifactId>

  <dependencies>
    <dependency>
      <groupId>${GROUP_ID}</groupId>
      <artifactId>lookup-i18n-core</artifactId>
      <version>${VERSION}</version>
    </dependency>

    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-autoconfigure</artifactId>
    </dependency>

    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>
</project>
EOF

################################
# Enum scanner
################################
cat > lookup-i18n-autoconfigure/src/main/java/com/example/i18n/internal/LookupEnumScanner.java <<EOF
package com.example.i18n.internal;

import com.example.i18n.LookupKey;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;

import java.util.HashMap;
import java.util.Map;

public final class LookupEnumScanner {

    public static Map<String, LookupKey> scan(
            ClassLoader classLoader,
            String... basePackages
    ) {
        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AssignableTypeFilter(LookupKey.class));

        Map<String, LookupKey> registry = new HashMap<>();

        for (String basePackage : basePackages) {
            scanner.findCandidateComponents(basePackage).forEach(def -> {
                try {
                    Class<?> clazz = Class.forName(
                            def.getBeanClassName(), false, classLoader);

                    if (!clazz.isEnum()) return;

                    for (Object constant : clazz.getEnumConstants()) {
                        LookupKey key = (LookupKey) constant;
                        registry.put(key.key(), key);
                    }
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                }
            });
        }
        return Map.copyOf(registry);
    }
}
EOF

################################
# Auto-configuration
################################
cat > lookup-i18n-autoconfigure/src/main/java/com/example/i18n/autoconfigure/LookupAutoConfiguration.java <<EOF
package com.example.i18n.autoconfigure;

import com.example.i18n.LocalLookupTranslator;
import com.example.i18n.internal.LookupEnumScanner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.util.Map;

@AutoConfiguration
public class LookupAutoConfiguration {

    @Bean
    LocalLookupTranslator localLookupTranslator() {
        var registry = LookupEnumScanner.scan(
                getClass().getClassLoader(),
                "com.example"
        );

        ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
        ms.setBasename("messages");
        ms.setDefaultEncoding("UTF-8");

        return new LocalLookupTranslator(registry, ms);
    }
}
EOF

################################
# AutoConfiguration imports
################################
cat > lookup-i18n-autoconfigure/src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports <<EOF
com.example.i18n.autoconfigure.LookupAutoConfiguration
EOF

################################
# Test
################################
cat > lookup-i18n-autoconfigure/src/test/java/com/example/i18n/StarterContextTest.java <<EOF
package com.example.i18n;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;

class StarterContextTest {

    @Test
    void autoConfiguresTranslator() {
        new ApplicationContextRunner()
                .run(ctx ->
                        assertThat(ctx)
                                .hasSingleBean(LocalLookupTranslator.class)
                );
    }
}
EOF

echo "✅ lookup-i18n-starter generated successfully"
