package com.example.outbox.config;

import org.hibernate.jpa.boot.spi.IntegratorProvider;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class HibernateConfig {

    @Bean
    public IntegratorProvider outboxIntegratorProvider() {
        return () -> java.util.Collections.singletonList(new HibernateIntegrator());
    }

    @Bean
    public HibernatePropertiesCustomizer hibernatePropertiesCustomizer(IntegratorProvider integratorProvider) {
        return props -> props.put("hibernate.integrator_provider", integratorProvider);
    }
}
