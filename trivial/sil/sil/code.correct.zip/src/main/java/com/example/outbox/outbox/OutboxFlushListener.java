package com.example.outbox.outbox;

import org.hibernate.event.spi.PreFlushEvent;
import org.hibernate.event.spi.PreFlushEventListener;
import org.hibernate.Session;

import java.util.List;

public class OutboxFlushListener implements PreFlushEventListener {

    @Override
    public void onPreFlush(PreFlushEvent event) {
        Session session = event.getSession();
        List<OutboxEntity> events = OutboxCollector.drain();

        for (OutboxEntity e : events) {
            session.persist(e); // safe here, rollback-safe
        }
    }
}
