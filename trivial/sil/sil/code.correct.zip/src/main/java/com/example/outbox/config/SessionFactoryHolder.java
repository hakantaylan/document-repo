package com.example.outbox.config;

import org.hibernate.engine.spi.SessionFactoryImplementor;

public final class SessionFactoryHolder {
    private static volatile SessionFactoryImplementor sessionFactory;

    private SessionFactoryHolder() {}

    public static void set(SessionFactoryImplementor sf) {
        sessionFactory = sf;
    }

    public static SessionFactoryImplementor get() {
        return sessionFactory;
    }
}
