package com.example.outbox.service;

import com.example.outbox.outbox.OutboxCollector;
import com.example.outbox.outbox.OutboxEntity;
import com.example.outbox.outbox.OutboxRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.List;

@Service
public class OutboxService {

    private final OutboxRepository repository;

    public OutboxService(OutboxRepository repository) {
        this.repository = repository;
    }

    public void persistCollectedOutboxEvents() {
        List<OutboxEntity> events = OutboxCollector.drain();
        if (!events.isEmpty()) {
            repository.saveAll(events);
        }
    }

    public void registerTransactionSynchronization() {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(
                    new TransactionSynchronizationAdapter() {

                        @Override
                        public void beforeCommit(boolean readOnly) {
                            persistCollectedOutboxEvents();
                        }
                    }
            );
        }
    }
}
