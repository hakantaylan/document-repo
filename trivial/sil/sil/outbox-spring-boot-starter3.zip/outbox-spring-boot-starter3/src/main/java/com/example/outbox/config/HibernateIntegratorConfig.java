//package com.example.outbox.config;
//
//import com.example.outbox.outbox.OutboxFlushListener;
//import com.example.outbox.outbox.OutboxHibernateListener;
//import org.hibernate.boot.Metadata;
//import org.hibernate.boot.spi.BootstrapContext;
//import org.hibernate.engine.spi.SessionFactoryImplementor;
//import org.hibernate.event.service.spi.EventListenerRegistry;
//import org.hibernate.event.spi.EventType;
//import org.hibernate.integrator.spi.Integrator;
//import org.springframework.context.annotation.Configuration;
//
////@Configuration
//public class HibernateIntegratorConfig implements Integrator {
//
//    @Override
//    public void integrate(Metadata metadata, BootstrapContext bootstrapContext, SessionFactoryImplementor sessionFactory) {
//        Integrator.super.integrate(metadata, bootstrapContext, sessionFactory);
//        EventListenerRegistry registry = sessionFactory.getServiceRegistry().getService(EventListenerRegistry.class);
//
//        OutboxHibernateListener listener = new OutboxHibernateListener();
//
//        registry.getEventListenerGroup(EventType.POST_INSERT)
//                .appendListener(listener);
//        registry.getEventListenerGroup(EventType.POST_UPDATE)
//                .appendListener(listener);
//        registry.getEventListenerGroup(EventType.POST_DELETE)
//                .appendListener(listener);
//
////        registry.getEventListenerGroup(EventType.FLUSH)
////                .appendListener(new OutboxFlushListener());
//    }
//}
//
//
