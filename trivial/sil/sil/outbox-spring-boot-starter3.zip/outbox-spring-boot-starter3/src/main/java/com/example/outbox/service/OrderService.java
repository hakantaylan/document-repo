package com.example.outbox.service;

import com.example.outbox.domain.MyOrder;
import com.example.outbox.domain.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class OrderService {

    private final OrderRepository repository;
    private final OutboxService outboxService;

    public OrderService(OrderRepository repository, OutboxService outboxService) {
        this.repository = repository;
        this.outboxService = outboxService;
    }

    @Transactional
    public void createAndShip(UUID id) {
        outboxService.registerTransactionSynchronization();
        MyOrder myOrder = new MyOrder();
        repository.save(myOrder);
        myOrder.ship();
    }

    @Transactional
    public void rollback(UUID id) {
        outboxService.registerTransactionSynchronization();
        MyOrder myOrder = new MyOrder(id);
        repository.save(myOrder);
        throw new RuntimeException("boom");
    }
}
