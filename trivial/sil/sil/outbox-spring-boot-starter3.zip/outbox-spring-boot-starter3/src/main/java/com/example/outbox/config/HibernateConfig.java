package com.example.outbox.config;

import com.example.outbox.outbox.OutboxHibernatePostListener;
import com.example.outbox.outbox.OutboxHibernatePreListener;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class HibernateConfig {

    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @PostConstruct
    public void registerHibernateListeners() {
        OutboxHibernatePostListener outboxHibernateListener = new OutboxHibernatePostListener();
        SessionFactoryImplementor sessionFactory =
                entityManagerFactory.unwrap(SessionFactoryImplementor.class);

        EventListenerRegistry registry = sessionFactory.getServiceRegistry()
                .getService(EventListenerRegistry.class);

        registry.getEventListenerGroup(EventType.POST_INSERT)
                .appendListener(outboxHibernateListener);
        registry.getEventListenerGroup(EventType.POST_UPDATE)
                .appendListener(outboxHibernateListener);
        registry.getEventListenerGroup(EventType.POST_DELETE)
                .appendListener(outboxHibernateListener);
    }

//    @PostConstruct
//    public void registerHibernateListeners() {
//        OutboxHibernatePreListener outboxHibernateListener = new OutboxHibernatePreListener();
//        SessionFactoryImplementor sessionFactory =
//                entityManagerFactory.unwrap(SessionFactoryImplementor.class);
//
//        EventListenerRegistry registry = sessionFactory.getServiceRegistry()
//                .getService(EventListenerRegistry.class);
//
//        registry.getEventListenerGroup(EventType.PRE_INSERT)
//                .appendListener(outboxHibernateListener);
//        registry.getEventListenerGroup(EventType.PRE_UPDATE)
//                .appendListener(outboxHibernateListener);
//        registry.getEventListenerGroup(EventType.PRE_DELETE)
//                .appendListener(outboxHibernateListener);
//    }
}
