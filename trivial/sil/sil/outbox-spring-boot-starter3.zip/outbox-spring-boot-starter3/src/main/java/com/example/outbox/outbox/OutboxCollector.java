package com.example.outbox.outbox;


import tools.jackson.databind.json.JsonMapper;

import java.util.ArrayList;
import java.util.List;

public final class OutboxCollector {

    private static final ThreadLocal<List<OutboxEntity>> EVENTS = ThreadLocal.withInitial(ArrayList::new);

    private static final JsonMapper OBJECT_MAPPER = new JsonMapper();

    private OutboxCollector() {
    }

    public static void collect(OutboxAggregate aggregate, String eventType) {
        OutboxEntity event = new OutboxEntity();
        event.setAggregateId(aggregate.getId());
        event.setAggregateType(aggregate.getClass().getSimpleName());
        event.setOperation(eventType);

        try {
            event.setPayload(OBJECT_MAPPER.writeValueAsString(aggregate));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }

        EVENTS.get().add(event);
    }

    public static List<OutboxEntity> drain() {
        List<OutboxEntity> events = new ArrayList<>(EVENTS.get());
        EVENTS.remove();
        return events;
    }
}
