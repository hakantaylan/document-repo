package com.example.outbox.outbox;


import org.hibernate.event.spi.*;
import org.hibernate.persister.entity.EntityPersister;

public class OutboxHibernatePostListener
        implements PostInsertEventListener,
        PostUpdateEventListener,
        PostDeleteEventListener {

    @Override
    public void onPostInsert(PostInsertEvent event) {
        handle(event.getEntity(), "CREATED");
    }

    @Override
    public void onPostUpdate(PostUpdateEvent event) {
        handle(event.getEntity(), "UPDATED");
    }

    @Override
    public void onPostDelete(PostDeleteEvent event) {
        handle(event.getEntity(), "DELETED");
    }

    private void handle(Object entity, String type) {
        if (entity instanceof OutboxAggregate aggregate) {
            OutboxCollector.collect(aggregate, type);
        }
    }

    @Override
    public boolean requiresPostCommitHandling(EntityPersister persister) {
        return true;
    }
}

