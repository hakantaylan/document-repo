//package com.example.outbox.outbox;
//
//import org.hibernate.event.spi.PostInsertEvent;
//import org.hibernate.event.spi.PostInsertEventListener;
//import org.hibernate.event.spi.PostUpdateEvent;
//import org.hibernate.event.spi.PostUpdateEventListener;
//import org.hibernate.event.spi.PostDeleteEvent;
//import org.hibernate.event.spi.PostDeleteEventListener;
//
//import jakarta.persistence.EntityManager;
//import jakarta.persistence.PersistenceContext;
//import org.hibernate.persister.entity.EntityPersister;
//
//public class MyEntityChangeListener
//        implements PostInsertEventListener, PostUpdateEventListener, PostDeleteEventListener {
//
//    @PersistenceContext
//    private EntityManager entityManager;
//
//    @Override
//    public void onPostInsert(PostInsertEvent event) {
//        OutboxCollector.addChange(event.getEntity(), entityManager);
//    }
//
//    @Override
//    public void onPostUpdate(PostUpdateEvent event) {
//        OutboxCollector.addChange(event.getEntity(), entityManager);
//    }
//
//    @Override
//    public void onPostDelete(PostDeleteEvent event) {
//        OutboxCollector.addChange(event.getEntity(), entityManager);
//    }
//
//}
//
