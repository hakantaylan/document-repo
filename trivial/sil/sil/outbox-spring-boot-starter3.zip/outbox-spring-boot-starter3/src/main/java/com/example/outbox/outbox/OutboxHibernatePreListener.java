package com.example.outbox.outbox;


import org.hibernate.event.spi.*;

public class OutboxHibernatePreListener
        implements PreInsertEventListener,
        PreUpdateEventListener,
        PreDeleteEventListener {


    @Override
    public boolean onPreDelete(PreDeleteEvent event) {
        handle(event.getEntity(), "DELETED");
        return false;
    }

    @Override
    public boolean onPreInsert(PreInsertEvent event) {
        handle(event.getEntity(), "CREATED");
        return false;
    }

    @Override
    public boolean onPreUpdate(PreUpdateEvent event) {
        handle(event.getEntity(), "UPDATED");
        return false;
    }

    private void handle(Object entity, String type) {
        if (entity instanceof OutboxAggregate aggregate) {
            OutboxCollector.collect(aggregate, type);
        }
    }
}

