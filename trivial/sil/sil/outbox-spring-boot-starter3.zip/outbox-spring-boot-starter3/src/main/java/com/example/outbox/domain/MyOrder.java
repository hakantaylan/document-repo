package com.example.outbox.domain;


import com.example.outbox.outbox.OutboxAggregate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.hibernate.annotations.UuidGenerator;

import java.util.UUID;

@Entity
public class MyOrder implements OutboxAggregate {

    @Id
    @UuidGenerator(style = UuidGenerator.Style.VERSION_7)
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    private String status;

    public MyOrder() {
    }

    public MyOrder(UUID id) {
        this.id = id;
        this.status = "NEW";
    }

    public void ship() {
        this.status = "SHIPPED";
    }

    @Override
    public UUID getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }
}

