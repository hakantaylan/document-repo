package com.example.outbox.outbox;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.event.spi.FlushEvent;
import org.hibernate.event.spi.FlushEventListener;
import org.springframework.stereotype.Component;

@Component
public class OutboxFlushListener implements FlushEventListener {

@PersistenceContext
private EntityManager em;
    @Override
    public void onFlush(FlushEvent flushEvent) throws HibernateException {
        Session session = flushEvent.getSession();
        for (OutboxEntity e : OutboxCollector.drain()) {
//            session.persist(e);
            em.persist(e);
        }
    }
}
