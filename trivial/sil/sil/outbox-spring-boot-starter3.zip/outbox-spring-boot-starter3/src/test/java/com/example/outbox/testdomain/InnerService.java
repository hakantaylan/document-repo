package com.example.outbox.testdomain;

import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class InnerService {

    private final EntityManager em;

    public InnerService(EntityManager em) {
        this.em = em;
    }

    @Transactional
    public void innerUpdate(DomainEntity entity) {
        entity.setName(entity.getName() + "_updated");
        em.merge(entity);
    }
}


