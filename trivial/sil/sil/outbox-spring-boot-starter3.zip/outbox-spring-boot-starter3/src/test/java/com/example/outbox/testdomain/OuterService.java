package com.example.outbox.testdomain;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OuterService {

    private final InnerService innerService;

    public OuterService(InnerService innerService) {
        this.innerService = innerService;
    }

    @Transactional
    public void happyPath(DomainEntity entity) {
        innerService.innerUpdate(entity);
    }
}



