#!/usr/bin/env bash
set -e

PROJECT=lookup-i18n-starter
GROUP=com.example.lookup
VERSION=1.0.0-SNAPSHOT
JAVA=25
SPRING_BOOT=4.0.0-M1

mkdir -p $PROJECT
cd $PROJECT

##############################
# Parent pom.xml
##############################
cat > pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         https://maven.apache.org/xsd/maven-4.0.0.xsd">

  <modelVersion>4.0.0</modelVersion>
  <groupId>$GROUP</groupId>
  <artifactId>lookup-i18n-starter</artifactId>
  <version>$VERSION</version>
  <packaging>pom</packaging>

  <modules>
    <module>lookup-i18n-core</module>
    <module>lookup-i18n-autoconfigure</module>
  </modules>

  <properties>
    <java.version>$JAVA</java.version>
    <spring.boot.version>$SPRING_BOOT</spring.boot.version>
  </properties>

  <dependencyManagement>
    <dependencies>
      <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-dependencies</artifactId>
        <version>\${spring.boot.version}</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
    </dependencies>
  </dependencyManagement>
</project>
EOF

##############################
# Core Module
##############################
mkdir -p lookup-i18n-core/src/main/java/com/example/lookup/core

cat > lookup-i18n-core/pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>$GROUP</groupId>
    <artifactId>lookup-i18n-starter</artifactId>
    <version>$VERSION</version>
  </parent>
  <artifactId>lookup-i18n-core</artifactId>
</project>
EOF

cat > lookup-i18n-core/src/main/java/com/example/lookup/core/LookupKey.java <<EOF
package com.example.lookup.core;
public interface LookupKey { String key(); }
EOF

cat > lookup-i18n-core/src/main/java/com/example/lookup/core/LocalLookupTranslator.java <<EOF
package com.example.lookup.core;
import org.springframework.context.MessageSource;
import java.util.Locale;
import java.util.Map;
public class LocalLookupTranslator {
    private final Map<String, LookupKey> registry;
    private final MessageSource messageSource;
    public LocalLookupTranslator(Map<String, LookupKey> registry, MessageSource messageSource) {
        this.registry = registry; this.messageSource = messageSource;
    }
    public String translate(LookupKey key, Locale locale) {
        if (!registry.containsKey(key.key())) throw new IllegalArgumentException("Unknown key: " + key.key());
        return messageSource.getMessage(key.key(), null, key.key(), locale);
    }
    public boolean owns(String key) { return registry.containsKey(key); }
}
EOF

##############################
# Auto-configure Module
##############################
mkdir -p lookup-i18n-autoconfigure/src/main/java/com/example/lookup/{autoconfigure,internal,order,payment}
mkdir -p lookup-i18n-autoconfigure/src/main/resources/META-INF/spring
mkdir -p lookup-i18n-autoconfigure/src/main/resources
mkdir -p lookup-i18n-autoconfigure/src/test/java/com/example/lookup

cat > lookup-i18n-autoconfigure/pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>$GROUP</groupId>
    <artifactId>lookup-i18n-starter</artifactId>
    <version>$VERSION</version>
  </parent>
  <artifactId>lookup-i18n-autoconfigure</artifactId>
  <dependencies>
    <dependency>
      <groupId>$GROUP</groupId>
      <artifactId>lookup-i18n-core</artifactId>
      <version>$VERSION</version>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-autoconfigure</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>
</project>
EOF

##############################
# Module Enums
##############################
cat > lookup-i18n-autoconfigure/src/main/java/com/example/lookup/order/OrderStatus.java <<EOF
package com.example.lookup.order;
import com.example.lookup.core.LookupKey;
public enum OrderStatus implements LookupKey {
    CREATED, PAID, SHIPPED, CANCELLED;
    @Override public String key() { return "order.status."+name().toLowerCase(); }
}
EOF

cat > lookup-i18n-autoconfigure/src/main/java/com/example/lookup/payment/PaymentMethod.java <<EOF
package com.example.lookup.payment;
import com.example.lookup.core.LookupKey;
public enum PaymentMethod implements LookupKey {
    CARD, PAYPAL, BANK_TRANSFER;
    @Override public String key() { return "payment.method."+name().toLowerCase(); }
}
EOF

##############################
# Message Bundles
##############################
cat > lookup-i18n-autoconfigure/src/main/resources/messages-order.properties <<EOF
order.status.created=Created
order.status.paid=Paid
order.status.shipped=Shipped
order.status.cancelled=Cancelled
EOF

cat > lookup-i18n-autoconfigure/src/main/resources/messages-payment.properties <<EOF
payment.method.card=Card
payment.method.paypal=PayPal
payment.method.bank_transfer=Bank Transfer
EOF

cat > lookup-i18n-autoconfigure/src/main/resources/messages-order_de.properties <<EOF
order.status.created=Erstellt
order.status.paid=Bezahlt
order.status.shipped=Versandt
order.status.cancelled=Storniert
EOF

##############################
# Enum Scanner
##############################
cat > lookup-i18n-autoconfigure/src/main/java/com/example/lookup/internal/LookupEnumScanner.java <<EOF
package com.example.lookup.internal;
import com.example.lookup.core.LookupKey;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;
import java.util.*;
public final class LookupEnumScanner {
    public static Map<String, LookupKey> scan(String basePackage, ClassLoader cl) {
        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AssignableTypeFilter(LookupKey.class));
        Map<String, LookupKey> map = new HashMap<>();
        scanner.findCandidateComponents(basePackage).forEach(def -> {
            try {
                Class<?> clazz = Class.forName(def.getBeanClassName(), false, cl);
                if (!clazz.isEnum()) return;
                for (Object c : clazz.getEnumConstants()) map.put(((LookupKey)c).key(), (LookupKey)c);
            } catch(Exception e){throw new IllegalStateException(e);}
        });
        return Map.copyOf(map);
    }
}
EOF

##############################
# AutoConfiguration
##############################
cat > lookup-i18n-autoconfigure/src/main/java/com/example/lookup/autoconfigure/LookupAutoConfiguration.java <<EOF
package com.example.lookup.autoconfigure;
import com.example.lookup.core.LocalLookupTranslator;
import com.example.lookup.internal.LookupEnumScanner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import java.util.Map;

@AutoConfiguration
public class LookupAutoConfiguration {
    @Bean
    public LocalLookupTranslator localLookupTranslator() {
        Map<String, ?> registry = LookupEnumScanner.scan("com.example.lookup", getClass().getClassLoader());
        ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
        ms.setBasenames("messages-order","messages-payment");
        ms.setDefaultEncoding("UTF-8");
        return new LocalLookupTranslator((Map)registry, ms);
    }
}
EOF

cat > lookup-i18n-autoconfigure/src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports <<EOF
com.example.lookup.autoconfigure.LookupAutoConfiguration
EOF

##############################
# Snapshot for validation
##############################
cat > lookup-i18n-autoconfigure/src/main/resources/lookup-keys.snapshot <<EOF
order.status.created
order.status.paid
order.status.shipped
order.status.cancelled
payment.method.card
payment.method.paypal
payment.method.bank_transfer
EOF

##############################
# Validation Test
##############################
cat > lookup-i18n-autoconfigure/src/test/java/com/example/lookup/LookupValidationTest.java <<EOF
package com.example.lookup;
import com.example.lookup.core.LookupKey;
import com.example.lookup.internal.LookupEnumScanner;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.ResourceBundleMessageSource;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;
import static org.assertj.core.api.Assertions.assertThat;

class LookupValidationTest {

    @Test
    void allEnumKeysHaveTranslations() throws Exception {
        Map<String, ?> registry = LookupEnumScanner.scan("com.example.lookup", getClass().getClassLoader());
        ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
        ms.setBasenames("messages-order","messages-payment");
        ms.setDefaultEncoding("UTF-8");
        Locale[] locales = {Locale.ENGLISH, Locale.GERMAN};
        for (Locale locale : locales) {
            for (Object keyObj : registry.values()) {
                String key = ((LookupKey)keyObj).key();
                String translation = ms.getMessage(key,null,null,locale);
                assertThat(translation).as("Missing translation for %s in %s", key, locale).isNotNull().isNotEmpty();
            }
        }
    }

    @Test
    void enumKeysDoNotBreakSnapshot() throws Exception {
        Map<String, ?> registry = LookupEnumScanner.scan("com.example.lookup", getClass().getClassLoader());
        Set<String> currentKeys = registry.keySet();
        Set<String> snapshot;
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(
                getClass().getClassLoader().getResourceAsStream("lookup-keys.snapshot"), StandardCharsets.UTF_8))){
            snapshot = reader.lines().filter(l->!l.isBlank()).collect(Collectors.toSet());
        }
        assertThat(currentKeys).containsAll(snapshot);
    }
}
EOF

##############################
# Sample Microservice
##############################
mkdir -p order-service/src/main/java/com/example/orderservice/service
mkdir -p order-service/src/main/java/com/example/orderservice
mkdir -p order-service/src/main/resources

cat > order-service/pom.xml <<EOF
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>$GROUP</groupId>
    <artifactId>lookup-i18n-starter</artifactId>
    <version>$VERSION</version>
  </parent>
  <artifactId>order-service</artifactId>
  <dependencies>
    <dependency>
      <groupId>$GROUP</groupId>
      <artifactId>lookup-i18n-autoconfigure</artifactId>
      <version>$VERSION</version>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>
</project>
EOF

cat > order-service/src/main/java/com/example/orderservice/OrderServiceApp.java <<EOF
package com.example.orderservice;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class OrderServiceApp {
    public static void main(String[] args){ SpringApplication.run(OrderServiceApp.class,args);}
}
EOF

cat > order-service/src/main/java/com/example/orderservice/service/OrderUiService.java <<EOF
package com.example.orderservice.service;
import com.example.lookup.core.LocalLookupTranslator;
import com.example.lookup.order.OrderStatus;
import org.springframework.stereotype.Service;
import java.util.Locale;
@Service
public class OrderUiService {
    private final LocalLookupTranslator translator;
    public OrderUiService(LocalLookupTranslator translator){this.translator=translator;}
    public String presentStatus(OrderStatus status, Locale locale){
        return translator.translate(status, locale);
    }
}
EOF

cat > order-service/src/main/resources/application.properties <<EOF
spring.main.allow-bean-definition-overriding=true
EOF

cat > order-service/src/test/java/com/example/orderservice/service/OrderUiServiceTest.java <<EOF
package com.example.orderservice.service;
import com.example.lookup.order.OrderStatus;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.Locale;
import static org.assertj.core.api.Assertions.assertThat;
@SpringBootTest
class OrderUiServiceTest {
    private final OrderUiService service;
    OrderUiServiceTest(OrderUiService service){this.service=service;}
    @Test
    void translatesOrderStatus(){
        assertThat(service.presentStatus(OrderStatus.PAID, Locale.ENGLISH)).isEqualTo("Paid");
        assertThat(service.presentStatus(OrderStatus.SHIPPED, Locale.GERMAN)).isEqualTo("Versandt");
    }
}
EOF

echo "✅ Full lookup-i18n-starter with validation + sample microservice generated"
