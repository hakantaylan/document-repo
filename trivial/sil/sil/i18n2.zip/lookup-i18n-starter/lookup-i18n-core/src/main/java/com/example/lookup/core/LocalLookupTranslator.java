package com.example.lookup.core;
import org.springframework.context.MessageSource;
import java.util.Locale;
import java.util.Map;
public class LocalLookupTranslator {
    private final Map<String, LookupKey> registry;
    private final MessageSource messageSource;
    public LocalLookupTranslator(Map<String, LookupKey> registry, MessageSource messageSource) {
        this.registry = registry; this.messageSource = messageSource;
    }
    public String translate(LookupKey key, Locale locale) {
        if (!registry.containsKey(key.key())) throw new IllegalArgumentException("Unknown key: " + key.key());
        return messageSource.getMessage(key.key(), null, key.key(), locale);
    }
    public boolean owns(String key) { return registry.containsKey(key); }
}
