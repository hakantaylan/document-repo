package com.example.lookup.core;
public interface LookupKey { String key(); }
