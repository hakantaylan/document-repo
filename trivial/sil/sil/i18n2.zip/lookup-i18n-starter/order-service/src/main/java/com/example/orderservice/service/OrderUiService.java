package com.example.orderservice.service;
import com.example.lookup.core.LocalLookupTranslator;
import com.example.lookup.order.OrderStatus;
import org.springframework.stereotype.Service;
import java.util.Locale;
@Service
public class OrderUiService {
    private final LocalLookupTranslator translator;
    public OrderUiService(LocalLookupTranslator translator){this.translator=translator;}
    public String presentStatus(OrderStatus status, Locale locale){
        return translator.translate(status, locale);
    }
}
