package com.example.lookup;
import com.example.lookup.core.LookupKey;
import com.example.lookup.internal.LookupEnumScanner;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.ResourceBundleMessageSource;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;
import static org.assertj.core.api.Assertions.assertThat;

class LookupValidationTest {

    @Test
    void allEnumKeysHaveTranslations() throws Exception {
        Map<String, ?> registry = LookupEnumScanner.scan("com.example.lookup", getClass().getClassLoader());
        ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
        ms.setBasenames("messages-order","messages-payment");
        ms.setDefaultEncoding("UTF-8");
        Locale[] locales = {Locale.ENGLISH, Locale.GERMAN};
        for (Locale locale : locales) {
            for (Object keyObj : registry.values()) {
                String key = ((LookupKey)keyObj).key();
                String translation = ms.getMessage(key,null,null,locale);
                assertThat(translation).as("Missing translation for %s in %s", key, locale).isNotNull().isNotEmpty();
            }
        }
    }

    @Test
    void enumKeysDoNotBreakSnapshot() throws Exception {
        Map<String, ?> registry = LookupEnumScanner.scan("com.example.lookup", getClass().getClassLoader());
        Set<String> currentKeys = registry.keySet();
        Set<String> snapshot;
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(
                getClass().getClassLoader().getResourceAsStream("lookup-keys.snapshot"), StandardCharsets.UTF_8))){
            snapshot = reader.lines().filter(l->!l.isBlank()).collect(Collectors.toSet());
        }
        assertThat(currentKeys).containsAll(snapshot);
    }
}
