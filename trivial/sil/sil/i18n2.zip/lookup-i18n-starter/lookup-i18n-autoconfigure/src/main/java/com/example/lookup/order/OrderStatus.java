package com.example.lookup.order;
import com.example.lookup.core.LookupKey;
public enum OrderStatus implements LookupKey {
    CREATED, PAID, SHIPPED, CANCELLED;
    @Override public String key() { return "order.status."+name().toLowerCase(); }
}
