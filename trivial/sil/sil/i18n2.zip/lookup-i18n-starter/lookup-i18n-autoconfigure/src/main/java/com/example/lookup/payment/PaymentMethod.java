package com.example.lookup.payment;
import com.example.lookup.core.LookupKey;
public enum PaymentMethod implements LookupKey {
    CARD, PAYPAL, BANK_TRANSFER;
    @Override public String key() { return "payment.method."+name().toLowerCase(); }
}
