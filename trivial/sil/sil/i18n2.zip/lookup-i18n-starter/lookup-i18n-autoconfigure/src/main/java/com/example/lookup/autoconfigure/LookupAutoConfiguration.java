package com.example.lookup.autoconfigure;
import com.example.lookup.core.LocalLookupTranslator;
import com.example.lookup.internal.LookupEnumScanner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import java.util.Map;

@AutoConfiguration
public class LookupAutoConfiguration {
    @Bean
    public LocalLookupTranslator localLookupTranslator() {
        Map<String, ?> registry = LookupEnumScanner.scan("com.example.lookup", getClass().getClassLoader());
        ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
        ms.setBasenames("messages-order","messages-payment");
        ms.setDefaultEncoding("UTF-8");
        return new LocalLookupTranslator((Map)registry, ms);
    }
}
