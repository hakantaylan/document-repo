package com.example.lookup.internal;
import com.example.lookup.core.LookupKey;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;
import java.util.*;
public final class LookupEnumScanner {
    public static Map<String, LookupKey> scan(String basePackage, ClassLoader cl) {
        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AssignableTypeFilter(LookupKey.class));
        Map<String, LookupKey> map = new HashMap<>();
        scanner.findCandidateComponents(basePackage).forEach(def -> {
            try {
                Class<?> clazz = Class.forName(def.getBeanClassName(), false, cl);
                if (!clazz.isEnum()) return;
                for (Object c : clazz.getEnumConstants()) map.put(((LookupKey)c).key(), (LookupKey)c);
            } catch(Exception e){throw new IllegalStateException(e);}
        });
        return Map.copyOf(map);
    }
}
