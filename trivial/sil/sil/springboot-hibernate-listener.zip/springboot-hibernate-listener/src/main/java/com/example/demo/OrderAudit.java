package com.example.demo;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name="order_audit")
public class OrderAudit {
    @Id @GeneratedValue
    private Long id;
    private Long orderId;
    private String action;
    private Instant occurredAt;

    protected OrderAudit() {}
    public OrderAudit(Long orderId, String action) {
        this.orderId = orderId;
        this.action = action;
        this.occurredAt = Instant.now();
    }
}
