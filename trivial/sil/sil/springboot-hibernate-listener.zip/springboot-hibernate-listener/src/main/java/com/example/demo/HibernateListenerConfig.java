package com.example.demo;

import org.hibernate.event.spi.*;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.service.spi.SessionFactoryServiceRegistry;
import org.springframework.boot.autoconfigure.orm.jpa.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
public class HibernateListenerConfig implements HibernatePropertiesCustomizer {

    private final OrderAuditListener listener;

    public HibernateListenerConfig(OrderAuditListener listener) {
        this.listener = listener;
    }

    @Override
    public void customize(Map<String, Object> hibernateProperties) {
        hibernateProperties.put(
            "hibernate.session_factory.observer",
            (org.hibernate.SessionFactoryObserver) sessionFactory -> {
                EventListenerRegistry registry =
                        sessionFactory.getServiceRegistry()
                                      .getService(EventListenerRegistry.class);

                registry.getEventListenerGroup(EventType.POST_INSERT).appendListener(listener);
                registry.getEventListenerGroup(EventType.POST_UPDATE).appendListener(listener);
                registry.getEventListenerGroup(EventType.POST_DELETE).appendListener(listener);
            }
        );
    }
}
