package com.example.demo;

import org.hibernate.event.spi.*;
import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

@Component
public class OrderAuditListener implements PostInsertEventListener, PostUpdateEventListener, PostDeleteEventListener {

    @Override
    public void onPostInsert(PostInsertEvent event) {
        if (event.getEntity() instanceof Order order) {
            event.getSession().persist(new OrderAudit(order.getId(), "INSERT"));
        }
    }

    @Override
    public void onPostUpdate(PostUpdateEvent event) {
        if (event.getEntity() instanceof Order order) {
            event.getSession().persist(new OrderAudit(order.getId(), "UPDATE"));
        }
    }

    @Override
    public void onPostDelete(PostDeleteEvent event) {
        if (event.getEntity() instanceof Order order) {
            event.getSession().persist(new OrderAudit(order.getId(), "DELETE"));
        }
    }

    @Override
    public boolean requiresPostCommitHandling(EntityPersister persister) { return false; }
}
