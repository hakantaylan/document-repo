package com.example.demo;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    private final EntityManager em;

    public OrderService(EntityManager em) { this.em = em; }

    @Transactional
    public void create() {
        Order o = new Order();
        o.setStatus("NEW");
        em.persist(o);
    }

    @Transactional
    public void update(Long id) {
        Order o = em.find(Order.class, id);
        o.setStatus("PAID");
    }

    @Transactional
    public void delete(Long id) {
        Order o = em.find(Order.class, id);
        em.remove(o);
    }
}
