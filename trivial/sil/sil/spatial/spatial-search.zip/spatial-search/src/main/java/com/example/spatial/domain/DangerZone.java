package com.example.spatial.domain;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class DangerZone {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @Column(columnDefinition = "geometry(Polygon,4326)")
    private Geometry shape;

    @ManyToOne(fetch = FetchType.LAZY)
    private ParentVersion parentVersion;
}
