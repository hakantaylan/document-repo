package com.example.spatial.spec;


import com.example.spatial.domain.Parent;
import com.example.spatial.domain.ParentVersion;
import org.springframework.data.jpa.domain.Specification;
import jakarta.persistence.criteria.*;

public class ParentVersionSpecifications {

    /**
     * Filters ParentVersion by whether it's the active version based on draft flag.
     */
    public static Specification<ParentVersion> byDraftFlag(boolean draft) {
        return (root, query, cb) -> {
            Join<ParentVersion, Parent> parent = root.join("parent");
            if (draft) {
                return cb.equal(parent.get("draftVersion").get("id"), root.get("id"));
            } else {
                return cb.equal(parent.get("lastVersion").get("id"), root.get("id"));
            }
        };
    }
}