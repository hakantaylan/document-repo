package com.example.spatial.domain;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Point;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class ParentVersion {

    @Id
    @GeneratedValue
    private Long id;

    private String type;

    private Instant createdAt;

    @Column(columnDefinition = "geometry(Point,4326)")
    private Point point;

    @ManyToOne(fetch = FetchType.LAZY)
    private Parent parent;

    @OneToMany(mappedBy = "parentVersion", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private Set<Location> locations = new HashSet<>();

    @OneToMany(mappedBy = "parentVersion", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private Set<DangerZone> dangerZones = new HashSet<>();

    public void addLocation(Location location) {
        locations.add(location);
        location.setParentVersion(this);
    }

    public void removeLocation(Location location) {
        locations.remove(location);
        location.setParentVersion(null);
    }

    public void addDangerZone(DangerZone dangerZone) {
        dangerZones.add(dangerZone);
        dangerZone.setParentVersion(this);
    }

    public void removeDangerZone(DangerZone dangerZone) {
        dangerZones.remove(dangerZone);
        dangerZone.setParentVersion(null);
    }
}
