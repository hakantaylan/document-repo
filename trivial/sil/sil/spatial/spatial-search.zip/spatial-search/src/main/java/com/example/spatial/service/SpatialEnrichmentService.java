package com.example.spatial.service;


import com.example.spatial.domain.Destination;
import com.example.spatial.dto.DestinationDangerDTO;
import com.example.spatial.repo.DestinationRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SpatialEnrichmentService {

    private final DestinationRepository destinationRepository;

    @Transactional(readOnly = true)
    public void enrichDestinations(Collection<Destination> destinations, Long versionId){

        if (destinations == null || destinations.isEmpty()) {
            return;
        }

        // Collect IDs
        List<Long> ids =
                destinations.stream()
                        .map(Destination::getId)
                        .filter(Objects::nonNull)
                        .toList();

        if (ids.isEmpty()) {
            return;
        }

        // Spatial query
        List<DestinationDangerDTO> geo = destinationRepository.findNearestDangerZones(ids, versionId);

        if (geo.isEmpty()) {
            return;
        }

        // Map by destinationId
        Map<Long, DestinationDangerDTO> map = geo.stream()
                        .collect(Collectors.toMap(
                                DestinationDangerDTO::getDestinationId,
                                d -> d
                        ));

        // Enrich entities
        for (Destination d : destinations) {

            var info = map.get(d.getId());

            if (info == null)
                continue;

            d.setDangerZoneName(info.getDangerZoneName());
            d.setDangerZoneDistance(info.getDistance());
            d.setDangerZoneAngle(info.getAngle());
        }
    }
}