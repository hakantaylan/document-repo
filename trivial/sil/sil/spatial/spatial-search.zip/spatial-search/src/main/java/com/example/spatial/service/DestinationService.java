package com.example.spatial.service;

import com.example.spatial.domain.Destination;
import com.example.spatial.domain.Parent;
import com.example.spatial.dto.DestinationDangerDTO;
import com.example.spatial.repo.DestinationRepository;
import com.example.spatial.repo.SpatialRepository;
import com.example.spatial.spec.DestinationSpecifications;
import com.example.spatial.spec.ParentSpecifications;
import com.example.spatial.util.VersionType;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DestinationService {

    private final DestinationRepository destinationRepository;
    private final SpatialEnrichmentService spatialService;
    private final SpatialRepository spatialRepository;

    @Transactional(readOnly = true)
    public Page<Destination> searchWithDangerZones(
            String name,
            VersionType type,
            Long versionId,
            Pageable pageable){

        // ========== PHASE 1 ==========
        var spec =
                DestinationSpecifications.hasName(name, type);

        Page<Destination> page =
                destinationRepository.findAll(spec, pageable);

        if (page.isEmpty()) {
            return page;
        }

        // ========== PHASE 2 ==========
        spatialService.enrichDestinations(
                page.getContent(),
                versionId
        );

        return page;
    }

    public Page<Destination> searchWithDangerZones(String name, boolean draft, Pageable pageable) {
        Specification<Destination> spec  = DestinationSpecifications.byName(name).and(DestinationSpecifications.byParentVersionFlag(draft));
//        Specification<Destination> spec = Specification.where(DestinationSpecifications.byName(name))
//                .and(DestinationSpecifications.byParentVersionFlag(draft));

        Page<Destination> page = destinationRepository.findAll(spec, pageable);

        if (page.isEmpty()) return page;

        // Phase 2: spatial enrichment
        List<Long> ids = page.stream().map(Destination::getId).toList();
        var dangers = spatialRepository.findNearestDangerZones(ids, draft);

        Map<Long, DestinationDangerDTO> map = dangers.stream()
                .collect(Collectors.toMap(DestinationDangerDTO::getDestinationId, d -> d));

        page.forEach(d -> {
            var dto = map.get(d.getId());
            if (dto != null) {
                d.setDangerZoneName(dto.getDangerZoneName());
                d.setDangerZoneDistance(dto.getDistance());
                d.setDangerZoneAngle(dto.getAngle());
            }
        });

        return page;
    }
}