package com.example.spatial.util;

import com.example.spatial.domain.Parent;
import com.example.spatial.domain.ParentVersion;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;


public final class VersionPredicateHelper {

    private VersionPredicateHelper() {
    }

    public static Predicate published(
            CriteriaBuilder cb,
            Root<ParentVersion> versionRoot,
            Root<Parent> parentRoot) {

        return cb.equal(
                parentRoot.get("lastVersion"),
                versionRoot
        );
    }

    public static Predicate draft(
            CriteriaBuilder cb,
            Root<ParentVersion> versionRoot,
            Root<Parent> parentRoot) {

        return cb.equal(
                parentRoot.get("draftVersion"),
                versionRoot
        );
    }
}