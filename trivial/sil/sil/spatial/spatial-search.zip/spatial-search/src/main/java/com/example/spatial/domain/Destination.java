package com.example.spatial.domain;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Point;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class Destination {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    private String no;

    @Column(columnDefinition = "geometry(Point,4326)")
    private Point point;

    @ManyToOne(fetch = FetchType.LAZY)
    private Location location;

    @Transient
    private Double dangerZoneDistance;

    @Transient
    private String dangerZoneName;

    @Transient
    private Double dangerZoneAngle;
}
