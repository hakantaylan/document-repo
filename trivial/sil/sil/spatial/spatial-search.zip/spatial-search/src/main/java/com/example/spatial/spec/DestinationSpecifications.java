package com.example.spatial.spec;

import com.example.spatial.domain.*;
import com.example.spatial.util.*;

import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.criteria.*;

public final class DestinationSpecifications {

    private DestinationSpecifications(){}

    public static Specification<Destination> hasName(
            String name,
            VersionType type){

        return (root, query, cb) -> {

            query.distinct(true);

            Join<Destination, Location> l =
                    root.join("location");

            Join<Location, ParentVersion> v =
                    l.join("parentVersion");

            Join<ParentVersion, Parent> p =
                    v.join("parent");

            Predicate versionPredicate =
                    (type == VersionType.DRAFT)
                            ? cb.equal(p.get("draftVersion"), v)
                            : cb.equal(p.get("lastVersion"), v);

            Predicate nameCheck =
                    cb.like(
                            cb.lower(root.get("name")),
                            "%" + name.toLowerCase() + "%"
                    );

            return cb.and(
                    versionPredicate,
                    nameCheck
            );
        };
    }


    public static Specification<Destination> byName(String name) {
        return (root, query, cb) -> {
            if (name == null || name.isEmpty()) return cb.conjunction(); // use conjunction instead of null
            return cb.like(root.get("name"), "%" + name + "%");
        };
    }

    public static Specification<Destination> byParentVersionFlag(boolean draft) {
        return (root, query, cb) -> {
            Join<Destination, Location> loc = root.join("location");
            Join<Location, ParentVersion> pv = loc.join("parentVersion");
            Join<ParentVersion, Parent> parent = pv.join("parent");

            if (draft) {
                return cb.equal(parent.get("draftVersion").get("id"), pv.get("id"));
            } else {
                return cb.equal(parent.get("lastVersion").get("id"), pv.get("id"));
            }
        };
    }
}