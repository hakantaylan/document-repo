package com.example.spatial.repo;


import com.example.spatial.domain.Destination;
import com.example.spatial.dto.DestinationDangerDTO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.util.List;

@org.springframework.stereotype.Repository
public interface SpatialRepository extends Repository<Destination, Long> {

    /**
     * Finds the nearest danger zone for each destination in the given IDs
     * according to draft/published flag.
     */
//    @Query(value = """
//        SELECT d.id AS destinationId,
//               dz.name AS dangerZoneName,
//               ST_Distance(d.point, dz.shape) AS distance,
//               degrees(ST_Azimuth(d.point, ST_ClosestPoint(dz.shape, d.point))) AS angle
//        FROM destination d
//        JOIN location l ON d.location_id = l.id
//        JOIN parent_version v ON l.parent_version_id = v.id
//        JOIN parent p ON v.parent_id = p.id
//        JOIN danger_zone dz ON dz.parent_version_id = v.id
//        WHERE d.id IN (:destinationIds)
//          AND ST_DWithin(d.point, dz.shape, 500)
//          AND v.id = CASE WHEN :draft THEN p.draft_version_id ELSE p.last_version_id END
//        ORDER BY d.id, distance
//        """, nativeQuery = true)
    @Query(value = """
        SELECT d.id AS destinationId,
               dz.name AS dangerZoneName,
               ST_DistanceSphere(d.point, dz.shape) AS distance,
               degrees(ST_Azimuth(d.point, ST_ClosestPoint(dz.shape, d.point))) AS angle
        FROM destination d
        JOIN location l ON d.location_id = l.id
        JOIN parent_version v ON l.parent_version_id = v.id
        JOIN parent p ON v.parent_id = p.id
        JOIN danger_zone dz ON dz.parent_version_id = v.id
        WHERE d.id IN (:destinationIds)
          AND ST_DistanceSphere(d.point, dz.shape) <= 500
          AND v.id = CASE WHEN :draft THEN p.draft_version_id ELSE p.last_version_id END
        ORDER BY d.id, distance
        """, nativeQuery = true)
    List<DestinationDangerDTO> findNearestDangerZones(
            @Param("destinationIds") List<Long> destinationIds,
            @Param("draft") boolean draft
    );
}