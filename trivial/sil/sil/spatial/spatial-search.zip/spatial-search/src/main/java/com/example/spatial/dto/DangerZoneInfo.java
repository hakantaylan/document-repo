package com.example.spatial.dto;

public record DangerZoneInfo(
        Long destinationId,
        String name,
        Double distance,
        Double angle
){}
