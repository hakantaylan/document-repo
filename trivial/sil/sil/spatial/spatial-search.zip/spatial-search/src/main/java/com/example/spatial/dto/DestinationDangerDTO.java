package com.example.spatial.dto;

public interface DestinationDangerDTO {

    Long getDestinationId();

    String getDangerZoneName();

    Double getDistance();

    Double getAngle();
}