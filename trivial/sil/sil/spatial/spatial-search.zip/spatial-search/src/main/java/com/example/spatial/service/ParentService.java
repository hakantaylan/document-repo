package com.example.spatial.service;

import com.example.spatial.domain.Parent;
import com.example.spatial.domain.ParentVersion;
import com.example.spatial.domain.Destination;
import com.example.spatial.dto.DestinationDangerDTO;
import com.example.spatial.repo.ParentRepository;
import com.example.spatial.repo.SpatialRepository;
import com.example.spatial.spec.ParentSpecifications;
import com.example.spatial.spec.ParentVersionSpecifications;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class ParentService {

    private final ParentRepository parentRepo;
    private final SpatialRepository spatialRepo;

    public ParentService(ParentRepository parentRepo, SpatialRepository spatialRepo) {
        this.parentRepo = parentRepo;
        this.spatialRepo = spatialRepo;
    }

    public Page<Parent> searchWithDangerZones(String parentNo, String street, boolean draft, Pageable pageable) {
        Specification<Parent> spec = ParentSpecifications.byParentNo(parentNo).and(ParentSpecifications.byLocationStreet(street, draft));
//        Specification<Parent> spec = Specification
//                .where(ParentSpecifications.byParentNo(parentNo))
//                .and(ParentSpecifications.byLocationStreet(street, draft));

        Page<Parent> page = draft == false ? parentRepo.findAllPublishedVersionBy(spec, pageable) : parentRepo.findAllDraftVersionBy(spec, pageable);

        if (page.isEmpty())
            return page;

        // Phase 2: collect all destinations
        List<Destination> allDestinations = page.stream()
                .flatMap(p -> {
                    ParentVersion version = draft ? p.getDraftVersion() : p.getLastVersion();
                    return version.getLocations().stream()
                            .flatMap(l -> l.getDestinations().stream());
                })
                .toList();

        if (allDestinations.isEmpty()) return page;

        // Phase 3: spatial enrichment
        List<Long> ids = allDestinations.stream().map(Destination::getId).toList();
        var dangers = spatialRepo.findNearestDangerZones(ids, draft);

        Map<Long, DestinationDangerDTO> map = dangers.stream()
                .collect(Collectors.toMap(DestinationDangerDTO::getDestinationId, d -> d));

        allDestinations.forEach(d -> {
            var dto = map.get(d.getId());
            if (dto != null) {
                d.setDangerZoneName(dto.getDangerZoneName());
                d.setDangerZoneDistance(dto.getDistance());
                d.setDangerZoneAngle(dto.getAngle());
            }
        });

        return page;
    }
}