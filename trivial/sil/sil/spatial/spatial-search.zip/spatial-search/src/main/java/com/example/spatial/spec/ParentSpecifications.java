package com.example.spatial.spec;

import com.example.spatial.domain.*;
import com.example.spatial.util.*;

import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.criteria.*;

public final class ParentSpecifications {

    private ParentSpecifications(){}

    public static Specification<Parent> hasStreet(String street, VersionType type){

        return (root, query, cb) -> {

            query.distinct(true);

            Root<ParentVersion> v = query.from(ParentVersion.class);

            Join<ParentVersion, Location> l = v.join("locations");

            Predicate link = cb.equal(v.get("parent"), root);

            Predicate versionPredicate =
                    (type == VersionType.DRAFT)
                            ? VersionPredicateHelper.draft(cb, v, root)
                            : VersionPredicateHelper.published(cb, v, root);

            Predicate streetCheck =
                    cb.like(
                            cb.lower(l.get("street")),
                            "%" + street.toLowerCase() + "%"
                    );

            return cb.and(
                    link,
                    versionPredicate,
                    streetCheck
            );
        };
    }

    public static Specification<Parent> hasParentNo(String no){

        return (r,q,cb) ->
                cb.equal(r.get("parentNo"), no);
    }

    public static Specification<Parent> byParentNo(String parentNo) {
        return (root, query, cb) ->
                parentNo == null ? null : cb.like(root.get("parentNo"), "%" + parentNo + "%");
    }

    public static Specification<Parent> byLocationStreet(String street, boolean draft) {
        return (root, query, cb) -> {
            // Join to version according to draft
            Join<Parent, ParentVersion> versionJoin = draft
                    ? root.join("draftVersion", JoinType.LEFT)
                    : root.join("lastVersion", JoinType.LEFT);

            Join<ParentVersion, Location> locJoin = versionJoin.join("locations", JoinType.LEFT);

            return street == null ? null : cb.like(locJoin.get("street"), "%" + street + "%");
        };
    }
}