package com.example.spatial.domain;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class Location {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    private String street;

    @Column(columnDefinition = "geometry(Polygon,4326)")
    private Geometry shape;

    @ManyToOne(fetch = FetchType.LAZY)
    private ParentVersion parentVersion;

    @OneToMany(mappedBy = "location", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private Set<Destination> destinations = new HashSet<>();

    public void addDestination(Destination destination) {
        destinations.add(destination);
        destination.setLocation(this);
    }

    public void removeDestination(Destination destination) {
        destinations.remove(destination);
        destination.setLocation(null);
    }
}
