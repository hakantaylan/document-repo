package com.example.spatial.util;

public enum VersionType {
    DRAFT,
    PUBLISHED
}
