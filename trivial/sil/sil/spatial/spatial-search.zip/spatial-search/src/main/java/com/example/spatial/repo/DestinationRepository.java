package com.example.spatial.repo;

import com.example.spatial.domain.Destination;
import com.example.spatial.dto.DestinationDangerDTO;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface DestinationRepository
        extends JpaRepository<Destination, Long>,
        JpaSpecificationExecutor<Destination> {

    // Nearest danger zone per destination (<= 500m)
    @Query(value = """
      SELECT DISTINCT ON (d.id)

        d.id AS destinationId,
        dz.name AS dangerZoneName,

        ST_Distance(
          d.point,
          dz.shape
        ) AS distance,

        degrees(
          ST_Azimuth(
            d.point,
            ST_ClosestPoint(dz.shape, d.point)
          )
        ) AS angle

      FROM destination d

      JOIN location l
        ON d.location_id = l.id

      JOIN parent_version v
        ON l.parent_version_id = v.id

      JOIN danger_zone dz
        ON dz.parent_version_id = v.id

      WHERE
        d.id IN (:ids)
        AND v.id = :versionId

        AND ST_DWithin(
          d.point,
          dz.shape,
          500
        )

      ORDER BY d.id, distance
    """, nativeQuery = true)
    List<DestinationDangerDTO> findNearestDangerZones(
            @Param("ids") List<Long> ids,
            @Param("versionId") Long versionId
    );
}