package com.example.spatial.repo;

import com.example.spatial.domain.Parent;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ParentRepository extends JpaRepository<Parent, Long>, JpaSpecificationExecutor<Parent> {

    @EntityGraph(attributePaths = {"lastVersion.dangerZones", "lastVersion.locations.destinations"})
    Page<Parent> findAllPublishedVersionBy(Specification<Parent> spec, Pageable pageable);

    @EntityGraph(attributePaths = {"draftVersion.dangerZones", "draftVersion.locations.destinations"})
    Page<Parent> findAllDraftVersionBy(Specification<Parent> spec, Pageable pageable);
}
