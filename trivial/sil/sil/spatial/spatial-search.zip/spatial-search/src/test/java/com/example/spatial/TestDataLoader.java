//package com.example.spatial;
//
//import com.example.spatial.domain.*;
//
//import com.example.spatial.domain.Location;
//import jakarta.persistence.EntityManager;
//import jakarta.transaction.Transactional;
//
//import org.locationtech.jts.geom.*;
//import org.springframework.stereotype.Component;
//
//@Component
//public class TestDataLoader {
//
//    private final EntityManager em;
//
//    private final GeometryFactory gf = new GeometryFactory(new PrecisionModel(), 4326);
//
//    public TestDataLoader(EntityManager em) {
//        this.em = em;
//    }
//
//    @Transactional
//    public void load() {
//
//        Parent parent = new Parent();
//        parent.setParentNo("P-001");
//        parent.setPlace("Center");
//
//        em.persist(parent);
//
//
//        ParentVersion published = new ParentVersion();
//        published.setType("PUBLISHED");
//        published.setParent(parent);
//        published.setPoint(point(41.0, 36.0));
//
//        em.persist(published);
//
//
//        ParentVersion draft = new ParentVersion();
//        draft.setType("DRAFT");
//        draft.setParent(parent);
//        draft.setPoint(point(41.001, 36.001));
//
//        em.persist(draft);
//
//
//        parent.setLastVersion(published);
//        parent.setDraftVersion(draft);
//
//        em.merge(parent);
//
//
//        Location loc1 = new Location();
//        loc1.setName("Loc-1");
//        loc1.setStreet("Main Street");
//        loc1.setParentVersion(published);
//
//        em.persist(loc1);
//
//
//        Location loc2 = new Location();
//        loc2.setName("Loc-2");
//        loc2.setStreet("Second Street");
//        loc2.setParentVersion(draft);
//
//        em.persist(loc2);
//
//
//        Destination d1 = new Destination();
//        d1.setName("Shop A");
//        d1.setNo("D1");
//        d1.setPoint(point(41.0001, 36.0001));
//        d1.setLocation(loc1);
//
//        em.persist(d1);
//
//
//        Destination d2 = new Destination();
//        d2.setName("Shop B");
//        d2.setNo("D2");
//        d2.setPoint(point(41.0003, 36.0003));
//        d2.setLocation(loc1);
//
//        em.persist(d2);
//
//
//        Destination d3 = new Destination();
//        d3.setName("Draft Shop");
//        d3.setNo("D3");
//        d3.setPoint(point(41.0011, 36.0011));
//        d3.setLocation(loc2);
//
//        em.persist(d3);
//
//
//        DangerZone dz1 = new DangerZone();
//        dz1.setName("Zone-1");
//        dz1.setShape(circle(41.0002, 36.0002, 0.001));
//        dz1.setParentVersion(published);
//
//        em.persist(dz1);
//
//
//        DangerZone dz2 = new DangerZone();
//        dz2.setName("Zone-2");
//        dz2.setShape(circle(41.0005, 36.0005, 0.001));
//        dz2.setParentVersion(published);
//
//        em.persist(dz2);
//
//
//        DangerZone dz3 = new DangerZone();
//        dz3.setName("Draft-Zone");
//        dz3.setShape(circle(41.0012, 36.0012, 0.001));
//        dz3.setParentVersion(draft);
//
//        em.persist(dz3);
//    }
//
//
//    private Point point(double lat, double lon) {
//        return gf.createPoint(new Coordinate(lon, lat));
//    }
//
//
//    private Geometry circle(double lat, double lon, double r) {
//
//        Point center =
//            gf.createPoint(new Coordinate(lon, lat));
//
//        return center.buffer(r);
//    }
//}
