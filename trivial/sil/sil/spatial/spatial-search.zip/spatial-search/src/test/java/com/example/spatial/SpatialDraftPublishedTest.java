package com.example.spatial;

import com.example.spatial.domain.*;
import com.example.spatial.domain.Location;
import com.example.spatial.repo.DestinationRepository;
import com.example.spatial.repo.ParentRepository;
import com.example.spatial.repo.SpatialRepository;
import com.example.spatial.service.ParentService;
import com.example.spatial.service.DestinationService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.locationtech.jts.geom.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SpatialDraftPublishedTest {

    @Autowired
    private ParentRepository parentRepo;

    @Autowired
    private DestinationRepository destRepo;

    @Autowired
    private SpatialRepository spatialRepo;

    @Autowired
    private ParentService parentService;

    @Autowired
    private DestinationService destinationService;

    private final GeometryFactory gf = new GeometryFactory(new PrecisionModel(), 4326);

    private Parent parent;

    // Berlin reference coordinate (realistic WGS84)
    private final double baseX = 13.4050;
    private final double baseY = 52.5200;

    // =========================
    // Helpers
    // =========================

    private Polygon createCircularZone(double centerX, double centerY, double radiusMeters) {
        double radiusDegrees = radiusMeters / 111_000d; // approx conversion
        Point center = gf.createPoint(new Coordinate(centerX, centerY));
        return (Polygon) center.buffer(radiusDegrees);
    }

    private Point createPoint(double x, double y) {
        return gf.createPoint(new Coordinate(x, y));
    }

    // =========================
    // Setup
    // =========================

    @BeforeEach
    void setup() {

        parent = Parent.builder()
                .parentNo("P001")
                .build();

        ParentVersion published = ParentVersion.builder()
                .type("published")
                .build();

        ParentVersion draft = ParentVersion.builder()
                .type("draft")
                .build();

        parent.setLastVersion(published);
        parent.setDraftVersion(draft);

        // =====================
        // PUBLISHED VERSION
        // =====================

        Location loc1 = Location.builder()
                .name("Location1")
                .street("Main Street")
                .shape(createCircularZone(baseX, baseY, 50))
                .build();

        Location loc2 = Location.builder()
                .name("Location2")
                .street("Second Street")
                .shape(createCircularZone(baseX + 0.0025, baseY + 0.0025, 50))
                .build();

        published.addLocation(loc1);
        published.addLocation(loc2);

        Destination d1 = Destination.builder()
                .name("Shop A")
                .point(createPoint(baseX + 0.0003, baseY + 0.0003))
                .build();

        Destination d2 = Destination.builder()
                .name("Shop B")
                .point(createPoint(baseX + 0.0027, baseY + 0.0027))
                .build();

        loc1.addDestination(d1);
        loc2.addDestination(d2);

        DangerZone dz1 = DangerZone.builder()
                .name("DZ1")
                .shape(createCircularZone(baseX, baseY, 200))
                .build();

        DangerZone dz2 = DangerZone.builder()
                .name("DZ2")
                .shape(createCircularZone(baseX + 0.0025, baseY + 0.0025, 300))
                .build();

        published.addDangerZone(dz1);
        published.addDangerZone(dz2);

        // =====================
        // DRAFT VERSION
        // =====================

        Location draftLoc = Location.builder()
                .name("DraftLoc")
                .street("Draft Street")
                .shape(createCircularZone(baseX + 0.01, baseY + 0.01, 50))
                .build();

        draft.addLocation(draftLoc);

        Destination d3 = Destination.builder()
                .name("Draft Shop")
                .point(createPoint(baseX + 0.0102, baseY + 0.0102))
                .build();

        draftLoc.addDestination(d3);

        DangerZone dzDraft = DangerZone.builder()
                .name("DraftDZ")
                .shape(createCircularZone(baseX + 0.01, baseY + 0.01, 250))
                .build();

        draft.addDangerZone(dzDraft);

        parentRepo.save(parent);
    }

    // =========================
    // Tests
    // =========================

    @Test
    void testParentSearchDraftFalse() {

        Page<Parent> result =
                parentService.searchWithDangerZones("P001", "Main Street", false, PageRequest.of(0,10));

        assertEquals(1, result.getTotalElements());

        Parent p = result.getContent().get(0);
        assertEquals("P001", p.getParentNo());

        List<Destination> destinations = p.getLastVersion().getLocations().stream()
                .flatMap(l -> l.getDestinations().stream())
                .toList();

        for (Destination d : destinations) {

            assertNotNull(d.getDangerZoneName());
            assertNotNull(d.getDangerZoneDistance());
            assertTrue(d.getDangerZoneDistance() <= 500);

            if (d.getName().equals("Shop A")) {
                assertEquals("DZ1", d.getDangerZoneName());
                assertTrue(d.getDangerZoneDistance() < 250);
            }

            if (d.getName().equals("Shop B")) {
                assertEquals("DZ2", d.getDangerZoneName());
                assertTrue(d.getDangerZoneDistance() < 350);
            }
        }
    }

    @Test
    void testParentSearchDraftTrue() {

        Page<Parent> result =
                parentService.searchWithDangerZones(null, "Draft Street", true, PageRequest.of(0,10));

        assertEquals(1, result.getTotalElements());

        ParentVersion draftVersion = result.getContent().get(0).getDraftVersion();

        Destination d = draftVersion.getLocations().iterator()
                .next()
                .getDestinations().iterator()
                .next();

        assertEquals("Draft Shop", d.getName());
        assertEquals("DraftDZ", d.getDangerZoneName());
        assertTrue(d.getDangerZoneDistance() <= 500);
        assertTrue(d.getDangerZoneDistance() < 300);
    }

    @Test
    void testDestinationSearchDraftFalse() {

        Page<Destination> page =
                destinationService.searchWithDangerZones("Shop", false, PageRequest.of(0,10));

        assertEquals(2, page.getTotalElements());

        page.forEach(d -> {
            assertTrue(d.getName().startsWith("Shop"));
            assertNotNull(d.getDangerZoneName());
            assertNotNull(d.getDangerZoneDistance());
            assertTrue(d.getDangerZoneDistance() <= 500);
        });
    }

    @Test
    void testDestinationSearchDraftTrue() {

        Page<Destination> page = destinationService.searchWithDangerZones("Draft", true, PageRequest.of(0,10));

        assertEquals(1, page.getTotalElements());

        Destination d = page.getContent().get(0);

        assertEquals("Draft Shop", d.getName());
        assertEquals("DraftDZ", d.getDangerZoneName());
        assertTrue(d.getDangerZoneDistance() <= 500);
    }

    @Test
    void testNoDangerZoneWithin500m() {

        Destination d = parent.getDraftVersion()
                .getLocations().iterator()
                .next()
                .getDestinations().iterator()
                .next();

        // Move ~111km away
        d.setPoint(createPoint(baseX + 1, baseY + 1));
        destRepo.save(d);

        Page<Destination> page =
                destinationService.searchWithDangerZones("Draft", true, PageRequest.of(0,10));

        Destination distant = page.getContent().get(0);

        assertNull(distant.getDangerZoneName());
        assertNull(distant.getDangerZoneDistance());
        assertNull(distant.getDangerZoneAngle());
    }
}