//package com.example.spatial;
//
//import com.example.spatial.domain.Parent;
//import com.example.spatial.domain.Destination;
//import com.example.spatial.service.ParentService;
//import com.example.spatial.util.VersionType;
//
//import org.junit.jupiter.api.*;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.*;
//
//import static org.assertj.core.api.Assertions.*;
//
//@TestInstance(TestInstance.Lifecycle.PER_CLASS)
//public class ParentServiceIT extends AbstractSpatialIT {
//
//    @Autowired
//    ParentService service;
//
//    @Autowired
//    TestDataLoader loader;
//
//
//    @BeforeAll
//    void setup() {
//        loader.load();
//    }
//
//
//    @Test
//    void parent_search_enriches_destinations() {
//
//        Page<Parent> page =
//            service.searchWithDangerZones(
//                "P-001",
//                "Main",
//                VersionType.PUBLISHED,
//                1L,
//                PageRequest.of(0, 10)
//            );
//
//        Parent p = page.getContent().get(0);
//
//        var version = p.getLastVersion();
//
//        boolean found = false;
//
//        for (var loc : version.getLocations()) {
//
//            for (Destination d : loc.getDestinations()) {
//
//                if (d.getDangerZoneName() != null) {
//
//                    found = true;
//
//                    assertThat(d.getDangerZoneDistance())
//                        .isLessThan(500);
//                }
//            }
//        }
//
//        assertThat(found).isTrue();
//    }
//
//
//    @Test
//    void parent_draft_search() {
//
//        Page<Parent> page =
//            service.searchWithDangerZones(
//                "P-001",
//                "Second",
//                VersionType.DRAFT,
//                2L,
//                PageRequest.of(0, 10)
//            );
//
//        Parent p = page.getContent().get(0);
//
//        var version = p.getDraftVersion();
//
//        Destination d =
//            version.getLocations()
//                   .iterator()
//                   .next()
//                   .getDestinations()
//                   .iterator()
//                   .next();
//
//        assertThat(d.getDangerZoneName())
//            .isEqualTo("Draft-Zone");
//    }
//
//
//    @Test
//    void empty_result_safe() {
//
//        Page<Parent> page =
//            service.searchWithDangerZones(
//                "XXX",
//                "YYY",
//                VersionType.PUBLISHED,
//                1L,
//                PageRequest.of(0, 10)
//            );
//
//        assertThat(page).isEmpty();
//    }
//}
