//package com.example.spatial;
//
//import com.example.spatial.domain.Destination;
//import com.example.spatial.service.DestinationService;
//import com.example.spatial.util.VersionType;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.TestInstance;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
//
//import static org.assertj.core.api.Assertions.assertThat;
//
//@TestInstance(TestInstance.Lifecycle.PER_CLASS)
//public class DestinationServiceIT extends AbstractSpatialIT {
//
//    @Autowired
//    DestinationService service;
//
//    @Autowired
//    TestDataLoader loader;
//
//
//    @BeforeAll
//    void setup() {
//        loader.load();
//    }
//
//
//    @Test
//    void published_search_with_danger_zones() {
//
//        Page<Destination> page =
//                service.searchWithDangerZones(
//                        "Shop",
//                        VersionType.PUBLISHED,
//                        1L,
//                        PageRequest.of(0, 10)
//                );
//
//        assertThat(page).isNotEmpty();
//
//        for (Destination d : page) {
//
//            assertThat(d.getDangerZoneName()).isNotNull();
//            assertThat(d.getDangerZoneDistance()).isLessThan(500);
//        }
//    }
//
//
//    @Test
//    void nearest_zone_only() {
//
//        Page<Destination> page =
//                service.searchWithDangerZones(
//                        "Shop A",
//                        VersionType.PUBLISHED,
//                        1L,
//                        PageRequest.of(0, 1)
//                );
//
//        Destination d = page.getContent().get(0);
//
//        assertThat(d.getDangerZoneName())
//                .isEqualTo("Zone-1");
//    }
//
//
//    @Test
//    void draft_version_search() {
//
//        Page<Destination> page =
//                service.searchWithDangerZones(
//                        "Draft",
//                        VersionType.DRAFT,
//                        2L,
//                        PageRequest.of(0, 10)
//                );
//
//        Destination d = page.getContent().get(0);
//
//        assertThat(d.getDangerZoneName())
//                .isEqualTo("Draft-Zone");
//    }
//}
