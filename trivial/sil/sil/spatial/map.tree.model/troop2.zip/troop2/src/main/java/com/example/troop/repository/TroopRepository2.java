package com.example.troop.repository;

import com.example.troop.entity.Troop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface TroopRepository2 extends JpaRepository<Troop, Long> {

    // 1 & 2. Find all sub-children (with optional type filtering)
    @Query(value = """
        WITH RECURSIVE subordinates AS (
            SELECT * FROM troop WHERE commander_id = :rootId AND deleted = false
            UNION ALL
            SELECT t.* FROM troop t INNER JOIN subordinates s ON t.commander_id = s.id
            WHERE t.deleted = false
        )
        SELECT * FROM subordinates WHERE (:type IS NULL OR type = :type)
        """, nativeQuery = true)
    List<Troop> findDescendants(Long rootId, String type);

    // 3. Find all parents
    @Query(value = """
        WITH RECURSIVE lineage AS (
            SELECT t.* FROM troop t WHERE t.id = (SELECT commander_id FROM troop WHERE id = :childId) AND t.deleted = false
            UNION ALL
            SELECT t.* FROM troop t INNER JOIN lineage l ON t.id = l.commander_id
            WHERE t.deleted = false
        )
        SELECT * FROM lineage
        """, nativeQuery = true)
    List<Troop> findAllAncestors(Long childId);

    // 4. DB-Level: First parent with specified type
    @Query(value = """
        WITH RECURSIVE lineage AS (
            SELECT t.* FROM troop t WHERE t.id = (SELECT commander_id FROM troop WHERE id = :troopId) AND t.deleted = false
            UNION ALL
            SELECT t.* FROM troop t INNER JOIN lineage l ON t.id = l.commander_id
            WHERE t.deleted = false
        )
        SELECT * FROM lineage WHERE type = :targetType LIMIT 1
        """, nativeQuery = true)
    Optional<Troop> findFirstParentOfType(Long troopId, String targetType);

    // 5. Ordered list by country
//    @Query(value = """
//        WITH RECURSIVE tree_path AS (
//            SELECT *, CAST(name AS VARCHAR(1000)) as sort_path FROM troop
//            WHERE commander_id IS NULL AND troop_country = :country AND deleted = false
//            UNION ALL
//            SELECT t.*, CAST(tp.sort_path || ' > ' || t.name AS VARCHAR(1000))
//            FROM troop t INNER JOIN tree_path tp ON t.commander_id = tp.id
//            WHERE t.deleted = false
//        )
//        SELECT * FROM tree_path ORDER BY sort_path
//        """, nativeQuery = true)
    @Query(value = """
WITH RECURSIVE tree_path( id, name, commander_id, country, deleted, sort_path ) AS ( SELECT id, name, commander_id, troop_country, deleted, CAST(name AS VARCHAR(1000)) AS sort_path FROM troop WHERE commander_id IS NULL AND troop_country = ? AND deleted = FALSE
UNION ALL
SELECT t.id, t.name, t.commander_id, t.country, t.deleted, CAST(CONCAT(tp.sort_path, ' > ', t.name) AS VARCHAR(1000)) AS sort_path FROM troop t INNER JOIN tree_path tp ON t.commander_id = tp.id WHERE t.deleted = FALSE ) SELECT id, name, commander_id, troop_country, deleted, sort_path FROM tree_path ORDER BY sort_path
        """, nativeQuery = true)
    List<Troop> findAllByCountryOrdered(String country);
}