package com.example.troop.repository;


import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopType;

import java.util.List;
import java.util.Optional;

public interface TroopHierarchyRepository {

    List<Troop> findDescendants(Long troopId);

    List<Troop> findDescendantsByType(Long troopId, TroopType type);

    List<Troop> findAncestors(Long troopId);

    Optional<Troop> findFirstAncestorByType(Long troopId, TroopType type);
}