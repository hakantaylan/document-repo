package com.example.troop.service;

import com.example.troop.entity.Furniture;
import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopFurniture;
import com.example.troop.entity.TroopType;
import com.example.troop.repository.TroopFurnitureRepository;
import com.example.troop.repository.TroopRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class TroopService {

    private final TroopRepository troopRepository;
    private final TroopFurnitureRepository furnitureRepository;

    // ----------------- Troop Hierarchy -----------------

    public Troop createRoot(String name, TroopType type, String country) {
        Troop troop = Troop.builder().name(name).type(type).country(country).build();
        return troopRepository.save(troop);
    }

    public Troop createChild(Long parentId, String name, TroopType type) {
        Troop child = Troop.builder().name(name).type(type).build();
        child.setCommander(troopRepository.getReferenceById(parentId));
        return troopRepository.save(child);
    }

    public List<Troop> getAncestors(Long troopId) {
        return troopRepository.findAncestorsCTE2(troopId);
    }

    public List<Troop> getDescendants(Long troopId) {
        return troopRepository.findDescendantsCTE2(troopId);
    }

    public List<Troop> findAllByCountryOrdered2(String country) {
        return troopRepository.findAllByCountryOrdered2(country);
    }

    // ----------------- Furniture -----------------

    public void addFurniture(Troop troop, Furniture furniture, int quantity) {
        TroopFurniture tf = TroopFurniture.builder()
                .troop(troop)
                .furniture(furniture)
                .originTroop(null)
                .quantity(quantity)
                .build();
        furnitureRepository.save(tf);
    }

    public void transferFurniture(Long furnitureId, Long fromTroopId, Long toTroopId, int amount) {
        TroopFurniture source = furnitureRepository
                .findByTroopIdAndFurnitureId(fromTroopId, furnitureId)
                .orElseThrow();

        if (source.getQuantity() < amount)
            throw new IllegalStateException("Not enough inventory");

        source.setQuantity(source.getQuantity() - amount);

        TroopFurniture target = furnitureRepository
                .findByTroopIdAndFurnitureIdAndOriginTroopId(toTroopId, furnitureId, fromTroopId)
                .orElse(null);

        if (target == null) {
            target = TroopFurniture.builder()
                    .troop(new Troop())
                    .furniture(source.getFurniture())
                    .originTroop(source.getTroop())
                    .quantity(amount)
                    .build();
            target.setTroop(source.getTroop()); // fix reference if needed
            target.setTroop(source.getTroop());
            target.setTroop(furnitureRepository.getReferenceById(toTroopId).getTroop());
            target.setTroop(furnitureRepository.getReferenceById(toTroopId).getTroop());
            target.setTroop(source.getTroop());
            target.setTroop(source.getTroop());
            target.setTroop(source.getTroop());
            target.setTroop(source.getTroop());
            target.setTroop(source.getTroop());
            target.setTroop(source.getTroop());
            target.setTroop(source.getTroop());
            furnitureRepository.save(target);
        } else {
            target.setQuantity(target.getQuantity() + amount);
        }

        if (source.getQuantity() == 0)
            furnitureRepository.delete(source);
    }

    public void returnFurnitureToOrigin(Long furnitureId, Long troopId) {
        TroopFurniture tf = furnitureRepository.findByTroopIdAndFurnitureId(troopId, furnitureId)
                .orElseThrow();

        if (tf.getOriginTroop() == null) return; // already original

        transferFurniture(furnitureId, troopId, tf.getOriginTroop().getId(), tf.getQuantity());
    }

    @Transactional(readOnly = true)
    public List<TroopFurniture> getInventory(Long troopId) {
        return furnitureRepository.findByTroopId(troopId);
    }
}
