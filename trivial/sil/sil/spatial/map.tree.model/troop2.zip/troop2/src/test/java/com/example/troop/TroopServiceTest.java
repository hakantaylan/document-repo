package com.example.troop;

import com.example.troop.entity.Furniture;
import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopFurniture;
import com.example.troop.entity.TroopType;
import com.example.troop.repository.FurnitureRepository;
import com.example.troop.repository.TroopRepository;
import com.example.troop.service.TroopService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class TroopServiceTest {

    @Autowired
    private TroopService troopService;

    @Autowired
    private TroopRepository troopRepository;

    @Autowired
    private FurnitureRepository furnitureRepository;

    @Test
    void testHierarchyAndFurniture() {

        Troop root = troopService.createRoot("Alpha", TroopType.INFANTRY, "Red Country");
        Troop child1 = troopService.createChild(root.getId(), "Bravo", TroopType.CAVALRY);
        Troop child2 = troopService.createChild(root.getId(), "Charlie", TroopType.ARTILLERY);
        List<Troop> all = troopRepository.findAll();
        // Ancestors
        List<Troop> ancestors = troopService.getAncestors(child1.getId());
        assertEquals(1, ancestors.size());
        assertEquals(root.getId(), ancestors.get(0).getId());

        // Descendants
        List<Troop> descendants = troopService.getDescendants(root.getId());
        assertEquals(2, descendants.size());

        // Furniture
        Furniture chair = furnitureRepository.save(Furniture.builder()
                .name("Chair").size("M").price(BigDecimal.valueOf(50)).color("Brown").build());
        troopService.addFurniture(root, chair, 10);

        // Transfer to child1
        troopService.transferFurniture(chair.getId(), root.getId(), child1.getId(), 4);

        List<TroopFurniture> rootInv = troopService.getInventory(root.getId());
        List<TroopFurniture> childInv = troopService.getInventory(child1.getId());

        assertEquals(6, rootInv.get(0).getQuantity());
        assertEquals(4, childInv.get(0).getQuantity());
        assertEquals(root.getId(), childInv.get(0).getOriginTroop().getId());

        // Return to origin
        troopService.returnFurnitureToOrigin(chair.getId(), child1.getId());

        rootInv = troopService.getInventory(root.getId());
        childInv = troopService.getInventory(child1.getId());

        assertEquals(10, rootInv.get(0).getQuantity());
        assertTrue(childInv.isEmpty());
    }

    @Test
    void testCteHierarchy() {
//        Troop root = troopService.createRoot("Alpha", TroopType.INFANTRY, "RedCountry");
//        Troop child1 = troopService.createChild(root.getId(), "Bravo", TroopType.CAVALRY);
//        Troop child2 = troopService.createChild(child1.getId(), "Charlie", TroopType.ARTILLERY);
        Troop troop = Troop.builder().name("Alpha").type(TroopType.INFANTRY).country("Red Country").build();
        Troop root = troopRepository.save(troop);
        Troop child1 = Troop.builder().name("Bravo").type(TroopType.CAVALRY).country("Red Country").build();
        child1.setCommander(root);
        child1 = troopRepository.save(child1);
        Troop child2 = Troop.builder().name("Charlie").type(TroopType.ARTILLERY).country("Red Country").build();
        child2.setCommander(child1);
        child2 = troopRepository.save(child2);
        List<Troop> ancestors = troopService.getAncestors(child2.getId());
        assertEquals(2, ancestors.size()); // Bravo + Alpha

        List<Troop> descendants = troopService.getDescendants(root.getId());
        assertEquals(2, descendants.size()); // Bravo + Charlie
        List<Troop> all = troopService.findAllByCountryOrdered2("Red Country");
        System.out.println("---------------------------------------");
    }
}