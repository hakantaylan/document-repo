package com.example.troop.repository;


import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopDto;
import com.example.troop.entity.TroopType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TroopRepository3 extends JpaRepository<Troop, Long>, JpaSpecificationExecutor<Troop> {
    @Query(value = """
        WITH RECURSIVE troop_tree(
            id, name, country, type, commander_id, deleted_time, deleted, version
        ) AS (
            -- Base case: start from the troop itself
            SELECT id, name, country, type, commander_id, deleted_time, deleted, version
            FROM troop
            WHERE id = :id

            UNION ALL

            -- Recursive step: select commander of current level
            SELECT t.id, t.name, t.country, t.type, t.commander_id, t.deleted_time, t.deleted, t.version
            FROM troop t
            JOIN troop_tree tt ON tt.commander_id = t.id
            WHERE t.deleted = FALSE
        )
        -- Exclude the starting troop itself
        SELECT *
        FROM troop_tree
        WHERE id <> :id AND id IS NOT NULL
    """, nativeQuery = true)
    List<TroopDto> findAscendants(@Param("id") Long id);

    @Query(value = """
    WITH RECURSIVE troop_tree(
        id, name, country, type, commander_id, deleted_time, deleted, version
    ) AS (
        SELECT id, name, country, type, commander_id, deleted_time, deleted, version
        FROM troop
        WHERE id = :id

        UNION ALL

        SELECT t.id, t.name, t.country, t.type, t.commander_id, t.deleted_time, t.deleted, t.version
        FROM troop t
        JOIN troop_tree tt ON t.commander_id = tt.id
    )
    SELECT *
    FROM troop_tree
    WHERE id <> :id AND id IS NOT NULL
""", nativeQuery = true)
    List<TroopDto> findDescendants(@Param("id") Long id);
}