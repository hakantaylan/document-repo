package com.example.troop.repository;

import com.example.troop.entity.Troop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TroopRepository extends JpaRepository<Troop, Long>, JpaSpecificationExecutor<Troop> {

//    @Query(nativeQuery = true,
//            value = """
//                WITH RECURSIVE ancestors(id, commander_id, name, type, deleted_time) AS (
//                    SELECT id, commander_id, name, type, deleted_time FROM troop WHERE id = :troopId
//                  UNION ALL
//                    SELECT t.id, t.commander_id, t.name, t.type, t.deleted_time
//                    FROM troop t
//                    INNER JOIN ancestors a ON t.id = a.commander_id
//                )
//                SELECT * FROM ancestors WHERE id != :troopId
//           """)
//    List<Troop> findAncestorsCTE(@Param("troopId") Long troopId);

    @Query(nativeQuery = true,
            value = """                                                  
            WITH RECURSIVE lineage(id, commander_id, name, type, country, deleted_time, deleted, version) AS (
                SELECT id, commander_id, name, type, country, deleted_time, deleted, version FROM troop t WHERE t.id = (SELECT commander_id FROM troop WHERE id = :childId) AND t.deleted = false
                UNION ALL
                SELECT t.id, t.commander_id, t.name, t.type, t.country, t.deleted_time, t.deleted, t.version FROM troop t INNER JOIN lineage l ON t.id = l.commander_id
                WHERE t.deleted = false
            )
            SELECT * FROM lineage
           """)
    List<Troop> findAncestorsCTE2(@Param("childId") Long troopId);
    @Query(nativeQuery = true,
            value = """
            WITH RECURSIVE subordinates(id, commander_id, name, type, country, deleted_time, deleted, version) AS (
                        SELECT id, commander_id, name, type, country, deleted_time, deleted, version FROM troop WHERE id = :rootId AND deleted = false
                        UNION ALL
                        SELECT t.id, t.commander_id, t.name, t.type, t.country, t.deleted_time, t.deleted, t.version FROM troop t
                        INNER JOIN subordinates s ON t.commander_id = s.id
                        WHERE t.deleted = false
                    )
                    SELECT * FROM subordinates WHERE id != :rootId
           """)
    List<Troop> findDescendantsCTE2(@Param("rootId") Long rootId);

//    @Query(nativeQuery = true,
//            value = """
//                WITH RECURSIVE descendants(id, commander_id, name, type, deleted_time) AS (
//                    SELECT id, commander_id, name, type, deleted_time
//                    FROM troop
//                    WHERE id = :troopId
//                  UNION ALL
//                    SELECT t.id, t.commander_id, t.name, t.type, t.deleted_time
//                    FROM troop t
//                    INNER JOIN descendants d ON t.commander_id = d.id
//                )
//                SELECT * FROM descendants WHERE id != :troopId
//           """)
//    List<Troop> findDescendantsCTE(@Param("troopId") Long troopId);

    @Query(value = """
        WITH RECURSIVE tree_order AS (
            SELECT *, 0 AS depth, CAST(name AS VARCHAR(255)) AS path 
            FROM troop WHERE commander_id IS NULL AND troop_country = :country AND deleted = false
            UNION ALL
            SELECT t.*, depth + 1, CAST(path || ' -> ' || t.name AS VARCHAR(255))
            FROM troop t
            INNER JOIN tree_order to ON t.commander_id = to.id
            WHERE t.deleted = false
        )
        SELECT * FROM tree_order ORDER BY path
        """, nativeQuery = true)
    List<Troop> findAllByCountryOrdered(String country);

//    @Query(value = """
//        WITH RECURSIVE tree_order(id, commander_id, name, type, country, deleted_time, deleted, version, depth, path) AS (
//            SELECT id, commander_id, name, type, country, deleted_time, deleted, version, 0 AS depth, CAST(name AS VARCHAR(255)) AS path
//            FROM troop WHERE commander_id IS NULL AND country = :country AND deleted = false
//            UNION ALL
//            SELECT t.id, t.commander_id, t.name, t.type, t.country, t.deleted_time, t.deleted, t.version, depth + 1, CAST(CONCAT(tp.path, ' > ', t.name)
//            FROM troop t
//            INNER JOIN tree_order to ON t.commander_id = to.id
//            WHERE t.deleted = false
//        )
//        SELECT * FROM tree_order ORDER BY path
//        """, nativeQuery = true)
    @Query(value = """
            WITH RECURSIVE tree_path(id, commander_id, name, type, country, deleted_time, deleted, version, sort_path) AS (
            SELECT id, commander_id, name, type, country, deleted_time, deleted, version, CAST(name AS VARCHAR(1000)) as sort_path FROM troop
            WHERE commander_id IS NULL AND country = :country AND deleted = false
            UNION ALL
            SELECT t.id, t.commander_id, t.name, t.type, t.country, t.deleted_time, t.deleted, t.version, CAST(tp.sort_path || ' > ' || t.name AS VARCHAR(1000))
            FROM troop t INNER JOIN tree_path tp ON t.commander_id = tp.id
            WHERE t.deleted = false
        )
                    SELECT * FROM tree_path ORDER BY sort_path
        """, nativeQuery = true)
    List<Troop> findAllByCountryOrdered2(String country);
}
