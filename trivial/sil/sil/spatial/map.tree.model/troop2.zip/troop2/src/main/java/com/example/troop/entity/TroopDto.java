package com.example.troop.entity;


import java.time.Instant;

public record TroopDto(
        Long id,
        String name,
        String country,
        TroopType type,
        Long commanderId,
        Instant deletedTime,
        boolean deleted,
        long version
) {

    // Compact constructor to convert String to TroopType
    public TroopDto(Long id, String name, String country, String typeStr,
                    Long commanderId, Instant deletedTime, boolean deleted, long version) {
        this(id, name, country, TroopType.valueOf(typeStr), commanderId, deletedTime, deleted, version);
    }
}