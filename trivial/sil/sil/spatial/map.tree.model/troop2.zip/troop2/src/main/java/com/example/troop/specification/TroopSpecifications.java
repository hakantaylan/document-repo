package com.example.troop.specification;

import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopType;
import org.springframework.data.jpa.domain.Specification;

public final class TroopSpecifications {

    private TroopSpecifications() {}

    public static Specification<Troop> countryEquals(String country) {
        return (root, query, cb) ->
                country == null ? null : cb.equal(root.get("country"), country);
    }

    public static Specification<Troop> typeEquals(TroopType type) {
        return (root, query, cb) ->
                type == null ? null : cb.equal(root.get("type"), type);
    }

    public static Specification<Troop> commanderEquals(Long commanderId) {
        return (root, query, cb) ->
                commanderId == null ? null : cb.equal(root.get("commander").get("id"), commanderId);
    }

    public static Specification<Troop> nameLike(String name) {
        return (root, query, cb) ->
                name == null ? null :
                        cb.like(cb.lower(root.get("name")), "%" + name.toLowerCase() + "%");
    }

    public static Specification<Troop> notDeleted() {
        return (root, query, cb) ->
                cb.isFalse(root.get("deleted"));
    }

}