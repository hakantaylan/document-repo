package com.example.troop.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        uniqueConstraints = @UniqueConstraint(columnNames = {"troop_id", "furniture_id", "origin_troop_id"}),
        indexes = {
                @Index(name = "idx_tf_troop", columnList = "troop_id"),               // get inventory for a troop
                @Index(name = "idx_tf_origin", columnList = "origin_troop_id"),      // query transferred furniture
                @Index(name = "idx_tf_furniture", columnList = "furniture_id")       // filter by furniture type
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TroopFurniture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Troop troop; // current owner

    @ManyToOne(optional = false)
    private Furniture furniture;

    @ManyToOne
    private Troop originTroop; // null = original

    @Column(nullable = false)
    private int quantity;

    @Version
    private long version;

    public boolean isOriginal() {
        return originTroop == null;
    }
}
