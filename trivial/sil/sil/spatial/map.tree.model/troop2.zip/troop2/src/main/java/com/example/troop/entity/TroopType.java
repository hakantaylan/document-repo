package com.example.troop.entity;

public enum TroopType {
    INFANTRY, CAVALRY, ARTILLERY
}