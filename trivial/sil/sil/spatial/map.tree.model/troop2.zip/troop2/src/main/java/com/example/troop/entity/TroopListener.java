package com.example.troop.entity;

import jakarta.persistence.PreUpdate;
import java.time.Instant;

public class TroopListener {

    @PreUpdate
    public void preUpdate(Troop troop) {
        if (troop.isDeleted() && troop.getDeletedTime() == null) {
            troop.setDeletedTime(Instant.now());
        }
        if (!troop.isDeleted()) {
            troop.setDeletedTime(null);
        }
    }
}