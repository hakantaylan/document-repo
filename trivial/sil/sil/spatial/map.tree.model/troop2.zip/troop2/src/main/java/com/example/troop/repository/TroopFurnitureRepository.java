package com.example.troop.repository;

import com.example.troop.entity.TroopFurniture;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TroopFurnitureRepository extends JpaRepository<TroopFurniture, Long> {

    Optional<TroopFurniture> findByTroopIdAndFurnitureIdAndOriginTroopId(
            Long troopId, Long furnitureId, Long originTroopId);

    Optional<TroopFurniture> findByTroopIdAndFurnitureId(Long troopId, Long furnitureId);

    List<TroopFurniture> findByTroopId(Long troopId);
}