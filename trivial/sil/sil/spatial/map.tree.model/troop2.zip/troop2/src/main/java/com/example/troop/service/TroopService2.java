package com.example.troop.service;


import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopType;
import com.example.troop.repository.TroopHierarchyRepository;
import com.example.troop.repository.TroopRepository;
import com.example.troop.specification.TroopSpecifications;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TroopService2 {

    private final TroopRepository troopRepository;
    private final TroopHierarchyRepository hierarchyRepository;

    public Page<Troop> searchTroops(
            String country,
            TroopType type,
            String name,
            Pageable pageable
    ) {

        Specification<Troop> spec =
                Specification.where(TroopSpecifications.notDeleted())
                        .and(TroopSpecifications.countryEquals(country))
                        .and(TroopSpecifications.typeEquals(type))
                        .and(TroopSpecifications.nameLike(name));

        return troopRepository.findAll(spec, pageable);
    }

    public List<Troop> findDescendants(Long troopId) {
        return hierarchyRepository.findDescendants(troopId);
    }

    public List<Troop> findDescendantsByType(Long troopId, TroopType type) {
        return hierarchyRepository.findDescendantsByType(troopId, type);
    }

    public List<Troop> findAncestors(Long troopId) {
        return hierarchyRepository.findAncestors(troopId);
    }

    public Optional<Troop> findFirstAncestorByType(Long troopId, TroopType type) {
        return hierarchyRepository.findFirstAncestorByType(troopId, type);
    }

}