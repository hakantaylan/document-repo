package com.example.troop.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(
        name = "troop",
        indexes = {
                @Index(name = "idx_troop_parent", columnList = "commander_id"),           // fast children query
                @Index(name = "idx_troop_type", columnList = "type"),                // filter by type
                @Index(name = "idx_troop_deleted", columnList = "deleted")           // soft-delete filtering
        }
)
//@SoftDelete
@EntityListeners(TroopListener.class)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
public class Troop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String country;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TroopType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "commander_id")
    private Troop commander;

//    @OneToMany(mappedBy = "commander", cascade = CascadeType.ALL)
//    @Builder.Default
//    private List<Troop> children = new ArrayList<>();

    @OneToMany(mappedBy = "troop", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<TroopFurniture> inventory = new ArrayList<>();

    private Instant deletedTime;
    private boolean deleted;

    @Version
    private long version;

//    public void addChild(Troop child) {
//        children.add(child);
//        child.setCommander(this);
//    }

}
