package com.example.troop.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(
        indexes = {
                @Index(name = "idx_furniture_name", columnList = "name"),            // search by name
                @Index(name = "idx_furniture_color", columnList = "color")           // filter by color
        }
)
public class Furniture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String size;

    private BigDecimal price;

    private String color;
}