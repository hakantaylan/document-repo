package com.example.troop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TroopApplication {
    public static void main(String[] args) {
        SpringApplication.run(TroopApplication.class, args);
    }
}
