//package com.example.troop.controller;
//
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/logistics")
//@RequiredArgsConstructor
//public class LogisticsController {
//    private final LogisticsService logisticsService;
//    private final FurnitureStockRepository stockRepo;
//
//    @PostMapping("/transfer")
//    public void transfer(@RequestParam Long stockId, @RequestParam Long toTroopId, @RequestParam int amount) {
//        logisticsService.transferFurniture(stockId, toTroopId, amount);
//    }
//
//    @PostMapping("/take-back/{id}")
//    public void takeBack(@PathVariable Long id) {
//        logisticsService.takeBack(id);
//    }
//
//    @GetMapping("/troop/{id}/value")
//    public ResponseEntity<Double> getValue(@PathVariable Long id) {
//        return ResponseEntity.ok(stockRepo.calculateTotalValue(id));
//    }
//}
