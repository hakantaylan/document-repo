package com.example.troop.repository;


import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
//@Profile("h2")
@RequiredArgsConstructor
public class H2TroopHierarchyRepository implements TroopHierarchyRepository {

    @PersistenceContext
    private final EntityManager em;

//    @Override
//    public List<Troop> findDescendants(Long troopId) {
//        return em.createNativeQuery("""
//                WITH RECURSIVE tree(id, name, country, type, commander_id, deleted, deleted_time, version) AS (
//                    SELECT * FROM troop WHERE id = :id
//                    UNION ALL
//                    SELECT t.*
//                    FROM troop t
//                    JOIN tree tr ON t.commander_id = tr.id
//                )
//                SELECT * FROM tree WHERE id <> :id
//                """, Troop.class)
//                .setParameter("id", troopId)
//                .getResultList();
//    }

    @Override
    public List<Troop> findDescendants(Long troopId) {
        return em.createNativeQuery("""
        WITH RECURSIVE tree(
            id,
            name,
            country,
            type,
            commander_id,
            deleted_time,
            deleted,
            version
        ) AS (
            SELECT
                id,
                name,
                country,
                type,
                commander_id,
                deleted_time,
                deleted,
                version
            FROM troop
            WHERE id = :id

            UNION ALL

            SELECT
                t.id,
                t.name,
                t.country,
                t.type,
                t.commander_id,
                t.deleted_time,
                t.deleted,
                t.version
            FROM troop t
            JOIN tree tr ON tr.id = t.commander_id
        )
        SELECT
            id,
            name,
            country,
            type,
            commander_id,
            deleted_time,
            deleted,
            version
        FROM tree
        WHERE id <> :id
        """, Troop.class)
                .setParameter("id", troopId)
                .getResultList();
    }

    @Override
    public List<Troop> findDescendantsByType(Long troopId, TroopType type) {
        return em.createNativeQuery("""
                WITH RECURSIVE tree AS (
                    SELECT * FROM troop WHERE id = :id
                    UNION ALL
                    SELECT t.*
                    FROM troop t
                    JOIN tree tr ON t.commander_id = tr.id
                )
                SELECT * FROM tree WHERE id <> :id AND type = :type
                """, Troop.class)
                .setParameter("id", troopId)
                .setParameter("type", type.name())
                .getResultList();
    }

    public List<Troop> findAncestors(Long troopId) {
        return em.createNativeQuery("""
        WITH RECURSIVE tree(
            id,
            name,
            country,
            type,
            commander_id,
            deleted_time,
            deleted,
            version
        ) AS (
            SELECT
                id,
                name,
                country,
                type,
                commander_id,
                deleted_time,
                deleted,
                version
            FROM troop
            WHERE id = :id

            UNION ALL

            SELECT
                parent.id,
                parent.name,
                parent.country,
                parent.type,
                parent.commander_id,
                parent.deleted_time,
                parent.deleted,
                parent.version
            FROM troop parent
            JOIN tree tr ON tr.commander_id = parent.id
        )
        SELECT *
        FROM tree
        WHERE id IS NOT NULL and id <> :id
        """, Troop.class)
                .setParameter("id", troopId)
                .getResultList();
    }

    @Override
    public Optional<Troop> findFirstAncestorByType(Long troopId, TroopType type) {

        List<Troop> result = em.createNativeQuery("""
                WITH RECURSIVE tree AS (
                    SELECT *, 0 depth FROM troop WHERE id = :id
                    UNION ALL
                    SELECT parent.*, depth + 1
                    FROM troop parent
                    JOIN tree tr ON tr.commander_id = parent.id
                )
                SELECT * FROM tree
                WHERE type = :type
                ORDER BY depth
                LIMIT 1
                """, Troop.class)
                .setParameter("id", troopId)
                .setParameter("type", type.name())
                .getResultList();

        return result.stream().findFirst();
    }
}