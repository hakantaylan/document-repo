package com.example.troop;

import com.example.troop.entity.Troop;
import com.example.troop.entity.TroopDto;
import com.example.troop.entity.TroopType;
import com.example.troop.repository.TroopRepository;
import com.example.troop.repository.TroopRepository2;
import com.example.troop.repository.TroopRepository3;
import com.example.troop.service.TroopService;
import com.example.troop.service.TroopService2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DataInitializer {

    @Autowired
    private TroopRepository troopRepository;
    @Autowired
    private TroopService troopService;
    @Autowired
    private TroopRepository2 troopRepository2;
    @Autowired
    private TroopService2 troopService2;

    @Autowired
    private TroopRepository3 troopRepository3;

    @EventListener(ApplicationReadyEvent.class)
    public void populateData(){
        Troop troop = Troop.builder().name("Alpha").type(TroopType.INFANTRY).country("Red Country").build();
        Troop root = troopRepository.save(troop);
        Troop child1 = Troop.builder().name("Bravo").type(TroopType.CAVALRY).country("Red Country").build();
        child1.setCommander(root);
        child1 = troopRepository.save(child1);
        Troop child2 = Troop.builder().name("Charlie").type(TroopType.ARTILLERY).country("Red Country").build();
        child2.setCommander(child1);
        child2 = troopRepository.save(child2);
        List<Troop> ancestors = troopService.getAncestors(child2.getId());
        List<Troop> descendants = troopService.getDescendants(root.getId());
        List<Troop> all = troopService.findAllByCountryOrdered2("Red Country");
//        List<Troop> redCountry = troopRepository2.findAllByCountryOrdered("Red Country");
        List<TroopDto> ancestors1 = troopRepository3.findAscendants(child2.getId());
        List<TroopDto> descendants1 = troopRepository3.findDescendants(root.getId());
        System.out.println("---------------------------------------");
    }

}
