package com.deneme.jpa.spatial.repository;

import com.deneme.jpa.spatial.model.DeliveryLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;


@Repository
public interface DeliveryLocationRepository extends JpaRepository<DeliveryLocation, UUID>, JpaSpecificationExecutor<DeliveryLocation> {

    @Query("""
            SELECT COUNT(loc) > 0 FROM DeliveryLocation loc
            WHERE ST_Contains(loc.geometry, ST_SetSRID(ST_MakePoint(:x, :y), 4326))
            """)
    boolean existsLocationContainingPoint(@Param("x") float longitudeX, @Param("y") float latitudeY);

    @Query("""
            SELECT loc FROM DeliveryLocation loc
            WHERE ST_Contains(loc.geometry, ST_SetSRID(ST_MakePoint(:x, :y), 4326))
            """)
    Optional<DeliveryLocation> findLocationByCoordinates(@Param("x") float longitudeX, @Param("y") float latitudeY);

}
