package com.deneme.jpa.spatial.service;

import com.deneme.jpa.spatial.model.Destination2;
import com.deneme.jpa.spatial.model.DangerZone;
import com.deneme.jpa.spatial.repository.DestinationRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
@Transactional
public class DMPI2Service {
    private final DestinationRepository repository;
    @PersistenceContext
    private EntityManager entityManager;

    public List<Destination2> findDMPIWithClosestSideEffect(double distance) {
//        String queryStr =
//                "SELECT dmpi, se, ST_Distance(dmpi.point, se.shape) AS distance " +
//                        "FROM DMPI2 dmpi " +
//                        "JOIN dmpi.targetElement te " +
//                        "JOIN te.targetVersion tv " +
//                        "JOIN tv.sideEffects se " +
//                        "WHERE ST_Distance(dmpi.point, se.shape) <= :_distance " +
//                        "ORDER BY distance";
        String queryStr =
                "WITH RankedData AS ( " +
                        "  SELECT dmpi, se, ST_DistanceSphere(dmpi.point, se.shape) AS distance, " +
                        "          ROW_NUMBER() OVER (PARTITION BY dmpi.id ORDER BY ST_DistanceSphere(dmpi.point, se.shape)) AS rn " +
                        "FROM DMPI2 dmpi " +
                        "JOIN dmpi.targetElement te " +
                        "JOIN te.targetVersion tv " +
                        "JOIN tv.sideEffects se " +
                        "WHERE ST_DistanceSphere(dmpi.point, se.shape) <= :_distance " +
                        ") " +
                        "SELECT rd.dmpi, rd.se, rd.distance " +
                        "FROM RankedData rd " +
                        "WHERE rd.rn = 1";

//        String queryStr =
//                "WITH RankedData AS ( " +
//                        "   SELECT pd.id AS phoneDetailId, pd, b, ST_Distance(pd.point, b.shape) AS distance, " +
//                        "          ROW_NUMBER() OVER (PARTITION BY pd.id ORDER BY ST_Distance(pd.point, b.shape)) AS rn " +
//                        "   FROM PhoneDetail pd " +
//                        "   JOIN pd.parent p " +
//                        "   JOIN p.author a " +
//                        "   JOIN a.books b " +
//                        "   WHERE ST_Distance(pd.point, b.shape) <= :distance " +
//                        ") " +
//                        "SELECT pd, b " +
//                        "FROM RankedData rb " +
//                        "JOIN PhoneDetail pd ON pd.id = rb.phoneDetailId " +
//                        "JOIN Book b ON b.id = rb.b.id " +
//                        "WHERE rb.rn = 1";
        List<Object[]> results = entityManager.createQuery(queryStr)
                .setParameter("_distance", distance)
                .getResultList();

        List<Destination2> resultList = new ArrayList<>();
        for (Object[] result : results) {
            Destination2 dmpi = (Destination2) result[0];
            DangerZone dangerZone = (DangerZone) result[1];
            Double sideEffectDistance = (Double) result[2];
            dmpi.setDangerZone(dangerZone);
            dmpi.setDangerZoneDistance(sideEffectDistance);
            resultList.add(dmpi);
        }

        return resultList;
    }
}
