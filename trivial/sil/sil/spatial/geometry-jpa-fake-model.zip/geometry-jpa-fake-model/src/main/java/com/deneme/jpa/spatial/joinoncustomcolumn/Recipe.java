package com.deneme.jpa.spatial.joinoncustomcolumn;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="recipes")
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class Recipe {
    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "cocktail")
    private String cocktail;

    @Column
    private String instructions;

}
