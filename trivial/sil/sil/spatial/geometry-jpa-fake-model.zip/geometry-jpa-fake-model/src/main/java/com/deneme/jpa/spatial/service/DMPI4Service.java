package com.deneme.jpa.spatial.service;

import com.deneme.jpa.spatial.model.Destination2;
import com.deneme.jpa.spatial.model.DangerZone;
import com.deneme.jpa.spatial.spec.DMPISpecification;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DMPI4Service {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Destination2> calis(double maxDistance) {
        return DMPISpecification.calis(entityManager);
    }

    public List<Destination2> findDMPIWithClosestSideEffect(double maxDistance) {

//        List<Object[]> childDetailsWithNearestAddress = DMPISpecification.findChildDetailsWithNearestAddress2(entityManager);
        List<Object[]> childDetailsWithNearestAddress = DMPISpecification.aaa(entityManager);
//        List<Object[]> childDetailsWithNearestAddress = DMPISpecification.aaa2(entityManager);
        return mapToDMPI2(childDetailsWithNearestAddress);
    }

    public List<Destination2> nativeQ(double maxDistance) {
//        entityManager.createQuery("SELECT d, ST_DistanceSphere(d.point, se.shape) as _dist, se from DMPI d join TargetElement te join SideEffect se on se.targetVersion = te.targetVersion"
//                        + " WHERE c.subscriptionId = s.id AND s.id = u.subscriptionId AND u.email=:email");
        Query query = entityManager.createQuery("select d,  ( select ST_DistanceSphere(d.point, se.shape) as _dist, se from SideEffect se join TargetElement te on te.targetVersion = se.targetVersion where te.id = d.targetElement.id order by _dist limit 1 ) from DMPI d");
//        query.setParameter("email", eamil)
//        List<Object[]> childDetailsWithNearestAddress = DMPISpecification.findChildDetailsWithNearestAddress2(entityManager);
        return mapToDMPI2(query.getResultList());
    }

    private List<Destination2> mapToDMPI2(List<Object[]> results) {
        List<Destination2> phoneDetails = new ArrayList<>();

        for (Object[] result : results) {
            Destination2 phoneDetail = (Destination2) result[0];
            DangerZone nearestBook = (DangerZone) result[1];
            Double distance = (Double) result[2];

            // Set the nearestBook and nearestBookDistance in PhoneDetail
            phoneDetail.setDangerZone(nearestBook);
            phoneDetail.setDangerZoneDistance(distance);

            // Add to the list of PhoneDetail
            phoneDetails.add(phoneDetail);
        }

        return phoneDetails;
    }
}
