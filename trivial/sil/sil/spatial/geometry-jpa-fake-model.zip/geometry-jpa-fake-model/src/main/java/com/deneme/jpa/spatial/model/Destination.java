package com.deneme.jpa.spatial.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Formula;
import org.locationtech.jts.geom.Point;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Destination {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private String name;
    private String no;

    @Column(name = "point" ) // , columnDefinition = "geometry(Point, 4326)")
    private Point point;

    @ManyToOne(fetch = FetchType.LAZY)
    private Location location;

//    @Formula("(SELECT DISTINCT ON (d.id) ST_Distance(d.point, s.shape) as distance FROM DMPI d inner join TARGET_ELEMENT te on te.id = d.target_element_id inner join SIDE_EFFECT s on s.target_version_id = te.target_version_id  where d.id = id order by d.id, ST_Distance(d.point, s.shape) ASC)")
//    @Formula("(SELECT ROUND(ST_DistanceSphere(d.point, s.shape), 2) as distance  FROM DMPI d inner join TARGET_ELEMENT te on te.id = d.target_element_id inner join SIDE_EFFECT s on s.target_version_id = te.target_version_id where d.id = id order by distance asc limit 1)")
//    @Formula("(SELECT ST_DistanceSphere(d.point, dz.shape) as _distance FROM DESTINATION d inner join LOCATION l on l.id = d.location_id inner join DANGER_ZONE dz on dz.parent_version_id = l.parent_version_id and ST_DistanceSphere(d.point, dz.shape) <= 1000 where d.id = {alias}.id order by _distance asc limit 1)")
//    @Formula("(SELECT ST_DistanceSphere(d.point, s.shape) FROM DMPI d INNER JOIN TARGET_ELEMENT te ON te.id = d.target_element_id INNER JOIN SIDE_EFFECT s ON s.target_version_id = te.target_version_id AND ST_DistanceSphere(d.point, s.shape) <= 1000 WHERE d.id = {alias}.id ORDER BY ST_DistanceSphere(d.point, s.shape) ASC LIMIT 1)")
    @Formula("""
    (SELECT ST_DistanceSphere(d.point, dz.shape) as _distance from DESTINATION d
        inner join LOCATION l on l.id = d.location_id
        inner join DANGER_ZONE dz on dz.parent_version_id = l.parent_version_id and ST_DistanceSphere(d.point, dz.shape) <= 1000
        where d.id = {alias}.id order by _distance asc limit 1
    )
    """)
    private Double dangerZoneDistance;
//    @Formula("(SELECT s.name FROM DMPI d inner join TARGET_ELEMENT te on te.id = d.target_element_id inner join SIDE_EFFECT s on s.target_version_id = te.target_version_id where d.id = id order by ROUND(ST_DistanceSphere(d.point, s.shape), 2) asc limit 1)")
    @Formula("""
    (SELECT dz.name from Destination d
        inner join Location l on l.id = d.location_id
        inner join DANGER_ZONE dz on dz.parent_version_id = l.parent_version_id and ST_DistanceSphere(d.point, dz.shape) <= 1000
        where d.id = {alias}.id order by ROUND(ST_DistanceSphere(d.point, dz.shape), 2) asc limit 1
    )
    """)
    private String dangerZoneName;
//
    @Formula("""
    (SELECT ST_Azimuth(ST_ClosestPoint(dz.shape, d.point), d.point) from Destination d
        inner join Location l on l.id = d.location_id
        inner join DANGER_ZONE dz on dz.parent_version_id = l.parent_version_id and ST_DistanceSphere(d.point, dz.shape) <= 1000
        where d.id = {alias}.id order by ROUND(ST_DistanceSphere(d.point, dz.shape), 2) asc limit 1
    )
    """)
    private Double dangerZoneAngle;
}
