package com.deneme.jpa.spatial.config;

import com.deneme.jpa.spatial.model.Destination2;
import com.deneme.jpa.spatial.service.DMPI2Service;
import com.deneme.jpa.spatial.service.DMPI3Service;
import com.deneme.jpa.spatial.service.DMPI4Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ZAppReadyCode {
    @Autowired
    private DMPI2Service service;
    @Autowired
    private DMPI3Service service3;
    @Autowired
    private DMPI4Service service4;


    @EventListener(ApplicationReadyEvent.class)
    public void appReady() throws Exception {
//        List<DMPI2> dmpiWithClosestSideEffect = service3.findDMPIWithClosestSideEffect2(1_000);
        List<Destination2> dmpiWithClosestSideEffect = service4.findDMPIWithClosestSideEffect(1_000);
//        List<DMPI2> dmpiWithClosestSideEffect = service4.calis(1_000);
//        List<DMPI2> dmpiWithClosestSideEffect = service4.nativeQ(1_000);
        System.out.println("-------------------------------------------------------");
    }
}
