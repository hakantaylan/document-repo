package com.deneme.jpa.spatial.repository;

import com.deneme.jpa.spatial.model.Destination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface DestinationRepository extends JpaRepository<Destination, Long>, JpaSpecificationExecutor<Destination> {

    @Query(value = """
            SELECT DISTINCT ON (d.id) d.*, dz.name as danger_zone_name, ST_Distance(d.point, s.shape) as distance  FROM Destination d inner join Location l on l.id = d.location_id inner join DANGER_ZONE dz on dz.parent_version_id = l.parent_version_id  order by d.id, ST_Distance(d.point, dz.shape) ASC
            """, nativeQuery = true)
    List<Object[]> findByQuery();

    @Override
//    @EntityGraph(attributePaths =)
    List<Destination> findAll();
}
