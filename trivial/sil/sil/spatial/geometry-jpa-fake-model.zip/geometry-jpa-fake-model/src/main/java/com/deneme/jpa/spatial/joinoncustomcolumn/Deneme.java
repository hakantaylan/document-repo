package com.deneme.jpa.spatial.joinoncustomcolumn;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Deneme {
    @Autowired
    private CocktailWithRecipeRepository cocktailWithRecipeRepository;
    @Autowired
    private CocktailRepository cocktailRepository;
    @Autowired
    private RecipeRepository recipeRepository;

    @PersistenceContext
    private EntityManager entityManager;


//    @EventListener(ApplicationReadyEvent.class)
    public void appReady() throws Exception {
        cocktailRepository.save(Cocktail.builder().name("Cocktail1").price(100).build());
        cocktailRepository.save(Cocktail.builder().name("Cocktail2").price(200).build());
        recipeRepository.save(Recipe.builder().cocktail("Cocktail1").instructions("Instructions1").build());
        recipeRepository.save(Recipe.builder().cocktail("Cocktail2").instructions("Instructions2").build());
        List<CocktailWithRecipe> all = cocktailWithRecipeRepository.findAll();
        System.out.println("-------------------------------------------------------");

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);
        CriteriaQuery<CocktailWithRecipe> query = cb.createQuery(CocktailWithRecipe.class);

        // Root for ChildDetail
        Root<CocktailWithRecipe> childDetailRoot = query.from(CocktailWithRecipe.class);

        // Join to Child entity
//        Join<CocktailWithRecipe, Recipe> childJoin = childDetailRoot.join("recipe", JoinType.LEFT).on(cb.equal(childDetailRoot.get("name"), childDetailRoot.get("recipe").get("cocktail")));
        Join<CocktailWithRecipe, Recipe> childJoin = childDetailRoot.join("recipe", JoinType.LEFT);
//        childJoin.on(cb.equal(childDetailRoot.get("name"), "Cocktail1"));


        // Create the main query
//        query.multiselect(childDetailRoot, childJoin).distinct(true);
        query.select(childDetailRoot);
        List<CocktailWithRecipe> resultList = entityManager.createQuery(query).getResultList();
        System.out.println("-------------------------------------------------------");
    }
}
