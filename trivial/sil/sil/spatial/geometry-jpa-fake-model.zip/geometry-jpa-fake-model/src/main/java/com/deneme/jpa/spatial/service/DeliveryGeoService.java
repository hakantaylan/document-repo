package com.deneme.jpa.spatial.service;

import com.deneme.jpa.spatial.repository.DeliveryLocationRepository;
import com.deneme.jpa.spatial.repository.DeliveryLocationRepository2;
import com.deneme.jpa.spatial.dto.DeliveryTermsResponse;
import com.deneme.jpa.spatial.exception.Message;
import com.deneme.jpa.spatial.exception.RestException;
import com.deneme.jpa.spatial.spec.LocationSpec;
import com.deneme.jpa.spatial.model.DeliveryLocation;
import com.deneme.jpa.spatial.dto.CreateZonesRequest;
import com.deneme.jpa.spatial.dto.LocationPointRequest;
import com.deneme.jpa.spatial.dto.mapper.DeliveryLocationToTermsMapper;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;
import org.geolatte.geom.jts.JTS;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Point;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Service
@RequiredArgsConstructor
public class DeliveryGeoService {
    private final DeliveryLocationRepository locationRepository;
    private final DeliveryLocationRepository2 locationRepository2;
    private final DeliveryLocationToTermsMapper locationToTermsMapper;
    @PersistenceContext
    private EntityManager entityManager;

    public void saveAllDeliveryZones(CreateZonesRequest geoJson) {
        var zones = geoJson.features().stream()
                .map(feature -> DeliveryLocation.builder()
                        .city(feature.properties().city())
                        .district(feature.properties().district())
                        .price(feature.properties().price())
                        .fill(feature.properties().fill())
                        .geometry(feature.geometry())
                        .build())
                .toList();

        locationRepository.saveAll(zones);
    }

    public DeliveryTermsResponse getDeliveryTerms(LocationPointRequest request) {
        var location = locationRepository.findLocationByCoordinates(
                request.longitudeX(), request.latitudeY()
        ).orElseThrow(() -> new RestException(Message.ADDRESS_OUT_OF_DELIVERY_ZONE));

        return locationToTermsMapper.toResponse(location);
    }


    public void inDeliveryZone(LocationPointRequest request) {
        var isDeliverable = locationRepository.existsLocationContainingPoint(
                request.longitudeX(), request.latitudeY()
        );
        if (!isDeliverable) throw new RestException(Message.ADDRESS_OUT_OF_DELIVERY_ZONE);
    }


    public List<DeliveryTermsResponse> getDeliveryZonesQueryingBySpec(LocationPointRequest request) {
        Specification<DeliveryLocation> locationSpec = LocationSpec.locationContains(request.longitudeX(), request.latitudeY());
        Specification<DeliveryLocation> cityEquals = LocationSpec.cityEquals("Eskişehir");
        var location = locationRepository.findAll(locationSpec.and(cityEquals));
        return locationToTermsMapper.toResponse(location);
    }

    public List<DeliveryLocation> findAllLocationsWithNearestNeighbour(float longitude, float latitude, double radius) {
        List<Object[]> results = locationRepository2.findAllLocationsWithNearestNeighbour(longitude, latitude, radius);
        List<DeliveryLocation> locations = new ArrayList<>();

        for (Object[] row : results) {
            byte[] UUIDBytes = (byte[]) row[0];
            ByteBuffer bb = ByteBuffer.wrap(UUIDBytes);
            Geometry geometry = JTS.to((org.geolatte.geom.Geometry) row[6]);
            DeliveryLocation dl = DeliveryLocation.builder().
                    id(new UUID(bb.getLong(), bb.getLong())).
                    version(((Number) row[1]).longValue()).
                    city((String) row[2]).
                    district((String) row[3]).
                    price((BigDecimal) row[4]).
                    fill((String) row[5]).
                    geometry(geometry).
                    build();
            locations.add(dl);
        }

        return locations;
    }

    public List<DeliveryLocation> findAllLocationsWithNearestNeighborUsingCriteria(float longitude, float latitude, double radius) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<DeliveryLocation> cq = cb.createQuery(DeliveryLocation.class);
        Root<DeliveryLocation> root = cq.from(DeliveryLocation.class);

        cq.select(cb.construct(DeliveryLocation.class,
                        root.get("id"),
                        root.get("version"),
                        root.get("city"),
                        root.get("district"),
                        root.get("price"),
                        root.get("fill"),
                        root.get("geometry"),
                        cb.function("ST_Distance", Double.class, root.get("geometry"),
                                cb.function("ST_SetSRID", Point.class,
                                        cb.function("ST_MakePoint", Point.class, cb.literal(longitude), cb.literal(latitude)), cb.literal(4326)
                                )
                        ).alias("distanceTo")
                ))
                .where(cb.le(cb.function("ST_Distance", Double.class, root.get("geometry"),
                        cb.function("ST_SetSRID", Point.class,
                                cb.function("ST_MakePoint", Point.class, cb.literal(longitude), cb.literal(latitude)),
                                cb.literal(4326))), radius))
                .orderBy(cb.asc(cb.literal("distanceTo")));

        return entityManager.createQuery(cq).setMaxResults(1).getResultList();
    }

    public List<DeliveryLocation> denemeWithFormulaAndCriter1a(float longitude, float latitude, double radius) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<DeliveryLocation> cq = cb.createQuery(DeliveryLocation.class);
        Root<DeliveryLocation> root = cq.from(DeliveryLocation.class);

        cq.select(root)
                .where(cb.le(cb.function("ST_Distance", Double.class, root.get("geometry"),
                        cb.function("ST_SetSRID", Point.class,
                                cb.function("ST_MakePoint", Point.class, cb.literal(longitude), cb.literal(latitude)),
                                cb.literal(4326))), radius))
                .orderBy(cb.asc(cb.literal("_distanceTo")));
        return entityManager.createQuery(cq).setMaxResults(1).getResultList();
    }

    public List<DeliveryLocation> denemeWithFormulaAndQuery(float longitude, float latitude, double radius) {
        return locationRepository2.deneme(longitude, latitude, radius);
    }

    public List<DeliveryLocation> denemeWithFindAll(float longitude, float latitude, double radius) {
        return locationRepository2.findAll();
    }
}
