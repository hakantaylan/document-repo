package com.deneme.jpa.spatial.spec;

import com.deneme.jpa.spatial.model.DeliveryLocation;
import jakarta.persistence.criteria.Expression;
import org.hibernate.query.sqm.internal.SqmCriteriaNodeBuilder;
import org.hibernate.spatial.SpatialFunction;
import org.hibernate.spatial.criteria.JTSSpatialCriteriaBuilder;
import org.hibernate.spatial.predicate.JTSSpatialPredicates;
import org.locationtech.jts.geom.*;
import org.springframework.data.jpa.domain.Specification;

public class LocationSpec {

    public static Specification<DeliveryLocation> filterWithinRadius(double longitude, double latitude, double radius) {
        return (root, query, builder) -> {
            Expression<Geometry> geography = builder.function("geography", Geometry.class, root.get("geometry"));
            Expression<Point> point = builder.function("ST_Point", Point.class, builder.literal(longitude),
                    builder.literal(latitude));
            Expression<Point> comparisonPoint = builder.function("ST_SetSRID", Point.class, point,
                    builder.literal(4326));
            Expression<Boolean> expression = builder.function(SpatialFunction.dwithin.toString(), boolean.class,
                    geography, comparisonPoint, builder.literal(radius));
            return builder.equal(expression, true);
        };
    }

    public static Specification<DeliveryLocation> filterWithinRadiusDeprecatedWay(float longitude, float latitude, float radius) {
        return (root, query, builder) -> {
            GeometryFactory factory = new GeometryFactory();
            Point comparisonPoint = factory.createPoint(new Coordinate(latitude, longitude));
            comparisonPoint.setSRID(4326);
            return JTSSpatialPredicates.distanceWithin(builder, root.get("geometry"), comparisonPoint, radius);
        };
    }

    public static Specification<DeliveryLocation> locationContainsDeprecatedWay(float longitude, float latitude) {
        return (root, query, builder) -> {
            GeometryFactory factory = new GeometryFactory();
            Point containsPoint = factory.createPoint(new Coordinate(latitude, longitude));
            containsPoint.setSRID(4326);
            return JTSSpatialPredicates.contains(builder, root.get("geometry"), containsPoint);
        };
    }

    public static Specification<DeliveryLocation> filterWithinRadius(float longitude, float latitude, float radius) {
        return (root, query, builder) -> {
            JTSSpatialCriteriaBuilder spatialCriteriaBuilder = ((SqmCriteriaNodeBuilder) builder).unwrap(JTSSpatialCriteriaBuilder.class);
            GeometryFactory factory = new GeometryFactory(new PrecisionModel(), 4326);
            Point comparisonPoint = factory.createPoint(new Coordinate(latitude, longitude));
            return spatialCriteriaBuilder.distanceWithin(root.get("geometry"), comparisonPoint, radius);
        };
    }

    public static Specification<DeliveryLocation> locationContains(float longitude, float latitude) {
        return (root, query, builder) -> {
            JTSSpatialCriteriaBuilder spatialCriteriaBuilder = ((SqmCriteriaNodeBuilder) builder).unwrap(JTSSpatialCriteriaBuilder.class);
            GeometryFactory factory = new GeometryFactory(new PrecisionModel(), 4326);
            Point containsPoint = factory.createPoint(new Coordinate(latitude, longitude));
            return spatialCriteriaBuilder.contains(root.get("geometry"), containsPoint);
        };
    }

    public static Specification<DeliveryLocation> cityEquals(String city) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("city"), city);
    }

}
