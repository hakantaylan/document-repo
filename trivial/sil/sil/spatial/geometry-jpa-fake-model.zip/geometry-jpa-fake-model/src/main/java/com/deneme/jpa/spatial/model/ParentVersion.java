package com.deneme.jpa.spatial.model;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Point;

import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class ParentVersion {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private String type;

//    @Column(name = "point") // , columnDefinition = "geometry(Polygon, 4326)
    private Point point;

    @Builder.Default
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "parentVersion", orphanRemoval = true)
    private Set<Location> locations = new HashSet<>();

    @Builder.Default
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "parentVersion", orphanRemoval = true)
    private Set<DangerZone> dangerZones = new HashSet<>();

    public void addLocation(Location location) {
        locations.add(location);
        location.setParentVersion(this);
    }

    public void removeLocation(Location location) {
        locations.remove(location);
        location.setParentVersion(null);
    }

    public void addDangerZone(DangerZone dangerZone) {
        dangerZones.add(dangerZone);
        dangerZone.setParentVersion(this);
    }

    public void removeDangerZone(DangerZone dangerZone) {
        dangerZones.remove(dangerZone);
        dangerZone.setParentVersion(null);
    }
}
