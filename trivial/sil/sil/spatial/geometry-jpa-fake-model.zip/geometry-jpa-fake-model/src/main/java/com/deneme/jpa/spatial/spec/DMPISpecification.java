package com.deneme.jpa.spatial.spec;

import com.deneme.jpa.spatial.model.Destination2;
import com.deneme.jpa.spatial.model.DangerZone;
import com.deneme.jpa.spatial.model.Location;
import com.deneme.jpa.spatial.model.ParentVersion;
//import jakarta.persistence.criteria.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.*;
import org.hibernate.query.Query;
import org.hibernate.query.criteria.*;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public class DMPISpecification {

    public static Specification<Destination2> hasNearestBookWithinDistance(double maxDistance) {
        return (root, query, cb) -> {
            // Creating the join between PhoneDetail and Phone
            Join<Destination2, Location> phoneJoin = root.join("targetElement");

            // Creating the join between Phone and Parent
            Join<Location, ParentVersion> parentJoin = phoneJoin.join("targetVersion");

            // Creating the join between Parent and Book
            Join<ParentVersion, DangerZone> bookJoin = parentJoin.join("sideEffects");

            // Calculate the distance to the book
            Expression<Double> distanceToBook = cb.function(
                    "ST_Distance",
                    Double.class,
                    root.get("point"), // Reference the PhoneDetail point directly
                    bookJoin.get("shape") // Reference the Book geometry
            );

            // Filtering based on distance constraint
            Predicate nearBooks = cb.lessThanOrEqualTo(distanceToBook, maxDistance);

            // Ensure distinct results and avoid duplicates
            query.distinct(true);//.select(root).where(nearBooks);

            return cb.and(nearBooks);
        };
    }
    public static Specification<Destination2> hasClosestBook() {
        return (root, query, cb) -> {
            // Create a subquery to find the ID of the closest book
            Subquery<Long> subquery = query.subquery(Long.class);
            Root<DangerZone> bookRoot = subquery.from(DangerZone.class);
            Join<DangerZone, ParentVersion> targetVersion = bookRoot.join("targetVersion", JoinType.INNER);
            Join<ParentVersion, Location> targetElements = targetVersion.join("targetElements", JoinType.LEFT);


            // Calculate distance
            Expression<Double> distanceToBook = cb.function(
                    "ST_DistanceSphere",
                    Double.class,
                    root.get("point"),
                    bookRoot.get("shape")
            );

            // Define the main query
//            subquery.select(bookRoot.get("id"))
//                    .where(cb.and(cb.equal(bookRoot.get("targetVersion").get("id"), root.get("targetElement").get("targetVersion").get("id")), // Ensuring we're checking the right author's books
//                            cb.lessThanOrEqualTo(distanceToBook, 1000.0))) // Assuming a check of 1000 meters
//                    .orderBy(cb.asc(distanceToBook)) // Order by distance to get closest
//                    .distinct(true);
            subquery.select(bookRoot.get("id"))
                    .where(cb.equal(bookRoot.get("targetVersion").get("id"), root.get("targetElement").get("targetVersion").get("id"))) // Ensure it matches the parent's author
                    .groupBy(bookRoot.get("id"))
                    .having(cb.equal(distanceToBook, cb.min(distanceToBook))); // Ensure we're selecting the book with min distance

            // Return condition: only select PhoneDetail that matches the closest book
            return cb.equal(bookRoot.get("id"), subquery);
//            return cb.and(cb.equal(bookRoot.get("id"), subquery)); // Only select PhoneDetail that matches closest book
        };
    }

    public static Specification<Destination2> hasClosestBook2() {
        return (root, query, cb) -> {
            // Creating the join between PhoneDetail and Phone
            Join<Destination2, Location> phoneJoin = root.join("targetElement");

            // Creating the join between Phone and Parent
            Join<Location, ParentVersion> parentJoin = phoneJoin.join("targetVersion");

            // Creating the join between Parent and Book
            Join<ParentVersion, DangerZone> bookJoin = parentJoin.join("sideEffects");

            // Calculate the distance to the book
            Expression<Double> distanceToBook = cb.function(
                    "ST_DistanceSphere",
                    Double.class,
                    root.get("point"), // Reference PhoneDetail's point
                    bookJoin.get("shape") // Reference Book's geometry
            );

            Predicate nearBooks = cb.lessThanOrEqualTo(distanceToBook, cb.literal(1000000.0)); // Example use case

            // Ensure distinct results and include the books
            query.distinct(true); // Ensure distinct results
            query.where(nearBooks); // You might not want this since you want to pull distances

            query.orderBy(cb.asc(distanceToBook)); // Order by distance
            return cb.and(nearBooks);
        };
    }

    public static List<Tuple> aaa2(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        JpaCriteriaQuery<Tuple> query = (JpaCriteriaQuery<Tuple>) cb.createTupleQuery();

        // Root for ChildDetail
        Root<Destination2> childDetailRoot = query.from(Destination2.class);

        // Join to Child entity
//        Join<DMPI2, TargetElement> childJoin = childDetailRoot.join("targetElement", JoinType.INNER);
//        // Join to ParentEntity
//        Join<TargetElement, TargetVersion> parentJoin = childJoin.join("targetVersion", JoinType.INNER);
//        // Join to Address entity
//        Join<TargetVersion, SideEffect> addressJoin = parentJoin.join("sideEffects", JoinType.LEFT);

        // Create a subquery for minimum distance for each ChildDetail
        JpaSubQuery<Tuple> nearestDistanceSubquery = query.subquery(Tuple.class);
        Root<DangerZone> addressSubqueryRoot = nearestDistanceSubquery.from(DangerZone.class);
        Join<DangerZone, ParentVersion> targetVersion = addressSubqueryRoot.join("targetVersion");
        Join<ParentVersion, Location> targetElements = targetVersion.join("targetElements");
        Join<Location, Destination2> dmpiList = targetElements.join("dmpiList");

        // Calculate distance
        Expression<Double> distance = cb.function("ST_DistanceSphere", Double.class,
                dmpiList.get("point"), addressSubqueryRoot.get("shape"));

        nearestDistanceSubquery.multiselect(addressSubqueryRoot, distance.alias("_dist"))
                .where(cb.le(distance, 1000)).orderBy(cb.asc(cb.literal("_dist")));

        // Create the main query now
        query.multiselect(
                        childDetailRoot,   // Select ChildDetail
                        nearestDistanceSubquery
                );



//        JpaCriteriaQuery<Tuple> cteSubquery = cb.createTupleQuery();
//        JpaSubQuery<Tuple> data1 = cteSubquery.subquery(Tuple.class);
//        data1.multiselect( cb.literal( "any uuid 1" ).alias( "col1" ), cb.literal( "any uuid 2" ).alias( "col2" ) );
//        List<JpaSubQuery<Tuple>> dataN = new ArrayList<>();
//        JpaSubQuery<Tuple> data2 = cteSubquery.subquery(Tuple.class);
//        data2.multiselect( cb.literal( "any uuid 3" ).alias( "col1" ), cb.literal( "any uuid 4" ).alias( "col2" ) );
//        dataN.add( data2 );
//
//        JpaCriteriaQuery<RealTable> cq = cb.createQuery( RealTable.class );
//        JpaRoot<Tuple> subqueryRoot = cteSubquery.from( cb.unionAll( data1, dataN.toArray( new JpaSubQuery[0] ) ) );
//        cteSubquery.multiselect( subqueryRoot.get("col1").alias("col1"), subqueryRoot.get("col2").alias("col2") );
//        JpaCteCriteria<Tuple> dataCte = cq.with( cteSubquery );
//        JpaRoot<RealTable> root = cq.from( RealTable.class );
//        JpaJoin<Tuple> cteJoin = root.join( dataCte );
//        cteJoin.on( cb.and( cb.equal( root.get( "col1" ), cteJoin.get( "col1" ) ), cb.equal( root.get( "col2" ), cteJoin.get( "col2" ) ) ) );



        // Execute the query
        List<Tuple> results = entityManager.createQuery(query).getResultList();

        return results; // This returns distinct ChildDetail, nearest Address, and its distance
    }

    public static List<Object[]> aaa(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);

        // Root for ChildDetail
        Root<Destination2> childDetailRoot = query.from(Destination2.class);

        // Join to Child entity
        Join<Destination2, Location> childJoin = childDetailRoot.join("location", JoinType.INNER);
        // Join to ParentEntity
        Join<Location, ParentVersion> parentJoin = childJoin.join("parentVersion", JoinType.INNER);
        // Join to Address entity
        Join<ParentVersion, DangerZone> addressJoin = parentJoin.join("dangerZones", JoinType.LEFT);

        // Calculate distance between ChildDetail point and Address shape
        Expression<Double> distance = cb.function("ST_DistanceSphere", Double.class,
                childDetailRoot.get("point"), addressJoin.get("shape"));

        // Create the main query
        query.multiselect(
                        childDetailRoot,   // Select ChildDetail
                        addressJoin,       // Select the Address entity
                        cb.min(distance)   // Calculate minimum distance
                ).distinct(true)
                .groupBy(childDetailRoot, addressJoin) // Group by ChildDetail and Address to find the nearest one

                // Add a having clause if necessary to filter for the minimum distance per ChildDetail
                .having(cb.equal(distance, cb.min(distance)));

        // Execute the query
        List<Object[]> results = entityManager.createQuery(query).getResultList();

        return results;
    }

    public static List<Object[]> aaaa(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);

        // Root for ChildDetail
        Root<Destination2> childDetailRoot = query.from(Destination2.class);

        // Join to Child entity
        Join<Destination2, Location> childJoin = childDetailRoot.join("location", JoinType.INNER);
        // Join to ParentEntity
        Join<Location, ParentVersion> parentJoin = childJoin.join("parentVersion", JoinType.INNER);
        // Join to Address entity
        Join<ParentVersion, DangerZone> addressJoin = parentJoin.join("dangerZones", JoinType.LEFT);

        // Calculate distance between ChildDetail point and Address shape
        Expression<Double> distance = cb.function("ST_DistanceSphere", Double.class,
                childDetailRoot.get("point"), addressJoin.get("shape"));

        // Create the main query
        query.multiselect(
                        childDetailRoot,   // Select ChildDetail
                        addressJoin,       // Select the Address entity
                        cb.min(distance)   // Calculate minimum distance
                ).distinct(true)
                .groupBy(childDetailRoot, addressJoin) // Group by ChildDetail and Address to find the nearest one

                // Add a having clause if necessary to filter for the minimum distance per ChildDetail
                .having(cb.equal(distance, cb.min(distance)));

        // Execute the query
        List<Object[]> results = entityManager.createQuery(query).getResultList();

        return results;
    }

    public static List<Object[]> findChildDetailsWithNearestAddress2(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);

        // Root for ChildDetail
        Root<Destination2> childDetailRoot = query.from(Destination2.class);

        // Join to Child
        Join<Destination2, Location> childJoin = childDetailRoot.join("targetElement");

        // Join to ParentEntity
        Join<Location, ParentVersion> parentJoin = childJoin.join("targetVersion");

        // Subquery to find the nearest Address
//        Subquery<SideEffect> nearestAddressSubquery = query.subquery(SideEffect.class);
//        Root<SideEffect> addressRoot = nearestAddressSubquery.from(SideEffect.class);

        Subquery<Double> nearestDistanceSubquery = query.subquery(Double.class);
        Root<DangerZone> addressRoot = nearestDistanceSubquery.from(DangerZone.class);
        Join<DangerZone, ParentVersion> targetVersionJoin = addressRoot.join("targetVersion", JoinType.INNER);
        Join<ParentVersion, Location> targetElementsJoin = targetVersionJoin.join("targetElements", JoinType.INNER);
        nearestDistanceSubquery.select(cb.min(cb.function("ST_DistanceSphere", Double.class,
                        childDetailRoot.get("point"), addressRoot.get("shape"))))
                .where(cb.and(cb.equal(addressRoot.get("targetVersion"), parentJoin), cb.le(cb.function("ST_DistanceSphere", Double.class,
                        childDetailRoot.get("point"), addressRoot.get("shape")), 1_000)));

        // Group the results by ChildDetail and find the minimum distance
//        nearestDistanceSubquery.groupBy(addressRoot)
//                .having(cb.equal(cb.function("ST_DistanceSphere", Double.class,
//                                childDetailRoot.get("point"), addressRoot.get("shape")),
//                        cb.min(cb.function("ST_Distance", Double.class,
//                                childDetailRoot.get("point"), addressRoot.get("shape")))));

        // Main query selects ChildDetail and its nearest address distance
        query.multiselect(
                childDetailRoot,
                nearestDistanceSubquery
        );//.groupBy(childDetailRoot); // Group the results to avoid duplication


        List<Object[]> results = entityManager.createQuery(query).getResultList();

        return results; // This will return List of Object[] where first element is ChildDetail and second element is the distance.
    }

    public static List<Object[]> findChildDetailsWithNearestAddress(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);

        // Root for ChildDetail
        Root<Destination2> childDetailRoot = query.from(Destination2.class);

        // Join to the Child entity
        Join<Destination2, Location> childJoin = childDetailRoot.join("targetElement", JoinType.INNER);
        // Join to the ParentEntity to establish the relationship
        Join<Location, ParentVersion> parentJoin = childJoin.join("targetVersion", JoinType.INNER);

        // Subquery to find the nearest Address
        Subquery<Double> nearestDistanceSubquery = query.subquery(Double.class);
        Root<DangerZone> sideEffectRoot = nearestDistanceSubquery.from(DangerZone.class);

        // Join the address to the parent
        nearestDistanceSubquery.select(cb.function("ST_DistanceSphere", Double.class,
                        childDetailRoot.get("point"), sideEffectRoot.get("shape")))
                .where(cb.equal(sideEffectRoot.get("targetVersion"), parentJoin));

        // Group the results by ChildDetail and find the minimum distance
        nearestDistanceSubquery.groupBy(sideEffectRoot)
                .having(cb.equal(cb.function("ST_DistanceSphere", Double.class,
                                childDetailRoot.get("point"), sideEffectRoot.get("shape")),
                        cb.min(cb.function("ST_DistanceSphere", Double.class,
                                childDetailRoot.get("point"), sideEffectRoot.get("shape")))));

        // Main query selects ChildDetail and its nearest address distance
        query.multiselect(
                childDetailRoot,  // Select the ChildDetail
                cb.selectCase()
                        .when(cb.exists(nearestDistanceSubquery),
                                cb.coalesce(cb.min(nearestDistanceSubquery), cb.literal(-1))) // Return min distance or -1
                        .otherwise(cb.literal(-1)) // Default to -1 if no address is found
        ).groupBy(childDetailRoot); // Group the results to avoid duplication

        // Execute the query
        List<Object[]> results = entityManager.createQuery(query).getResultList();

        return results;
    }

    public static List<Object[]> findChildDetailsWithNearestAddressaaa(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);

        // Root for ChildDetail
        Root<Destination2> childDetailRoot = query.from(Destination2.class);

        // Join to Child entity
        Join<Destination2, Location> childJoin = childDetailRoot.join("targetElement", JoinType.INNER);
        // Join to ParentEntity to get the parent
        Join<Location, ParentVersion> parentJoin = childJoin.join("targetVersion", JoinType.INNER);

        // Subquery to find the nearest Address
        Subquery<Object[]> nearestAddressSubquery = query.subquery(Object[].class);
        Root<DangerZone> addressRoot = nearestAddressSubquery.from(DangerZone.class);

        // Calculate distance from ChildDetail point to Address shape
        Expression<Double> distance = cb.function("ST_DistanceSphere", Double.class, childDetailRoot.get("point"), addressRoot.get("shape"));

        // The subquery needs to select the Address and the distance
//        nearestAddressSubquery.select(cb.array(addressRoot, distance))
//                .where(cb.equal(addressRoot.get("parent"), parentJoin)) // Ensure Address belongs to the same ParentEntity
//                .orderBy(cb.asc(distance)); // Order by distance ascending
//
//        // Also, we need to restrict it to the nearest address only
//        nearestAddressSubquery.setMaxResults(1); // Only get the nearest one

        // Now build the main query to select ChildDetails and their nearest address distance
        query.multiselect(
                childDetailRoot,
                cb.coalesce(
                        cb.selectCase()
                                .when(cb.exists(nearestAddressSubquery),
                                        cb.function("ST_DistanceSphere", Double.class,
                                                childDetailRoot.get("point"), addressRoot.get("shape")))
                                .otherwise(-1), // Default to -1 when no address found
                        -1) // Fallback if there's no address
        );

        // Execute the query and retrieve results
        List<Object[]> results = entityManager.createQuery(query).getResultList();

        return results; // This returns ChildDetail with its nearest address distance
    }


    public static List<Destination2> calis(EntityManager entityManager) {
        String query = """
                select d.*,  ( select min(ST_DistanceSphere(d.point, se.shape)) as _dist, se.*  from side_effect se join target_element te on te.target_version_id =  se.target_version_id where te.id = d.target_element_id and ST_DistanceSphere(d.point, se.shape)<= 1000) from destination d;
                """;
        List<Destination2> data = entityManager.createQuery(query, Destination2.class).unwrap(Query.class)
                .setTupleTransformer((Object[] tuple, String[] aliases) -> {
                    Destination2 destination = (Destination2) tuple[0];
                    destination.setDangerZoneDistance((Double) tuple[1]);
                    destination.setDangerZone((DangerZone) tuple[2]);
                    return destination;
                }).getResultList();
        return data;
    }
}
