package com.deneme.jpa.spatial.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * @author Evgeny Gribanov
 * @version 22.07.2024
 */
@Schema(description = "Coordinates")
public record LocationPointRequest(
        @JsonProperty("latitudeY")
        @Schema(description = "Latitude", example = "48.716496")
        Float latitudeY,

        @JsonProperty("longitudeX")
        @Schema(description = "Longitude", example = "44.530353")
        Float longitudeX
) {
}
