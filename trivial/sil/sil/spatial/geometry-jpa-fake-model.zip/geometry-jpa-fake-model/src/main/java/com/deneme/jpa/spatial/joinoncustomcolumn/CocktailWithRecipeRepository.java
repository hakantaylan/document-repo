package com.deneme.jpa.spatial.joinoncustomcolumn;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CocktailWithRecipeRepository extends JpaRepository<CocktailWithRecipe, Long> {

    @Override
    @EntityGraph(attributePaths = {"recipe"})
    List<CocktailWithRecipe> findAll();
}
