package com.deneme.jpa.spatial.repository;

import com.deneme.jpa.spatial.model.Parent;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ParentRepository extends JpaRepository<Parent, Long>, JpaSpecificationExecutor<Parent> {

//    @Query("""
//            SELECT COUNT(loc) > 0 FROM DeliveryLocation loc
//            WHERE ST_Contains(loc.geometry, ST_SetSRID(ST_MakePoint(:x, :y), 4326))
//            """)
//    boolean existsLocationContainingPoint(@Param("x") float longitudeX, @Param("y") float latitudeY);
//
//    @Query("""
//            SELECT loc FROM DeliveryLocation loc
//            WHERE ST_Contains(loc.geometry, ST_SetSRID(ST_MakePoint(:x, :y), 4326))
//            """)
//    Optional<DeliveryLocation> findLocationByCoordinates(@Param("x") float longitudeX, @Param("y") float latitudeY);


    @Override
//    @EntityGraph(attributePaths = {"lastVersion.dangerZones", "lastVersion.locations", "lastVersion.locations.destinationList", "draftVersion.dangerZones", "draftVersion.locations", "draftVersion.locations.destinationList"})
    @EntityGraph(attributePaths = {"lastVersion.dangerZones", "lastVersion.locations", "lastVersion.locations.destinationList"})
    List<Parent> findAll();
}
