package com.deneme.jpa.spatial.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.boot.restclient.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.MapperFeature;
import tools.jackson.databind.SerializationFeature;
import tools.jackson.databind.json.JsonMapper;

@Configuration(proxyBeanMethods = false)
public class WebConfig {

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder, Environment env) {
        Integer localPort = env.getProperty("local.server.port", Integer.class);
        int port = (localPort != null)
                ? localPort          // tests (RANDOM_PORT)
                : env.getProperty("server.port", Integer.class, 8080); // prod

        return builder
                .rootUri("http://localhost:" + port)
                .build();
    }

    @Bean
    @Primary
    public JsonMapper jsonMapper() {
        return JsonMapper.builder()
                .changeDefaultPropertyInclusion(incl -> incl.withValueInclusion(JsonInclude.Include.NON_NULL))
                .changeDefaultPropertyInclusion(incl -> incl.withContentInclusion(JsonInclude.Include.NON_NULL))
//                .serializationInclusion(JsonInclude.Include.NON_NULL)

                // Mapper features
                .enable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY)
                .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)

                // Deserialization
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES)

                // Serialization
//                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .enable(SerializationFeature.INDENT_OUTPUT)
                // Java time
//                .addModule(new JavaTimeModule())

                .build();
    }

}
