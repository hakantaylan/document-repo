package com.deneme.jpa.spatial.config;

import com.deneme.jpa.spatial.controller.DeliveryController;
import com.deneme.jpa.spatial.model.*;
import com.deneme.jpa.spatial.model.Location;
import com.deneme.jpa.spatial.repository.DestinationRepository;
import com.deneme.jpa.spatial.repository.ParentRepository;
import com.deneme.jpa.spatial.service.DeliveryGeoService;
import com.deneme.jpa.spatial.service.TargetService;
import lombok.RequiredArgsConstructor;
import org.geotools.referencing.GeodeticCalculator;
import org.geotools.referencing.datum.DefaultEllipsoid;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.io.WKTReader;
import org.locationtech.jts.operation.distance.DistanceOp;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import si.uom.SI;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer {

    private final RestTemplate restTemplate;
    private final DeliveryGeoService service;
    private final TargetService targetService;
    private final ParentRepository parentRepository;
    private final DestinationRepository destinationRepository;
    private static final int SRID = 4326;


    @EventListener(ApplicationReadyEvent.class)
    public void initData() throws Exception {
        WKTReader wktReader = new WKTReader();
        Geometry g1 = wktReader.read("POINT (32.83 39.91)");
        GeometryFactory factory = new GeometryFactory();
        Point point = factory.createPoint(new Coordinate(32.82f, 39.91f));
        point.setSRID(SRID);
        Destination destination1 = Destination.builder().name("DEST1").no("D-1").point(point).build();
        point = factory.createPoint(new Coordinate(32.84f, 39.92f));
        point.setSRID(SRID);
        Destination destination2 = Destination.builder().name("DEST2").no("D-2").point(point).build();

        point = factory.createPoint(new Coordinate(32.8f, 39.91f));
        point.setSRID(SRID);
        Destination destination3 = Destination.builder().name("DEST3").no("D-3").point(point).build();
        point = factory.createPoint(new Coordinate(32.4f, 39.2f));
        point.setSRID(SRID);
        Destination destination4 = Destination.builder().name("DEST4").no("D-3").point(point).build();

        Parent parent = Parent.builder().parentNo("Parent Place").parentNo("PN-1").build();
        ParentVersion parentVersion = ParentVersion.builder().type("Parent Version Type").point(factory.createPoint(new Coordinate(32.8086, 39.9342))).build();
        Geometry te1Shape = wktReader.read("POLYGON ((32.8174051421509 39.93492857609917, 32.8174051421509 39.9056052036878, 32.874530348905296 39.9056052036878, 32.874530348905296 39.93492857609917, 32.8174051421509 39.93492857609917))");
        te1Shape.setSRID(SRID);
        Geometry te2Shape = wktReader.read("POLYGON ((32.840872808384574 39.94073358368692, 32.83953055459003 39.94068301858765, 32.83820123333618 39.94053181048234, 32.83689765238931 39.940281416247934, 32.83563237117717 39.93993424838994, 32.83441757963379 39.93949365176744, 32.8332649806274 39.93896387132478, 32.832185677110886 39.93835001114282, 32.831190065086915 39.93765798520674, 32.83028773342264 39.936894460367434, 32.82948737148154 39.93606679204909, 32.8287966854627 39.93518295332554, 32.82822232425223 39.93425145805142, 32.82776981549858 39.933281278792215, 32.82744351252301 39.93228176034598, 32.82724655257115 39.93126252969245, 32.82718082680066 39.93023340323885, 32.827246962286466 39.92920429225729, 32.827444316208506 39.9281851074253, 32.82777098226908 39.927185663389224, 32.82822380926942 39.92621558426924, 32.82879843165818 39.925284211015125, 32.82948931175002 39.924400511503165, 32.83028979320068 39.92357299423824, 32.83119216521841 39.922809626489226, 32.83218773688897 39.922117757643434, 32.83326692089593 39.92150404851489, 32.83441932582935 39.92097440728384, 32.83563385619444 39.92053393268136, 32.83689881915989 39.920186864962595, 32.83820203702174 39.91993654513835, 32.839530964305375 39.919785382854585, 32.840872808384574 39.91973483322736, 32.842214652463774 39.919785382854585, 32.843543579747404 39.91993654513835, 32.84484679760926 39.920186864962595, 32.84611176057471 39.92053393268136, 32.847326290939804 39.92097440728384, 32.84847869587321 39.92150404851489, 32.84955787988018 39.922117757643434, 32.85055345155073 39.922809626489226, 32.851455823568465 39.92357299423824, 32.85225630501913 39.924400511503165, 32.85294718511096 39.925284211015125, 32.85352180749973 39.92621558426924, 32.85397463450007 39.927185663389224, 32.854301300560635 39.9281851074253, 32.85449865448268 39.92920429225729, 32.85456478996849 39.93023340323885, 32.854499064197995 39.93126252969245, 32.85430210424614 39.93228176034598, 32.85397580127057 39.933281278792215, 32.85352329251692 39.93425145805142, 32.85294893130645 39.93518295332554, 32.8522582452876 39.93606679204909, 32.851457883346505 39.936894460367434, 32.850555551682234 39.93765798520674, 32.849559939658256 39.93835001114282, 32.84848063614175 39.93896387132478, 32.84732803713536 39.93949365176744, 32.84611324559197 39.93993424838994, 32.84484796437984 39.940281416247934, 32.84354438343296 39.94053181048234, 32.842215062179115 39.94068301858765, 32.840872808384574 39.94073358368692))");
        te2Shape.setSRID(SRID);
        Location te1 = Location.builder().name("Location 1").street("Street 1").shape(te1Shape).build();
        Location te2 = Location.builder().name("Location 2").street("Street 2").shape(te2Shape).build();
        te1.addDestination(destination1);
        te1.addDestination(destination3);
        te2.addDestination(destination2);
        te2.addDestination(destination4);
        parentVersion.addLocation(te1);
        parentVersion.addLocation(te2);

        Geometry dangerZone1Shape = wktReader.read("POLYGON ((32.84676107494758 39.93117924903618, 32.848505228235524 39.930273326031426, 32.85002440248593 39.93092059147486, 32.84957438133111 39.93260332180421, 32.84602969554081 39.93312076864129, 32.84676107494758 39.93117924903618))");
        Geometry dangerZone2Shape = wktReader.read("POLYGON ((32.829052750666165 39.918021568579945, 32.829052750666165 39.915537559244086, 32.832816894042026 39.915537559244086, 32.832816894042026 39.918021568579945, 32.829052750666165 39.918021568579945))");
        Geometry dangerZone3Shape = wktReader.read("POLYGON ((32.83400395737493 39.92927170484677, 32.83770617955648 39.92805451084982, 32.83942353469536 39.92688956030213, 32.83981867594483 39.929273452268916, 32.83400395737493 39.92927170484677))");
        Geometry dangerZone4Shape = wktReader.read("POLYGON ((32.820145866595055 39.92126457917658, 32.82449220129118 39.91955397747, 32.826427224050235 39.9206947018759, 32.82694632525917 39.922353757139604, 32.820145866595055 39.92126457917658))");
        dangerZone1Shape.setSRID(SRID);
        dangerZone2Shape.setSRID(SRID);
        dangerZone3Shape.setSRID(SRID);
        dangerZone4Shape.setSRID(SRID);
        parentVersion.addDangerZone(DangerZone.builder().name("Danger Zone 1").shape(dangerZone1Shape).build());
        parentVersion.addDangerZone(DangerZone.builder().name("Danger Zone 2").shape(dangerZone2Shape).build());
        parentVersion.addDangerZone(DangerZone.builder().name("Danger Zone 3").shape(dangerZone3Shape).build());
        parentVersion.addDangerZone(DangerZone.builder().name("Danger Zone 4").shape(dangerZone4Shape).build());

        parent.setDraftVersion(parentVersion);
        parent.setLastVersion(parentVersion);

        parentRepository.save(parent);

        List<Parent> parentList = targetService.findAll();
        List<Destination> all1 = destinationRepository.findAll();
        calculateProgramaticallyByUsingSpheroid(parentList.get(0));
        calculateProgramaticallyByUsingSphere(parentList.get(0));
        System.out.println("-----------------------------------------");
    }

    private void calculateProgramaticallyByUsingSpheroid(Parent parent) {
        for (Location te : parent.getLastVersion().getLocations()) {
            for (Destination destination : te.getDestinationList()) {
                System.out.println("DMPI Distance");
                System.out.println(destination.getDangerZoneDistance());
//                System.out.println("------------------------------------");
                for (DangerZone dangerZone : parent.getLastVersion().getDangerZones()) {
                    double min = -1;
                    Coordinate[] coordinates = DistanceOp.nearestPoints(destination.getPoint(), dangerZone.getShape());
                    GeodeticCalculator gc = new GeodeticCalculator();
                    GeometryFactory factory = new GeometryFactory(new PrecisionModel(), 4326);
                    Point p0 = factory.createPoint(coordinates[0]);
                    Point p1 = factory.createPoint(coordinates[1]);
//                    org.geolatte.geom.Point<?> from = JTS.from(p0);
                    gc.setStartingGeographicPoint(p0.getX(), p0.getY());
                    gc.setDestinationGeographicPoint(p1.getX(), p1.getY());
                    System.out.println(gc.getOrthodromicDistance());
                }
                System.out.println("----------------------------------------------------------");

            }
        }

    }

    private void calculateProgramaticallyByUsingSphere(Parent parent) {
        GeodeticCalculator gc = new GeodeticCalculator(DefaultEllipsoid.createEllipsoid("MY_CUSTOM_SPHERE", 6371008.771415061 , 6371008.771415061 , SI.METRE));
        for (Location te : parent.getLastVersion().getLocations()) {
            for (Destination destination : te.getDestinationList()) {
                System.out.println("Destination Danger Zone Distance");
                System.out.println(destination.getDangerZoneDistance());
//                System.out.println("------------------------------------");
                for (DangerZone dangerZone : parent.getLastVersion().getDangerZones()) {
                    double min = -1;
                    Coordinate[] coordinates = DistanceOp.nearestPoints(destination.getPoint(), dangerZone.getShape());
//                    GeodeticCalculator gc = new GeodeticCalculator(DefaultEllipsoid.SPHERE);
                    GeometryFactory factory = new GeometryFactory(new PrecisionModel(), 4326);
                    Point p0 = factory.createPoint(coordinates[0]);
                    Point p1 = factory.createPoint(coordinates[1]);
//                    org.geolatte.geom.Point<?> from = JTS.from(p0);
                    gc.setStartingGeographicPoint(p0.getX(), p0.getY());
                    gc.setDestinationGeographicPoint(p1.getX(), p1.getY());
                    System.out.println(gc.getOrthodromicDistance());
                }
                System.out.println("----------------------------------------------------------");

            }
        }

    }

        @EventListener(ApplicationReadyEvent.class)
//    public void onApplicationEvent(ContextRefreshedEvent event) {
    public void onApplicationReadyEvent() {
        String body = """
                {
                  "type": "FeatureCollection",
                  "features": [
                    {
                      "type": "Feature",
                      "properties": {
                        "price": 100,
                        "city": "Eskişehir",
                        "district": "District",
                        "fill": "#37ab0d"
                      },
                      "geometry": {
                        "coordinates": [
                          [
                            [
                              29.48684538996872,
                              39.46735724303116
                            ],
                            [
                              29.89266015210859,
                              38.43040062028902
                            ],
                            [
                              31.255224182804966,
                              38.38682596738363
                            ],
                            [
                              31.9927294449337,
                              39.53053731458053
                            ],
                            [
                              31.312885555214763,
                              40.19002573916768
                            ],
                            [
                              29.48684538996872,
                              39.46735724303116
                            ]
                          ]
                        ],
                        "type": "Polygon"
                      }
                    },
                    {
                      "type": "Feature",
                      "properties": {
                        "price": 200,
                        "city": "Ankara",
                        "district": "District"
                      },
                      "geometry": {
                        "coordinates": [
                          32.83382489516828,
                          39.910072578722065
                        ],
                        "type": "Point"
                      },
                      "id": 1
                    },
                    {
                      "type": "Feature",
                      "properties": {
                        "price": 200,
                        "city": "Aksaray",
                        "district": "District"
                      },
                      "geometry": {
                        "coordinates": [
                          [
                            32.22281943070675,
                            38.696149939044915
                          ],
                          [
                            33.477547676512074,
                            39.09316804234771
                          ],
                          [
                            33.87545120247643,
                            38.47669020285517
                          ],
                          [
                            33.09100080104426,
                            38.03265883139582
                          ]
                        ],
                        "type": "LineString"
                      }
                    },
                    {
                      "type": "Feature",
                      "properties": {
                        "price": 125,
                        "city": "Adana",
                        "district": "District",
                        "fill": "#3498db "
                      },
                      "geometry": {
                        "coordinates": [
                          [
                            [
                              34.326309557938885,
                              38.07434792105647
                            ],
                            [
                              34.326309557938885,
                              37.376755835692705
                            ],
                            [
                              35.46815917268117,
                              37.376755835692705
                            ],
                            [
                              35.46815917268117,
                              38.07434792105647
                            ],
                            [
                              34.326309557938885,
                              38.07434792105647
                            ]
                          ]
                        ],
                        "type": "Polygon"
                      }
                    },
                    {
                      "type": "Feature",
                      "properties": {
                        "price": 50,
                        "city": "Çorum",
                        "district": "District",
                        "fill": "#cb4335"
                      },
                      "geometry": {
                        "type": "Polygon",
                        "coordinates": [
                          [
                            [
                              34.75584437802461,
                              40.75346825201103
                            ],
                            [
                              34.66991370291493,
                              40.750238549058096
                            ],
                            [
                              34.58483523079331,
                              40.74058147976687
                            ],
                            [
                              34.50145196874762,
                              40.72459281638105
                            ],
                            [
                              34.4205886623649,
                              40.7024310294109
                            ],
                            [
                              34.34304298752443,
                              40.67431558005085
                            ],
                            [
                              34.269577120407526,
                              40.64052456363598
                            ],
                            [
                              34.200909797480804,
                              40.60139173717836
                            ],
                            [
                              34.137708965730035,
                              40.55730297204436
                            ],
                            [
                              34.080585110003156,
                              40.50869217987842
                            ],
                            [
                              34.03008532949379,
                              40.45603676581962
                            ],
                            [
                              33.98668821972357,
                              40.39985266781551
                            ],
                            [
                              33.95079960042163,
                              40.34068904437553
                            ],
                            [
                              33.92274911398136,
                              40.279122675433015
                            ],
                            [
                              33.90278770417209,
                              40.21575214214604
                            ],
                            [
                              33.891085970896135,
                              40.151191851544766
                            ],
                            [
                              33.88773338432328,
                              40.086065971032426
                            ],
                            [
                              33.892738330926086,
                              40.02100233599396
                            ],
                            [
                              33.90602895490898,
                              39.95662639129738
                            ],
                            [
                              33.927454751312766,
                              39.893555224426656
                            ],
                            [
                              33.95678886164825,
                              39.832391744499745
                            ],
                            [
                              33.99373101916452,
                              39.77371905762792
                            ],
                            [
                              34.0379110886373,
                              39.71809508508062
                            ],
                            [
                              34.08889314467757,
                              39.66604746663418
                            ],
                            [
                              34.146180032797815,
                              39.61806878738571
                            ],
                            [
                              34.209218358606456,
                              39.57461216227423
                            ],
                            [
                              34.27740385230609,
                              39.5360872086176
                            ],
                            [
                              34.350087057931106,
                              39.502856433180526
                            ],
                            [
                              34.42657929927493,
                              39.47523205665488
                            ],
                            [
                              34.50615887704478,
                              39.45347329496663
                            ],
                            [
                              34.58807745428528,
                              39.43778411351803
                            ],
                            [
                              34.67156658939615,
                              39.42831146732012
                            ],
                            [
                              34.75584437802461,
                              39.42514403694611
                            ],
                            [
                              34.84012216665308,
                              39.42831146732012
                            ],
                            [
                              34.92361130176395,
                              39.43778411351803
                            ],
                            [
                              35.00552987900445,
                              39.45347329496663
                            ],
                            [
                              35.085109456774305,
                              39.47523205665488
                            ],
                            [
                              35.161601698118126,
                              39.502856433180526
                            ],
                            [
                              35.234284903743145,
                              39.5360872086176
                            ],
                            [
                              35.302470397442775,
                              39.57461216227423
                            ],
                            [
                              35.36550872325141,
                              39.61806878738571
                            ],
                            [
                              35.42279561137166,
                              39.66604746663418
                            ],
                            [
                              35.47377766741193,
                              39.71809508508062
                            ],
                            [
                              35.51795773688471,
                              39.77371905762792
                            ],
                            [
                              35.55489989440098,
                              39.832391744499745
                            ],
                            [
                              35.58423400473646,
                              39.893555224426656
                            ],
                            [
                              35.60565980114025,
                              39.95662639129738
                            ],
                            [
                              35.618950425123145,
                              40.02100233599396
                            ],
                            [
                              35.62395537172595,
                              40.086065971032426
                            ],
                            [
                              35.620602785153096,
                              40.151191851544766
                            ],
                            [
                              35.60890105187714,
                              40.21575214214604
                            ],
                            [
                              35.58893964206787,
                              40.279122675433015
                            ],
                            [
                              35.5608891556276,
                              40.34068904437553
                            ],
                            [
                              35.52500053632566,
                              40.39985266781551
                            ],
                            [
                              35.481603426555445,
                              40.45603676581962
                            ],
                            [
                              35.431103646046076,
                              40.50869217987842
                            ],
                            [
                              35.3739797903192,
                              40.55730297204436
                            ],
                            [
                              35.31077895856843,
                              40.60139173717836
                            ],
                            [
                              35.242111635641706,
                              40.64052456363598
                            ],
                            [
                              35.168645768524804,
                              40.67431558005085
                            ],
                            [
                              35.091100093684325,
                              40.7024310294109
                            ],
                            [
                              35.010236787301615,
                              40.72459281638105
                            ],
                            [
                              34.92685352525592,
                              40.74058147976687
                            ],
                            [
                              34.84177505313429,
                              40.750238549058096
                            ],
                            [
                              34.75584437802461,
                              40.75346825201103
                            ]
                          ]
                        ]
                      }
                    }
                  ]
                }""";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        restTemplate.postForEntity(DeliveryController.SAVE_DELIVERY_LOCATION_URL, entity, Void.class);
        List<DeliveryLocation> deneme = service.denemeWithFormulaAndCriter1a(34.51f, 38.14f, 0.1);
        List<DeliveryLocation> deneme2 = service.denemeWithFindAll(34.51f, 38.14f, 0.1);
//        List<DeliveryLocation> allLocationsWithNearestNeighbour = service.findAllLocationsWithNearestNeighbour(34.51f, 38.14f, 0.1);
//        List<DeliveryLocation> dataWithCriteria = service.findAllLocationsWithNearestNeighborUsingCriteria(34.51f, 38.14f, 0.1);
        System.out.println("-------------------------------------");
    }

}
