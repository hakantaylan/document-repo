package com.deneme.jpa.spatial.model;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Point;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "Destination")
public class Destination2 {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private String name;
    private String code;

//    @Column(name = "point") // , columnDefinition = "geometry(Polygon, 4326)
    private Point point;

    @ManyToOne(fetch = FetchType.LAZY)
    private Location location;

    @Transient
    private Double dangerZoneDistance;
    @Transient
    private DangerZone dangerZone;
}
