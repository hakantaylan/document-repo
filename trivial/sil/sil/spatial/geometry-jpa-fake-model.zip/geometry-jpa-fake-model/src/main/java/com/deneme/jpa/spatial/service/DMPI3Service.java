package com.deneme.jpa.spatial.service;

import com.deneme.jpa.spatial.model.Destination2;
import com.deneme.jpa.spatial.model.DangerZone;
import com.deneme.jpa.spatial.model.Location;
import com.deneme.jpa.spatial.model.ParentVersion;
import com.deneme.jpa.spatial.spec.DMPISpecification;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DMPI3Service {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Destination2> findDMPIWithClosestSideEffect(double maxDistance) {

        Specification<Destination2> spec = DMPISpecification.hasClosestBook();

        // Create the query to fetch PhoneDetail with the only closest Book
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Destination2> query = cb.createQuery(Destination2.class);
        Root<Destination2> phoneDetailRoot = query.from(Destination2.class);

        // Select only PhoneDetails that match the criteria
        query.select(phoneDetailRoot).where(spec.toPredicate(phoneDetailRoot, query, cb));

        TypedQuery<Destination2> typedQuery = entityManager.createQuery(query);
        return typedQuery.getResultList();
    }

    public List<Destination2> findDMPIWithClosestSideEffect2(double maxDistance) {
        // Define the specification with only maxDistance
//        Specification<DMPI2> spec = DMPISpecification.hasNearestBookWithinDistance(maxDistance);
        Specification<Destination2> spec = DMPISpecification.hasClosestBook();

        // Create the query
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);
        Root<Destination2> phoneDetailRoot = query.from(Destination2.class);
        Join<Destination2, Location> phoneJoin = phoneDetailRoot.join("targetElement");
        Join<Location, ParentVersion> parentJoin = phoneJoin.join("targetVersion");
        Join<ParentVersion, DangerZone> bookJoin = parentJoin.join("sideEffects");

        // Apply the specification
//        Predicate predicate = spec.toPredicate(phoneDetailRoot, query, cb);
//        query.multiselect(phoneDetailRoot, bookJoin, cb.function("ST_DistanceSphere", Double.class, phoneDetailRoot.get("point"), bookJoin.get("shape")))
//                .where(predicate).distinct(true);

        query.multiselect(phoneDetailRoot, bookJoin, cb.function("ST_DistanceSphere", Double.class,
                        phoneDetailRoot.get("point"), bookJoin.get("shape"))) // Distance Calculation
                .where(spec.toPredicate(phoneDetailRoot, query, cb)) // Use the generated predicate
                .distinct(true) // Ensure distinct PhoneDetail with the closest Book
                .orderBy(cb.asc(cb.function("ST_DistanceSphere", Double.class, phoneDetailRoot.get("point"), bookJoin.get("shape")))); // Order by distance

        TypedQuery<Object[]> typedQuery = entityManager.createQuery(query);
        List<Object[]> results = typedQuery.getResultList();

        // Convert the results to PhoneDetail objects with nearestBook and distance:
        return mapToPhoneDetails(results);
    }

    private List<Destination2> mapToPhoneDetails(List<Object[]> results) {
        List<Destination2> phoneDetails = new ArrayList<>();

        for (Object[] result : results) {
            Destination2 phoneDetail = (Destination2) result[0];
            DangerZone nearestBook = (DangerZone) result[1];
            Double distance = (Double) result[2];

            // Set the nearestBook and nearestBookDistance in PhoneDetail
            phoneDetail.setDangerZone(nearestBook);
            phoneDetail.setDangerZoneDistance(distance);

            // Add to the list of PhoneDetail
            phoneDetails.add(phoneDetail);
        }

        return phoneDetails;
    }
}
