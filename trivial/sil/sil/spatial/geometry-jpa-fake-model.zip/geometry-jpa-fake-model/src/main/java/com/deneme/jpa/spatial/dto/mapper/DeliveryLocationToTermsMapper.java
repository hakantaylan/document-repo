package com.deneme.jpa.spatial.dto.mapper;

import com.deneme.jpa.spatial.dto.DeliveryTermsResponse;
import com.deneme.jpa.spatial.model.DeliveryLocation;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Evgeny Gribanov
 * @version 22.07.2024
 */
@Component
public class DeliveryLocationToTermsMapper {

    public DeliveryTermsResponse toResponse(DeliveryLocation location) {
        return new DeliveryTermsResponse(location.getCity(), location.getDistrict(), location.getPrice());
    }

    public List<DeliveryTermsResponse> toResponse(List<DeliveryLocation> locations) {
        return locations.stream()
                .map(zone -> new DeliveryTermsResponse(zone.getCity(), zone.getDistrict(), zone.getPrice()))
                .toList();
    }
}