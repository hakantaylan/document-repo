package com.deneme.jpa.spatial.controller;

import com.deneme.jpa.spatial.dto.CreateZonesRequest;
import com.deneme.jpa.spatial.dto.DeliveryTermsResponse;
import com.deneme.jpa.spatial.dto.LocationPointRequest;
import com.deneme.jpa.spatial.service.DeliveryGeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name="Delivery Areas")
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Zones added / Address in delivery zone"),
        @ApiResponse(responseCode = "406", description = "Address outside the delivery area")
})
public class DeliveryController {
    public static final String SAVE_DELIVERY_LOCATION_URL = "/v1/location";
    public static final String DELIVERY_LOCATION_TERM_URL = "/v1/location-term";
    public static final String DELIVERY_LOCATION_CHECK_URL = "/v1/location-check";
    public static final String DELIVERY_LOCATION_CHECK_SPEC = "/v1/location-check-spec";

    private final DeliveryGeoService geoService;

    @Operation(summary = "add delivery zones in GeoJson format")
    @PostMapping(SAVE_DELIVERY_LOCATION_URL)
    @ResponseStatus(HttpStatus.OK)
    public void saveAllDeliveryZones(@RequestBody CreateZonesRequest geoJson) {
        geoService.saveAllDeliveryZones(geoJson);
    }

    @Operation(summary = "available areas for specified point")
    @PostMapping(DELIVERY_LOCATION_TERM_URL)
    @ResponseStatus(HttpStatus.OK)
    public DeliveryTermsResponse getDeliveryTerms(@RequestBody LocationPointRequest request) {
        return geoService.getDeliveryTerms(request);
    }

    @Operation(summary = "is location in delivery area")
    @PostMapping(DELIVERY_LOCATION_CHECK_URL)
    @ResponseStatus(HttpStatus.OK)
    public void inDeliveryZone(@RequestBody LocationPointRequest request) {
        geoService.inDeliveryZone(request);
    }

    @Operation(summary = "is location in delivery area querying by spec")
    @PostMapping(DELIVERY_LOCATION_CHECK_SPEC)
    @ResponseStatus(HttpStatus.OK)
    public List<DeliveryTermsResponse> getDeliveryZonesQueryingBySpec(@RequestBody LocationPointRequest request) {
        return geoService.getDeliveryZonesQueryingBySpec(request);
    }
}
