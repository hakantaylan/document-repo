package com.deneme.jpa.spatial.model;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class DangerZone {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    private String name;
//    @Column(name = "shape") // , columnDefinition = "geometry(Polygon, 4326)
    private Geometry shape;

    @ManyToOne
    private ParentVersion parentVersion;
}
