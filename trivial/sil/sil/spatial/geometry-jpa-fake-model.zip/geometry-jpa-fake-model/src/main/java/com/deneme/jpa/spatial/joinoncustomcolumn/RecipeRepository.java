package com.deneme.jpa.spatial.joinoncustomcolumn;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RecipeRepository extends JpaRepository<Recipe, Long> {
}
