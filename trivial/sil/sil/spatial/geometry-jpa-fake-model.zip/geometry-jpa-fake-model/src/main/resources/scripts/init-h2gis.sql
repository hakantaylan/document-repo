CREATE ALIAS IF NOT EXISTS H2GIS_SPATIAL FOR "org.h2gis.functions.factory.H2GISFunctions.load";
CALL H2GIS_SPATIAL();

CREATE SPATIAL INDEX geom_idx1 ON delivery_location(geometry);
CREATE SPATIAL INDEX geom_idx2 ON parent_version(point);
CREATE SPATIAL INDEX geom_idx3 ON location(shape);
CREATE SPATIAL INDEX geom_idx4 ON danger_zone(shape);
CREATE SPATIAL INDEX geom_idx5 ON destination(point);