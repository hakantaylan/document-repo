package com.deneme.jpa.spatial.service;

import com.deneme.jpa.spatial.model.Destination;
import com.deneme.jpa.spatial.repository.DestinationRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.geolatte.geom.jts.JTS;
import org.locationtech.jts.geom.Point;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedList;
import java.util.List;


@Service
@RequiredArgsConstructor
@Transactional
public class DMPIService {
    private final DestinationRepository repository;
    @PersistenceContext
    private EntityManager entityManager;

    public List<Destination> findAll() {
        List<Object[]> results = repository.findByQuery();
        List<Destination> returnValue = new LinkedList<>();
        for (Object[] row : results) {
            Point geometry = JTS.to((org.geolatte.geom.Point) row[3]);
            Destination dl = Destination.builder().
                    id(((Number)row[0]).longValue()).
                    no(((String) row[1])).
                    name((String) row[2]).
                    point(geometry).
//                    sideEffectName((String) row[7]).
//                    sideEffectDistance(((Number) row[8]).doubleValue()).
                    build();
            returnValue.add(dl);
        }
        return returnValue;
    }


//    public List<DeliveryLocation> findAllLocationsWithNearestNeighbour(float longitude, float latitude, double radius) {
//        List<Object[]> results = locationRepository2.findAllLocationsWithNearestNeighbour(longitude, latitude, radius);
//        List<DeliveryLocation> locations = new ArrayList<>();
//
//        for (Object[] row : results) {
//            byte[] UUIDBytes = (byte[]) row[0];
//            ByteBuffer bb = ByteBuffer.wrap(UUIDBytes);
//            Geometry geometry = JTS.to((org.geolatte.geom.Geometry) row[6]);
//            DeliveryLocation dl = DeliveryLocation.builder().
//                    id(new UUID(bb.getLong(), bb.getLong())).
//                    version(((Number) row[1]).longValue()).
//                    city((String) row[2]).
//                    district((String) row[3]).
//                    price((BigDecimal) row[4]).
//                    fill((String) row[5]).
//                    geometry(geometry).
//                    build();
//            locations.add(dl);
//        }
//
//        return locations;
//    }

}
