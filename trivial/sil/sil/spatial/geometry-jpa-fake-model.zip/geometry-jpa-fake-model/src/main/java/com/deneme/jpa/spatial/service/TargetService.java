package com.deneme.jpa.spatial.service;

import com.deneme.jpa.spatial.model.Parent;
import com.deneme.jpa.spatial.repository.ParentRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@RequiredArgsConstructor
@Transactional
public class TargetService {
    private final DMPIService dmpiService;
    private final ParentRepository parentRepository;
    @PersistenceContext
    private EntityManager entityManager;

    public List<Parent> findAll() {
        List<Parent> all = parentRepository.findAll();
//        List<DMPI> allDMPIs = dmpiService.findAll();
        return all;
    }


//    public List<DeliveryLocation> findAllLocationsWithNearestNeighbour(float longitude, float latitude, double radius) {
//        List<Object[]> results = locationRepository2.findAllLocationsWithNearestNeighbour(longitude, latitude, radius);
//        List<DeliveryLocation> locations = new ArrayList<>();
//
//        for (Object[] row : results) {
//            byte[] UUIDBytes = (byte[]) row[0];
//            ByteBuffer bb = ByteBuffer.wrap(UUIDBytes);
//            Geometry geometry = JTS.to((org.geolatte.geom.Geometry) row[6]);
//            DeliveryLocation dl = DeliveryLocation.builder().
//                    id(new UUID(bb.getLong(), bb.getLong())).
//                    version(((Number) row[1]).longValue()).
//                    city((String) row[2]).
//                    district((String) row[3]).
//                    price((BigDecimal) row[4]).
//                    fill((String) row[5]).
//                    geometry(geometry).
//                    build();
//            locations.add(dl);
//        }
//
//        return locations;
//    }

}
