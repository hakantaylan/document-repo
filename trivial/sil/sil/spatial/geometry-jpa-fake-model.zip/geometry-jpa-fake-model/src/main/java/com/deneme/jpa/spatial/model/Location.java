package com.deneme.jpa.spatial.model;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Location {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private String name;
    private String street;

//    @Column(name = "shape") // , columnDefinition = "geometry(Polygon, 4326)
    private Geometry shape;

    @ManyToOne(fetch = FetchType.LAZY)
    private ParentVersion parentVersion;

    @Builder.Default
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "location", orphanRemoval = true)
    private Set<Destination> destinationList = new HashSet<>();

    public void addDestination(Destination destination) {
        destinationList.add(destination);
        destination.setLocation(this);
    }

    public void removeDestination(Destination destination) {
        destinationList.remove(destination);
        destination.setLocation(null);
    }
}
