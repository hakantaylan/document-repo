package com.deneme.jpa.spatial.joinoncustomcolumn;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "COCKTAIL")
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class Cocktail {
    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "cocktail_name")
    private String name;

    @Column
    private double price;

}