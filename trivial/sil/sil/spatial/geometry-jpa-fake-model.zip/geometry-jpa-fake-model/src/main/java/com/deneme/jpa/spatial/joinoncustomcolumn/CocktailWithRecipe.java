package com.deneme.jpa.spatial.joinoncustomcolumn;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.JoinColumnOrFormula;

@Entity
@Table(name = "COCKTAIL")
@Data
public class CocktailWithRecipe {
    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "cocktail_name")
    private String name;

    @Column
    private double price;

    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "cocktail_name",
//            referencedColumnName = "cocktail",
//            insertable = false, updatable = false,
//            foreignKey = @jakarta.persistence
//                    .ForeignKey(value = ConstraintMode.NO_CONSTRAINT))

//    @JoinColumnOrFormula(column = @JoinColumn(name = "cocktail_name", referencedColumnName="cocktail", insertable=false, updatable=false, foreignKey = @jakarta.persistence.ForeignKey(value = ConstraintMode.NO_CONSTRAINT)))
//    @JoinFormula(value = "select dd.id from cocktail dd  where dd.cocktail_name = cocktail", referencedColumnName = "cocktail" )
    @JoinColumnOrFormula(column = @JoinColumn(name = "cocktail_name", referencedColumnName="cocktail", insertable=false, updatable=false))
//    @JoinFormula(value = """
//        (SELECT r.id
//        FROM recipes r
//        WHERE r.cocktail = cocktail_name)
//        """, referencedColumnName = "cocktail"
//    )
    private Recipe recipe;
}
