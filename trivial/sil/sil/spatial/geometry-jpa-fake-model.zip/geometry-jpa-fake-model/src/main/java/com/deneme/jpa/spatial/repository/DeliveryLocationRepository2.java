package com.deneme.jpa.spatial.repository;

import com.deneme.jpa.spatial.model.DeliveryLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;


@Repository
public interface DeliveryLocationRepository2 extends JpaRepository<DeliveryLocation, UUID>, JpaSpecificationExecutor<DeliveryLocation> {

    //    @TODO l.* yerine attirbute'lar constructor ile uyumlu sırada select edilebilir.
    @Query(
            value = "SELECT l.*, " +
                    "ST_Distance(l.geometry, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326)) AS distance " +
                    "FROM delivery_location l " +
                    "WHERE ST_DWithin(l.geometry, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326), :radius) " +
                    "ORDER BY distance ASC",
            nativeQuery = true
    )
    List<Object[]> findAllLocationsWithNearestNeighbour(float longitude, float latitude, double radius);

    @Query(
            value = "SELECT l.* FROM delivery_location l " +
                    "WHERE ST_DWithin(l.geometry, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326), :radius) ",
//                    "ORDER BY distanceTo ASC",
            nativeQuery = true
    )
    List<DeliveryLocation> deneme(float longitude, float latitude, double radius);

    /**
//    @TODO PostGIS ile bu örneği dene. H2'de çalışmadı
    @Query(
            value = """
                    SELECT new com.habr.egribanov.geometry.dao.table.DeliveryLocation(l.id,
                    l.version, l.createdDate, l.lastModifiedDate, l.city, l.district, l.price, l.fill, l.geometry),
                    ST_Distance(l.geometry, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326)) AS distance
                    FROM DeliveryLocation l
                    WHERE ST_DWithin(l.geometry, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326), :radius)
                    ORDER BY distance ASC"""
            , nativeQuery = false
    )
    List<Object[]> findAllLocationsWithNearestNeighbor(float longitude, float latitude, double radius);
    **/
}
