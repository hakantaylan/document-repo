package com.deneme.jpa.spatial.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;
import org.hibernate.annotations.Formula;
import org.locationtech.jts.geom.Geometry;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;


@Entity
//@Builder
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "delivery_location")
@Schema(description = "Доступные зоны доставки")
public class DeliveryLocation extends AbstractEntity {

    @Column(name = "city")
    private String city;

    @Column(name = "district")
    private String district;

    @Column(name = "price")
    private BigDecimal price;

    @Column(name = "fill")
    private String fill;

    @Column(name = "geometry") // , columnDefinition = "geometry(Polygon, 4326)
    private Geometry geometry;

    @Formula("ST_Distance(geometry, ST_SetSRID(ST_MakePoint(34.51, 38.14), 4326)) as _distanceTo")
    private Double distance;

    @Builder
    private DeliveryLocation(UUID id, Long version, String city, String district, BigDecimal price, String fill, Geometry geometry) {
        this.id = id;
        this.version = version;
        this.city = city;
        this.district = district;
        this.price = price;
        this.fill = fill;
        this.geometry = geometry;
    }

    private DeliveryLocation(UUID id, Long version, String city, String district, BigDecimal price, String fill, Geometry geometry, Double distance) {
        this.id = id;
        this.version = version;
        this.city = city;
        this.district = district;
        this.price = price;
        this.fill = fill;
        this.geometry = geometry;
    }

    public DeliveryLocation(UUID id, Long version, Date createdDate, Date lastModifiedDate, String city, String district, BigDecimal price, String fill, Geometry geometry) {
        this.id = id;
        this.version = version;
        this.createdDate = createdDate;
        this.lastModifiedDate = lastModifiedDate;
        this.city = city;
        this.district = district;
        this.price = price;
        this.fill = fill;
        this.geometry = geometry;
    }
}