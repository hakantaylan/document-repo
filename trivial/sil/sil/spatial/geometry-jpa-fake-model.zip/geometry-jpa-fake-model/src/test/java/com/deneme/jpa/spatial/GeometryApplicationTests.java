package com.deneme.jpa.spatial;

import com.deneme.jpa.spatial.dto.CreateZonesRequest;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.n52.jackson.datatype.jts.JtsModule;
import org.springframework.boot.test.context.SpringBootTest;
import tools.jackson.databind.json.JsonMapper;


@SpringBootTest(webEnvironment =  SpringBootTest.WebEnvironment.DEFINED_PORT)
class GeometryApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    public void shouldSerializeGeoJsonPolygonCorrectly() {
        GeometryFactory gf = new GeometryFactory();
        Point point = gf.createPoint(new Coordinate(1.2345678, 2.3456789));
		JsonMapper mapper = JsonMapper.builder()
				.addModule(new JtsModule())
				.build();
        String geojson = mapper.writeValueAsString(point);
        System.out.println("------------------------------------------");
    }

    @Test
    public void serializationTest() {
		JsonMapper mapper = JsonMapper.builder()
				.addModule(new JtsModule())
				.build();
        String s = """
                {
                  "type": "FeatureCollection",
                  "features": [
                    {
                      "type": "Feature",
                      "properties": {
                        "city": "Волгоград",
                        "district": "Центральный район",
                        "price": 100,
                        "fill": "#37ab0d"
                      },
                      "geometry": {
                        "envelope": "string",
                        "factory": {
                          "precisionModel": {
                            "scale": 0.1,
                            "type": {},
                            "floating": true,
                            "maximumSignificantDigits": 1073741824,
                            "offsetX": 0.1,
                            "offsetY": 0.1
                          },
                          "coordinateSequenceFactory": {},
                          "srid": 1073741824
                        },
                        "userData": {},
                        "length": 0.1,
                        "empty": true,
                        "valid": true,
                        "simple": true,
                        "precisionModel": {
                          "scale": 0.1,
                          "type": {},
                          "floating": true,
                          "maximumSignificantDigits": 1073741824,
                          "offsetX": 0.1,
                          "offsetY": 0.1
                        },
                        "interiorPoint": {
                          "envelope": "string",
                          "factory": {
                            "precisionModel": {
                              "scale": 0.1,
                              "type": {},
                              "floating": true,
                              "maximumSignificantDigits": 1073741824,
                              "offsetX": 0.1,
                              "offsetY": 0.1
                            },
                            "coordinateSequenceFactory": {},
                            "srid": 1073741824
                          },
                          "userData": {},
                          "coordinates": [
                            {
                              "x": 0.1,
                              "y": 0.1,
                              "z": 0.1,
                              "valid": true,
                              "m": 0.1,
                              "coordinate": "string"
                            }
                          ],
                          "empty": true,
                          "simple": true,
                          "numPoints": 1073741824,
                          "boundaryDimension": 1073741824,
                          "coordinateSequence": {
                            "measures": 1073741824,
                            "dimension": 1073741824
                          },
                          "geometryType": "string",
                          "y": 0.1,
                          "x": 0.1,
                          "dimension": 1073741824,
                          "coordinate": {
                            "x": 0.1,
                            "y": 0.1,
                            "z": 0.1,
                            "valid": true,
                            "m": 0.1,
                            "coordinate": "string"
                          },
                          "boundary": "string",
                          "length": 0.1,
                          "valid": true,
                          "precisionModel": {
                            "scale": 0.1,
                            "type": {},
                            "floating": true,
                            "maximumSignificantDigits": 1073741824,
                            "offsetX": 0.1,
                            "offsetY": 0.1
                          },
                          "interiorPoint": "string",
                          "centroid": "string",
                          "rectangle": true,
                          "envelopeInternal": {
                            "null": true,
                            "width": 0.1,
                            "diameter": 0.1,
                            "maxX": 0.1,
                            "minY": 0.1,
                            "minX": 0.1,
                            "maxY": 0.1,
                            "height": 0.1,
                            "area": 0.1
                          },
                          "srid": 1073741824,
                          "area": 0.1,
                          "numGeometries": 1073741824
                        },
                        "numPoints": 1073741824,
                        "centroid": {
                          "envelope": "string",
                          "factory": {
                            "precisionModel": {
                              "scale": 0.1,
                              "type": {},
                              "floating": true,
                              "maximumSignificantDigits": 1073741824,
                              "offsetX": 0.1,
                              "offsetY": 0.1
                            },
                            "coordinateSequenceFactory": {},
                            "srid": 1073741824
                          },
                          "userData": {},
                          "coordinates": [
                            {
                              "x": 0.1,
                              "y": 0.1,
                              "z": 0.1,
                              "valid": true,
                              "m": 0.1,
                              "coordinate": "string"
                            }
                          ],
                          "empty": true,
                          "simple": true,
                          "numPoints": 1073741824,
                          "boundaryDimension": 1073741824,
                          "coordinateSequence": {
                            "measures": 1073741824,
                            "dimension": 1073741824
                          },
                          "geometryType": "string",
                          "y": 0.1,
                          "x": 0.1,
                          "dimension": 1073741824,
                          "coordinate": {
                            "x": 0.1,
                            "y": 0.1,
                            "z": 0.1,
                            "valid": true,
                            "m": 0.1,
                            "coordinate": "string"
                          },
                          "boundary": "string",
                          "length": 0.1,
                          "valid": true,
                          "precisionModel": {
                            "scale": 0.1,
                            "type": {},
                            "floating": true,
                            "maximumSignificantDigits": 1073741824,
                            "offsetX": 0.1,
                            "offsetY": 0.1
                          },
                          "interiorPoint": "string",
                          "centroid": "string",
                          "rectangle": true,
                          "envelopeInternal": {
                            "null": true,
                            "width": 0.1,
                            "diameter": 0.1,
                            "maxX": 0.1,
                            "minY": 0.1,
                            "minX": 0.1,
                            "maxY": 0.1,
                            "height": 0.1,
                            "area": 0.1
                          },
                          "srid": 1073741824,
                          "area": 0.1,
                          "numGeometries": 1073741824
                        },
                        "coordinates": [
                          {
                            "x": 0.1,
                            "y": 0.1,
                            "z": 0.1,
                            "valid": true,
                            "m": 0.1,
                            "coordinate": "string"
                          }
                        ],
                        "rectangle": true,
                        "envelopeInternal": {
                          "null": true,
                          "width": 0.1,
                          "diameter": 0.1,
                          "maxX": 0.1,
                          "minY": 0.1,
                          "minX": 0.1,
                          "maxY": 0.1,
                          "height": 0.1,
                          "area": 0.1
                        },
                        "boundaryDimension": 1073741824,
                        "srid": 1073741824,
                        "geometryType": "string",
                        "area": 0.1,
                        "dimension": 1073741824,
                        "coordinate": {
                          "x": 0.1,
                          "y": 0.1,
                          "z": 0.1,
                          "valid": true,
                          "m": 0.1,
                          "coordinate": "string"
                        },
                        "numGeometries": 1073741824,
                        "boundary": "string"
                      }
                    }
                  ]
                }""";

		String s2 = """
				{
				  "type": "FeatureCollection",
				  "features": [
				    {
				      "type": "Feature",
				      "properties": {
				        "price": 200,
				        "city": "Ankara",
				        "district": "District",
				        "fill": "#37ab0d"
				      },
				      "geometry": {
				        "type": "Point",
				        "coordinates": [-112.0372, 46.60805]
				      }
				    }
				  ]
				}
				""";
		String s3 = """
				{
				  "type": "FeatureCollection",
				  "features": [
				    {
				      "type": "Feature",
				      "properties": {
				        "price": 200,
				        "city": "Ankara",
				        "district": "District",
				        "fill": "#37ab0d"
				      },
				      "geometry": {
						"type": "Polygon",
        				"coordinates": [
						  [
							[ -81.66371, 40.71829 ],
							[ -81.06224, 39.31625 ],
							[ -80.26034, 40.93560 ],
							[ -81.66371, 40.71829 ]
						  ]
        				]
				      }
				    },
				    {
				      "type": "Feature",
				      "properties": {
				        "price": 200,
				        "city": "Ankara",
				        "district": "District",
				        "fill": "#37ab0d"
				      },
				      "geometry": {
				        "type": "Point",
				        "coordinates": [-112.0372, 46.60805]
				      }
				    }
				  ]
				}
				""";

		String s4 = """
				{
				  "type": "FeatureCollection",
				  "features": [
				    {
				      "type": "Feature",
				      "properties": {
							  "price": 100,
								"city": "Eskişehir",
								"district": "District",
								"fill": "#37ab0d"
							},
				      "geometry": {
				        "coordinates": [
				          [
				            [
				              29.48684538996872,
				              39.46735724303116
				            ],
				            [
				              29.89266015210859,
				              38.43040062028902
				            ],
				            [
				              31.255224182804966,
				              38.38682596738363
				            ],
				            [
				              31.9927294449337,
				              39.53053731458053
				            ],
				            [
				              31.312885555214763,
				              40.19002573916768
				            ],
				            [
				              29.48684538996872,
				              39.46735724303116
				            ]
				          ]
				        ],
				        "type": "Polygon"
				      }
				    },
				    {
				      "type": "Feature",
				      "properties": {
							  "price": 200,
								"city": "Ankara",
								"district": "District",
								"fill": "#37ab0d"
							},
				      "geometry": {
				        "coordinates": [
				          32.83382489516828,
				          39.910072578722065
				        ],
				        "type": "Point"
				      }
				    },
				    {
				      "type": "Feature",
				      "properties": {
							  "price": 200,
								"city": "Aksaray",
								"district": "District",
								"fill": "#37ab0d"
							},
				      "geometry": {
				        "coordinates": [
				          [
				            32.22281943070675,
				            38.696149939044915
				          ],
				          [
				            33.477547676512074,
				            39.09316804234771
				          ],
				          [
				            33.87545120247643,
				            38.47669020285517
				          ],
				          [
				            33.09100080104426,
				            38.03265883139582
				          ]
				        ],
				        "type": "LineString"
				      }
				    },
				    {
				      "type": "Feature",
				      "properties": {
							  "price":125,
								"city": "Adana",
								"district": "District",
								"fill": "#3498db "
							},
				      "geometry": {
				        "coordinates": [
				          [
				            [
				              34.326309557938885,
				              38.07434792105647
				            ],
				            [
				              34.326309557938885,
				              37.376755835692705
				            ],
				            [
				              35.46815917268117,
				              37.376755835692705
				            ],
				            [
				              35.46815917268117,
				              38.07434792105647
				            ],
				            [
				              34.326309557938885,
				              38.07434792105647
				            ]
				          ]
				        ],
				        "type": "Polygon"
				      }
				    },
				    {
				      "type": "Feature",
				      "properties": {
							  "price": 50,
								"city": "Çorum",
								"district": "District",
								"fill": "#cb4335"
							},
				      "geometry": {
				        "type": "Polygon",
				        "coordinates": [
				          [
				            [
				              34.75584437802461,
				              40.75346825201103
				            ],
				            [
				              34.66991370291493,
				              40.750238549058096
				            ],
				            [
				              34.58483523079331,
				              40.74058147976687
				            ],
				            [
				              34.50145196874762,
				              40.72459281638105
				            ],
				            [
				              34.4205886623649,
				              40.7024310294109
				            ],
				            [
				              34.34304298752443,
				              40.67431558005085
				            ],
				            [
				              34.269577120407526,
				              40.64052456363598
				            ],
				            [
				              34.200909797480804,
				              40.60139173717836
				            ],
				            [
				              34.137708965730035,
				              40.55730297204436
				            ],
				            [
				              34.080585110003156,
				              40.50869217987842
				            ],
				            [
				              34.03008532949379,
				              40.45603676581962
				            ],
				            [
				              33.98668821972357,
				              40.39985266781551
				            ],
				            [
				              33.95079960042163,
				              40.34068904437553
				            ],
				            [
				              33.92274911398136,
				              40.279122675433015
				            ],
				            [
				              33.90278770417209,
				              40.21575214214604
				            ],
				            [
				              33.891085970896135,
				              40.151191851544766
				            ],
				            [
				              33.88773338432328,
				              40.086065971032426
				            ],
				            [
				              33.892738330926086,
				              40.02100233599396
				            ],
				            [
				              33.90602895490898,
				              39.95662639129738
				            ],
				            [
				              33.927454751312766,
				              39.893555224426656
				            ],
				            [
				              33.95678886164825,
				              39.832391744499745
				            ],
				            [
				              33.99373101916452,
				              39.77371905762792
				            ],
				            [
				              34.0379110886373,
				              39.71809508508062
				            ],
				            [
				              34.08889314467757,
				              39.66604746663418
				            ],
				            [
				              34.146180032797815,
				              39.61806878738571
				            ],
				            [
				              34.209218358606456,
				              39.57461216227423
				            ],
				            [
				              34.27740385230609,
				              39.5360872086176
				            ],
				            [
				              34.350087057931106,
				              39.502856433180526
				            ],
				            [
				              34.42657929927493,
				              39.47523205665488
				            ],
				            [
				              34.50615887704478,
				              39.45347329496663
				            ],
				            [
				              34.58807745428528,
				              39.43778411351803
				            ],
				            [
				              34.67156658939615,
				              39.42831146732012
				            ],
				            [
				              34.75584437802461,
				              39.42514403694611
				            ],
				            [
				              34.84012216665308,
				              39.42831146732012
				            ],
				            [
				              34.92361130176395,
				              39.43778411351803
				            ],
				            [
				              35.00552987900445,
				              39.45347329496663
				            ],
				            [
				              35.085109456774305,
				              39.47523205665488
				            ],
				            [
				              35.161601698118126,
				              39.502856433180526
				            ],
				            [
				              35.234284903743145,
				              39.5360872086176
				            ],
				            [
				              35.302470397442775,
				              39.57461216227423
				            ],
				            [
				              35.36550872325141,
				              39.61806878738571
				            ],
				            [
				              35.42279561137166,
				              39.66604746663418
				            ],
				            [
				              35.47377766741193,
				              39.71809508508062
				            ],
				            [
				              35.51795773688471,
				              39.77371905762792
				            ],
				            [
				              35.55489989440098,
				              39.832391744499745
				            ],
				            [
				              35.58423400473646,
				              39.893555224426656
				            ],
				            [
				              35.60565980114025,
				              39.95662639129738
				            ],
				            [
				              35.618950425123145,
				              40.02100233599396
				            ],
				            [
				              35.62395537172595,
				              40.086065971032426
				            ],
				            [
				              35.620602785153096,
				              40.151191851544766
				            ],
				            [
				              35.60890105187714,
				              40.21575214214604
				            ],
				            [
				              35.58893964206787,
				              40.279122675433015
				            ],
				            [
				              35.5608891556276,
				              40.34068904437553
				            ],
				            [
				              35.52500053632566,
				              40.39985266781551
				            ],
				            [
				              35.481603426555445,
				              40.45603676581962
				            ],
				            [
				              35.431103646046076,
				              40.50869217987842
				            ],
				            [
				              35.3739797903192,
				              40.55730297204436
				            ],
				            [
				              35.31077895856843,
				              40.60139173717836
				            ],
				            [
				              35.242111635641706,
				              40.64052456363598
				            ],
				            [
				              35.168645768524804,
				              40.67431558005085
				            ],
				            [
				              35.091100093684325,
				              40.7024310294109
				            ],
				            [
				              35.010236787301615,
				              40.72459281638105
				            ],
				            [
				              34.92685352525592,
				              40.74058147976687
				            ],
				            [
				              34.84177505313429,
				              40.750238549058096
				            ],
				            [
				              34.75584437802461,
				              40.75346825201103
				            ]
				          ]
				        ]
				      }
				    }
				  ]
				}
				""";
        CreateZonesRequest createZonesRequest = mapper.readValue(s3, CreateZonesRequest.class);
        System.out.println("------------------------------------------");
    }

}
