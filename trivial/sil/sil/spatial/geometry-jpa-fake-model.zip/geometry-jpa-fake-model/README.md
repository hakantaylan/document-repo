[Работа с геометрией в JPA и Spring Boot 3 код из статьи на Habr](https://habr.com/ru/articles/831566/)

http://localhost:8080/swagger-ui/index.html

mvn clean install "-Dmaven.wagon.http.ssl.insecure=true" "-Dmaven.wagon.http.ssl.allowall=true" "-Dmaven.wagon.http.ssl.ignore.validity.dates=true" "-Dmaven.resolver.transport=wagon"

