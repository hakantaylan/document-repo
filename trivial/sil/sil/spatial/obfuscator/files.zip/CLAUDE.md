# Java Source Obfuscator — CLAUDE.md

This file tells Claude what this project is, how it is structured, and what the key
invariants are that must be preserved when making changes.

---

## What this project does

This is a **source-level Java obfuscator** built on top of
[JavaParser](https://javaparser.org/).  Given a Spring Boot / Spring Data project
it produces an obfuscated copy by renaming classes, methods, and fields to
meaningless generated names (e.g. `FruitService` → `LotusBadger19Service`,
`fruitMapper` → `fLily98`).  A `mapping.json` file records every rename so a
companion **deobfuscator** can reverse the process exactly.

The project does **not** obfuscate bytecode.  It works at the source (.java) level
and the output is a fully compilable Maven/Gradle project.

---

## Package layout

```
com.example.obfuscator
├── ObfuscationRules.java     — policy: which classes/methods/fields are renamed
├── RenameContext.java        — mutable state: all rename maps
├── NameGenerator.java        — Faker-backed context-aware name generator
├── AstUtils.java             — shared static AST helpers used by obf + deobf
├── MappingStore.java         — reads/writes mapping.json
├── ProjectCopier.java        — copies project trees, relocates .java files
│
├── ObfuscatorMain.java       — entry point; orchestrates 4 passes
├── DeobfuscatorMain.java     — entry point; orchestrates phases + DeobfContext
│
├── obf/                      — six visitors applied per CU in the apply pass
│   ├── ClassRenameVisitor    — V1: class/import/type-ref renames
│   ├── MethodRenameVisitor   — V2: method decls, calls, method-reference ids
│   ├── FieldDeclVisitor      — V3a: field declaration renames
│   ├── FieldUsageVisitor     — V3b: field usages (NameExpr, FieldAccessExpr, MRE scopes)
│   ├── BuilderChainVisitor   — V4: Lombok @Builder / @SuperBuilder setter chains
│   └── AccessorVisitor       — V5: Lombok getter/setter/record-accessor calls
│
└── deobf/                    — five visitors applied per CU in the restore phases
    ├── ClassRestoreVisitor   — Phase 1a: restore class names
    ├── FieldDeclRestoreVisitor — Phase 1b: restore field declarations
    ├── FieldUsageRestoreVisitor — Phase 1c: restore field usages + MRE scopes + builder chains
    ├── AccessorRestoreVisitor — Phase 1c (second pass): restore getter/setter calls
    └── MethodRestoreVisitor  — Phase 2: restore method names (after relocation)
```

---

## Running

```bash
# Obfuscate
java -cp obfuscator.jar com.example.obfuscator.ObfuscatorMain /path/to/project

# Deobfuscate (requires mapping.json in the obfuscated project root)
java -cp obfuscator.jar com.example.obfuscator.DeobfuscatorMain /path/to/project-obf
```

Output folders are created as siblings: `myproject-obf` and `myproject-orj`.

---

## Obfuscation rules (ObfuscationRules.java)

**Class names** — every project class is renamed.  Classes whose names end with a
*preserved suffix* (e.g. `Service`, `Repository`, `Mapper`, `Dto`) get a generated
prefix before the suffix (`FruitService` → `LotusBadger19Service`).  Classes without
a preserved suffix get a fully generated name (`FruitSpecBuilder` → `ZorblinFox4`).

**Methods** — renamed selectively:
- Always renamed: non-framework methods in `*Service`, `*Specification`, `*Specifications`
- Never renamed: methods in `*Repository`, `*Controller`, `*Mapper`, `*Dto`, `*Entity`
- Never renamed: methods carrying Spring/JPA/JUnit annotations (`@GetMapping`,
  `@Transactional`, `@Override`, `@Test`, etc.)
- Also renamed: private methods in utility classes (no recognised suffix, no Spring bean annotation)

**Fields** — renamed unless:
- `public`, `static final`, or ALL_CAPS constant
- Name is on the blacklist (`id`, `log`, `serialVersionUID`, `createdAt`, …)
- Inside an interface
- Annotated with a blocking annotation (`@Column`, `@Autowired`, `@JsonProperty`,
  `@Getter`, `@Mapping`, …)

**Not obfuscated**: enum constants, method parameters, local variables, annotations.

---

## Obfuscator pass ordering — critical invariant

The four-pass design and the ordering of the six apply-pass visitors are
**load-bearing**.  Do not reorder them.

### Collection passes (1–3)
1. **PASS 1** — collect class renames + superclass hierarchy
2. **PASS 2** — collect method renames (uses resolved method signatures)
3. **PASS 3** — collect field renames + build `flatFieldRenames`

All collection passes complete before any AST mutation begins.  This ensures that
when we encounter a reference to a not-yet-processed class/method/field we already
have its new name in the relevant map.

### Apply pass visitors (V1–V5), run per compilation unit
```
V1 ClassRenameVisitor    → V2 MethodRenameVisitor → V3a FieldDeclVisitor
                                                    → V3b FieldUsageVisitor
                                                    → V4 BuilderChainVisitor
                                                    → V5 AccessorVisitor
```

**V3a before V3b**: The symbol solver is configured against the *original source files
on disk* (the obf copy before any mutation).  V3a renames field declarations in the
in-memory AST; V3b then resolves field *usages* by querying the solver which still
returns the original declaring-type FQ — matching our `fieldMap` keys.  If both ran
in the same pass, V3a's rename would make V3b's resolver fail to find the original name.

---

## Deobfuscator phase ordering — critical invariant

```
Phase 1a (classes) → Phase 1b (field decls) → Phase 1c (field usages + accessors)
→ Relocation (rename .java files) → Phase 2 (methods, re-parse)
```

**Why relocation before Phase 2**: The symbol solver needs to find restored class names
on disk under their correct file names.  Phase 2 re-parses all files after relocation
so the solver works with correct names.

---

## Key data structures

### RenameContext (obfuscator)

| Field | Key format | Value |
|-------|-----------|-------|
| `classMap` | `origFQ` | `newSimple` |
| `methodMap` | `MethodKey("FQ.name#(p1,p2)")` | `newName` |
| `fieldMap` | `"origFQ\|origFieldName"` | `newName` |
| `metamodelMap` | `"OldSimple_"` | `"NewSimple_"` |
| `superclassMap` | `origChildFQ` | `origParentFQ` |
| `flatFieldRenames` | `origFieldName` (unique project-wide) | `newName` |
| `allRenamedOrigFieldNames` | set of all original field names renamed | — |

### DeobfContext (deobfuscator, built from mapping.json)

| Field | Key format | Value |
|-------|-----------|-------|
| `obfFqToOrig` | `obfFQ` | `origFQ` |
| `newSimpleToOrig` | `newSimple` | `origSimple` |
| `fieldByObfFq` | `"obfFQ\|newFieldName"` | `origFieldName` |
| `fieldByOrigFq` | `"origFQ\|newFieldName"` | `origFieldName` |
| `newFieldToOrig` | `newFieldName` (project-wide) | `origFieldName` |
| `methodRev` | `"origDT\|descriptor\|obfName"` | `origName` |
| `superclassMap` | both `obfChildFQ→obfParentFQ` and `origChildFQ→origParentFQ` | — |

---

## The method-reference scope problem

JavaParser's symbol solver frequently **cannot resolve** a `NameExpr` that is the
direct scope of a `MethodReferenceExpr` (e.g. `fruitMapper` in
`fruitMapper::toDtoBase`).  For Lombok-injected fields of interface types (MapStruct
mappers) the solver may also represent the scope as a `TypeExpr` rather than a
`NameExpr`.

The fix is in `FieldUsageVisitor.visit(MethodReferenceExpr)` (V3b) and mirrored in
`FieldUsageRestoreVisitor`.  Both call `super.visit` first so children are processed,
then apply an unconditional field-map lookup using `AstUtils.mreSimpleScopeName()`
which extracts the name regardless of whether the scope is a `NameExpr` or `TypeExpr`.

---

## The Lombok accessor / builder problem

Lombok-generated methods (`getName()`, `setPrice()`, builder setters `.name("x")`)
are **absent from source**, so the symbol solver cannot resolve them.

- **Getters/setters** are handled by `AccessorVisitor` (V5) and `AccessorRestoreVisitor`:
  derive the field name from the method name prefix (`get`/`set`/`is`), then look up the
  field rename.  When the solver fails, `AstUtils.resolveScopeOwnerFq()` finds the
  owner type by reading the *declared* type of the scope expression from the AST
  (parameter list or field declaration) rather than resolving it.

- **Builder setters** are handled by `BuilderChainVisitor` (V4) and
  `FieldUsageRestoreVisitor.visit(MethodCallExpr)`: walk the scope chain to find
  `.builder()`, identify the owner class, then look up the field.  Inherited fields
  (e.g. `name`/`price` on base `Fruit` used in `ExoticFruit.builder()`) are found by
  walking the type-solver ancestor chain via `findFieldInHierarchy` / `fieldInHierarchy`.

---

## Adding a new rule

**To exclude a new annotation from method renaming** — add it to
`ObfuscationRules.METHOD_BLOCKED_ANNOTATIONS`.

**To exclude a new field annotation** — add it to
`ObfuscationRules.FIELD_BLOCKED_ANNOTATIONS`.

**To preserve a new class-name suffix** — add it to
`ObfuscationRules.PRESERVE_SUFFIXES`.

**To rename methods in a new class category** — add the suffix to either
`METHOD_RENAME_SUFFIXES` or `METHOD_NO_RENAME_SUFFIXES`.

**To add a new infrastructure package** — add a `startsWith` check to both
`AstUtils.isInfrastructureFq()` (blocks method/field rename at usage sites) and
`AstUtils.excludePkg()` (skips the entire package during collection passes).

---

## Dependencies

```xml
<!-- DataFaker — for the vocabulary-backed NameGenerator -->
<dependency>
    <groupId>net.datafaker</groupId>
    <artifactId>datafaker</artifactId>
    <version>2.x</version>
</dependency>

<!-- JavaParser with symbol solver -->
<dependency>
    <groupId>com.github.javaparser</groupId>
    <artifactId>javaparser-symbol-solver-core</artifactId>
    <version>3.25.x</version>
</dependency>

<!-- Jackson (tools.jackson variant) -->
<dependency>
    <groupId>tools.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
</dependency>
```

Requires **Java 17+** (uses pattern matching, sealed types, records).

---

## Known limitations

- **Annotations with string arguments** referencing field names (e.g.
  `@JsonProperty("someField")`) are not updated.  The obfuscated class will still
  have the original string literal.
- **Spring Data derived query method names** (e.g. `findByPriceGreaterThan`) are
  intentionally not renamed (`Repository` suffix rule), but the field names embedded
  in them would be stale if the entity field is renamed.  This is by design — Spring
  Data repositories are excluded from method renaming entirely.
- **Reflection-based access** using original field/method name strings is not handled.
- The obfuscator is **not idempotent**: running it twice on the same project will fail
  because the output folder already exists.
