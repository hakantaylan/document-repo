package com.example.obfuscator;

import net.datafaker.Faker;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * Context-aware name generator backed by <a href="https://github.com/datafaker-net/datafaker">
 * DataFaker</a> for an effectively infinite, human-readable vocabulary.
 *
 * <h2>Naming conventions</h2>
 * <pre>
 * ┌─────────────────────────┬─────────────────────────┬──────────────────────────────┐
 * │ What                    │ Pattern                  │ Examples                     │
 * ├─────────────────────────┼─────────────────────────┼──────────────────────────────┤
 * │ *Service class base     │ Adjective + Animal       │ SwiftFalcon, CrimsonOtter    │
 * │ *Controller class base  │ Color + Place            │ GoldenHarbor, SilverValley   │
 * │ *Repository class base  │ Material + Object        │ MarbleVault, CrystalCache    │
 * │ *Entity class base      │ Mythical + Animal        │ PhantomWolf, AncientDragon   │
 * │ *Dto class base         │ Element + Nature         │ IronMist, CoralDust          │
 * │ *Mapper class base      │ Material + Instrument    │ CopperViolin, SteelDrum      │
 * │ *Specification base     │ Adjective + Space word   │ HollowComet, CurvedNebula    │
 * │ Other class             │ Adjective + Noun         │ FrozenLantern, DimSpire      │
 * ├─────────────────────────┼─────────────────────────┼──────────────────────────────┤
 * │ getter / setter method  │ verb + Noun (camelCase)  │ fetchRiver, gatherDust       │
 * │ other method            │ verb + Noun (camelCase)  │ parseComet, buildRidge       │
 * ├─────────────────────────┼─────────────────────────┼──────────────────────────────┤
 * │ id / key / code field   │ animal + Id/Key/Code     │ falconId, marbleKey          │
 * │ regular field           │ color + ingredient       │ goldenAnchor, crimsonDust    │
 * └─────────────────────────┴─────────────────────────┴──────────────────────────────┘
 * </pre>
 *
 * <h2>Uniqueness</h2>
 * Every generated name is registered in a shared {@code used} set.  On collision
 * (rare given the large vocabulary) a numeric suffix is appended and incremented
 * until the name is free.
 *
 * <h2>Determinism</h2>
 * The Faker instance is seeded, so repeated runs on the same source produce the
 * same mapping.  Change {@link #SEED} to produce a completely different mapping.
 */
public final class NameGenerator {

    // ── Configuration ─────────────────────────────────────────────────────────────

    /** Change this seed to produce a completely different obfuscation mapping. */
    private static final long SEED = 123_456_789L;

    // ── Id-like field name suffixes ────────────────────────────────────────────────

    /**
     * If an original field name <em>ends with</em> one of these (case-insensitive),
     * the generated name preserves the semantic suffix.
     * e.g. {@code userId → falconId},  {@code orderKey → marbleKey}
     */
    private static final List<String> ID_LIKE_SUFFIXES = List.of(
            "Id", "ID", "Key", "KEY", "Code", "CODE", "Ref", "REF",
            "Uuid", "UUID", "Guid", "GUID", "Token", "TOKEN", "Hash", "HASH"
    );

    // ── Verb pool for methods (Faker has no verb category) ────────────────────────

    private static final List<String> VERBS = List.of(
            "build", "parse", "fetch", "gather", "resolve", "compute", "transform",
            "validate", "extract", "apply", "process", "generate", "convert", "merge",
            "filter", "collect", "assemble", "dispatch", "evaluate", "inspect",
            "prepare", "execute", "propagate", "calculate", "derive", "map",
            "encode", "decode", "publish", "consume", "invoke", "emit", "capture"
    );

    // ── Place/location nouns for Controller names ─────────────────────────────────

    private static final List<String> PLACES = List.of(
            "Harbor", "Valley", "Ridge", "Summit", "Canyon", "Delta", "Basin",
            "Crest", "Shore", "Glen", "Bluff", "Fjord", "Mesa", "Moor",
            "Peak", "Inlet", "Gorge", "Dune", "Tundra", "Steppe"
    );

    // ── Material nouns for Repository / Mapper names ──────────────────────────────

    private static final List<String> MATERIALS = List.of(
            "Marble", "Crystal", "Iron", "Copper", "Silver", "Bronze", "Obsidian",
            "Granite", "Quartz", "Amber", "Ivory", "Onyx", "Jade", "Flint",
            "Steel", "Cobalt", "Slate", "Basalt", "Topaz", "Opal"
    );

    // ── Mythical descriptors for Entity names ─────────────────────────────────────

    private static final List<String> MYTHICAL = List.of(
            "Ancient", "Phantom", "Mystic", "Ethereal", "Arcane", "Primordial",
            "Spectral", "Celestial", "Eldritch", "Sacred", "Runic", "Astral",
            "Cursed", "Divine", "Forgotten", "Hollow", "Eternal", "Shadow",
            "Void", "Fabled"
    );

    // ── Object nouns for generic classes / Repository ─────────────────────────────

    private static final List<String> OBJECTS = List.of(
            "Vault", "Cache", "Ledger", "Archive", "Registry", "Beacon", "Lantern",
            "Anchor", "Compass", "Forge", "Anvil", "Prism", "Spire", "Tower",
            "Bridge", "Pillar", "Shard", "Relic", "Totem", "Emblem"
    );

    // ── Adjectives (Faker has no dedicated adjective provider) ───────────────────

    private static final List<String> ADJECTIVES = List.of(
            "Swift", "Crimson", "Golden", "Silent", "Hollow", "Frozen", "Curved",
            "Blazing", "Dark", "Pale", "Vivid", "Dim", "Rough", "Smooth", "Bold",
            "Faint", "Sharp", "Narrow", "Broad", "Agile", "Nimble", "Radiant",
            "Stormy", "Calm", "Fierce", "Gentle", "Ancient", "Twisted", "Bright",
            "Cloudy", "Dusty", "Rustic", "Sleek", "Solemn", "Stark", "Hollow",
            "Bitter", "Barren", "Lush", "Murky", "Glowing", "Tattered", "Lofty"
    );

    // ── Core state ────────────────────────────────────────────────────────────────

    private final Faker faker;
    private final Random rnd;
    private final Set<String> used = new HashSet<>();
    private final AtomicInteger collisionCounter = new AtomicInteger(1);

    // ── Pattern for stripping non-identifier characters from Faker output ─────────

    /** Matches any character that is not a letter or digit. */
    private static final Pattern NON_ALNUM = Pattern.compile("[^a-zA-Z0-9]");

    public NameGenerator() {
        this.rnd   = new Random(SEED);
        this.faker = new Faker(new Random(SEED));
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Public API — class naming
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Generates a class-name base for a class whose name ends with a recognised
     * architectural suffix (e.g. {@code Service}, {@code Repository}, {@code Dto}).
     *
     * <p>The suffix itself is appended by the caller ({@code ObfuscatorMain.proposeClassName}).
     *
     * @param suffix the preserved suffix, e.g. {@code "Service"}, {@code "Repository"}
     */
    public String nextClassBase(String suffix) {
        String candidate = switch (suffix) {
            case "Service"                          -> adjective() + animal();
            case "Controller", "Ctrl"               -> color() + place();
            case "Repository"                       -> material() + object();
            case "Entity"                           -> mythical() + animal();
            case "Dto", "DTO", "ResponseDto"        -> element() + ingredient();
            case "Mapper"                           -> material() + instrument();
            case "Specification", "Specifications"  -> adjective() + spaceThing();
            default                                 -> adjective() + object();
        };
        return unique(candidate);
    }

    /**
     * Generates a full class name for classes without a recognised preserved suffix
     * (utility classes, helper classes, etc.).
     * Pattern: Adjective + Noun.
     */
    public String nextClassName() {
        return unique(adjective() + object());
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Public API — method naming
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Generates a method name.
     *
     * <p>If the original method name starts with a bean-style prefix ({@code get},
     * {@code set}, {@code is}) the generated name preserves that prefix so the
     * method still reads as an accessor.  Other methods receive a fresh verb.
     *
     * @param originalName the original method name, used only to detect accessor prefixes
     */
    public String nextMethodName(String originalName) {
        String prefix = detectAccessorPrefix(originalName);
        String noun   = capitalize(ingredient()); // a varied noun from food ingredients

        String candidate = prefix.isEmpty()
                ? lowerFirst(verb() + capitalize(spaceThing()))   // e.g. parseComet, buildNebula
                : prefix + capitalize(noun);                       // e.g. getName → getSilver
        return uniqueLower(candidate);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Public API — field naming
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Generates a field name.
     *
     * <p>If the original name ends with an id-like suffix ({@code Id}, {@code Key},
     * {@code Code}, …) the generated name preserves that suffix so the semantic
     * role of the field remains recognisable.
     * e.g. {@code userId → falconId},  {@code orderKey → marbleKey}
     *
     * @param originalName the original field name, used only to detect id-like suffixes
     */
    public String nextFieldName(String originalName) {
        String idSuffix = detectIdSuffix(originalName);
        String candidate = idSuffix.isEmpty()
                ? lowerFirst(color() + capitalize(ingredient()))   // e.g. goldenAnchor, crimsonDust
                : lowerFirst(animal()) + idSuffix;                 // e.g. falconId, marbleKey
        return uniqueLower(candidate);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Word sources — each call draws a fresh word from Faker or a curated list
    // ─────────────────────────────────────────────────────────────────────────────

    /** e.g. {@code "Falcon"}, {@code "Otter"} */
    private String animal() {
        return sanitize(faker.animal().name());
    }

    /** e.g. {@code "Golden"}, {@code "Crimson"} */
    private String color() {
        return sanitize(faker.color().name());
    }

    /** e.g. {@code "Basalt"}, {@code "Crystal"} */
    private String element() {
        return sanitize(faker.science().element());
    }

    /** e.g. {@code "Saffron"}, {@code "Cardamom"} — used as varied nouns */
    private String ingredient() {
        return sanitize(faker.food().ingredient());
    }

    /** e.g. {@code "Cello"}, {@code "Oboe"} */
    private String instrument() {
        return sanitize(faker.music().instrument());
    }

    /** e.g. {@code "Andromeda"}, {@code "Polaris"}, {@code "Europa"} */
    private String spaceThing() {
        // Randomly pick from planets, stars, or galaxies for variety
        return switch (rnd.nextInt(3)) {
            case 0 -> sanitize(faker.space().planet());
            case 1 -> sanitize(faker.space().star());
            default -> sanitize(faker.space().galaxy());
        };
    }

    private String adjective() { return pickFrom(ADJECTIVES); }
    private String place()     { return pickFrom(PLACES);     }
    private String material()  { return pickFrom(MATERIALS);  }
    private String mythical()  { return pickFrom(MYTHICAL);   }
    private String object()    { return pickFrom(OBJECTS);    }
    private String verb()      { return pickFrom(VERBS);      }

    private String pickFrom(List<String> list) {
        return list.get(rnd.nextInt(list.size()));
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Sanitization helpers
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Converts a raw Faker string (which may contain spaces, hyphens, apostrophes,
     * numbers, etc.) into a clean PascalCase identifier segment.
     *
     * <p>Examples:
     * <ul>
     *   <li>{@code "blue whale" → "BlueWhale"}</li>
     *   <li>{@code "lion's mane" → "LionsMane"}</li>
     *   <li>{@code "carbon-14" → "Carbon14"}</li>
     * </ul>
     */
    static String sanitize(String raw) {
        if (raw == null || raw.isBlank()) return "Alpha";
        // Split on any non-alphanumeric boundary, capitalise each token
        StringBuilder sb = new StringBuilder();
        for (String token : NON_ALNUM.split(raw)) {
            if (token.isEmpty()) continue;
            sb.append(Character.toUpperCase(token.charAt(0)));
            sb.append(token.substring(1).toLowerCase());
        }
        // Guard: must start with a letter (Faker can produce things like "23 Skidoo")
        if (sb.isEmpty() || !Character.isLetter(sb.charAt(0))) sb.insert(0, "X");
        return sb.toString();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static String lowerFirst(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Uniqueness guarantees
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Registers a candidate PascalCase name and returns it.  On collision
     * (the same two-word combination was already generated) appends an
     * incrementing numeric suffix until the name is unique.
     */
    private String unique(String candidate) {
        if (used.add(candidate)) return candidate;
        // Collision path — extremely rare given the vocabulary size
        String suffixed;
        do {
            suffixed = candidate + collisionCounter.getAndIncrement();
        } while (!used.add(suffixed));
        return suffixed;
    }

    /**
     * Same as {@link #unique} but forces the first character to lower-case
     * (used for method and field names).
     */
    private String uniqueLower(String candidate) {
        return unique(lowerFirst(candidate));
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Accessor / id-suffix detection
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Returns the bean-style prefix ({@code "get"}, {@code "set"}, {@code "is"})
     * if the original method name starts with one followed by an uppercase letter;
     * otherwise returns {@code ""}.
     */
    private static String detectAccessorPrefix(String name) {
        if (name == null) return "";
        if (name.length() > 3 && name.startsWith("get") && Character.isUpperCase(name.charAt(3))) return "get";
        if (name.length() > 3 && name.startsWith("set") && Character.isUpperCase(name.charAt(3))) return "set";
        if (name.length() > 2 && name.startsWith("is")  && Character.isUpperCase(name.charAt(2))) return "is";
        return "";
    }

    /**
     * If the original field name ends with one of the recognised id-like suffixes
     * (case-sensitive, e.g. {@code "Id"}, {@code "Key"}, {@code "UUID"}), returns
     * that suffix so the generated name can preserve it.
     * Returns {@code ""} when no id-like suffix is detected.
     */
    private static String detectIdSuffix(String name) {
        if (name == null) return "";
        for (String suffix : ID_LIKE_SUFFIXES)
            if (name.endsWith(suffix) && name.length() > suffix.length())
                return suffix;
        return "";
    }
}
