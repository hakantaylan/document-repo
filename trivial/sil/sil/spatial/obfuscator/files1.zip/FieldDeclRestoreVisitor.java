package com.example.obfuscator.deobf;

import com.example.obfuscator.DeobfuscatorMain.DeobfContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;

import java.util.Map;

/**
 * Phase 1b — restores field <em>declarations</em> and record component names.
 *
 * <p>Must be a separate pass from {@link FieldUsageRestoreVisitor} (Phase 1c)
 * so that the symbol solver — still reading the obfuscated files on disk — can
 * resolve field usages by their original obfuscated names during Phase 1c.
 */
public class FieldDeclRestoreVisitor extends ModifierVisitor<Void> {

    private final DeobfContext                    dctx;
    private final Map<TypeDeclaration<?>, String> typeObfFq;

    public FieldDeclRestoreVisitor(DeobfContext dctx, Map<TypeDeclaration<?>, String> typeObfFq) {
        this.dctx      = dctx;
        this.typeObfFq = typeObfFq;
    }

    @Override
    public Visitable visit(FieldDeclaration fd, Void arg) {
        fd.findAncestor(TypeDeclaration.class).ifPresent(owner -> {
            String obfFq = typeObfFq.get(owner);
            if (obfFq == null) return;
            for (VariableDeclarator vd : fd.getVariables()) {
                String orig = dctx.fieldInHierarchy(obfFq, vd.getNameAsString());
                if (orig != null) vd.setName(orig);
            }
        });
        return super.visit(fd, arg);
    }

    /** Restores record component (parameter) names — treated as fields in the mapping. */
    @Override
    public Visitable visit(RecordDeclaration rd, Void arg) {
        String obfFq = typeObfFq.get(rd);
        if (obfFq != null) {
            for (Parameter rc : rd.getParameters()) {
                String orig = dctx.fieldLookup(obfFq, rc.getNameAsString());
                if (orig == null) orig = dctx.newFieldToOrig.get(rc.getNameAsString());
                if (orig != null) rc.setName(orig);
            }
        }
        return super.visit(rd, arg);
    }
}
