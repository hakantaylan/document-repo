package com.example.obfuscator;

import com.example.obfuscator.deobf.*;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.printer.configuration.PrettyPrinterConfiguration;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.*;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Deobfuscator — reverses an obfuscated source tree produced by {@link ObfuscatorMain}.
 *
 * <p>Phases:
 * <ol>
 *   <li>1a — Restore class / interface / enum names, imports, type references.</li>
 *   <li>1b — Restore field declarations.</li>
 *   <li>1c — Restore field usages, MRE scopes, builder chains, getters/setters.</li>
 *   <li>Relocation — rename {@code .java} files to match restored class names.</li>
 *   <li>2  — Restore method names (re-parse after relocation).</li>
 * </ol>
 */
public class DeobfuscatorMain {

    public static void main(String[] args) throws Exception {
        Path obfProject = (args.length >= 1 && args[0] != null && !args[0].isBlank())
                ? Paths.get(args[0]).toAbsolutePath().normalize()
                : Paths.get(".").toAbsolutePath().normalize();

        DeobfContext dctx = MappingStore.read(obfProject);

        // ── Prepare output folder ─────────────────────────────────────────────────
        String folderName = obfProject.getFileName().toString();
        String outName = folderName.endsWith("-obf")
                ? folderName.substring(0, folderName.length() - 4) + "-orj"
                : folderName + "-orj";
        Path deofProject = obfProject.resolveSibling(outName);
        if (Files.exists(deofProject)) {
            System.err.println("Target already exists: " + deofProject + ". Delete it first."); System.exit(4);
        }
        ProjectCopier.copyTree(obfProject, deofProject);
        Path srcRoot = deofProject.resolve("src/main/java");

        // ── Parser + symbol solver ────────────────────────────────────────────────
        CombinedTypeSolver solver = new CombinedTypeSolver();
        solver.add(new ReflectionTypeSolver(false));
        solver.add(new JavaParserTypeSolver(srcRoot.toFile()));
        JavaParser parser = new JavaParser(
                new ParserConfiguration().setSymbolResolver(new JavaSymbolSolver(solver)));

        // ── Parse all CUs ─────────────────────────────────────────────────────────
        List<Path> javaFiles;
        try (Stream<Path> s = Files.walk(srcRoot)) {
            javaFiles = s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        }
        Map<Path, CompilationUnit> units = parseAll(parser, javaFiles, "phase 1");

        // ── PRE-PASS: snapshot TypeDeclaration → obfuscated FQ ───────────────────
        Map<TypeDeclaration<?>, String> typeObfFq = new IdentityHashMap<>();
        for (CompilationUnit cu : units.values())
            for (TypeDeclaration<?> td : cu.findAll(TypeDeclaration.class))
                typeObfFq.put(td, computeCurrentFq(td, cu));

        // ── Phase 1a: restore class names ─────────────────────────────────────────
        for (var en : units.entrySet())
            en.getValue().accept(new ClassRestoreVisitor(dctx), null);

        // ── Phase 1b: restore field declarations ──────────────────────────────────
        for (var en : units.entrySet())
            en.getValue().accept(new FieldDeclRestoreVisitor(dctx, typeObfFq), null);

        // ── Phase 1c: restore field usages, builder chains, getters/setters ───────
        for (var en : units.entrySet()) {
            CompilationUnit cu = en.getValue();
            cu.accept(new FieldUsageRestoreVisitor(dctx, typeObfFq), null);
            cu.accept(new AccessorRestoreVisitor(dctx), null);
            Files.createDirectories(en.getKey().getParent());
            try (BufferedWriter w = Files.newBufferedWriter(en.getKey())) {
                w.write(cu.toString(new PrettyPrinterConfiguration()));
            }
        }

        // ── Relocation pass ───────────────────────────────────────────────────────
        ProjectCopier.relocateJavaFiles(srcRoot, parser);

        // ── Phase 2: restore method names (re-parse after relocation) ────────────
        javaFiles = Files.walk(srcRoot).filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        units = parseAll(parser, javaFiles, "phase 2");

        for (var en : units.entrySet()) {
            en.getValue().accept(new MethodRestoreVisitor(dctx), null);
            Files.createDirectories(en.getKey().getParent());
            try (BufferedWriter w = Files.newBufferedWriter(en.getKey())) {
                w.write(en.getValue().toString(new PrettyPrinterConfiguration()));
            }
        }

        System.out.println("Deobfuscation complete. Output at: " + deofProject);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // DeobfContext — all reverse-lookup maps
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Immutable snapshot of all reverse-lookup maps built from {@code mapping.json}.
     */
    public static final class DeobfContext {

        /** obfFq → origFq */
        public final Map<String, String> obfFqToOrig    = new HashMap<>();
        /** newSimple → origSimple */
        public final Map<String, String> newSimpleToOrig = new HashMap<>();
        /** "new" metamodel name → "original" metamodel name */
        public final Map<String, String> metamodelRev    = new HashMap<>();
        /** "declaringType|descriptor|obfName" → origName */
        public final Map<String, String> methodRev       = new HashMap<>();
        /** obfFq|newFieldName → origFieldName */
        public final Map<String, String> fieldByObfFq    = new HashMap<>();
        /** origFq|newFieldName → origFieldName */
        public final Map<String, String> fieldByOrigFq   = new HashMap<>();
        /** newFieldName → origFieldName (project-wide) */
        public final Map<String, String> newFieldToOrig  = new HashMap<>();
        /** obfChildFq → obfParentFq (+ origChildFq → origParentFq) */
        public final Map<String, String> superclassMap   = new HashMap<>();
        /** All obfuscated field names */
        public final Set<String> allNewFieldNames        = new HashSet<>();

        @SuppressWarnings("unchecked")
        public static DeobfContext from(Map<String, Object> mapping) {
            DeobfContext c = new DeobfContext();

            // Class maps
            Map<String, String> origToNew = new HashMap<>();
            for (var m : (List<Map<String, String>>) mapping.getOrDefault("classMap", List.of()))
                origToNew.put(m.get("original"), m.get("newSimple"));

            for (var e : origToNew.entrySet()) {
                String origFq = e.getKey(), newSimple = e.getValue();
                int dot = origFq.lastIndexOf('.');
                String pkg = dot >= 0 ? origFq.substring(0, dot) : "";
                c.obfFqToOrig.put(pkg.isEmpty() ? newSimple : pkg + "." + newSimple, origFq);
                c.newSimpleToOrig.put(newSimple, AstUtils.simpleName(origFq));
            }

            // Metamodel
            for (var x : (List<Map<String, String>>) mapping.getOrDefault("metamodelMap", List.of()))
                c.metamodelRev.put(x.get("new"), x.get("original"));

            // Methods
            for (var me : (List<Map<String, Object>>) mapping.getOrDefault("methods", List.of()))
                c.methodRev.put(me.get("declaringType") + "|" + me.get("descriptor") + "|" + me.get("newName"),
                        (String) me.get("originalName"));

            // Fields
            for (var fe : (List<Map<String, String>>) mapping.getOrDefault("fields", List.of())) {
                String origDt = fe.get("declaringType"), origFn = fe.get("originalName"), newFn = fe.get("newName");
                c.fieldByOrigFq.put(origDt + "|" + newFn, origFn);
                String obfDt = toObfFq(origDt, origToNew);
                c.fieldByObfFq.put(obfDt + "|" + newFn, origFn);
                c.newFieldToOrig.put(newFn, origFn);
            }
            c.allNewFieldNames.addAll(c.newFieldToOrig.keySet());

            // Superclass hierarchy
            for (var sc : (List<Map<String, String>>) mapping.getOrDefault("superclassMap", List.of())) {
                String childOrig = sc.get("child"), parentOrig = sc.get("parent");
                c.superclassMap.put(toObfFq(childOrig, origToNew), toObfFq(parentOrig, origToNew));
                c.superclassMap.put(childOrig, parentOrig);
            }

            return c;
        }

        /** Hierarchy-aware field lookup walking up via superclassMap. */
        public String fieldInHierarchy(String startFq, String newFieldName) {
            String fq = startFq;
            Set<String> visited = new HashSet<>();
            while (fq != null && visited.add(fq)) {
                String v = fieldLookup(fq, newFieldName);
                if (v != null) return v;
                fq = superclassMap.get(fq);
            }
            return null;
        }

        public String fieldLookup(String declaringFq, String newName) {
            String v = fieldByObfFq.get(declaringFq + "|" + newName);
            return v != null ? v : fieldByOrigFq.get(declaringFq + "|" + newName);
        }

        public boolean isKnownProjectType(String fq) {
            if (fq == null) return false;
            String prefix = fq + "|";
            for (String k : fieldByObfFq.keySet())  if (k.startsWith(prefix)) return true;
            for (String k : fieldByOrigFq.keySet()) if (k.startsWith(prefix)) return true;
            return superclassMap.containsKey(fq) || superclassMap.containsValue(fq);
        }

        private static String toObfFq(String origFq, Map<String, String> origToNew) {
            String ns = origToNew.get(origFq);
            if (ns == null) return origFq;
            int dot = origFq.lastIndexOf('.');
            return dot < 0 ? ns : origFq.substring(0, dot) + "." + ns;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────────

    private static Map<Path, CompilationUnit> parseAll(JavaParser parser, List<Path> files, String phase)
            throws IOException {
        Map<Path, CompilationUnit> map = new LinkedHashMap<>();
        for (Path p : files) {
            var res = parser.parse(p);
            if (res.isSuccessful() && res.getResult().isPresent()) {
                map.put(p, res.getResult().get());
            } else {
                System.err.println("Parse failed (" + phase + "): " + p);
                res.getProblems().forEach(System.err::println);
                throw new IllegalStateException("Parse failed: " + p);
            }
        }
        return map;
    }

    private static String computeCurrentFq(TypeDeclaration<?> td, CompilationUnit cu) {
        return AstUtils.computeFq(td, cu);
    }
}
