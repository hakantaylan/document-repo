package com.example.obfuscator.deobf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.DeobfuscatorMain.DeobfContext;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;

/**
 * Phase 1a — restores class / interface / enum / record declaration names,
 * constructor names, import statements, and all type-reference sites.
 */
public class ClassRestoreVisitor extends ModifierVisitor<Void> {

    private final DeobfContext dctx;

    public ClassRestoreVisitor(DeobfContext dctx) {
        this.dctx = dctx;
    }

    @Override
    public Node visit(ImportDeclaration id, Void arg) {
        String name = id.getNameAsString();
        if (dctx.obfFqToOrig.containsKey(name)) {
            id.setName(dctx.obfFqToOrig.get(name));
            return super.visit(id, arg);
        }
        for (String ns : dctx.newSimpleToOrig.keySet()) {
            if (name.endsWith("." + ns)) {
                String candidate = dctx.obfFqToOrig.getOrDefault(name,
                        dctx.obfFqToOrig.keySet().stream()
                                .filter(obfFq -> {
                                    int i = obfFq.lastIndexOf('.');
                                    return i > 0 && name.equals(obfFq.substring(0, i) + "." + ns);
                                }).findFirst().map(dctx.obfFqToOrig::get).orElse(null));
                if (candidate != null) { id.setName(candidate); break; }
            }
        }
        return super.visit(id, arg);
    }

    @Override
    public Visitable visit(ClassOrInterfaceType cit, Void arg) {
        try {
            String fq = cit.resolve().asReferenceType().getQualifiedName();
            if (dctx.obfFqToOrig.containsKey(fq)) cit.setName(AstUtils.simpleName(dctx.obfFqToOrig.get(fq)));
        } catch (Throwable ignored) {
            String s = cit.getNameAsString();
            if (dctx.newSimpleToOrig.containsKey(s))  cit.setName(dctx.newSimpleToOrig.get(s));
            else if (dctx.metamodelRev.containsKey(s)) cit.setName(dctx.metamodelRev.get(s));
        }
        return super.visit(cit, arg);
    }

    @Override
    public Visitable visit(ClassExpr ce, Void arg) {
        if (ce.getType().isClassOrInterfaceType()) {
            ClassOrInterfaceType cit = ce.getType().asClassOrInterfaceType();
            try {
                String fq = cit.resolve().asReferenceType().getQualifiedName();
                if (dctx.obfFqToOrig.containsKey(fq)) cit.setName(AstUtils.simpleName(dctx.obfFqToOrig.get(fq)));
            } catch (Throwable ignored) {
                String s = cit.getNameAsString();
                if (dctx.newSimpleToOrig.containsKey(s)) cit.setName(dctx.newSimpleToOrig.get(s));
            }
        }
        return super.visit(ce, arg);
    }

    @Override
    public Visitable visit(ObjectCreationExpr oce, Void arg) {
        oce.getType().ifClassOrInterfaceType(cit -> {
            try {
                String fq = cit.resolve().asReferenceType().getQualifiedName();
                if (dctx.obfFqToOrig.containsKey(fq)) cit.setName(AstUtils.simpleName(dctx.obfFqToOrig.get(fq)));
            } catch (Throwable ignored) {
                String s = cit.getNameAsString();
                if (dctx.newSimpleToOrig.containsKey(s)) cit.setName(dctx.newSimpleToOrig.get(s));
            }
        });
        return super.visit(oce, arg);
    }

    @Override
    public Visitable visit(ClassOrInterfaceDeclaration cid, Void arg) {
        String s = cid.getNameAsString();
        if (dctx.newSimpleToOrig.containsKey(s)) cid.setName(dctx.newSimpleToOrig.get(s));
        return super.visit(cid, arg);
    }

    @Override
    public Visitable visit(EnumDeclaration ed, Void arg) {
        String s = ed.getNameAsString();
        if (dctx.newSimpleToOrig.containsKey(s)) ed.setName(dctx.newSimpleToOrig.get(s));
        return super.visit(ed, arg);
    }

    @Override
    public Visitable visit(RecordDeclaration rd, Void arg) {
        String s = rd.getNameAsString();
        if (dctx.newSimpleToOrig.containsKey(s)) rd.setName(dctx.newSimpleToOrig.get(s));
        return super.visit(rd, arg);
    }

    @Override
    public Visitable visit(ConstructorDeclaration cd, Void arg) {
        // Re-sync constructor name to match the (possibly just-renamed) declaring type
        Node p = cd.getParentNode().orElse(null);
        while (p != null && !(p instanceof TypeDeclaration)) p = p.getParentNode().orElse(null);
        if (p instanceof TypeDeclaration<?> td) cd.setName(td.getNameAsString());
        return super.visit(cd, arg);
    }
}
