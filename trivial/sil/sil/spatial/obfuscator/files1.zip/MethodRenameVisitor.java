package com.example.obfuscator.obf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.RenameContext;
import com.example.obfuscator.RenameContext.MethodKey;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * V2 — renames method declarations, call sites, and method references.
 *
 * <p>Method reference identifiers (e.g. {@code toDtoBase} in {@code fruitMapper::toDtoBase})
 * use a four-tier fallback when the symbol solver cannot resolve the reference directly:
 * scope-type resolution → textual parameter/field lookup → unique-name fallback.
 *
 * <p>Method reference scopes (the {@code fruitMapper} part) that are renamed fields
 * are handled by {@link FieldUsageVisitor} (V3b), which runs after this visitor.
 */
public class MethodRenameVisitor extends ModifierVisitor<Void> {

    private final Map<MethodKey, String> methodMap;
    private final Map<String, String>    classMap;
    private final Map<String, String>    fieldMap;
    private final Map<String, String>    flatFieldRenames;

    public MethodRenameVisitor(RenameContext ctx) {
        this.methodMap       = ctx.methodMap;
        this.classMap        = ctx.classMap;
        this.fieldMap        = ctx.fieldMap;
        this.flatFieldRenames = ctx.flatFieldRenames;
    }

    @Override
    public Visitable visit(MethodDeclaration md, Void arg) {
        try {
            MethodKey mk = new MethodKey(AstUtils.methodKey(md.resolve()));
            if (methodMap.containsKey(mk)) md.setName(methodMap.get(mk));
        } catch (Throwable ignored) {}
        return super.visit(md, arg);
    }

    @Override
    public Visitable visit(MethodCallExpr mce, Void arg) {
        try {
            ResolvedMethodDeclaration rmd = mce.resolve();
            if (AstUtils.isInfrastructureFq(rmd.declaringType().getQualifiedName())) return super.visit(mce, arg);
            MethodKey mk = new MethodKey(AstUtils.methodKey(rmd));
            if (methodMap.containsKey(mk)) mce.setName(methodMap.get(mk));
        } catch (Throwable ignored) {}
        return super.visit(mce, arg);
    }

    @Override
    public Visitable visit(MethodReferenceExpr mre, Void arg) {
        // ── Part 1: rename the identifier (e.g. "toDtoBase") ─────────────────────
        try {
            ResolvedMethodDeclaration rmd = mre.resolve();
            if (!AstUtils.isInfrastructureFq(rmd.declaringType().getQualifiedName())) {
                MethodKey mk = new MethodKey(AstUtils.methodKey(rmd));
                if (methodMap.containsKey(mk)) mre.setIdentifier(methodMap.get(mk));
            }
        } catch (Throwable ignored) {
            tryRenameIdentifierFallback(mre);
        }

        // ── Part 2: rename FieldAccessExpr scope (Case B) ────────────────────────
        // NameExpr scopes are handled by FieldUsageVisitor (V3b).
        Expression scope = mre.getScope();
        if (scope instanceof FieldAccessExpr fae) {
            try {
                ResolvedValueDeclaration rvd = fae.resolve();
                if (rvd.isField()) {
                    String key = rvd.asField().declaringType().getQualifiedName() + "|" + fae.getNameAsString();
                    String mapped = fieldMap.get(key);
                    if (mapped == null) mapped = flatFieldRenames.get(fae.getNameAsString());
                    if (mapped != null) fae.setName(mapped);
                }
            } catch (Throwable ignored) {
                renameFieldAccessExprFallback(fae);
            }
        }

        return super.visit(mre, arg);
    }

    // ── Identifier fallback ───────────────────────────────────────────────────────

    private void tryRenameIdentifierFallback(MethodReferenceExpr mre) {
        String identifier = mre.getIdentifier();

        // Tier 1: resolve scope type → prefix search in methodMap
        try {
            String scopeFq = AstUtils.resolveScopeTypeFq(mre.getScope());
            if (scopeFq != null && !AstUtils.isInfrastructureFq(scopeFq)) {
                String newId = searchMethodMap(scopeFq, identifier);
                if (newId != null) { mre.setIdentifier(newId); return; }
            }
        } catch (Throwable ignored) {}

        // Tier 2 & 3: textual parameter / field lookup
        Expression sc = mre.getScope();
        if (sc instanceof NameExpr ne) {
            String varName = ne.getNameAsString();
            String textualFq = null;

            Optional<CallableDeclaration<?>> encCallable = ne.findAncestor(CallableDeclaration.class);
            if (encCallable.isPresent()) {
                for (Parameter p : encCallable.get().getParameters()) {
                    if (p.getNameAsString().equals(varName)) {
                        String textual = (p.getType() instanceof ClassOrInterfaceType cit)
                                ? cit.getNameWithScope() : p.getType().toString();
                        textualFq = AstUtils.textualToOrigFq(textual, classMap);
                        break;
                    }
                }
            }
            if (textualFq == null) {
                Optional<ClassOrInterfaceDeclaration> encClass = ne.findAncestor(ClassOrInterfaceDeclaration.class);
                if (encClass.isPresent()) {
                    outer:
                    for (FieldDeclaration fd : encClass.get().getFields()) {
                        for (VariableDeclarator vd : fd.getVariables()) {
                            if (vd.getNameAsString().equals(varName)) {
                                String textual = (vd.getType() instanceof ClassOrInterfaceType cit)
                                        ? cit.getNameWithScope() : vd.getType().toString();
                                textualFq = AstUtils.textualToOrigFq(textual, classMap);
                                break outer;
                            }
                        }
                    }
                }
            }
            if (textualFq != null && !AstUtils.isInfrastructureFq(textualFq)) {
                String newId = searchMethodMap(textualFq, identifier);
                if (newId != null) { mre.setIdentifier(newId); return; }
            }
        }

        // Tier 4: unique-name fallback (project-wide unambiguous)
        List<String> candidates = methodMap.entrySet().stream()
                .filter(e -> {
                    String k = e.getKey().key;
                    int hash = k.indexOf('#');
                    String withoutParams = hash >= 0 ? k.substring(0, hash) : k;
                    int dot = withoutParams.lastIndexOf('.');
                    return (dot >= 0 ? withoutParams.substring(dot + 1) : withoutParams).equals(identifier);
                })
                .map(Map.Entry::getValue).distinct().collect(Collectors.toList());
        if (candidates.size() == 1) mre.setIdentifier(candidates.get(0));
    }

    private String searchMethodMap(String typeFq, String methodName) {
        String prefix = typeFq + "." + methodName + "#(";
        List<String> hits = methodMap.entrySet().stream()
                .filter(e -> e.getKey().key.startsWith(prefix))
                .map(Map.Entry::getValue).distinct().collect(Collectors.toList());
        if (!hits.isEmpty()) return hits.get(0);

        // Reverse-map through classMap in case solver returned an obfuscated name
        String simpleCandidate = typeFq.contains(".") ? typeFq.substring(typeFq.lastIndexOf('.') + 1) : typeFq;
        Optional<String> maybeOrig = classMap.entrySet().stream()
                .filter(e -> e.getValue().equals(simpleCandidate)).map(Map.Entry::getKey).findFirst();
        if (maybeOrig.isPresent()) {
            String revPrefix = maybeOrig.get() + "." + methodName + "#(";
            hits = methodMap.entrySet().stream()
                    .filter(e -> e.getKey().key.startsWith(revPrefix))
                    .map(Map.Entry::getValue).distinct().collect(Collectors.toList());
            if (!hits.isEmpty()) return hits.get(0);
        }
        return null;
    }

    private void renameFieldAccessExprFallback(FieldAccessExpr fae) {
        // Walk to rightmost identifier
        String rightMost = null;
        Expression cur = fae;
        while (cur instanceof FieldAccessExpr fe) {
            rightMost = fe.getNameAsString();
            if (fe.getScope() instanceof NameExpr) break;
            cur = fe.getScope();
        }
        if (rightMost == null) return;
        String mapped = flatFieldRenames.get(rightMost);
        if (mapped != null) fae.setName(mapped);
    }
}
