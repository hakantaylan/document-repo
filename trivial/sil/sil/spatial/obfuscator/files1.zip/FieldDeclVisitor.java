package com.example.obfuscator.obf;

import com.example.obfuscator.RenameContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;

import java.util.Map;

/**
 * V3a — renames field <em>declarations</em> only.
 *
 * <p>Must run as a separate pass from {@link FieldUsageVisitor} (V3b) because the
 * symbol solver is configured against the original files on disk.  If declarations
 * were renamed in the same pass as usages, V3b's {@code ne.resolve()} calls would
 * try to look up the original name in a declaration that has already been mutated,
 * causing mismatches.  By splitting them, V3b can still find the original name on
 * disk while the in-memory AST already has the new declaration name.
 */
public class FieldDeclVisitor extends ModifierVisitor<Void> {

    private final Map<String, String>             fieldMap;
    private final Map<TypeDeclaration<?>, String> typeOrigFq;

    public FieldDeclVisitor(RenameContext ctx, Map<TypeDeclaration<?>, String> typeOrigFq) {
        this.fieldMap   = ctx.fieldMap;
        this.typeOrigFq = typeOrigFq;
    }

    @Override
    public Visitable visit(FieldDeclaration fd, Void arg) {
        fd.findAncestor(TypeDeclaration.class).ifPresent(owner -> {
            String fq = typeOrigFq.get(owner);
            if (fq == null) return;
            for (VariableDeclarator vd : fd.getVariables()) {
                String key = fq + "|" + vd.getNameAsString();
                if (fieldMap.containsKey(key)) vd.setName(fieldMap.get(key));
            }
        });
        return super.visit(fd, arg);
    }
}
