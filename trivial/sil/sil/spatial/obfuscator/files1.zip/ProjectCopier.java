package com.example.obfuscator;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * File-system operations used by both the obfuscator and deobfuscator:
 * copying a project tree and relocating {@code .java} files after renaming.
 */
public final class ProjectCopier {

    private static final Set<String> SKIP_DIRS = Set.of("target", "build");

    private ProjectCopier() {}

    /**
     * Recursively copies {@code src} to {@code dst}, skipping any directory named
     * {@code target} or {@code build}.
     */
    public static void copyTree(Path src, Path dst) throws IOException {
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path d, BasicFileAttributes a) throws IOException {
                for (Path s : src.relativize(d))
                    if (SKIP_DIRS.contains(s.toString())) return FileVisitResult.SKIP_SUBTREE;
                Files.createDirectories(dst.resolve(src.relativize(d)));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException {
                Path rel = src.relativize(f);
                for (Path s : rel)
                    if (SKIP_DIRS.contains(s.toString())) return FileVisitResult.CONTINUE;
                Files.copy(f, dst.resolve(rel));
                return FileVisitResult.CONTINUE;
            }
        });
    }

    /**
     * Renames every {@code .java} file under {@code srcRoot} so its file name
     * matches the primary public type declared inside it.
     *
     * <p>Used by the deobfuscator after class names have been restored to move
     * e.g. {@code LilyFox17Service.java} → {@code FruitService.java}.
     */
    public static void relocateJavaFiles(Path srcRoot, JavaParser parser) {
        List<Path> files;
        try (var s = Files.walk(srcRoot)) {
            files = s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException("Cannot walk " + srcRoot, e);
        }
        for (Path fp : files) {
            try {
                var res = parser.parse(fp);
                if (!res.isSuccessful() || res.getResult().isEmpty()) continue;
                CompilationUnit cu = res.getResult().get();
                if (cu.getTypes().isEmpty()) continue;
                String simple = cu.getTypes().get(0).getNameAsString();
                String pkg    = cu.getPackageDeclaration()
                        .map(PackageDeclaration::getNameAsString).orElse("");
                Path dir    = pkg.isBlank() ? srcRoot : srcRoot.resolve(pkg.replace('.', '/'));
                Path target = dir.resolve(simple + ".java");
                Files.createDirectories(dir);
                if (!fp.toAbsolutePath().normalize().equals(target.toAbsolutePath().normalize())) {
                    Files.deleteIfExists(target);
                    Files.move(fp, target);
                }
            } catch (Throwable t) {
                System.err.println("Relocate failed: " + fp + " — " + t.getMessage());
            }
        }
    }
}
