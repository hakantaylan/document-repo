package com.example.obfuscator;

import com.example.obfuscator.RenameContext.MethodKey;
import com.example.obfuscator.obf.*;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.printer.configuration.PrettyPrinterConfiguration;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.*;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Source-level Java obfuscator — entry point and pass orchestrator.
 *
 * <pre>
 * ┌─────────────────────────┬────────────┬──────────────┬────────────────────────────────────┐
 * │ Class type              │ Class name │ Fields       │ Methods                            │
 * ├─────────────────────────┼────────────┼──────────────┼────────────────────────────────────┤
 * │ Entity                  │ YES        │ YES *        │ NO (JPA hooks, Lombok getters)     │
 * │ DTO / ResponseDto        │ YES        │ YES *        │ NO (Lombok generated)              │
 * │ Enum                    │ YES        │ YES *        │ NO (enum constants kept)           │
 * │ Repository              │ YES        │ YES *        │ NO (Spring Data query derivation)  │
 * │ Service                 │ YES        │ YES *        │ YES (non-framework, any visibility)│
 * │ Specification(s)        │ YES        │ YES *        │ YES (non-framework)                │
 * │ Utility / other         │ YES        │ YES *        │ YES (non-framework)                │
 * │ Controller / Ctrl       │ YES        │ YES *        │ NO  (Spring MVC endpoints)         │
 * │ Mapper                  │ YES        │ YES *        │ NO  (MapStruct / interface)        │
 * ├─────────────────────────┴────────────┴──────────────┴────────────────────────────────────┤
 * │ * Fields: skip when FIELD_BLOCKED_ANNOTATIONS present, public, static+final,            │
 * │   ALL_CAPS, blacklisted name, or inside an interface.                                   │
 * └─────────────────────────────────────────────────────────────────────────────────────────┘
 * </pre>
 *
 * <p>Passes:
 * <ol>
 *   <li>Collect class renames + superclass hierarchy.</li>
 *   <li>Collect method renames.</li>
 *   <li>Collect field renames + build flat-field map.</li>
 *   <li>Apply all renames via six visitors per compilation unit.</li>
 *   <li>Write {@code mapping.json} and {@code obfuscation-mapping.txt}.</li>
 * </ol>
 */
public class ObfuscatorMain {

    private final RenameContext ctx   = new RenameContext();
    private final Path projectRoot;
    private final Path obfRoot;
    private final Path srcRoot;

    public ObfuscatorMain(Path projectRoot) {
        this.projectRoot = projectRoot.toAbsolutePath().normalize();
        this.obfRoot     = projectRoot.resolveSibling(projectRoot.getFileName() + "-obf");
        this.srcRoot     = obfRoot.resolve("src/main/java");
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) { System.err.println("Usage: ObfuscatorMain <project-root>"); System.exit(2); }
        ObfuscatorMain o = new ObfuscatorMain(Paths.get(args[0]));
        o.copyProject();
        o.runObfuscation();
        System.out.println("Done. Output: " + o.obfRoot);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Step 1 — copy project
    // ─────────────────────────────────────────────────────────────────────────────

    private void copyProject() throws IOException {
        if (Files.exists(obfRoot)) { System.err.println("Already exists: " + obfRoot); System.exit(3); }
        System.out.println("Copying " + projectRoot + " → " + obfRoot);
        ProjectCopier.copyTree(projectRoot, obfRoot);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Step 2 — main pipeline
    // ─────────────────────────────────────────────────────────────────────────────

    private void runObfuscation() throws IOException {
        List<Path> javaFiles;
        try (Stream<Path> s = Files.walk(srcRoot)) {
            javaFiles = s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        }
        if (javaFiles.isEmpty()) { System.err.println("No .java files under " + srcRoot); return; }

        // ── Parser + symbol solver ────────────────────────────────────────────────
        final CombinedTypeSolver solver = new CombinedTypeSolver();
        solver.add(new ReflectionTypeSolver(false));
        solver.add(new JavaParserTypeSolver(srcRoot.toFile()));
        JavaParser parser = new JavaParser(
                new ParserConfiguration().setSymbolResolver(new JavaSymbolSolver(solver)));

        // ── Parse all CUs ─────────────────────────────────────────────────────────
        Map<Path, CompilationUnit> units = new LinkedHashMap<>();
        for (Path p : javaFiles) {
            var r = parser.parse(p);
            if (r.isSuccessful() && r.getResult().isPresent()) {
                units.put(p, r.getResult().get());
            } else {
                System.err.println("Parse failed: " + p);
                r.getProblems().forEach(pr -> System.err.println("  " + pr));
                throw new IllegalStateException("Parse failed: " + p);
            }
        }

        // ── PRE-PASS: snapshot TypeDeclaration → original FQ (before any mutation) ─
        Map<TypeDeclaration<?>, String> typeOrigFq = new IdentityHashMap<>();
        Map<Path, String> topOrigFq = new LinkedHashMap<>();
        for (var en : units.entrySet()) {
            CompilationUnit cu  = en.getValue();
            String pkg = cu.getPackageDeclaration().map(PackageDeclaration::getNameAsString).orElse("");
            for (TypeDeclaration<?> td : cu.findAll(TypeDeclaration.class))
                typeOrigFq.put(td, AstUtils.computeFq(td, cu));
            cu.getTypes().stream().findFirst().ifPresent(td ->
                    topOrigFq.put(en.getKey(), pkg.isEmpty() ? td.getNameAsString() : pkg + "." + td.getNameAsString()));
        }

        // ── PASS 1: collect class renames + superclass hierarchy ──────────────────
        for (var en : units.entrySet()) {
            CompilationUnit cu  = en.getValue();
            String pkg = cu.getPackageDeclaration().map(PackageDeclaration::getNameAsString).orElse("");
            if (AstUtils.excludePkg(pkg)) continue;
            for (TypeDeclaration<?> td : cu.getTypes()) {
                if (!td.isTopLevelType()) continue;
                String fq = typeOrigFq.get(td);
                if (fq == null || ctx.classMap.containsKey(fq)) continue;

                String oldSimple = td.getNameAsString();
                String newSimple = proposeClassName(oldSimple);
                ctx.classMap.put(fq, newSimple);
                System.out.println("[class]  " + fq + " → " + newSimple);

                if (ObfuscationRules.isEntity(td, pkg))
                    ctx.metamodelMap.put(oldSimple + "_", newSimple + "_");

                collectSuperclass(td, fq, typeOrigFq);
            }
        }

        // ── PASS 2: collect method renames ────────────────────────────────────────
        for (var en : units.entrySet()) {
            CompilationUnit cu = en.getValue();
            if (AstUtils.excludePkg(cu.getPackageDeclaration().map(PackageDeclaration::getNameAsString).orElse(""))) continue;
            for (MethodDeclaration md : cu.findAll(MethodDeclaration.class)) {
                if (!ObfuscationRules.shouldRenameMethod(md)) continue;
                try {
                    ResolvedMethodDeclaration rmd = md.resolve();
                    String key = AstUtils.methodKey(rmd);
                    if (!ctx.methodMap.containsKey(new MethodKey(key))) {
                        String newName = ctx.nameGen.nextMethodName();
                        ctx.methodMap.put(new MethodKey(key), newName);
                        System.out.println("[method] " + key + " → " + newName);
                    }
                } catch (Throwable ignored) {}
            }
        }

        // ── PASS 3: collect field renames ─────────────────────────────────────────
        for (var en : units.entrySet()) {
            CompilationUnit cu = en.getValue();
            if (AstUtils.excludePkg(cu.getPackageDeclaration().map(PackageDeclaration::getNameAsString).orElse(""))) continue;
            for (TypeDeclaration<?> td : cu.findAll(TypeDeclaration.class)) {
                String origFq = typeOrigFq.get(td);
                if (origFq == null) continue;
                for (FieldDeclaration fd : td.getFields()) {
                    if (!ObfuscationRules.shouldRenameField(fd)) continue;
                    for (VariableDeclarator vd : fd.getVariables()) {
                        String origName = vd.getNameAsString();
                        String key = origFq + "|" + origName;
                        if (!ctx.fieldMap.containsKey(key)) {
                            String newName = ctx.nameGen.nextFieldName();
                            ctx.fieldMap.put(key, newName);
                            ctx.typeOrigFields.computeIfAbsent(origFq, k -> new HashSet<>()).add(origName);
                            ctx.allRenamedOrigFieldNames.add(origName);
                            System.out.println("[field]  " + key + " → " + newName);
                        }
                    }
                }
            }
        }
        ctx.buildFlatFieldRenames();

        // ── PASS 4: apply all renames ─────────────────────────────────────────────
        for (var en : units.entrySet()) {
            Path srcPath = en.getKey();
            CompilationUnit cu = en.getValue();

            cu.accept(new ClassRenameVisitor(ctx, typeOrigFq), null);
            cu.accept(new MethodRenameVisitor(ctx), null);
            cu.accept(new FieldDeclVisitor(ctx, typeOrigFq), null);
            cu.accept(new FieldUsageVisitor(ctx, typeOrigFq), null);
            cu.accept(new BuilderChainVisitor(ctx, solver), null);
            cu.accept(new AccessorVisitor(ctx), null);

            // Write file — rename .java if the top-level class was renamed
            String origFq = topOrigFq.get(srcPath);
            Path target = srcPath;
            if (origFq != null && ctx.classMap.containsKey(origFq)) {
                Path np = srcPath.resolveSibling(ctx.classMap.get(origFq) + ".java");
                if (!np.equals(srcPath)) Files.deleteIfExists(srcPath);
                target = np;
            }
            Files.createDirectories(target.getParent());
            try (BufferedWriter w = Files.newBufferedWriter(target)) {
                w.write(cu.toString(new PrettyPrinterConfiguration()));
            }
        }

        // ── PASS 5: write mapping ─────────────────────────────────────────────────
        MappingStore.write(ctx, obfRoot, projectRoot, topOrigFq);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────────

    private String proposeClassName(String oldSimple) {
        for (String s : ObfuscationRules.PRESERVE_SUFFIXES)
            if (oldSimple.endsWith(s)) return ctx.nameGen.nextClassBase() + s;
        return ctx.nameGen.nextClassName();
    }

    private void collectSuperclass(TypeDeclaration<?> td, String fq,
                                   Map<TypeDeclaration<?>, String> typeOrigFq) {
        if (!(td instanceof ClassOrInterfaceDeclaration cid) || cid.isInterface()) return;
        for (ClassOrInterfaceType extType : cid.getExtendedTypes()) {
            try {
                String parentFq = extType.resolve().asReferenceType().getQualifiedName();
                if (!AstUtils.excludePkg(parentFq.contains(".")
                        ? parentFq.substring(0, parentFq.lastIndexOf('.')) : "")) {
                    ctx.superclassMap.put(fq, parentFq);
                    System.out.println("[super]  " + fq + " → " + parentFq);
                }
            } catch (Throwable ignored) {
                // Textual fallback
                String extSimple = extType.getNameAsString();
                int lt = extSimple.indexOf('<');
                if (lt > 0) extSimple = extSimple.substring(0, lt);
                final String extS = extSimple;
                typeOrigFq.values().stream()
                        .filter(p -> p.endsWith("." + extS) || p.equals(extS))
                        .findFirst()
                        .ifPresent(parentFq -> {
                            ctx.superclassMap.put(fq, parentFq);
                            System.out.println("[super]  " + fq + " → " + parentFq + " (textual)");
                        });
            }
        }
    }
}
