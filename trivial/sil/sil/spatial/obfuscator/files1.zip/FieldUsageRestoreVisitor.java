package com.example.obfuscator.deobf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.DeobfuscatorMain.DeobfContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;

import java.util.Map;
import java.util.Optional;

/**
 * Phase 1c — restores field <em>usage</em> sites:
 * {@link FieldAccessExpr}, bare {@link NameExpr}, method-reference scopes,
 * and Lombok {@code @Builder} chain setter calls.
 *
 * <p>Three-tier lookup for every name:
 * <ol>
 *   <li>Symbol resolution → exact {@code declaringType|fieldName} key.</li>
 *   <li>Name is a known obfuscated field → enclosing-type hierarchy lookup then
 *       flat {@code newFieldToOrig} map.</li>
 *   <li>Class / metamodel simple-name fallback.</li>
 * </ol>
 *
 * <p>Method-reference scopes (e.g. {@code fLily98} in {@code fLily98::toDtoBase})
 * are handled by the explicit {@link #visit(MethodReferenceExpr, Void)} override,
 * which works regardless of whether the scope is a {@link NameExpr} or
 * {@link TypeExpr} (the node type JavaParser uses for interface-typed fields
 * such as MapStruct mappers).
 */
public class FieldUsageRestoreVisitor extends ModifierVisitor<Void> {

    private final DeobfContext                    dctx;
    private final Map<TypeDeclaration<?>, String> typeObfFq;

    public FieldUsageRestoreVisitor(DeobfContext dctx, Map<TypeDeclaration<?>, String> typeObfFq) {
        this.dctx     = dctx;
        this.typeObfFq = typeObfFq;
    }

    // ── FieldAccessExpr ───────────────────────────────────────────────────────────

    @Override
    public Visitable visit(FieldAccessExpr fae, Void arg) {
        String obfName = fae.getNameAsString();

        // Tier 1: symbol resolution
        try {
            ResolvedValueDeclaration rvd = fae.resolve();
            if (rvd.isField()) {
                String orig = dctx.fieldInHierarchy(
                        rvd.asField().declaringType().getQualifiedName(), obfName);
                if (orig != null) { fae.setName(orig); return super.visit(fae, arg); }
            }
        } catch (Throwable ignored) {}

        // Tier 2: metamodel access (e.g. ObfFruit_.fRose3 → Fruit_.name)
        if (dctx.allNewFieldNames.contains(obfName)) {
            Expression scope = fae.getScope();
            if (scope instanceof NameExpr ne) {
                String sn = ne.getNameAsString();
                if (sn.endsWith("_") || dctx.metamodelRev.containsKey(sn) || dctx.metamodelRev.containsValue(sn)) {
                    String orig = dctx.newFieldToOrig.get(obfName);
                    if (orig != null) { fae.setName(orig); return super.visit(fae, arg); }
                }
            }
        }

        // Tier 3: flat fallback
        String orig = dctx.newFieldToOrig.get(obfName);
        if (orig != null) fae.setName(orig);
        return super.visit(fae, arg);
    }

    // ── NameExpr ─────────────────────────────────────────────────────────────────

    @Override
    public Visitable visit(NameExpr ne, Void arg) {
        String s = ne.getNameAsString();

        // Tier 1: symbol resolution
        try {
            ResolvedValueDeclaration rvd = ne.resolve();
            if (rvd.isField()) {
                String orig = dctx.fieldInHierarchy(
                        rvd.asField().declaringType().getQualifiedName(), s);
                if (orig != null) { ne.setName(orig); return super.visit(ne, arg); }
            }
            // Resolved as non-field — only skip Tier 2 when not a known obf field name
            // (solver may misclassify MRE scope nodes)
            if (!dctx.allNewFieldNames.contains(s)) return super.visit(ne, arg);
        } catch (Throwable ignored) {}

        // Tier 2: known obfuscated field name
        if (dctx.allNewFieldNames.contains(s)) {
            String orig = ne.findAncestor(TypeDeclaration.class)
                    .map(td -> typeObfFq.get(td))
                    .map(fq -> dctx.fieldInHierarchy(fq, s))
                    .orElse(null);
            if (orig == null) orig = dctx.newFieldToOrig.get(s);
            if (orig != null) { ne.setName(orig); return super.visit(ne, arg); }
        }

        // Class / metamodel fallback
        if (dctx.newSimpleToOrig.containsKey(s))  ne.setName(dctx.newSimpleToOrig.get(s));
        else if (dctx.metamodelRev.containsKey(s)) ne.setName(dctx.metamodelRev.get(s));
        return super.visit(ne, arg);
    }

    // ── MethodReferenceExpr scope ─────────────────────────────────────────────────

    /**
     * Restores the scope of a method reference (e.g. {@code fLily98} in
     * {@code fLily98::toDtoBase}).
     *
     * <p>Mirrors {@link com.example.obfuscator.obf.FieldUsageVisitor}'s MRE override
     * exactly: calls {@code super.visit} first so children are processed, then applies
     * an unconditional field-map lookup that handles both {@link NameExpr} and
     * {@link TypeExpr} scopes.
     */
    @Override
    public Visitable visit(MethodReferenceExpr mre, Void arg) {
        Visitable result = super.visit(mre, arg); // children first
        if (!(result instanceof MethodReferenceExpr mre2)) return result;

        Expression sc = mre2.getScope();
        String scopeName = AstUtils.mreSimpleScopeName(sc);
        if (scopeName == null || !dctx.allNewFieldNames.contains(scopeName)) return result;
        if (sc instanceof NameExpr ne3 && AstUtils.isDeclaredAsLocalOrParameter(ne3, scopeName))
            return result;

        // Hierarchy-aware lookup: enclosing type first, then flat map
        String orig = mre2.findAncestor(TypeDeclaration.class)
                .map(td -> typeObfFq.get(td))
                .map(fq -> dctx.fieldInHierarchy(fq, scopeName))
                .orElse(null);
        if (orig == null) orig = dctx.newFieldToOrig.get(scopeName);

        if (orig != null) {
            if (sc instanceof NameExpr ne4)  ne4.setName(orig);
            else if (sc instanceof TypeExpr) mre2.setScope(new NameExpr(orig));
        }
        return result;
    }

    // ── Builder-chain setter calls ────────────────────────────────────────────────

    /**
     * Restores Lombok builder chain setters (e.g. {@code .fRose3("x") → .name("x")}).
     * Only fires when the call cannot be resolved by the symbol solver (Lombok-generated)
     * AND the builder owner can be positively identified by walking the scope chain.
     */
    @Override
    public Visitable visit(MethodCallExpr mce, Void arg) {
        Visitable result = super.visit(mce, arg);
        if (!(result instanceof MethodCallExpr call)) return result;
        String callName = call.getNameAsString();
        if (!dctx.allNewFieldNames.contains(callName)) return result;
        try { call.resolve(); return result; } catch (Throwable ignored) {}

        String ownerObfFq = resolveBuilderOwner(call);
        if (ownerObfFq == null) return result;

        String orig = dctx.fieldInHierarchy(ownerObfFq, callName);
        if (orig != null) { call.setName(orig); return call; }
        return result;
    }

    // ── Builder owner resolution ──────────────────────────────────────────────────

    private String resolveBuilderOwner(MethodCallExpr mce) {
        Optional<Expression> scopeOpt = mce.getScope();
        while (scopeOpt.isPresent()) {
            Expression scope = scopeOpt.get();
            if (scope instanceof MethodCallExpr sc) {
                if ("builder".equals(sc.getNameAsString()))
                    return resolveBuilderClass(sc.getScope().orElse(null));
                scopeOpt = sc.getScope();
            } else break;
        }
        return null;
    }

    private String resolveBuilderClass(Expression scopeExpr) {
        if (scopeExpr == null) return null;
        if (!(scopeExpr instanceof NameExpr ne)) return null;
        String name = ne.getNameAsString();
        final String n = name;
        // Case A: obfuscated simple name
        Optional<String> hit = dctx.obfFqToOrig.keySet().stream()
                .filter(fq -> fq.endsWith("." + n) || fq.equals(n)).findFirst();
        if (hit.isPresent()) return hit.get();
        // Case B: original simple name (Phase 1a already ran)
        return dctx.obfFqToOrig.keySet().stream()
                .filter(fq -> {
                    String obfSimple = fq.substring(fq.lastIndexOf('.') + 1);
                    return dctx.newSimpleToOrig.getOrDefault(obfSimple, "").equals(n);
                })
                .findFirst().orElse(null);
    }
}
