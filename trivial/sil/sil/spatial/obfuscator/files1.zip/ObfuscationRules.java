package com.example.obfuscator;

import com.github.javaparser.ast.AccessSpecifier;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.AnnotationExpr;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * All obfuscation policy decisions: which classes, methods and fields may be renamed,
 * and which suffixes / annotations act as guards.  Pure static logic — no state.
 */
public final class ObfuscationRules {

    private ObfuscationRules() {}

    // ── Class suffix rules ────────────────────────────────────────────────────────

    /** Suffixes whose simple name must be preserved verbatim after the generated base. */
    public static final List<String> PRESERVE_SUFFIXES = List.of(
            "Controller", "Ctrl",
            "Repository",
            "Service",
            "Mapper",
            "Dto", "DTO", "ResponseDto",
            "Entity",
            "Specification", "Specifications",
            "Application", "DataInitializer"
    );

    // ── Method rename rules ───────────────────────────────────────────────────────

    /** Rename ALL non-framework methods in classes whose name ends with one of these. */
    public static final Set<String> METHOD_RENAME_SUFFIXES = Set.of(
            "Service", "Specification", "Specifications"
    );

    /** Never rename methods in classes whose name ends with one of these. */
    public static final Set<String> METHOD_NO_RENAME_SUFFIXES = Set.of(
            "Repository", "Controller", "Ctrl", "Mapper",
            "Dto", "DTO", "ResponseDto", "Entity",
            "Application", "DataInitializer"
    );

    /** Class-level annotations that forbid renaming any method on the class. */
    public static final Set<String> CLASS_NO_METHOD_RENAME_ANNOTATIONS = Set.of(
            "Repository", "Controller", "RestController", "Mapper"
    );

    /** Method-level annotations that always block renaming that specific method. */
    public static final Set<String> METHOD_BLOCKED_ANNOTATIONS = Set.of(
            "GetMapping", "PostMapping", "PutMapping", "DeleteMapping", "PatchMapping",
            "RequestMapping", "ExceptionHandler", "ResponseBody", "ResponseStatus",
            "Bean", "PostConstruct", "PreDestroy", "EventListener", "Scheduled", "Async",
            "Transactional",
            "PreAuthorize", "PostAuthorize", "Secured", "RolesAllowed",
            "PrePersist", "PostPersist", "PreUpdate", "PostUpdate",
            "PreRemove", "PostRemove", "PostLoad",
            "Override",
            "Test", "Before", "After", "BeforeEach", "AfterEach", "BeforeAll", "AfterAll",
            "ParameterizedTest"
    );

    // ── Field rename rules ────────────────────────────────────────────────────────

    /**
     * Field-level annotations that BLOCK renaming.
     * Validation / Swagger annotations (@NotNull, @Schema …) are intentionally excluded.
     */
    public static final Set<String> FIELD_BLOCKED_ANNOTATIONS = Set.of(
            "Id", "GeneratedValue", "Column", "JoinColumn", "JoinTable",
            "OneToOne", "OneToMany", "ManyToOne", "ManyToMany",
            "Embedded", "EmbeddedId", "Transient", "Lob",
            "ElementCollection", "CollectionTable", "AttributeOverride",
            "Version", "CreatedDate", "LastModifiedDate", "CreatedBy", "LastModifiedBy",
            "Autowired", "Inject", "Resource", "Value", "Qualifier",
            "Getter", "Setter", "Builder", "With",
            "JsonIgnore", "JsonProperty", "JsonAlias",
            "Mapping", "Mappings"
    );

    /** Field names that must never be renamed regardless of other rules. */
    public static final Set<String> FIELD_NAME_BLACKLIST = Set.of(
            "serialVersionUID",
            "log", "logger", "LOGGER", "LOG",
            "id",
            "createdAt", "updatedAt", "createdDate", "updatedDate",
            "version"
    );

    // ── Decision methods ──────────────────────────────────────────────────────────

    /**
     * Full decision tree for whether a method declaration should be renamed.
     *
     * <pre>
     * 1. Has blocked method annotation           → NO
     * 2. Declared inside an interface            → NO
     * 3. Owner has blocked class annotation      → NO
     * 4. Owner name ends with no-rename suffix   → NO
     * 5. Owner name ends with yes-rename suffix  → YES
     * 6. Utility / helper class                  → YES
     * 7. Fallback: private method only           → YES
     * </pre>
     */
    public static boolean shouldRenameMethod(MethodDeclaration md) {
        for (AnnotationExpr ann : md.getAnnotations())
            if (METHOD_BLOCKED_ANNOTATIONS.contains(ann.getNameAsString())) return false;

        if (md.findAncestor(ClassOrInterfaceDeclaration.class)
                .map(ClassOrInterfaceDeclaration::isInterface).orElse(false)) return false;

        Optional<ClassOrInterfaceDeclaration> ownerOpt =
                md.findAncestor(ClassOrInterfaceDeclaration.class);
        String ownerSimple = ownerOpt.map(ClassOrInterfaceDeclaration::getNameAsString).orElse("");

        if (ownerOpt.map(o -> o.getAnnotations().stream()
                .anyMatch(a -> CLASS_NO_METHOD_RENAME_ANNOTATIONS.contains(a.getNameAsString())))
                .orElse(false)) return false;

        for (String s : METHOD_NO_RENAME_SUFFIXES) if (ownerSimple.endsWith(s)) return false;
        for (String s : METHOD_RENAME_SUFFIXES)    if (ownerSimple.endsWith(s)) return true;
        if (isUtilityOwner(ownerOpt)) return true;

        try {
            return md.resolve().accessSpecifier() == AccessSpecifier.PRIVATE;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Returns true when a field declaration is eligible for renaming.
     * Fields are blocked when: public, static+final, ALL_CAPS, blacklisted name,
     * inside an interface, or carrying a blocked annotation.
     */
    public static boolean shouldRenameField(FieldDeclaration fd) {
        if (fd.isPublic()) return false;
        if (fd.isStatic() && fd.isFinal()) return false;
        if (fd.findAncestor(ClassOrInterfaceDeclaration.class)
                .map(ClassOrInterfaceDeclaration::isInterface).orElse(false)) return false;
        for (VariableDeclarator vd : fd.getVariables()) {
            String n = vd.getNameAsString();
            if (FIELD_NAME_BLACKLIST.contains(n)) return false;
            if (n.length() > 1 && n.equals(n.toUpperCase())) return false;
        }
        for (AnnotationExpr ann : fd.getAnnotations())
            if (FIELD_BLOCKED_ANNOTATIONS.contains(ann.getNameAsString())) return false;
        return true;
    }

    /** Returns true when a type declaration belongs to an entity package or has @Entity. */
    public static boolean isEntity(TypeDeclaration<?> td, String pkg) {
        return td.getAnnotationByName("Entity").isPresent()
                || (pkg != null && pkg.endsWith(".entity"));
    }

    // ── Private helpers ───────────────────────────────────────────────────────────

    private static boolean isUtilityOwner(Optional<ClassOrInterfaceDeclaration> ownerOpt) {
        return ownerOpt.map(cid -> {
            String name = cid.getNameAsString();
            for (String s : PRESERVE_SUFFIXES) if (name.endsWith(s)) return false;
            if (cid.getAnnotationByName("Entity").isPresent()) return false;
            Set<String> springManaged = Set.of(
                    "Component", "Configuration", "Service", "Repository",
                    "Controller", "RestController", "Bean");
            return cid.getAnnotations().stream()
                    .noneMatch(a -> springManaged.contains(a.getNameAsString()));
        }).orElse(false);
    }
}
