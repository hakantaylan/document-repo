package com.example.obfuscator.obf;

import com.example.obfuscator.RenameContext;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * V1 — renames class / interface / enum declarations, constructor names,
 * import statements, and all type-reference sites (field types, return types,
 * parameters, generic bounds, object-creation expressions, class literals).
 */
public class ClassRenameVisitor extends ModifierVisitor<Void> {

    private final Map<String, String> classMap;
    private final Map<String, String> metamodelMap;
    private final Map<TypeDeclaration<?>, String> typeOrigFq;

    public ClassRenameVisitor(RenameContext ctx, Map<TypeDeclaration<?>, String> typeOrigFq) {
        this.classMap    = ctx.classMap;
        this.metamodelMap = ctx.metamodelMap;
        this.typeOrigFq  = typeOrigFq;
    }

    @Override
    public Node visit(ImportDeclaration id, Void arg) {
        String name = id.getNameAsString();
        if (classMap.containsKey(name)) {
            id.setName(rebuildFq(name, classMap.get(name)));
            return super.visit(id, arg);
        }
        for (var e : classMap.entrySet()) {
            if (name.equals(e.getKey())) {
                id.setName(rebuildFq(e.getKey(), e.getValue()));
                break;
            }
        }
        return super.visit(id, arg);
    }

    @Override
    public Visitable visit(ClassOrInterfaceType cit, Void arg) {
        try {
            String fq = cit.resolve().asReferenceType().getQualifiedName();
            if (classMap.containsKey(fq)) cit.setName(classMap.get(fq));
        } catch (Throwable ignored) {
            String s = cit.getNameAsString();
            if (metamodelMap.containsKey(s)) cit.setName(metamodelMap.get(s));
            else classMap.entrySet().stream()
                    .filter(e -> e.getKey().endsWith("." + s))
                    .findFirst()
                    .ifPresent(e -> cit.setName(e.getValue()));
        }
        return super.visit(cit, arg);
    }

    @Override
    public Visitable visit(ClassExpr ce, Void arg) {
        if (ce.getType().isClassOrInterfaceType()) {
            ClassOrInterfaceType cit = ce.getType().asClassOrInterfaceType();
            try {
                String fq = cit.resolve().asReferenceType().getQualifiedName();
                if (classMap.containsKey(fq)) cit.setName(classMap.get(fq));
            } catch (Throwable ignored) {
                classMap.entrySet().stream()
                        .filter(e -> e.getKey().endsWith("." + cit.getNameAsString()))
                        .findFirst().ifPresent(e -> cit.setName(e.getValue()));
            }
        }
        return super.visit(ce, arg);
    }

    @Override
    public Visitable visit(ObjectCreationExpr oce, Void arg) {
        oce.getType().ifClassOrInterfaceType(cit -> {
            try {
                String fq = cit.resolve().asReferenceType().getQualifiedName();
                if (classMap.containsKey(fq)) cit.setName(classMap.get(fq));
            } catch (Throwable ignored) {
                classMap.entrySet().stream()
                        .filter(e -> e.getKey().endsWith("." + cit.getNameAsString()))
                        .findFirst().ifPresent(e -> cit.setName(e.getValue()));
            }
        });
        return super.visit(oce, arg);
    }

    @Override
    public Visitable visit(ConstructorDeclaration cd, Void arg) {
        if (cd.getParentNode().orElse(null) instanceof TypeDeclaration<?> owner) {
            String fq = typeOrigFq.get(owner);
            if (fq != null && classMap.containsKey(fq)) cd.setName(classMap.get(fq));
        }
        return super.visit(cd, arg);
    }

    @Override
    public Visitable visit(ClassOrInterfaceDeclaration cid, Void arg) {
        String fq = typeOrigFq.get(cid);
        if (fq != null && classMap.containsKey(fq)) cid.setName(classMap.get(fq));
        return super.visit(cid, arg);
    }

    @Override
    public Visitable visit(EnumDeclaration ed, Void arg) {
        String fq = typeOrigFq.get(ed);
        if (fq != null && classMap.containsKey(fq)) ed.setName(classMap.get(fq));
        return super.visit(ed, arg);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────────

    private static String rebuildFq(String origFq, String newSimple) {
        int dot = origFq.lastIndexOf('.');
        if (dot < 0) return newSimple;
        return origFq.substring(0, dot) + "." + newSimple;
    }
}
