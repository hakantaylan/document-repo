package com.example.obfuscator.deobf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.DeobfuscatorMain.DeobfContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;

import java.util.Map;
import java.util.Optional;

/**
 * Phase 1c (second visitor) — restores Lombok getter/setter and record-accessor
 * call names derived from obfuscated field names.
 *
 * <p>e.g. {@code criteria.getFPoppy71()} → {@code criteria.getName()}
 *
 * <p>Resolution strategy for the scope owner:
 * <ol>
 *   <li>Symbol solver — works for explicit getters and record accessors.</li>
 *   <li>Textual parameter lookup — handles Lombok getters on DTO parameters where
 *       the solver fails after Phase 1a has renamed the class.</li>
 *   <li>Textual field lookup — handles {@code this.someField.getXxx()} style calls.</li>
 * </ol>
 *
 * <p>Infrastructure types are never touched.  Only calls whose scope owner is a
 * positively-identified project type are renamed.
 */
public class AccessorRestoreVisitor extends ModifierVisitor<Void> {

    private final DeobfContext dctx;

    public AccessorRestoreVisitor(DeobfContext dctx) {
        this.dctx = dctx;
    }

    @Override
    public Visitable visit(MethodCallExpr mce, Void arg) {
        Visitable result = super.visit(mce, arg);
        if (!(result instanceof MethodCallExpr call)) return result;
        if (call.getScope().isEmpty()) return result;

        String methodName = call.getNameAsString();
        String prefix     = AstUtils.accessorPrefix(methodName);
        String obfField   = AstUtils.derivedFieldName(methodName, prefix);
        if (obfField == null) return result;
        if (!dctx.allNewFieldNames.contains(obfField)) return result;

        // 1) Resolve method directly (best case)
        String ownerObfFq = null;
        try {
            ResolvedMethodDeclaration rmd = call.resolve();
            String dt = rmd.declaringType().getQualifiedName();
            if (AstUtils.isInfrastructureFq(dt)) return result;
            ownerObfFq = dt;
        } catch (Throwable ignored) {
            // 2) Resolve scope type via solver + textual fallbacks
            ownerObfFq = resolveScopeOwner(call.getScope().get());
            if (ownerObfFq == null) return result;
            if (AstUtils.isInfrastructureFq(ownerObfFq)) return result;
            if (!dctx.isKnownProjectType(ownerObfFq)) return result;
        }

        // 3) Hierarchy-aware field lookup
        String origFieldName = dctx.fieldInHierarchy(ownerObfFq, obfField);
        if (origFieldName == null) return result;

        String newMethodName = prefix.isEmpty()
                ? origFieldName
                : prefix + Character.toUpperCase(origFieldName.charAt(0)) + origFieldName.substring(1);
        call.setName(newMethodName);
        return call;
    }

    // ── Scope owner resolution ────────────────────────────────────────────────────

    /**
     * Resolves the FQ type of the call's scope expression.
     * Tries the symbol solver first, then falls back to reading the declared type
     * from the AST (parameter list or field declaration) — necessary after Phase 1a
     * has already restored class names, which breaks the solver's ability to find them.
     */
    private String resolveScopeOwner(Expression scope) {
        // Tier 1: symbol solver
        String fq = AstUtils.resolveScopeTypeFq(scope);
        if (fq != null) return fq;

        // Tier 2: textual — parameter in enclosing callable
        if (scope instanceof NameExpr ne) {
            String varName = ne.getNameAsString();
            Optional<CallableDeclaration<?>> encCallable = ne.findAncestor(CallableDeclaration.class);
            if (encCallable.isPresent()) {
                NodeList<Parameter> params = encCallable.get().getParameters();
                for (Parameter p : params) {
                    if (p.getNameAsString().equals(varName)) {
                        String textual = (p.getType() instanceof ClassOrInterfaceType cit)
                                ? cit.getNameWithScope() : p.getType().toString();
                        fq = textualToObfOrOrigFq(textual);
                        if (fq != null) return fq;
                    }
                }
            }
            // Tier 3: textual — field in enclosing class
            Optional<ClassOrInterfaceDeclaration> encClass = ne.findAncestor(ClassOrInterfaceDeclaration.class);
            if (encClass.isPresent()) {
                for (FieldDeclaration fd : encClass.get().getFields()) {
                    for (VariableDeclarator vd : fd.getVariables()) {
                        if (vd.getNameAsString().equals(varName)) {
                            String textual = (vd.getType() instanceof ClassOrInterfaceType cit)
                                    ? cit.getNameWithScope() : vd.getType().toString();
                            return textualToObfOrOrigFq(textual);
                        }
                    }
                }
            }
        }

        // Tier 4: FieldAccessExpr — look up the rightmost field name
        if (scope instanceof FieldAccessExpr fae) {
            String fieldName = fae.getNameAsString();
            Optional<TypeDeclaration<?>> tdOpt = fae.findAncestor(TypeDeclaration.class);
            if (tdOpt.isPresent()) {
                for (FieldDeclaration fd : tdOpt.get().getFields()) {
                    for (VariableDeclarator vd : fd.getVariables()) {
                        if (vd.getNameAsString().equals(fieldName)) {
                            String textual = (vd.getType() instanceof ClassOrInterfaceType cit)
                                    ? cit.getNameWithScope() : vd.getType().toString();
                            return textualToObfOrOrigFq(textual);
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Maps a textual type name (possibly already restored to its original form by
     * Phase 1a, or still obfuscated) to the obfuscated FQ that is a key in
     * {@code obfFqToOrig}, so downstream {@code fieldByObfFq} lookups work correctly.
     */
    private String textualToObfOrOrigFq(String typeName) {
        if (typeName == null || typeName.isBlank()) return null;
        String t = typeName.strip();
        int lt = t.indexOf('<');
        if (lt > 0) t = t.substring(0, lt);
        final String qt = t;
        // Match against obfuscated FQ keys (name not yet restored)
        Optional<String> byObf = dctx.obfFqToOrig.keySet().stream()
                .filter(fq -> fq.equals(qt) || fq.endsWith("." + qt)).findFirst();
        if (byObf.isPresent()) return byObf.get();
        // Match against original FQ values (name already restored by Phase 1a)
        return dctx.obfFqToOrig.entrySet().stream()
                .filter(e -> {
                    String origFq = e.getValue();
                    return origFq.equals(qt) || origFq.endsWith("." + qt);
                })
                .map(Map.Entry::getKey)
                .findFirst().orElse(null);
    }
}
