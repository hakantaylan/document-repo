package com.example.obfuscator.deobf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.DeobfuscatorMain.DeobfContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;

import java.util.Map;
import java.util.Optional;

/**
 * Phase 2 — restores method declaration names, call sites, and method-reference
 * identifiers.  Runs after the relocation pass so the symbol solver can resolve
 * types by their restored original names.
 *
 * <p>Method-reference identifiers use a two-tier strategy:
 * <ol>
 *   <li>Symbol resolution (preferred).</li>
 *   <li>Scope-type resolution then {@code methodRev} prefix scan — handles cases
 *       where the solver cannot resolve the reference directly (e.g. MapStruct mappers).</li>
 * </ol>
 *
 * <p>Method-reference scopes (the field-typed part, e.g. {@code fruitMapper}) that
 * were not restored in Phase 1c are caught here as a safety net using
 * {@code newFieldToOrig}.
 */
public class MethodRestoreVisitor extends ModifierVisitor<Void> {

    private final DeobfContext dctx;

    public MethodRestoreVisitor(DeobfContext dctx) {
        this.dctx = dctx;
    }

    @Override
    public Visitable visit(MethodDeclaration md, Void arg) {
        try {
            ResolvedMethodDeclaration rmd = md.resolve();
            if (!AstUtils.isInfrastructureFq(rmd.declaringType().getQualifiedName())) {
                String orig = lookupMethod(rmd, md.getNameAsString());
                if (orig != null) md.setName(orig);
            }
        } catch (Throwable ignored) {}
        return super.visit(md, arg);
    }

    @Override
    public Visitable visit(MethodCallExpr mce, Void arg) {
        try {
            ResolvedMethodDeclaration rmd = mce.resolve();
            if (!AstUtils.isInfrastructureFq(rmd.declaringType().getQualifiedName())) {
                String orig = lookupMethod(rmd, mce.getNameAsString());
                if (orig != null) mce.setName(orig);
            }
        } catch (Throwable ignored) {}
        return super.visit(mce, arg);
    }

    @Override
    public Visitable visit(MethodReferenceExpr mre, Void arg) {
        // ── Part 1: restore the identifier ───────────────────────────────────────
        // Tier 1: symbol resolution
        try {
            ResolvedMethodDeclaration rmd = mre.resolve();
            if (!AstUtils.isInfrastructureFq(rmd.declaringType().getQualifiedName())) {
                String orig = lookupMethod(rmd, mre.getIdentifier());
                if (orig != null) mre.setIdentifier(orig);
            }
        } catch (Throwable ignored) {
            // Tier 2: scope-type resolution + methodRev scan
            String currentId = mre.getIdentifier();
            if (!"new".equals(currentId)) {
                String scopeOrigFq = resolveMethodRefScopeFq(mre.getScope());
                if (scopeOrigFq != null && !AstUtils.isInfrastructureFq(scopeOrigFq)) {
                    String orig = lookupMethodByOrigTypeAndObfName(scopeOrigFq, currentId);
                    if (orig != null) mre.setIdentifier(orig);
                }
            }
        }

        // ── Part 2: scope rename safety net ──────────────────────────────────────
        // Phase 1c should have renamed field scopes, but as a safety net we apply
        // the flat newFieldToOrig lookup for any that were missed.
        Expression sc = mre.getScope();
        String scopeName = AstUtils.mreSimpleScopeName(sc);
        if (scopeName != null && dctx.allNewFieldNames.contains(scopeName)) {
            if (!(sc instanceof NameExpr ne5 && AstUtils.isDeclaredAsLocalOrParameter(ne5, scopeName))) {
                String orig = dctx.newFieldToOrig.get(scopeName);
                if (orig != null) {
                    if (sc instanceof NameExpr ne6) ne6.setName(orig);
                    else if (sc instanceof TypeExpr) mre.setScope(new NameExpr(orig));
                }
            }
        }

        return super.visit(mre, arg);
    }

    // ── Method lookup helpers ─────────────────────────────────────────────────────

    private String lookupMethod(ResolvedMethodDeclaration rmd, String currentName) {
        String dt = rmd.declaringType().getQualifiedName();
        StringBuilder desc = new StringBuilder(dt).append("#(");
        for (int i = 0; i < rmd.getNumberOfParams(); i++) {
            if (i > 0) desc.append(",");
            try { desc.append(rmd.getParam(i).getType().describe()); }
            catch (Throwable ignored) { desc.append("?"); }
        }
        desc.append(")");
        return dctx.methodRev.get(dt + "|" + desc + "|" + currentName);
    }

    /**
     * Resolves a method-reference scope expression to the original FQ of its type.
     * Handles {@link NameExpr}, {@link TypeExpr}, and {@link FieldAccessExpr} scopes.
     * Returns null if the type cannot be determined.
     */
    private String resolveMethodRefScopeFq(Expression scope) {
        String name = AstUtils.mreSimpleScopeName(scope);
        if (name == null && scope instanceof FieldAccessExpr fae) name = fae.getNameAsString();
        if (name == null) return null;

        final String n = name;
        // After Phase 1a the scope already carries the original simple name
        Optional<String> byOrigSimple = dctx.obfFqToOrig.values().stream()
                .filter(origFq -> AstUtils.simpleName(origFq).equals(n)).findFirst();
        if (byOrigSimple.isPresent()) return byOrigSimple.get();

        // Before Phase 1a: scope is still the obfuscated simple name
        return dctx.obfFqToOrig.entrySet().stream()
                .filter(e -> AstUtils.simpleName(e.getKey()).equals(n))
                .map(Map.Entry::getValue).findFirst().orElse(null);
    }

    /**
     * Scans {@code methodRev} for an entry whose declaring type is {@code origFq}
     * and whose obfuscated method name matches {@code obfName}.
     *
     * <p>Key format: {@code "declaringType|descriptor|obfName"}
     */
    private String lookupMethodByOrigTypeAndObfName(String origFq, String obfName) {
        String prefix = origFq + "|";
        String suffix = "|" + obfName;
        for (var entry : dctx.methodRev.entrySet()) {
            String key = entry.getKey();
            if (key.startsWith(prefix) && key.endsWith(suffix)) return entry.getValue();
        }
        return null;
    }
}
