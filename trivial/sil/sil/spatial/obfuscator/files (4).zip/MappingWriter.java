package com.example.obfuscator.passes;

import com.example.obfuscator.core.ObfuscationContext;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Writes the human-readable {@code obfuscation-mapping.txt} and the
 * machine-readable {@code mapping.json} after all passes have completed.
 *
 * <h3>Method entry format (mapping.json)</h3>
 * Each method entry carries these fields:
 * <pre>
 * {
 *   "declaringType":  "com.example.Foo",
 *   "originalName":   "process",
 *   "paramTypes":     ["java.lang.String", "int"],
 *   "descriptor":     "com.example.Foo|process|java.lang.String,int",
 *   "newName":        "fetchMatrix"
 * }
 * </pre>
 * The {@code descriptor} field is the canonical {@link com.example.obfuscator.model.MethodKey}
 * string in {@code "fqcn|methodName|param1,param2,..."} format.  The deobfuscator
 * reads this field to reconstruct its own reverse-lookup keys.
 */
public final class MappingWriter {

    private final ObfuscationContext ctx;
    private static final ObjectMapper OM = JsonMapper.builder().build();

    public MappingWriter(ObfuscationContext ctx) {
        this.ctx = ctx;
    }

    public void write() throws IOException {
        writeTextMapping();
        writeJsonMapping();
    }

    private void writeTextMapping() throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(ctx.obfRoot.resolve("obfuscation-mapping.txt"))) {
            section(w, "classMap");
            ctx.classMap.forEach((k, v) -> writeLine(w, k + " -> " + v));

            section(w, "metamodelMap");
            ctx.metamodelMap.forEach((k, v) -> writeLine(w, k + " -> " + v));

            section(w, "methodMap");
            ctx.methodMap.forEach((k, v) -> writeLine(w, k.key + " -> " + v));

            section(w, "fieldMap");
            ctx.fieldMap.forEach((k, v) -> writeLine(w, k + " -> " + v));

            section(w, "recordTypes");
            ctx.recordTypes.stream().sorted().forEach(fq -> writeLine(w, fq));

            section(w, "recordComponents");
            ctx.recordComponents.forEach((fq, components) ->
                    writeLine(w, fq + " : " + String.join(", ", components)));

            section(w, "superclassMap");
            ctx.superclassMap.forEach((k, v) -> writeLine(w, k + " -> " + v));
        }
    }

    private void writeJsonMapping() throws IOException {
        Map<String, Object> root = new LinkedHashMap<>();

        root.put("metadata", Map.of(
                "timestamp", Instant.now().toString(),
                "seed", 123456789,
                "version", "2.0"));

        root.put("classMap", ctx.classMap.entrySet().stream()
                .map(e -> Map.of("original", e.getKey(), "newSimple", e.getValue()))
                .collect(Collectors.toList()));

        root.put("originalTopLevel", ctx.topOrigFq.entrySet().stream()
                .map(e -> Map.of(
                        "relativePath",
                        ctx.projectRoot.relativize(e.getKey()).toString().replace('\\', '/'),
                        "originalFq", e.getValue()))
                .collect(Collectors.toList()));

        root.put("metamodelMap", ctx.metamodelMap.entrySet().stream()
                .map(e -> Map.of("original", e.getKey(), "new", e.getValue()))
                .collect(Collectors.toList()));

        root.put("methods", ctx.methodMap.entrySet().stream()
                .map(e -> buildMethodEntry(e.getKey().key, e.getValue()))
                .collect(Collectors.toList()));

        root.put("fields", ctx.fieldMap.entrySet().stream()
                .map(e -> {
                    int sep = e.getKey().lastIndexOf('|');
                    return Map.of(
                            "declaringType", sep >= 0 ? e.getKey().substring(0, sep) : e.getKey(),
                            "originalName",  sep >= 0 ? e.getKey().substring(sep + 1) : e.getKey(),
                            "newName", e.getValue());
                })
                .collect(Collectors.toList()));

        root.put("superclassMap", ctx.superclassMap.entrySet().stream()
                .map(e -> Map.of("child", e.getKey(), "parent", e.getValue()))
                .collect(Collectors.toList()));

        root.put("recordTypes", ctx.recordTypes.stream().sorted().collect(Collectors.toList()));

        root.put("recordComponents", ctx.recordComponents.entrySet().stream()
                .map(e -> {
                    List<Map<String, String>> components = e.getValue().stream()
                            .map(compName -> {
                                String newName = ctx.fieldMap.get(e.getKey() + "|" + compName);
                                Map<String, String> m = new LinkedHashMap<>();
                                m.put("original", compName);
                                m.put("new", newName != null ? newName : compName);
                                return m;
                            })
                            .collect(Collectors.toList());
                    return Map.of("type", e.getKey(), "components", components);
                })
                .collect(Collectors.toList()));

        OM.writerWithDefaultPrettyPrinter()
                .writeValue(ctx.obfRoot.resolve("mapping.json").toFile(), root);
        System.out.println("Mapping written to " + ctx.obfRoot.resolve("mapping.json"));
    }

    /**
     * Parses a canonical method key ({@code "fqcn|methodName|param1,param2,..."}) and
     * returns the JSON object for the {@code "methods"} array in {@code mapping.json}.
     *
     * <p>The three segments are split on {@code '|'} with a limit of 3 so that a
     * parameter type string that somehow contained a pipe would not be misinterpreted
     * (in practice JavaParser type descriptors never contain {@code '|'}).
     *
     * <p><b>Old format note:</b> the previous format was
     * {@code "com.example.Foo.methodName#(param1,param2)"}.  If you have existing
     * {@code mapping.json} files produced by an older version you must regenerate them.
     */
    private static Map<String, Object> buildMethodEntry(String key, String newName) {
        // key format: "com.example.Foo|methodName|param1Type,param2Type"
        String[] parts = key.split("\\|", 3);
        String dt       = parts.length > 0 ? parts[0] : "";
        String origName = parts.length > 1 ? parts[1] : "";
        String paramStr = parts.length > 2 ? parts[2] : "";

        List<String> params = new ArrayList<>();
        if (!paramStr.isEmpty()) {
            for (String s : paramStr.split(",", -1)) {
                String trimmed = s.trim();
                if (!trimmed.isEmpty()) params.add(trimmed);
            }
        }

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("declaringType", dt);
        m.put("originalName",  origName);
        m.put("paramTypes",    params);
        m.put("descriptor",    key);   // full canonical key — used by deobfuscator
        m.put("newName",       newName);
        return m;
    }

    private static void section(BufferedWriter w, String name) {
        writeLine(w, "\n# " + name);
    }

    private static void writeLine(BufferedWriter w, String line) {
        try { w.write(line + "\n"); }
        catch (IOException e) { throw new RuntimeException(e); }
    }
}
