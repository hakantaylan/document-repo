package com.example.obfuscator.resolver;

import com.example.obfuscator.core.ObfuscationContext;
import com.example.obfuscator.core.ObfuscationRules;
import com.example.obfuscator.model.MethodKey;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Handles renaming of {@link MethodReferenceExpr} nodes when
 * {@code mre.resolve()} has already failed (or was not attempted).
 *
 * <h3>Key format</h3>
 * All lookups use the canonical {@link com.example.obfuscator.model.MethodKey} format:
 * <pre>
 *   fqcn|methodName|param1Type,param2Type,...
 * </pre>
 * Prefix searches use {@link SymbolResolverUtils#methodKeyPrefix(String, String)} which
 * produces {@code "fqcn|methodName|"}.  A result is returned only when exactly one
 * overload matches (unambiguous rename).
 */
public final class MethodReferenceResolver {

    private final ObfuscationContext ctx;

    public MethodReferenceResolver(ObfuscationContext ctx) {
        this.ctx = ctx;
    }

    // ── Identifier (method name part) renaming ────────────────────────────────

    /**
     * Attempts to rename the method-identifier segment of a {@link MethodReferenceExpr}
     * (e.g. {@code process} in {@code Foo::process}).
     *
     * <p>Three strategies in priority order:
     * <ol>
     *   <li>Resolve the scope type via the symbol solver → exact prefix search on that type.</li>
     *   <li>Resolve the scope type textually (parameter / field inspection) → prefix search.</li>
     *   <li>Global unique-name fallback: if only one method with this name is registered
     *       project-wide, use that (safe only for non-overloaded names).</li>
     * </ol>
     */
    public void tryRenameIdentifier(MethodReferenceExpr mre) {
        String identifier = mre.getIdentifier();

        // Strategy 1: symbol-solver scope resolution
        try {
            String scopeFq = SymbolResolverUtils.resolveScopeTypeFq(mre.getScope());
            if (scopeFq != null && !ObfuscationRules.isInfrastructureFq(scopeFq)) {
                String newId = searchMethodMapByTypeAndName(scopeFq, identifier);
                if (newId != null) { mre.setIdentifier(newId); return; }
            }
        } catch (Throwable ignored) {}

        // Strategy 2: textual scope resolution
        try {
            Expression sc = mre.getScope();
            if (sc instanceof NameExpr) {
                String textualFq = SymbolResolverUtils.resolveOwnerFqTextually(sc, ctx.classMap);
                if (textualFq != null && !ObfuscationRules.isInfrastructureFq(textualFq)) {
                    String newId = searchMethodMapByTypeAndName(textualFq, identifier);
                    if (newId != null) { mre.setIdentifier(newId); return; }
                }
            }
        } catch (Throwable ignored) {}

        // Strategy 3: project-wide unique-name fallback
        // If the identifier maps to exactly one obfuscated name across all types, it is
        // unambiguous and safe to rename even without knowing the declaring type.
        List<String> candidates = ctx.methodMap.entrySet().stream()
                .filter(e -> extractMethodName(e.getKey().key).equals(identifier))
                .map(Map.Entry::getValue)
                .distinct()
                .collect(Collectors.toList());
        if (candidates.size() == 1) mre.setIdentifier(candidates.get(0));
    }

    // ── Scope expression renaming ─────────────────────────────────────────────

    public void tryRenameScope(MethodReferenceExpr mre,
                               Map<TypeDeclaration<?>, String> typeOrigFq) {
        Expression scope = mre.getScope();
        if (scope instanceof NameExpr ne) {
            renameMreScopeExpr(ne.getNameAsString(), scope, mre, typeOrigFq);
        } else if (scope instanceof TypeExpr te
                && te.getType() instanceof com.github.javaparser.ast.type.ClassOrInterfaceType cit) {
            String name = cit.getNameAsString();
            int lt = name.indexOf('<');
            if (lt > 0) name = name.substring(0, lt);
            renameMreScopeExpr(name, scope, mre, typeOrigFq);
        } else if (scope instanceof FieldAccessExpr fae) {
            renameFieldAccessExprScope(fae, typeOrigFq);
        }
    }

    private void renameMreScopeExpr(String s, Expression scope,
                                     MethodReferenceExpr mre,
                                     Map<TypeDeclaration<?>, String> typeOrigFq) {
        if (!ctx.allRenamedOrigFieldNames.contains(s)) return;

        // Priority 1: symbol resolution
        try {
            if (scope instanceof NameExpr ne) {
                var rvd = ne.resolve();
                if (rvd.isField()) {
                    String key = rvd.asField().declaringType().getQualifiedName() + "|" + s;
                    String mapped = ctx.fieldMap.get(key);
                    if (mapped != null) { setMreScope(mre, scope, mapped); return; }
                }
            }
        } catch (Throwable ignored) {}

        // Priority 2: enclosing-type direct hit
        String enclosingFq = scope.findAncestor(TypeDeclaration.class)
                .map(td -> typeOrigFq.get((TypeDeclaration<?>) td))
                .orElse(null);
        String mapped = (enclosingFq != null) ? ctx.fieldMap.get(enclosingFq + "|" + s) : null;

        // Priority 3: superclass hierarchy walk
        if (mapped == null) mapped = lookupInHierarchy(enclosingFq, s);

        // Priority 4: flat unique-name fallback
        if (mapped == null) mapped = ctx.flatFieldRenames.get(s);

        if (mapped != null) setMreScope(mre, scope, mapped);
    }

    /** Sets the MRE scope to the new name, handling both NameExpr and TypeExpr. */
    private static void setMreScope(MethodReferenceExpr mre, Expression scope, String newName) {
        if (scope instanceof NameExpr ne) {
            ne.setName(newName);
        } else {
            // TypeExpr — replace with a NameExpr carrying the new name
            mre.setScope(new NameExpr(newName));
        }
    }

    /** Walk superclassMap to find the fieldMap entry for {@code origName}. */
    private String lookupInHierarchy(String ownerFq, String origName) {
        java.util.Set<String> visited = new java.util.HashSet<>();
        String fq = ownerFq;
        while (fq != null && visited.add(fq)) {
            String v = ctx.fieldMap.get(fq + "|" + origName);
            if (v != null) return v;
            fq = ctx.superclassMap.get(fq);
        }
        return null;
    }

    private void renameFieldAccessExprScope(FieldAccessExpr fae,
                                            Map<TypeDeclaration<?>, String> typeOrigFq) {
        try {
            var rvd = fae.resolve();
            if (rvd.isField()) {
                String key    = rvd.asField().declaringType().getQualifiedName() + "|" + fae.getNameAsString();
                String mapped = ctx.fieldMap.get(key);
                if (mapped == null) mapped = ctx.flatFieldRenames.get(fae.getNameAsString());
                if (mapped != null) fae.setName(mapped);
            }
        } catch (Throwable t) {
            String rightMost = extractRightMost(fae);
            if (rightMost == null || !ctx.allRenamedOrigFieldNames.contains(rightMost)) return;

            String enclosingFq = fae.findAncestor(TypeDeclaration.class)
                    .map(td -> typeOrigFq.get((TypeDeclaration<?>) td))
                    .orElse(null);
            String mapped = enclosingFq != null
                    ? ctx.fieldMap.get(enclosingFq + "|" + rightMost) : null;
            if (mapped == null) mapped = ctx.flatFieldRenames.get(rightMost);
            if (mapped != null) fae.setName(mapped);
        }
    }

    private static String extractRightMost(FieldAccessExpr fae) {
        String rightMost = null;
        Expression cur = fae;
        while (cur instanceof FieldAccessExpr fe) {
            rightMost = fe.getNameAsString();
            if (fe.getScope() instanceof NameExpr) break;
            cur = fe.getScope();
        }
        return rightMost;
    }

    // ── Core prefix-based method search ──────────────────────────────────────

    /**
     * Searches {@code methodMap} for entries whose key starts with
     * {@code "typeFq|methodName|"}, walking the class hierarchy.
     *
     * <p>Returns a new name only when exactly ONE candidate is found at a given
     * hierarchy level.  If multiple overloads have been registered (same declaring
     * type, same method name, different params), this method returns {@code null}
     * rather than picking arbitrarily — the caller must rely on a more specific
     * resolution path that includes parameter types.
     *
     * @param typeFq     fully-qualified declaring type (original or obfuscated)
     * @param methodName the original method simple name
     * @return the obfuscated name, or {@code null} if absent or ambiguous
     */
    private String searchMethodMapByTypeAndName(String typeFq, String methodName) {
        // Try the given type directly
        String result = searchPrefix(typeFq, methodName);
        if (result != null) return result;

        // The supplied FQ might be an obfuscated name — look up the original FQ
        String simpleCandidate = typeFq.contains(".")
                ? typeFq.substring(typeFq.lastIndexOf('.') + 1) : typeFq;
        Optional<String> maybeOrig = ctx.classMap.entrySet().stream()
                .filter(e -> e.getValue().equals(simpleCandidate))
                .map(Map.Entry::getKey)
                .findFirst();
        if (maybeOrig.isPresent()) {
            result = searchPrefix(maybeOrig.get(), methodName);
            if (result != null) return result;
        }

        return null;
    }

    /**
     * Performs the actual prefix scan for {@code "fqcn|methodName|"} in
     * {@code methodMap}.  Returns the mapped name only when the result is unambiguous
     * (exactly one distinct value matches).
     */
    private String searchPrefix(String fqcn, String methodName) {
        // Key format: "fqcn|methodName|param1,param2,..."
        // Prefix:     "fqcn|methodName|"
        String prefix = SymbolResolverUtils.methodKeyPrefix(fqcn, methodName);

        List<String> hits = ctx.methodMap.entrySet().stream()
                .filter(e -> e.getKey().key.startsWith(prefix))
                .map(Map.Entry::getValue)
                .distinct()
                .collect(Collectors.toList());

        return hits.size() == 1 ? hits.get(0) : null;
    }

    // ── Key parsing helper ────────────────────────────────────────────────────

    /**
     * Extracts the method simple name (segment [1]) from a canonical key string
     * {@code "fqcn|methodName|paramTypes"}.
     *
     * <p>Used by the global unique-name fallback in {@link #tryRenameIdentifier} to
     * match entries whose original name equals the current identifier.
     */
    private static String extractMethodName(String key) {
        // Key format:  "com.example.Foo|process|java.lang.String,int"
        // Segments:    [0] = "com.example.Foo"
        //              [1] = "process"          ← this is what we want
        //              [2] = "java.lang.String,int"
        String[] parts = key.split("\\|", 3);
        return parts.length > 1 ? parts[1] : key;
    }
}
