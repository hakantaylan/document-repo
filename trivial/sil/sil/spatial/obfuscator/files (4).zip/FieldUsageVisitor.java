package com.example.obfuscator.passes;

import com.example.obfuscator.core.ObfuscationContext;
import com.example.obfuscator.model.MethodKey;
import com.example.obfuscator.resolver.SymbolResolverUtils;
import com.example.obfuscator.util.ASTUtils;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * V3b — renames every field usage: {@link FieldAccessExpr}, {@link NameExpr},
 * {@link MethodReferenceExpr} scopes, and also {@link MethodCallExpr} sites that
 * call project methods recorded in {@link ObfuscationContext#methodMap}.
 *
 * <h3>MethodCallExpr lookup priority</h3>
 * <ol>
 *   <li><b>Symbol resolution</b> — builds the exact {@link MethodKey} (including param
 *       types) via {@link SymbolResolverUtils#methodKey(ResolvedMethodDeclaration)}.
 *       This correctly handles overloaded methods because the key encodes all parameter
 *       types.</li>
 *   <li><b>Scope-type prefix search</b> — resolves the scope type without param types
 *       and searches for keys matching {@code "fqcn|methodName|*"}.  Returns a result
 *       only when exactly one overload is found; silently skips ambiguous cases.</li>
 *   <li><b>Enclosing-class prefix search</b> — same prefix strategy applied to the
 *       innermost declaring class.</li>
 * </ol>
 *
 * <h3>Key invariant</h3>
 * The {@code methodMap} key format is {@code "fqcn|methodName|param1,param2,..."}.
 * This matches exactly what {@link SymbolResolverUtils#methodKey} produces and what
 * {@link MethodRenameCollector} stores.  No legacy {@code "#("} or {@code "|name"}
 * formats are used here.
 */
final class FieldUsageVisitor extends ModifierVisitor<Void> {

    private final ObfuscationContext ctx;

    FieldUsageVisitor(ObfuscationContext ctx) {
        this.ctx = ctx;
    }

    // ── FieldAccessExpr (this.price, obj.name) ────────────────────────────────

    @Override
    public Visitable visit(FieldAccessExpr fae, Void arg) {
        String s = fae.getNameAsString();

        try {
            ResolvedValueDeclaration rvd = fae.resolve();
            if (rvd.isField()) {
                String qualifiedName = rvd.asField().declaringType().getQualifiedName();
                String key = lookupFieldWithHierarchy(qualifiedName, s);
                if (ctx.fieldMap.containsKey(key)) {
                    fae.setName(ctx.fieldMap.get(key));
                    return super.visit(fae, arg);
                }
            }
        } catch (Throwable ignored) {}

        // Special handling for static metamodel accesses like Fruit_.name
        Expression scopeExpr = fae.getScope();
        if (scopeExpr instanceof NameExpr scopeNameExpr) {
            String metaSimple = scopeNameExpr.getNameAsString();
            if (metaSimple.endsWith("_") || ctx.metamodelMap.containsKey(metaSimple)
                    || ctx.metamodelMap.containsValue(metaSimple)) {
                String entitySimple = metaSimple.endsWith("_")
                        ? metaSimple.substring(0, metaSimple.length() - 1)
                        : metaSimple.replaceAll("_$", "");
                String foundOrigFq = ctx.classMap.keySet().stream()
                        .filter(fq -> fq.endsWith("." + entitySimple) || fq.equals(entitySimple))
                        .findFirst().orElse(null);
                if (foundOrigFq == null) {
                    foundOrigFq = ctx.classMap.entrySet().stream()
                            .filter(e -> e.getValue().equals(entitySimple))
                            .map(java.util.Map.Entry::getKey)
                            .findFirst().orElse(null);
                }
                if (foundOrigFq != null) {
                    String metaOrigFq = foundOrigFq + "_";
                    String newName = lookupFieldWithHierarchy(metaOrigFq, s);
                    if (newName != null) {
                        fae.setName(newName);
                        return super.visit(fae, arg);
                    }
                    String metaObfFq = ASTUtils.toObfFq(foundOrigFq, ctx.classMap) + "_";
                    newName = lookupFieldWithHierarchy(metaObfFq, s);
                    if (newName != null) {
                        fae.setName(newName);
                        return super.visit(fae, arg);
                    }
                }
            }
        }
        if (!ctx.allRenamedOrigFieldNames.contains(s)) return super.visit(fae, arg);

        String mapped = fae.findAncestor(TypeDeclaration.class)
                .map(td -> ctx.typeOrigFq.get((TypeDeclaration<?>) td))
                .map(fq -> lookupFieldWithHierarchy(fq, s))
                .orElse(null);

        if (mapped == null) mapped = ctx.flatFieldRenames.get(s);
        if (mapped != null) fae.setName(mapped);
        return super.visit(fae, arg);
    }

    // ── NameExpr ──────────────────────────────────────────────────────────────

    @Override
    public Visitable visit(NameExpr ne, Void arg) {
        String s = ne.getNameAsString();
        if (!ctx.allRenamedOrigFieldNames.contains(s)) return super.visit(ne, arg);

        // MethodReferenceExpr.getScope() returns Expression directly (NOT Optional).
        boolean isMreScope = false;
        if (ne.getParentNode().orElse(null) instanceof MethodReferenceExpr mreParent) {
            isMreScope = mreParent.getScope() == ne;
        }

        if (!isMreScope) {
            if (SymbolResolverUtils.isDeclaredAsLocalOrParameter(ne, s))
                return super.visit(ne, arg);
        }

        // Enclosing-type direct hit
        String enclosingFq = ne.findAncestor(TypeDeclaration.class)
                .map(td -> ctx.typeOrigFq.get((TypeDeclaration<?>) td))
                .orElse(null);
        String directFieldHit = enclosingFq != null
                ? lookupFieldWithHierarchy(enclosingFq, s) : null;

        if (directFieldHit != null) {
            ne.setName(directFieldHit);
            return super.visit(ne, arg);
        }

        // Symbol resolution → exact declaring-type key
        try {
            ResolvedValueDeclaration rvd = ne.resolve();
            if (rvd.isField()) {
                String qualifiedName = rvd.asField().declaringType().getQualifiedName();
                String mapped = lookupFieldWithHierarchy(qualifiedName, s);
                if (mapped != null) {
                    ne.setName(mapped);
                    return super.visit(ne, arg);
                }
            }
        } catch (Throwable ignored) {}

        // Flat unique-name fallback
        String mapped = ctx.flatFieldRenames.get(s);
        if (mapped != null) ne.setName(mapped);

        return super.visit(ne, arg);
    }

    // ── MethodReferenceExpr scope — safety net ────────────────────────────────

    @Override
    public Visitable visit(MethodReferenceExpr mre, Void arg) {
        Visitable result = super.visit(mre, arg);
        if (!(result instanceof MethodReferenceExpr mre2)) return result;

        Expression scope = mre2.getScope();

        String s = null;
        if (scope instanceof NameExpr ne0) {
            s = ne0.getNameAsString();
        } else if (scope instanceof TypeExpr te
                && te.getType() instanceof ClassOrInterfaceType cit0) {
            s = cit0.getNameAsString();
            int lt = s.indexOf('<');
            if (lt > 0) s = s.substring(0, lt);
        }
        if (s == null || !ctx.allRenamedOrigFieldNames.contains(s)) return mre2;

        String mapped = null;
        if (scope instanceof NameExpr ne0) {
            try {
                ResolvedValueDeclaration rvd = ne0.resolve();
                if (rvd.isField()) {
                    String key = rvd.asField().declaringType().getQualifiedName() + "|" + s;
                    mapped = ctx.fieldMap.get(key);
                }
            } catch (Throwable ignored) {}
        }

        if (mapped == null) {
            String enclosingFq = scope.findAncestor(TypeDeclaration.class)
                    .map(td -> ctx.typeOrigFq.get((TypeDeclaration<?>) td))
                    .orElse(null);
            mapped = lookupInHierarchy(enclosingFq, s);
        }

        if (mapped == null) mapped = ctx.flatFieldRenames.get(s);

        if (mapped != null) {
            if (scope instanceof NameExpr ne0) {
                ne0.setName(mapped);
            } else {
                mre2.setScope(new NameExpr(mapped));
            }
        }
        return mre2;
    }

    // ── MethodCallExpr — project method renames ───────────────────────────────
    //
    // This is the central fix for overloading.
    //
    // Strategy 1 (preferred): symbol resolution gives us a ResolvedMethodDeclaration.
    //   We build the EXACT MethodKey via SymbolResolverUtils.methodKey(), which encodes
    //   the full parameter type list.  This correctly disambiguates overloads.
    //
    // Strategy 2 (fallback when resolution fails): we only know the declaring FQCN and
    //   the method name.  We search the methodMap for keys matching the prefix
    //   "fqcn|methodName|".  If exactly ONE overload is registered, we can safely return
    //   it.  If multiple overloads exist, we skip to avoid renaming the wrong one.
    //
    // Strategy 3 (last resort): same prefix search on the enclosing class.

    @Override
    public Visitable visit(MethodCallExpr mc, Void arg) {
        super.visit(mc, arg);

        String methodName = mc.getNameAsString();

        // Strategy 1: exact key via symbol resolution (overload-safe)
        try {
            ResolvedMethodDeclaration resolved = mc.resolve();
            String declaringType = resolved.declaringType().getQualifiedName();
            MethodKey mk = new MethodKey(SymbolResolverUtils.methodKey(resolved));

            // Direct hit first
            String v = ctx.methodMap.get(mk);
            if (v != null) {
                mc.setName(v);
                return mc;
            }

            // Walk superclass hierarchy with exact key
            String current = ctx.superclassMap.get(declaringType);
            while (current != null) {
                // Rebuild key with ancestor FQCN but same name + params
                String rebuiltKey = SymbolResolverUtils.buildMethodKey(
                        current, methodName, extractParamTypes(resolved));
                String hit = ctx.methodMap.get(new MethodKey(rebuiltKey));
                if (hit != null) {
                    mc.setName(hit);
                    return mc;
                }
                current = ctx.superclassMap.get(current);
            }
        } catch (Exception ignored) {}

        // Strategy 2: scope-type prefix search (safe only for non-overloaded names)
        if (mc.getScope().isPresent()) {
            String ownerFq = SymbolResolverUtils.resolveScopeTypeFq(mc.getScope().get());
            String newName = lookupMethodByPrefix(ownerFq, methodName);
            if (newName != null) {
                mc.setName(newName);
                return mc;
            }
        }

        // Strategy 3: enclosing class prefix search
        String currentClassFq = resolveEnclosingClassFq(mc);
        String newName = lookupMethodByPrefix(currentClassFq, methodName);
        if (newName != null) {
            mc.setName(newName);
        }

        return mc;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String lookupInHierarchy(String ownerFq, String origName) {
        Set<String> visited = new HashSet<>();
        String fq = ownerFq;
        while (fq != null && visited.add(fq)) {
            String v = lookupFieldWithHierarchy(fq, origName);
            if (v != null) return v;
            fq = ctx.superclassMap.get(fq);
        }
        return null;
    }

    private String lookupFieldWithHierarchy(String ownerFq, String fieldName) {
        String v = ctx.fieldMap.get(ownerFq + "|" + fieldName);
        if (v != null) return v;
        String current = ownerFq;
        while (true) {
            String parent = ctx.superclassMap.get(current);
            if (parent == null) break;
            v = ctx.fieldMap.get(parent + "|" + fieldName);
            if (v != null) return v;
            current = parent;
        }
        return null;
    }

    /**
     * Searches {@code methodMap} by prefix {@code "fqcn|methodName|"}, walking the
     * superclass chain.  Returns the mapped name only when exactly one overload matches
     * at a given hierarchy level (avoids wrongly renaming one overload to another's name).
     */
    private String lookupMethodByPrefix(String ownerFq, String methodName) {
        if (ownerFq == null) return null;
        String current = ownerFq;
        Set<String> visited = new HashSet<>();
        while (current != null && visited.add(current)) {
            String prefix = SymbolResolverUtils.methodKeyPrefix(current, methodName);
            List<String> hits = ctx.methodMap.entrySet().stream()
                    .filter(e -> e.getKey().key.startsWith(prefix))
                    .map(java.util.Map.Entry::getValue)
                    .distinct()
                    .collect(Collectors.toList());
            if (hits.size() == 1) return hits.get(0);
            // Multiple overloads and no param info → cannot safely resolve; try next level
            current = ctx.superclassMap.get(current);
        }
        return null;
    }

    /**
     * Extracts the comma-joined parameter type descriptors from a
     * {@link ResolvedMethodDeclaration}, matching the format written by
     * {@link SymbolResolverUtils#methodKey}.
     */
    private static String extractParamTypes(ResolvedMethodDeclaration rmd) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rmd.getNumberOfParams(); i++) {
            if (i > 0) sb.append(",");
            try { sb.append(rmd.getParam(i).getType().describe()); }
            catch (Throwable t) { sb.append("?"); }
        }
        return sb.toString();
    }

    private String resolveEnclosingClassFq(Node node) {
        return node.findAncestor(com.github.javaparser.ast.body.ClassOrInterfaceDeclaration.class)
                .map(this::resolveFqcn)
                .orElse(null);
    }

    private String resolveFqcn(com.github.javaparser.ast.body.ClassOrInterfaceDeclaration cd) {
        String pkg = cd.findCompilationUnit()
                .flatMap(cu -> cu.getPackageDeclaration())
                .map(pd -> pd.getNameAsString())
                .orElse("");
        String className = cd.getNameAsString();
        Node parent = cd.getParentNode().orElse(null);
        while (parent instanceof com.github.javaparser.ast.body.ClassOrInterfaceDeclaration) {
            className = ((com.github.javaparser.ast.body.ClassOrInterfaceDeclaration) parent).getNameAsString()
                    + "$" + className;
            parent = parent.getParentNode().orElse(null);
        }
        return pkg.isEmpty() ? className : pkg + "." + className;
    }
}
