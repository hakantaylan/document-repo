package com.example.obfuscator.resolver;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.types.ResolvedType;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class SymbolResolverUtils {

    private SymbolResolverUtils() {}

    // ── Method key ────────────────────────────────────────────────────────────
    //
    // KEY FORMAT (new):  "com.example.Foo|methodName|param1Type,param2Type"
    //
    // The three segments are separated by '|':
    //   [0] declaring type FQCN
    //   [1] original (or obfuscated) method simple name
    //   [2] comma-joined parameter type descriptors (empty string if no params)
    //
    // This format is overload-safe: two methods with the same name but different
    // parameter types produce distinct keys.  It is also pipe-separated (never
    // contains '#' or '.'-after-last-dot) so MappingWriter.buildMethodEntry()
    // can split on '|' with a simple limit-3 split.

    /**
     * Builds the canonical method key from a resolved method declaration.
     *
     * <p>Strategy:
     * <ol>
     *   <li>Try {@code rmd.getQualifiedName()} → split on last '.' to get FQCN + name.</li>
     *   <li>Fallback to {@code rmd.declaringType().getQualifiedName()} + {@code rmd.getName()}.</li>
     *   <li>Last-resort: use name alone as FQCN.</li>
     * </ol>
     * Parameter types are resolved via {@link ResolvedMethodDeclaration#getParam(int)};
     * any individual type that fails to resolve is replaced with {@code "?"} so the
     * key stays consistent between the collector pass and the applier pass.
     */
    public static String methodKey(ResolvedMethodDeclaration rmd) {
        String fqcn;
        String name;

        try {
            String qn = rmd.getQualifiedName(); // e.g. "com.example.Foo.process"
            int lastDot = qn.lastIndexOf('.');
            fqcn = lastDot >= 0 ? qn.substring(0, lastDot) : "";
            name = lastDot >= 0 ? qn.substring(lastDot + 1) : qn;
        } catch (Throwable t) {
            try {
                fqcn = rmd.declaringType().getQualifiedName();
                name = rmd.getName();
            } catch (Throwable ignored) {
                fqcn = "";
                name = rmd.getName();
            }
        }

        StringBuilder params = new StringBuilder();
        for (int i = 0; i < rmd.getNumberOfParams(); i++) {
            if (i > 0) params.append(",");
            try { params.append(rmd.getParam(i).getType().describe()); }
            catch (Throwable t) { params.append("?"); }
        }

        return buildMethodKey(fqcn, name, params.toString());
    }

    /**
     * Low-level key builder — use when you already have the three segments.
     *
     * @param fqcn       declaring type fully-qualified name (e.g. {@code "com.example.Foo"})
     * @param methodName simple method name (e.g. {@code "process"})
     * @param paramTypes comma-separated parameter types, or empty string for no-arg methods
     * @return canonical key string {@code "fqcn|methodName|paramTypes"}
     */
    public static String buildMethodKey(String fqcn, String methodName, String paramTypes) {
        return fqcn + "|" + methodName + "|" + (paramTypes == null ? "" : paramTypes);
    }

    /**
     * Convenience overload accepting a {@link List} of already-described parameter types.
     */
    public static String buildMethodKey(String fqcn, String methodName, List<String> paramTypes) {
        return buildMethodKey(fqcn, methodName,
                paramTypes == null ? "" : String.join(",", paramTypes));
    }

    /**
     * Returns the prefix string used for partial (name-only) lookups:
     * {@code "fqcn|methodName|"}.  Any key that starts with this prefix belongs
     * to an overload of {@code methodName} declared by {@code fqcn}.
     */
    public static String methodKeyPrefix(String fqcn, String methodName) {
        return fqcn + "|" + methodName + "|";
    }

    // ── Scope-type resolution via symbol solver ───────────────────────────────

    public static String resolveScopeTypeFq(Expression scope) {
        try {
            ResolvedType rt;
            if (scope instanceof NameExpr ne)              rt = ne.resolve().getType();
            else if (scope instanceof FieldAccessExpr fae) rt = fae.resolve().getType();
            else if (scope instanceof MethodCallExpr mce)  rt = mce.resolve().getReturnType();
            else return null;
            if (rt.isReferenceType()) return rt.asReferenceType().getQualifiedName();
        } catch (Throwable ignored) {}
        return null;
    }

    // ── Textual FQ lookup ─────────────────────────────────────────────────────

    public static String textualToOrigFq(String textual, Map<String, String> classMap) {
        if (textual == null) return null;
        String t = textual.strip();
        int lt = t.indexOf('<');
        if (lt > 0) t = t.substring(0, lt);
        final String qt = t;
        Optional<String> byOrig = classMap.keySet().stream()
                .filter(fq -> fq.equals(qt) || fq.endsWith("." + qt))
                .findFirst();
        if (byOrig.isPresent()) return byOrig.get();
        return classMap.entrySet().stream()
                .filter(e -> e.getValue().equals(qt))
                .map(Map.Entry::getKey)
                .findFirst().orElse(null);
    }

    // ── Textual owner-FQ resolution (single-file) ────────────────────────────

    public static String resolveOwnerFqTextually(Expression scope, Map<String, String> classMap) {
        if (scope instanceof NameExpr ne)         return resolveFromNameExpr(ne, classMap);
        if (scope instanceof FieldAccessExpr fae) return resolveFromFieldAccess(fae, classMap);
        return null;
    }

    private static String resolveFromNameExpr(NameExpr ne, Map<String, String> classMap) {
        String varName = ne.getNameAsString();

        // 1) Lambda parameters — walk parent chain manually since LambdaExpr is
        //    NOT a CallableDeclaration and findAncestor skips past it.
        com.github.javaparser.ast.Node cursor = ne.getParentNode().orElse(null);
        while (cursor != null && !(cursor instanceof CallableDeclaration<?>)) {
            if (cursor instanceof LambdaExpr lambda) {
                for (Parameter p : lambda.getParameters()) {
                    if (p.getNameAsString().equals(varName)) {
                        String textual = p.getType() instanceof ClassOrInterfaceType cit
                                ? cit.getNameWithScope() : p.getType().toString();
                        String fq = textualToOrigFq(textual, classMap);
                        if (fq != null) return fq;
                    }
                }
            }
            cursor = cursor.getParentNode().orElse(null);
        }

        // 2) Method / constructor parameters
        var callable = (Optional<CallableDeclaration<?>>) (Optional<?>)
                ne.findAncestor(CallableDeclaration.class);
        if (callable.isPresent()) {
            for (Parameter p : callable.get().getParameters()) {
                if (p.getNameAsString().equals(varName)) {
                    String textual = p.getType() instanceof ClassOrInterfaceType cit
                            ? cit.getNameWithScope() : p.getType().toString();
                    return textualToOrigFq(textual, classMap);
                }
            }
            // 3) Local variables anywhere in the method body
            for (VariableDeclarator vd : callable.get().findAll(VariableDeclarator.class)) {
                if (vd.getNameAsString().equals(varName)) {
                    String textual = vd.getType() instanceof ClassOrInterfaceType cit
                            ? cit.getNameWithScope() : vd.getType().toString();
                    String fq = textualToOrigFq(textual, classMap);
                    if (fq != null) return fq;
                }
            }
        }

        // 4) Class fields
        var encTd = (Optional<TypeDeclaration<?>>) (Optional<?>)
                ne.findAncestor(TypeDeclaration.class);
        if (encTd.isPresent()) {
            for (FieldDeclaration fd : encTd.get().getFields()) {
                for (VariableDeclarator vd : fd.getVariables()) {
                    if (vd.getNameAsString().equals(varName)) {
                        String textual = vd.getType() instanceof ClassOrInterfaceType cit
                                ? cit.getNameWithScope() : vd.getType().toString();
                        return textualToOrigFq(textual, classMap);
                    }
                }
            }
        }
        return null;
    }

    private static String resolveFromFieldAccess(FieldAccessExpr fae, Map<String, String> classMap) {
        String fieldName = fae.getNameAsString();
        var tdOpt = (Optional<TypeDeclaration<?>>) (Optional<?>)
                fae.findAncestor(TypeDeclaration.class);
        if (tdOpt.isEmpty()) return null;
        for (FieldDeclaration fd : tdOpt.get().getFields()) {
            for (VariableDeclarator vd : fd.getVariables()) {
                if (vd.getNameAsString().equals(fieldName)) {
                    String textual = vd.getType() instanceof ClassOrInterfaceType cit
                            ? cit.getNameWithScope() : vd.getType().toString();
                    return textualToOrigFq(textual, classMap);
                }
            }
        }
        return null;
    }

    // ── Chained getter return-type resolution (cross-file) ────────────────────

    /**
     * For a scope like {@code parent.getFIris164()}, resolves the return type of
     * {@code getFIris164()} by scanning all parsed CUs. Handles both get/is-prefixed
     * getters and zero-prefix record accessors. Matches TypeDeclarations by both
     * original and obfuscated name (V1 may have already renamed them), and fields by
     * both obfuscated name (post-V3a) and original name (pre-V3a).
     */
    public static String resolveChainedGetterReturnType(
            MethodCallExpr mce,
            Map<String, String> classMap,
            Map<String, String> fieldMap,
            Collection<CompilationUnit> allUnits) {

        String methodName = mce.getNameAsString();
        if (mce.getScope().isEmpty()) return null;

        // Derive candidate field name from method name
        String obfFieldName;
        if (methodName.length() > 3 && methodName.startsWith("get")
                && Character.isUpperCase(methodName.charAt(3))) {
            String after = methodName.substring(3);
            obfFieldName = Character.toLowerCase(after.charAt(0)) + after.substring(1);
        } else if (methodName.length() > 2 && methodName.startsWith("is")
                && Character.isUpperCase(methodName.charAt(2))) {
            String after = methodName.substring(2);
            obfFieldName = Character.toLowerCase(after.charAt(0)) + after.substring(1);
        } else {
            obfFieldName = methodName; // zero-prefix record accessor
        }

        Expression receiver = mce.getScope().get();
        String receiverFq = resolveOwnerFqTextually(receiver, classMap);
        if (receiverFq == null) return null;

        String origSimple = receiverFq.contains(".")
                ? receiverFq.substring(receiverFq.lastIndexOf('.') + 1) : receiverFq;
        String obfSimple  = classMap.get(receiverFq);

        // Reverse-look up original field name for pre-V3a CUs
        final String finalObfField = obfFieldName;
        String origFieldName = fieldMap.entrySet().stream()
                .filter(e -> e.getValue().equals(finalObfField)
                        && e.getKey().startsWith(receiverFq + "|"))
                .map(e -> e.getKey().substring(e.getKey().lastIndexOf('|') + 1))
                .findFirst().orElse(null);

        for (CompilationUnit cu : allUnits) {
            for (TypeDeclaration<?> td : cu.findAll(TypeDeclaration.class)) {
                String tdName = td.getNameAsString();
                if (!tdName.equals(origSimple) && !tdName.equals(obfSimple)) continue;

                for (FieldDeclaration fd : td.getFields()) {
                    for (VariableDeclarator vd : fd.getVariables()) {
                        String vdName = vd.getNameAsString();
                        if (!vdName.equals(obfFieldName)
                                && (origFieldName == null || !vdName.equals(origFieldName))) continue;

                        String textual = vd.getType() instanceof ClassOrInterfaceType cit
                                ? cit.getNameWithScope() : vd.getType().toString();
                        return textualToOrigFq(textual, classMap);
                    }
                }
            }
        }
        return null;
    }

    // ── Lambda parameter type inference ───────────────────────────────────────

    /**
     * Infers the element type for an untyped lambda parameter such as {@code zone} in
     * {@code locations.stream().map(zone -> zone.getCity())} by finding the collection
     * variable the stream is built from and reading its generic type argument.
     */
    public static String inferLambdaParamType(NameExpr ne, Map<String, String> classMap,
                                              Collection<CompilationUnit> allUnits) {
        String paramName = ne.getNameAsString();

        // Walk up to the enclosing LambdaExpr
        com.github.javaparser.ast.Node cursor = ne.getParentNode().orElse(null);
        while (cursor != null && !(cursor instanceof LambdaExpr)) {
            cursor = cursor.getParentNode().orElse(null);
        }
        if (!(cursor instanceof LambdaExpr lambda)) return null;

        // Confirm paramName is a parameter of this lambda
        boolean isParam = lambda.getParameters().stream()
                .anyMatch(p -> p.getNameAsString().equals(paramName));
        if (!isParam) return null;

        // The lambda must be an argument to a MethodCallExpr (e.g. .map, .forEach)
        if (!(lambda.getParentNode().orElse(null) instanceof MethodCallExpr streamCall)) return null;
        if (streamCall.getScope().isEmpty()) return null;

        // Unwrap .stream() if present: locations.stream() → locations
        Expression streamScope = streamCall.getScope().get();
        Expression elementSource = streamScope;
        if (streamScope instanceof MethodCallExpr mce2
                && "stream".equals(mce2.getNameAsString())
                && mce2.getScope().isPresent()) {
            elementSource = mce2.getScope().get();
        }

        if (!(elementSource instanceof NameExpr collectionExpr)) return null;
        String collName = collectionExpr.getNameAsString();

        // Find the collection variable's declared type with generics
        var callableOpt = (Optional<CallableDeclaration<?>>) (Optional<?>)
                ne.findAncestor(CallableDeclaration.class);
        if (callableOpt.isPresent()) {
            for (Parameter p : callableOpt.get().getParameters()) {
                if (p.getNameAsString().equals(collName)) {
                    return extractElementType(p.getType().toString(), classMap);
                }
            }
            for (VariableDeclarator vd : callableOpt.get().findAll(VariableDeclarator.class)) {
                if (vd.getNameAsString().equals(collName)) {
                    return extractElementType(vd.getType().toString(), classMap);
                }
            }
        }

        var tdOpt = (Optional<TypeDeclaration<?>>) (Optional<?>)
                ne.findAncestor(TypeDeclaration.class);
        if (tdOpt.isPresent()) {
            for (FieldDeclaration fd : tdOpt.get().getFields()) {
                for (VariableDeclarator vd : fd.getVariables()) {
                    if (vd.getNameAsString().equals(collName)) {
                        return extractElementType(vd.getType().toString(), classMap);
                    }
                }
            }
        }
        return null;
    }

    /** Extracts {@code Foo} from {@code List<Foo>}, {@code Set<Foo>}, etc. */
    private static String extractElementType(String typeStr, Map<String, String> classMap) {
        int lt = typeStr.indexOf('<');
        int gt = typeStr.lastIndexOf('>');
        if (lt < 0 || gt <= lt) return null;
        String inner = typeStr.substring(lt + 1, gt).strip();
        int innerLt = inner.indexOf('<');
        if (innerLt > 0) inner = inner.substring(0, innerLt).strip();
        return textualToOrigFq(inner, classMap);
    }

    // ── Local-variable / parameter guard ─────────────────────────────────────

    public static boolean isDeclaredAsLocalOrParameter(NameExpr ne, String name) {
        var enclosing = (Optional<CallableDeclaration<?>>) (Optional<?>)
                ne.findAncestor(CallableDeclaration.class);
        if (enclosing.isPresent()) {
            CallableDeclaration<?> cd = enclosing.get();
            for (Parameter p : cd.getParameters())
                if (p.getNameAsString().equals(name)) return true;
            for (VariableDeclarator vd : cd.findAll(VariableDeclarator.class))
                if (vd.getNameAsString().equals(name)) return true;
        }
        var blockOpt = (Optional<BlockStmt>) (Optional<?>)
                ne.findAncestor(BlockStmt.class);
        if (blockOpt.isPresent()) {
            for (VariableDeclarator vd : blockOpt.get().findAll(VariableDeclarator.class))
                if (vd.getNameAsString().equals(name)) return true;
        }
        return false;
    }
}
