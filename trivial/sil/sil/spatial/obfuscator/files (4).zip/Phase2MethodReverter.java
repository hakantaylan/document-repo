package com.example.obfuscator.deobf.passes;

import com.example.obfuscator.core.ObfuscationRules;
import com.example.obfuscator.deobf.core.DeobfuscationContext;
import com.example.obfuscator.deobf.resolver.DeobfSymbolResolverUtils;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;

/**
 * Phase 2 — run after file relocation; reverts obfuscated method names.
 *
 * <p>Requires relocation to have completed first so that the symbol solver
 * can resolve method declarations correctly against the restored class names.
 *
 * <h3>Reverse-lookup key format</h3>
 * The {@link DeobfuscationContext#methodRev} map is keyed by:
 * <pre>
 *   origFqcn|obfMethodName|origParamTypes
 * </pre>
 * This is assembled at query time from:
 * <ul>
 *   <li>{@code origFqcn} — the declaring type's FQ name as resolved by the symbol
 *       solver (already back to original names after Phase 1a)</li>
 *   <li>{@code obfMethodName} — the current (obfuscated) name of the method node</li>
 *   <li>{@code origParamTypes} — comma-joined parameter type descriptors as returned
 *       by {@link ResolvedMethodDeclaration#getParam(int)}</li>
 * </ul>
 * This three-segment key is symmetric with the forward key stored during obfuscation
 * ({@code "origFqcn|origMethodName|origParamTypes"}) — only the name segment differs.
 *
 * <h3>Overloading</h3>
 * Because the parameter types are included in the key, two overloads of the same
 * method name always produce distinct keys and are therefore reverted independently
 * without any ambiguity.
 */
public final class Phase2MethodReverter {

    private final DeobfuscationContext ctx;

    public Phase2MethodReverter(DeobfuscationContext ctx) {
        this.ctx = ctx;
    }

    public void apply(CompilationUnit cu) {
        cu.accept(new Visitor(), null);
    }

    private final class Visitor extends ModifierVisitor<Void> {

        // ── Method declarations ───────────────────────────────────────────────

        @Override
        public Visitable visit(MethodDeclaration md, Void arg) {
            try {
                ResolvedMethodDeclaration rmd = md.resolve();
                if (ObfuscationRules.isInfrastructureFq(rmd.declaringType().getQualifiedName()))
                    return super.visit(md, arg);
                String orig = lookupMethod(rmd, md.getNameAsString());
                if (orig != null) md.setName(orig);
            } catch (Throwable ignored) {}
            return super.visit(md, arg);
        }

        // ── Method call sites ─────────────────────────────────────────────────

        @Override
        public Visitable visit(MethodCallExpr mce, Void arg) {
            try {
                ResolvedMethodDeclaration rmd = mce.resolve();
                if (ObfuscationRules.isInfrastructureFq(rmd.declaringType().getQualifiedName()))
                    return super.visit(mce, arg);
                String orig = lookupMethod(rmd, mce.getNameAsString());
                if (orig != null) mce.setName(orig);
            } catch (Throwable ignored) {}
            return super.visit(mce, arg);
        }

        // ── Method references ─────────────────────────────────────────────────

        @Override
        public Visitable visit(MethodReferenceExpr mre, Void arg) {
            String currentId = mre.getIdentifier();
            if (!"new".equals(currentId)) {
                try {
                    ResolvedMethodDeclaration rmd = mre.resolve();
                    if (!ObfuscationRules.isInfrastructureFq(rmd.declaringType().getQualifiedName())) {
                        String orig = lookupMethod(rmd, currentId);
                        if (orig != null) mre.setIdentifier(orig);
                    }
                } catch (Throwable ignored) {
                    // Symbol resolution failed (e.g., lambda context, generated types).
                    // Fall back to a prefix scan using the original declaring type.
                    String scopeOrigFq = DeobfSymbolResolverUtils.resolveMethodRefScopeFq(
                            mre.getScope(), ctx.obfFqToOrig, ctx.newSimpleToOrig);
                    if (scopeOrigFq != null && !ObfuscationRules.isInfrastructureFq(scopeOrigFq)) {
                        String orig = lookupMethodByOrigTypeAndObfName(scopeOrigFq, currentId);
                        if (orig != null) mre.setIdentifier(orig);
                    }
                }
            }

            // Scope safety-net for any field renames Phase 1c missed
            Expression sc = mre.getScope();
            String scopeName = extractScopeName(sc);
            if (scopeName != null && ctx.allNewFieldNames.contains(scopeName)) {
                boolean isLocal = sc instanceof NameExpr ne5
                        && DeobfSymbolResolverUtils.isDeclaredAsLocalOrParameter(ne5, scopeName);
                if (!isLocal) {
                    String orig = ctx.newFieldToOrig.get(scopeName);
                    if (orig != null) {
                        if (sc instanceof NameExpr ne6) ne6.setName(orig);
                        else if (sc instanceof TypeExpr) mre.setScope(new NameExpr(orig));
                    }
                }
            }

            return super.visit(mre, arg);
        }

        // ── Core reverse-lookup ───────────────────────────────────────────────

        /**
         * Looks up the original method name for an obfuscated method.
         *
         * <p>Builds the reverse key {@code "origFqcn|obfName|origParamTypes"} and
         * queries {@link DeobfuscationContext#methodRev}.  The parameter types come
         * from the resolved declaration, which is already working against original
         * class names (Phase 1a completed before Phase 2 runs).
         *
         * <p>If the direct hit fails, walks the superclass chain using the same key
         * structure so that inherited methods are also reverted correctly.
         *
         * @param rmd         resolved declaration of the method being visited
         * @param currentName the method's current (obfuscated) simple name
         * @return original name, or {@code null} if not found
         */
        private String lookupMethod(ResolvedMethodDeclaration rmd, String currentName) {
            String dt = rmd.declaringType().getQualifiedName();

            // Build the comma-joined parameter types exactly as the obfuscator did
            String params = buildParamTypes(rmd);

            // Direct hit: origFqcn|obfName|origParamTypes
            String key = dt + "|" + currentName + "|" + params;
            String orig = ctx.methodRev.get(key);
            if (orig != null) return orig;

            // Walk superclass hierarchy — the method may be declared on a parent
            String parent = ctx.superclassObfMap.get(dt);
            java.util.Set<String> visited = new java.util.HashSet<>();
            while (parent != null && visited.add(parent)) {
                String inheritedKey = parent + "|" + currentName + "|" + params;
                orig = ctx.methodRev.get(inheritedKey);
                if (orig != null) return orig;
                parent = ctx.superclassObfMap.get(parent);
            }

            return null;
        }

        /**
         * Fallback used when symbol resolution has failed for a {@link MethodReferenceExpr}.
         *
         * <p>Performs a prefix scan on {@link DeobfuscationContext#methodRev} for all
         * keys matching {@code "origFqcn|obfName|*"}.  Returns a result only when
         * exactly one match is found to avoid misidentifying one overload for another.
         *
         * @param origFq     original (not obfuscated) fully-qualified declaring type
         * @param obfName    current obfuscated method name
         */
        private String lookupMethodByOrigTypeAndObfName(String origFq, String obfName) {
            String prefix = origFq + "|" + obfName + "|";
            java.util.List<String> matches = ctx.methodRev.entrySet().stream()
                    .filter(e -> e.getKey().startsWith(prefix))
                    .map(java.util.Map.Entry::getValue)
                    .distinct()
                    .collect(java.util.stream.Collectors.toList());

            // Only return when unambiguous — if multiple overloads share the same obf
            // name (unusual but possible), we cannot determine which original to restore.
            return matches.size() == 1 ? matches.get(0) : null;
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        /**
         * Produces the comma-joined parameter type string for a resolved method.
         * Matches the format written by {@link com.example.obfuscator.resolver.SymbolResolverUtils#methodKey}.
         */
        private static String buildParamTypes(ResolvedMethodDeclaration rmd) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < rmd.getNumberOfParams(); i++) {
                if (i > 0) sb.append(",");
                try { sb.append(rmd.getParam(i).getType().describe()); }
                catch (Throwable t) { sb.append("?"); }
            }
            return sb.toString();
        }

        private String extractScopeName(Expression sc) {
            if (sc instanceof NameExpr ne) return ne.getNameAsString();
            if (sc instanceof TypeExpr te) {
                String raw = te.getType().toString();
                int lt = raw.indexOf('<');
                if (lt > 0) raw = raw.substring(0, lt);
                int dot = raw.lastIndexOf('.');
                return dot >= 0 ? raw.substring(dot + 1) : raw;
            }
            return null;
        }
    }
}
