package com.example.obfuscator.deobf.core;

import com.example.obfuscator.util.ASTUtils;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * All state needed during deobfuscation, loaded from {@code mapping.json}.
 * Indexes are built once in the constructor and are read-only during pipeline passes.
 *
 * <h3>methodRev key format</h3>
 * The reverse method lookup map uses the key:
 * <pre>
 *   origFqcn|obfMethodName|origParamTypes
 * </pre>
 * For example, a method {@code com.example.Foo.process(String,int)} that was renamed to
 * {@code fetchMatrix} produces the key:
 * <pre>
 *   com.example.Foo|fetchMatrix|java.lang.String,int
 * </pre>
 *
 * <p>This format is symmetric with the forward map key used during obfuscation
 * ({@code "origFqcn|origMethodName|origParamTypes"}) — only the method name segment
 * differs (obf name vs original name).  The {@link com.example.obfuscator.deobf.passes.Phase2MethodReverter}
 * builds the same key at query time using the resolved declaring type and param types
 * (which are back to their original forms after Phase 1a).
 */
public final class DeobfuscationContext {

    // ── Loaded from mapping.json ─────────────────────────────────────────────

    /** origFQ → newSimpleName */
    public final Map<String, String> origToNew;
    /** obfFQ  → origFQ */
    public final Map<String, String> obfFqToOrig;
    /** newSimpleName → origSimpleName */
    public final Map<String, String> newSimpleToOrig;
    /** obfuscated metamodel name → original metamodel name */
    public final Map<String, String> metamodelRev;

    /**
     * Reverse method lookup.
     *
     * <p>Key: {@code "origFqcn|obfMethodName|origParamTypes"}
     * <br>Value: original method simple name
     *
     * <p>Built from each entry in the {@code "methods"} JSON array using the
     * {@code "descriptor"} field (canonical forward key) plus the {@code "newName"}
     * field as the obfuscated name segment.
     */
    public final Map<String, String> methodRev;

    /** Key: {@code "obfFQ|newFieldName"} → original field name */
    public final Map<String, String> fieldByObfFq;
    /** Key: {@code "origFQ|newFieldName"} → original field name */
    public final Map<String, String> fieldByOrigFq;
    /** newFieldName → origFieldName (flat global reverse) */
    public final Map<String, String> newFieldToOrig;
    /** obfTypeFQ → set of all obfuscated field names it declares */
    public final Map<String, Set<String>> obfTypeNewFields;
    /** All obfuscated field names across the project */
    public final Set<String> allNewFieldNames;
    /** Superclass map keyed on OBFUSCATED FQs (and also original FQs) */
    public final Map<String, String> superclassObfMap;
    /** Record component info: origTypeFQ → list of {original, new} component pairs */
    public final Map<String, List<Map<String, String>>> recordComponentsByType;

    // ── Filesystem paths ─────────────────────────────────────────────────────

    public final Path obfProject;
    public final Path deofProject;
    public final Path srcRoot;

    // ── Live AST state (populated during pipeline) ────────────────────────────

    public final Map<com.github.javaparser.ast.body.TypeDeclaration<?>, String> typeObfFq
            = new IdentityHashMap<>();

    // ── Construction ─────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public DeobfuscationContext(Path obfProject, Map<String, Object> mapping) {
        this.obfProject = obfProject;

        String folderName = obfProject.getFileName().toString();
        String outName = folderName.endsWith("-obf")
                ? folderName.substring(0, folderName.length() - 4) + "-orj"
                : folderName + "-orj";
        this.deofProject = obfProject.resolveSibling(outName);
        this.srcRoot = deofProject.resolve("src/main/java");

        // classMap
        Map<String, String> origToNewTmp       = new HashMap<>();
        Map<String, String> obfFqToOrigTmp     = new HashMap<>();
        Map<String, String> newSimpleToOrigTmp = new HashMap<>();

        for (var m : (List<Map<String, String>>) mapping.getOrDefault("classMap", List.of())) {
            String origFq    = m.get("original");
            String newSimple = m.get("newSimple");
            origToNewTmp.put(origFq, newSimple);
            int dot = origFq.lastIndexOf('.');
            String pkg = dot >= 0 ? origFq.substring(0, dot) : "";
            String obfFq = pkg.isEmpty() ? newSimple : pkg + "." + newSimple;
            obfFqToOrigTmp.put(obfFq, origFq);
            newSimpleToOrigTmp.put(newSimple, ASTUtils.simpleName(origFq));
        }
        this.origToNew       = Collections.unmodifiableMap(origToNewTmp);
        this.obfFqToOrig     = Collections.unmodifiableMap(obfFqToOrigTmp);
        this.newSimpleToOrig = Collections.unmodifiableMap(newSimpleToOrigTmp);

        // metamodelMap
        Map<String, String> mmRev = new HashMap<>();
        for (var x : (List<Map<String, String>>) mapping.getOrDefault("metamodelMap", List.of()))
            mmRev.put(x.get("new"), x.get("original"));
        this.metamodelRev = Collections.unmodifiableMap(mmRev);

        // methods — reverse lookup keyed by "origFqcn|obfName|origParamTypes"
        //
        // The forward key (stored as "descriptor" in mapping.json) has the format:
        //   "origFqcn|origMethodName|origParamTypes"
        //
        // We build the REVERSE key by replacing segment [1] (origMethodName) with the
        // obfuscated name.  This lets Phase2MethodReverter query:
        //   methodRev.get(resolvedDt + "|" + currentObfName + "|" + resolvedParams)
        // and get the original name back.
        Map<String, String> mRev = new HashMap<>();
        for (var me : (List<Map<String, Object>>) mapping.getOrDefault("methods", List.of())) {
            String origN = (String) me.get("originalName");
            String newN  = (String) me.get("newName");        // obfuscated name
            String descriptor = (String) me.get("descriptor"); // "fqcn|origName|params"

            if (descriptor == null || descriptor.isBlank()) continue;

            // Parse the descriptor to extract fqcn and paramTypes
            String[] parts = descriptor.split("\\|", 3);
            if (parts.length < 2) continue;

            String fqcn      = parts[0];                          // "com.example.Foo"
            String paramTypes = parts.length == 3 ? parts[2] : ""; // "java.lang.String,int"

            // Reverse key: origFqcn|obfName|origParamTypes
            String reverseKey = fqcn + "|" + newN + "|" + paramTypes;
            mRev.put(reverseKey, origN);
        }
        this.methodRev = Collections.unmodifiableMap(mRev);

        // fields
        Map<String, String>        byObf      = new HashMap<>();
        Map<String, String>        byOrig     = new HashMap<>();
        Map<String, String>        newToOrig  = new HashMap<>();
        Map<String, Set<String>>   typeFields = new HashMap<>();

        for (var fe : (List<Map<String, String>>) mapping.getOrDefault("fields", List.of())) {
            String origDt = fe.get("declaringType");
            String origFn = fe.get("originalName");
            String newFn  = fe.get("newName");
            byOrig.put(origDt + "|" + newFn, origFn);
            String obfDt = ASTUtils.toObfFq(origDt, origToNewTmp);
            byObf.put(obfDt + "|" + newFn, origFn);
            newToOrig.put(newFn, origFn);
            typeFields.computeIfAbsent(obfDt, k -> new HashSet<>()).add(newFn);
        }
        this.fieldByObfFq     = Collections.unmodifiableMap(byObf);
        this.fieldByOrigFq    = Collections.unmodifiableMap(byOrig);
        this.newFieldToOrig   = Collections.unmodifiableMap(newToOrig);
        this.obfTypeNewFields = Collections.unmodifiableMap(typeFields);
        this.allNewFieldNames = Collections.unmodifiableSet(new HashSet<>(newToOrig.keySet()));

        // superclassMap
        Map<String, String> scObf = new HashMap<>();
        for (var sc : (List<Map<String, String>>) mapping.getOrDefault("superclassMap", List.of())) {
            String childOrig  = sc.get("child");
            String parentOrig = sc.get("parent");
            String childObf   = ASTUtils.toObfFq(childOrig, origToNewTmp);
            String parentObf  = ASTUtils.toObfFq(parentOrig, origToNewTmp);
            scObf.put(childObf, parentObf);
            scObf.put(childOrig, parentOrig);
        }
        this.superclassObfMap = Collections.unmodifiableMap(scObf);

        // recordComponents
        Map<String, List<Map<String, String>>> rcMap = new HashMap<>();
        for (var rc : (List<Map<String, Object>>) mapping.getOrDefault("recordComponents", List.of())) {
            String typeFq = (String) rc.get("type");
            rcMap.put(typeFq, (List<Map<String, String>>) rc.get("components"));
        }
        this.recordComponentsByType = Collections.unmodifiableMap(rcMap);
    }

    // ── Factory ───────────────────────────────────────────────────────────────

    public static DeobfuscationContext load(Path obfProject) throws IOException {
        Path mappingFile = obfProject.resolve("mapping.json");
        if (!Files.exists(mappingFile))
            throw new IllegalStateException("mapping.json not found in: " + obfProject);

        ObjectMapper om = JsonMapper.builder().build();
        @SuppressWarnings("unchecked")
        Map<String, Object> mapping = om.readValue(mappingFile.toFile(), Map.class);
        return new DeobfuscationContext(obfProject, mapping);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public String fieldLookup(String typeFq, String newFieldName) {
        String v = fieldByObfFq.get(typeFq + "|" + newFieldName);
        return v != null ? v : fieldByOrigFq.get(typeFq + "|" + newFieldName);
    }

    public String fieldLookupInHierarchy(String startObfFq, String newFieldName) {
        String fq = startObfFq;
        Set<String> visited = new HashSet<>();
        while (fq != null && visited.add(fq)) {
            String v = fieldLookup(fq, newFieldName);
            if (v != null) return v;
            fq = superclassObfMap.get(fq);
        }
        return null;
    }
}
