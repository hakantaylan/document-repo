package com.example.obfuscator.obf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.RenameContext;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;

import java.util.Optional;

/**
 * V5 — renames Lombok {@code @Getter} / {@code @Setter} calls and
 * record component accessor calls.
 *
 * <p>Case A: {@code call.resolve()} throws (Lombok-generated method not in source).
 * The field name is derived from the method name prefix and looked up in
 * {@code fieldMap} after resolving the scope type.
 *
 * <p>Case B: {@code call.resolve()} succeeds for an explicit getter/setter but the
 * method was generated from a renamed field that is not in {@code methodMap}.
 * We catch it here by checking whether the derived field name exists in
 * {@code fieldMap} for the resolved declaring type.
 *
 * <p>Safety: infrastructure types (jakarta, spring, …) are never touched.
 * The unique-value fallback is gated on a positively-identified project owner.
 */
public class AccessorVisitor extends ModifierVisitor<Void> {

    private final RenameContext ctx;

    public AccessorVisitor(RenameContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public Visitable visit(MethodCallExpr mce, Void arg) {
        Visitable result = super.visit(mce, arg);
        if (!(result instanceof MethodCallExpr call)) return result;
        if (call.getScope().isEmpty()) return result;

        String methodName = call.getNameAsString();
        String prefix     = AstUtils.accessorPrefix(methodName);
        String origField  = AstUtils.derivedFieldName(methodName, prefix);
        if (origField == null) return result;
        if (!ctx.allRenamedOrigFieldNames.contains(origField)) return result;

        // 1) Resolve the method directly (best case — explicit getter or record accessor)
        String ownerFq = null;
        try {
            ResolvedMethodDeclaration rmd = call.resolve();
            String dt = rmd.declaringType().getQualifiedName();
            if (AstUtils.isInfrastructureFq(dt)) return result;
            ownerFq = dt;
        } catch (Throwable ignored) {
            // 2) Resolve scope type — symbol solver + textual fallbacks
            ownerFq = AstUtils.resolveScopeOwnerFq(call.getScope().get(), ctx.classMap);
            if (ownerFq != null && AstUtils.isInfrastructureFq(ownerFq)) return result;
        }

        // 3) Lookup new field name
        String newFieldName = null;
        if (ownerFq != null) {
            newFieldName = ctx.fieldMap.get(ownerFq + "|" + origField);
            if (newFieldName == null) {
                // Reverse-map obfuscated simple name → original FQ
                String ownerSimple = ownerFq.contains(".") ? ownerFq.substring(ownerFq.lastIndexOf('.') + 1) : ownerFq;
                Optional<String> maybeOrig = ctx.classMap.entrySet().stream()
                        .filter(e -> e.getValue().equals(ownerSimple)).map(Map.Entry::getKey).findFirst();
                if (maybeOrig.isPresent())
                    newFieldName = ctx.fieldMap.get(maybeOrig.get() + "|" + origField);
            }
        }

        // 4) Unique fallback — only when owner is a known project class
        if (newFieldName == null && ownerFq != null && !AstUtils.isInfrastructureFq(ownerFq))
            newFieldName = ctx.uniqueValueForField(origField);
        if (newFieldName == null) return result;

        String newMethodName = prefix.isEmpty()
                ? newFieldName
                : prefix + Character.toUpperCase(newFieldName.charAt(0)) + newFieldName.substring(1);
        call.setName(newMethodName);
        return call;
    }
}
