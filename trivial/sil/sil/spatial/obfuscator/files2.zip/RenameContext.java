package com.example.obfuscator;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Mutable state shared across all obfuscation passes:
 * the rename maps that are built during collection passes and read during
 * the apply pass, plus the {@link NameGenerator} that mints new names.
 *
 * <p>Key formats:
 * <ul>
 *   <li>{@code classMap}   — {@code origFQ → newSimple}</li>
 *   <li>{@code methodMap}  — {@code MethodKey → newName}</li>
 *   <li>{@code fieldMap}   — {@code "origFQ|origFieldName" → newName}</li>
 *   <li>{@code metamodelMap}  — {@code "OldSimple_" → "NewSimple_"}</li>
 *   <li>{@code superclassMap} — {@code origChildFQ → origParentFQ}</li>
 * </ul>
 */
public final class RenameContext {

    // ── Core rename maps ──────────────────────────────────────────────────────────

    public final Map<String, String>         classMap       = new LinkedHashMap<>();
    public final Map<MethodKey, String>      methodMap      = new HashMap<>();
    public final Map<String, String>         fieldMap       = new LinkedHashMap<>();
    public final Map<String, String>         metamodelMap   = new HashMap<>();
    public final Map<String, String>         superclassMap  = new LinkedHashMap<>();

    // ── Derived / cached structures ───────────────────────────────────────────────

    /**
     * All original field names that were renamed.
     * Used as a fast pre-filter before doing type-based lookup.
     */
    public final Set<String> allRenamedOrigFieldNames = new HashSet<>();

    /**
     * originalFieldName → newFieldName, only for names that are unique project-wide.
     * Built after PASS 3 completes.  Used as a safe fallback when type resolution fails.
     */
    public final Map<String, String> flatFieldRenames = new HashMap<>();

    // ── Name generator ────────────────────────────────────────────────────────────

    public final NameGenerator nameGen = new NameGenerator();

    // ── Flat-map builder ──────────────────────────────────────────────────────────

    /**
     * Populate {@link #flatFieldRenames} from the completed {@link #fieldMap}.
     * Must be called once after all field renames have been collected (end of PASS 3).
     */
    public void buildFlatFieldRenames() {
        flatFieldRenames.clear();
        Map<String, List<String>> byOrigName = new HashMap<>();
        for (var e : fieldMap.entrySet()) {
            int sep = e.getKey().lastIndexOf('|');
            if (sep < 0) continue;
            String origName = e.getKey().substring(sep + 1);
            byOrigName.computeIfAbsent(origName, k -> new ArrayList<>()).add(e.getValue());
        }
        for (var e : byOrigName.entrySet())
            if (e.getValue().size() == 1) flatFieldRenames.put(e.getKey(), e.getValue().get(0));
    }

    // ── Lookup helpers ────────────────────────────────────────────────────────────

    /**
     * Returns the obfuscated name when ALL fieldMap entries for this original field
     * name share the same new name — meaning the field is declared exactly once in
     * the project (possibly inherited by subclasses that don't re-declare it).
     */
    public String uniqueValueForField(String originalName) {
        List<String> distinct = fieldMap.entrySet().stream()
                .filter(e -> e.getKey().endsWith("|" + originalName))
                .map(Map.Entry::getValue).distinct()
                .collect(Collectors.toList());
        return distinct.size() == 1 ? distinct.get(0) : null;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // MethodKey
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Value type wrapping a method descriptor string used as a map key.
     * Format: {@code "fully.qualified.ClassName.methodName#(param1,param2)"}
     */
    public static final class MethodKey {
        public final String key;

        public MethodKey(String key) { this.key = key; }

        @Override public boolean equals(Object o) { return o instanceof MethodKey mk && mk.key.equals(key); }
        @Override public int hashCode()            { return key.hashCode(); }
        @Override public String toString()         { return key; }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // NameGenerator
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Produces deterministic obfuscated names seeded at construction time.
     * Class bases use {@code FlowerAnimalN}, pure utility classes use {@code FakeAnimalN},
     * methods use {@code mAnimalN}, fields use {@code fFlowerN}.
     */
    public static final class NameGenerator {

        private final Random rnd = new Random(123456789L);
        private final AtomicInteger counter = new AtomicInteger(1);
        private final Set<String> used = new HashSet<>();

        private static final List<String> FLOWERS = List.of(
                "Rose", "Lily", "Orchid", "Tulip", "Iris",
                "Daisy", "Marigold", "Lotus", "Poppy", "Violet");
        private static final List<String> ANIMALS = List.of(
                "Fox", "Hare", "Sparrow", "Otter", "Badger",
                "Falcon", "Bee", "Stag", "Wren", "Lynx");
        private static final List<String> FAKES = List.of(
                "Zorblin", "Quax", "Mimra", "Blinx", "Vorun",
                "Kezel", "Gorim", "Nexu", "Sibra", "Yulon");

        private String pick(List<String> l) { return l.get(rnd.nextInt(l.size())); }

        /** Returns e.g. {@code "RoseFox3"} — used as prefix before a preserved suffix. */
        public String nextClassBase() {
            String v;
            do { v = pick(FLOWERS) + pick(ANIMALS) + counter.getAndIncrement(); } while (!used.add(v));
            return v;
        }

        /** Returns e.g. {@code "ZorblinFox7"} — for classes without a preserved suffix. */
        public String nextClassName() {
            String v;
            do { v = pick(FAKES) + pick(ANIMALS) + counter.getAndIncrement(); } while (!used.add(v));
            return v;
        }

        /** Returns e.g. {@code "mFalcon12"}. */
        public String nextMethodName() {
            String v;
            do { v = "m" + pick(ANIMALS) + counter.getAndIncrement(); } while (!used.add(v));
            return Character.toLowerCase(v.charAt(0)) + v.substring(1);
        }

        /** Returns e.g. {@code "fLily5"}. */
        public String nextFieldName() {
            String v;
            do { v = "f" + pick(FLOWERS) + counter.getAndIncrement(); } while (!used.add(v));
            return Character.toLowerCase(v.charAt(0)) + v.substring(1);
        }
    }
}
