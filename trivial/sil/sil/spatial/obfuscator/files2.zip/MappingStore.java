package com.example.obfuscator;

import tools.jackson.databind.ObjectMapper;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Reads and writes {@code mapping.json} — the artifact that links every obfuscated
 * name back to its original and allows the deobfuscator to reverse the
 * process.
 *
 * <p>JSON structure:
 * <pre>
 * {
 *   "metadata":       { "timestamp": "...", "seed": 123456789 },
 *   "classMap":       [ { "original": "...", "newSimple": "..." }, ... ],
 *   "originalTopLevel": [ { "relativePath": "...", "originalFq": "..." }, ... ],
 *   "metamodelMap":   [ { "original": "...", "new": "..." }, ... ],
 *   "superclassMap":  [ { "child": "...", "parent": "..." }, ... ],
 *   "methods":        [ { "declaringType", "originalName", "paramTypes", "descriptor", "newName" }, ... ],
 *   "fields":         [ { "declaringType", "originalName", "newName" }, ... ]
 * }
 * </pre>
 */
public final class MappingStore {

    private static final ObjectMapper OM = new ObjectMapper();

    private MappingStore() {}

    // ── Write ─────────────────────────────────────────────────────────────────────

    /**
     * Serialises the complete rename context to {@code <obfRoot>/mapping.json} and
     * also writes a human-readable {@code obfuscation-mapping.txt} alongside it.
     */
    public static void write(RenameContext ctx, Path obfRoot, Path projectRoot,
                             Map<Path, String> topOrigFq) throws IOException {

        // ── Human-readable text mapping ───────────────────────────────────────────
        try (BufferedWriter w = Files.newBufferedWriter(obfRoot.resolve("obfuscation-mapping.txt"))) {
            w.write("# classMap\n");
            ctx.classMap.forEach((k, v) -> writeLine(w, k + " -> " + v));
            w.write("\n# metamodelMap\n");
            ctx.metamodelMap.forEach((k, v) -> writeLine(w, k + " -> " + v));
            w.write("\n# superclassMap\n");
            ctx.superclassMap.forEach((k, v) -> writeLine(w, k + " -> " + v));
            w.write("\n# methodMap\n");
            ctx.methodMap.forEach((k, v) -> writeLine(w, k.key + " -> " + v));
            w.write("\n# fieldMap\n");
            ctx.fieldMap.forEach((k, v) -> writeLine(w, k + " -> " + v));
        }

        // ── JSON mapping ──────────────────────────────────────────────────────────
        Map<String, Object> root = new LinkedHashMap<>();

        root.put("metadata", Map.of(
                "timestamp", java.time.Instant.now().toString(),
                "seed", 123456789));

        root.put("classMap", ctx.classMap.entrySet().stream()
                .map(e -> Map.of("original", e.getKey(), "newSimple", e.getValue()))
                .collect(Collectors.toList()));

        root.put("originalTopLevel", topOrigFq.entrySet().stream()
                .map(e -> Map.of(
                        "relativePath", projectRoot.relativize(e.getKey()).toString().replace('\\', '/'),
                        "originalFq", e.getValue()))
                .collect(Collectors.toList()));

        root.put("metamodelMap", ctx.metamodelMap.entrySet().stream()
                .map(e -> Map.of("original", e.getKey(), "new", e.getValue()))
                .collect(Collectors.toList()));

        root.put("superclassMap", ctx.superclassMap.entrySet().stream()
                .map(e -> Map.of("child", e.getKey(), "parent", e.getValue()))
                .collect(Collectors.toList()));

        root.put("methods", ctx.methodMap.entrySet().stream().map(e -> {
            String key   = e.getKey().key;
            int hash     = key.indexOf('#');
            String prefix = hash >= 0 ? key.substring(0, hash) : key;
            int dot       = prefix.lastIndexOf('.');
            String dt     = dot >= 0 ? prefix.substring(0, dot) : "";
            String name   = dot >= 0 ? prefix.substring(dot + 1) : prefix;
            List<String> params = new ArrayList<>();
            int ps = key.indexOf('('), pe = key.indexOf(')');
            if (ps >= 0 && pe > ps + 1)
                for (String s : key.substring(ps + 1, pe).split(",")) params.add(s.trim());
            return Map.of("declaringType", dt, "originalName", name,
                    "paramTypes", params, "descriptor", key, "newName", e.getValue());
        }).collect(Collectors.toList()));

        root.put("fields", ctx.fieldMap.entrySet().stream().map(e -> {
            int sep = e.getKey().lastIndexOf('|');
            return Map.of(
                    "declaringType", sep >= 0 ? e.getKey().substring(0, sep) : e.getKey(),
                    "originalName",  sep >= 0 ? e.getKey().substring(sep + 1) : e.getKey(),
                    "newName", e.getValue());
        }).collect(Collectors.toList()));

        OM.writerWithDefaultPrettyPrinter().writeValue(obfRoot.resolve("mapping.json").toFile(), root);
        System.out.println("Mapping written to " + obfRoot.resolve("mapping.json"));
    }

    // ── Read ──────────────────────────────────────────────────────────────────────

    /**
     * Loads and parses {@code mapping.json} from the given obfuscated project root.
     * Returns the raw deserialized map; callers build their own typed context from it.
     *
     * @throws IllegalStateException when the file is missing (exits with code 3)
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> read(Path obfProject) throws IOException {
        Path mappingFile = obfProject.resolve("mapping.json");
        if (!Files.exists(mappingFile)) {
            System.err.println("mapping.json not found in: " + obfProject);
            System.exit(3);
        }
        return OM.readValue(mappingFile.toFile(), Map.class);
    }

    // ── Private helpers ───────────────────────────────────────────────────────────

    private static void writeLine(BufferedWriter w, String line) {
        try { w.write(line + "\n"); }
        catch (IOException e) { throw new RuntimeException(e); }
    }
}
