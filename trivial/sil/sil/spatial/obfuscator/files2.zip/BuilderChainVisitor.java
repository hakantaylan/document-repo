package com.example.obfuscator.obf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.RenameContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;

import java.util.Optional;

/**
 * V4 — renames Lombok {@code @Builder} / {@code @SuperBuilder} setter calls.
 *
 * <p>Lombok-generated builder setters (e.g. {@code .name("x")}) are absent from
 * source, so the symbol solver cannot resolve them.  This visitor identifies the
 * builder owner type by walking the scope chain to find {@code .builder()}, then
 * looks up the field rename in {@code fieldMap}.  Inherited fields are handled by
 * {@link #findFieldInHierarchy} which walks the type solver's ancestor chain.
 */
public class BuilderChainVisitor extends ModifierVisitor<Void> {

    private final RenameContext      ctx;
    private final CombinedTypeSolver solver;

    public BuilderChainVisitor(RenameContext ctx, CombinedTypeSolver solver) {
        this.ctx    = ctx;
        this.solver = solver;
    }

    @Override
    public Visitable visit(MethodCallExpr mce, Void arg) {
        Visitable result = super.visit(mce, arg); // bottom-up
        if (!(result instanceof MethodCallExpr call)) return result;
        String methodName = call.getNameAsString();
        if (!ctx.allRenamedOrigFieldNames.contains(methodName)) return result;

        // 1) Identify builder owner via chain walking
        String ownerOrigFq = resolveBuilderOwner(call);

        // 2) Symbol solver fallback
        if (ownerOrigFq == null && call.getScope().isPresent())
            ownerOrigFq = AstUtils.resolveScopeTypeFq(call.getScope().get());

        // 3) Textual fallback (parameter / field declared type)
        if (ownerOrigFq == null && call.getScope().isPresent())
            ownerOrigFq = AstUtils.resolveScopeOwnerFq(call.getScope().get(), ctx.classMap);

        // 4) Exact + hierarchy lookup
        if (ownerOrigFq != null) {
            String newName = lookupWithHierarchy(ownerOrigFq, methodName);
            if (newName != null) { call.setName(newName); return call; }
        }

        // 5) Unique-across-project fallback — only when owner is a known project class
        if (ownerOrigFq != null && !AstUtils.isInfrastructureFq(ownerOrigFq)) {
            String newName = ctx.uniqueValueForField(methodName);
            if (newName != null) call.setName(newName);
        }
        return call;
    }

    // ── Builder-chain owner resolution ───────────────────────────────────────────

    private String resolveBuilderOwner(MethodCallExpr mce) {
        Optional<Expression> scopeOpt = mce.getScope();
        while (scopeOpt.isPresent()) {
            Expression scope = scopeOpt.get();
            if (scope instanceof MethodCallExpr scopeCall) {
                if ("builder".equals(scopeCall.getNameAsString()))
                    return resolveBuilderClass(scopeCall.getScope().orElse(null));
                scopeOpt = scopeCall.getScope();
            } else break;
        }
        return null;
    }

    private String resolveBuilderClass(Expression scopeExpr) {
        if (scopeExpr == null) return null;
        String qualifiedText = null, simpleName = null;
        if (scopeExpr instanceof NameExpr ne) {
            simpleName = qualifiedText = ne.getNameAsString();
        } else if (scopeExpr instanceof FieldAccessExpr fae) {
            StringBuilder sb = new StringBuilder();
            Expression cur = fae;
            while (cur instanceof FieldAccessExpr f) {
                if (sb.length() > 0) sb.insert(0, '.');
                sb.insert(0, f.getNameAsString());
                cur = f.getScope();
            }
            if (cur instanceof NameExpr n) { if (sb.length() > 0) sb.insert(0, '.'); sb.insert(0, n.getNameAsString()); }
            qualifiedText = sb.toString();
            if (!qualifiedText.isEmpty()) simpleName = qualifiedText.substring(qualifiedText.lastIndexOf('.') + 1);
        } else if (scopeExpr instanceof ClassExpr ce && ce.getType().isClassOrInterfaceType()) {
            simpleName = qualifiedText = ce.getType().asClassOrInterfaceType().getNameAsString();
        }
        if (qualifiedText != null && !qualifiedText.isBlank()) {
            final String qt = qualifiedText;
            Optional<String> hit = ctx.ctx.classMap.keySet().stream().filter(fq -> fq.equals(qt) || fq.endsWith("." + qt)).findFirst();
            if (hit.isPresent()) return hit.get();
        }
        if (simpleName != null && !simpleName.isBlank()) {
            final String sn = simpleName;
            Optional<String> hit = ctx.ctx.classMap.keySet().stream().filter(fq -> fq.endsWith("." + sn) || fq.equals(sn)).findFirst();
            if (hit.isPresent()) return hit.get();
            hit = ctx.ctx.classMap.entrySet().stream().filter(e -> e.getValue().equals(sn)).map(Map.Entry::getKey).findFirst();
            if (hit.isPresent()) return hit.get();
        }
        return null;
    }

    // ── Field lookup with hierarchy ───────────────────────────────────────────────

    private String lookupWithHierarchy(String ownerFq, String fieldName) {
        // Direct lookup
        String v = ctx.fieldMap.get(ownerFq + "|" + fieldName);
        if (v != null) return v;

        // Reverse-map obfuscated simple name → original FQ
        String ownerSimple = ownerFq.contains(".") ? ownerFq.substring(ownerFq.lastIndexOf('.') + 1) : ownerFq;
        Optional<String> maybeOrig = ctx.classMap.entrySet().stream()
                .filter(e -> e.getValue().equals(ownerSimple)).map(Map.Entry::getKey).findFirst();
        if (maybeOrig.isPresent()) {
            v = ctx.fieldMap.get(maybeOrig.get() + "|" + fieldName);
            if (v != null) return v;
            v = findFieldInHierarchy(maybeOrig.get(), fieldName);
            if (v != null) return v;
        }
        return findFieldInHierarchy(ownerFq, fieldName);
    }

    private String findFieldInHierarchy(String ownerOrigFq, String origFieldName) {
        if (ownerOrigFq == null) return null;
        try {
            var decl = solver.solveType(ownerOrigFq);
            String key = decl.getQualifiedName() + "|" + origFieldName;
            if (ctx.fieldMap.containsKey(key)) return ctx.fieldMap.get(key);
            for (var anc : decl.getAllAncestors()) {
                try {
                    if (anc.getTypeDeclaration().isPresent()) {
                        String afq = anc.getTypeDeclaration().get().getQualifiedName();
                        String k = afq + "|" + origFieldName;
                        if (ctx.fieldMap.containsKey(k)) return ctx.fieldMap.get(k);
                    }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return null;
    }
}
