package com.example.obfuscator;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Shared static utilities used by both the obfuscator and deobfuscator:
 * AST navigation, symbol resolution helpers, and infrastructure guards.
 */
public final class AstUtils {

    private AstUtils() {}

    // ── Infrastructure guard ──────────────────────────────────────────────────────

    /**
     * Returns true when an FQ class name belongs to a framework / JDK package
     * that must never be renamed or have its methods/fields touched.
     */
    public static boolean isInfrastructureFq(String fq) {
        if (fq == null) return false;
        return fq.startsWith("java.")
                || fq.startsWith("javax.")
                || fq.startsWith("jakarta.")
                || fq.startsWith("org.springframework")
                || fq.startsWith("org.hibernate")
                || fq.startsWith("com.fasterxml")
                || fq.startsWith("org.mapstruct")
                || fq.startsWith("org.slf4j")
                || fq.startsWith("ch.qos.logback")
                || fq.startsWith("org.apache")
                || fq.startsWith("io.swagger")
                || fq.startsWith("springfox")
                || fq.startsWith("com.google")
                || fq.startsWith("org.junit")
                || fq.startsWith("org.mockito");
    }

    /** Returns true when a package name belongs to infrastructure and should be skipped entirely. */
    public static boolean excludePkg(String pkg) {
        if (pkg == null) return false;
        return pkg.startsWith("java.") || pkg.startsWith("javax.") || pkg.startsWith("jakarta.")
                || pkg.startsWith("org.springframework") || pkg.startsWith("com.fasterxml")
                || pkg.startsWith("org.mapstruct");
    }

    // ── FQ name computation ───────────────────────────────────────────────────────

    /**
     * Computes the fully-qualified name of a type declaration by walking up the
     * AST nesting chain and prepending the compilation unit's package.
     */
    public static String computeFq(TypeDeclaration<?> td, CompilationUnit cu) {
        StringBuilder sb = new StringBuilder(td.getNameAsString());
        Node cur = td.getParentNode().orElse(null);
        while (cur instanceof TypeDeclaration<?> p) {
            sb.insert(0, p.getNameAsString() + ".");
            cur = p.getParentNode().orElse(null);
        }
        String pkg = cu.getPackageDeclaration().map(PackageDeclaration::getNameAsString).orElse("");
        return pkg.isEmpty() ? sb.toString() : pkg + "." + sb;
    }

    /** Returns the simple name from a fully-qualified class name. */
    public static String simpleName(String fq) {
        int d = fq.lastIndexOf('.');
        return d >= 0 ? fq.substring(d + 1) : fq;
    }

    // ── Method key ────────────────────────────────────────────────────────────────

    /**
     * Builds a stable string descriptor for a resolved method declaration.
     * Format: {@code "fully.qualified.ClassName.methodName#(paramType1,paramType2)"}
     */
    public static String methodKey(ResolvedMethodDeclaration rmd) {
        StringBuilder sb = new StringBuilder();
        try {
            sb.append(rmd.getQualifiedName());
        } catch (Throwable t) {
            try {
                sb.append(rmd.declaringType().getQualifiedName()).append(".").append(rmd.getName());
            } catch (Throwable ignored) {
                sb.append(rmd.getName());
            }
        }
        sb.append("#(");
        for (int i = 0; i < rmd.getNumberOfParams(); i++) {
            if (i > 0) sb.append(",");
            try { sb.append(rmd.getParam(i).getType().describe()); }
            catch (Throwable ignored) { sb.append("?"); }
        }
        sb.append(")");
        return sb.toString();
    }

    // ── Accessor helpers ──────────────────────────────────────────────────────────

    /**
     * Returns {@code "get"}, {@code "set"}, {@code "is"}, or {@code ""}
     * (record / no-prefix accessor).
     */
    public static String accessorPrefix(String methodName) {
        if (methodName.length() > 3 && methodName.startsWith("get") && Character.isUpperCase(methodName.charAt(3))) return "get";
        if (methodName.length() > 3 && methodName.startsWith("set") && Character.isUpperCase(methodName.charAt(3))) return "set";
        if (methodName.length() > 2 && methodName.startsWith("is")  && Character.isUpperCase(methodName.charAt(2))) return "is";
        return "";
    }

    /**
     * Derives the field name from an accessor method name given its prefix.
     * e.g. {@code "getName", "get" → "name"};  {@code "weight", "" → "weight"}.
     * Returns null when the result would be empty.
     */
    public static String derivedFieldName(String methodName, String prefix) {
        if (prefix.isEmpty()) return methodName.isEmpty() ? null : methodName;
        String rest = methodName.substring(prefix.length());
        if (rest.isEmpty()) return null;
        return Character.toLowerCase(rest.charAt(0)) + rest.substring(1);
    }

    // ── Scope type resolution ─────────────────────────────────────────────────────

    /**
     * Attempts to resolve the declared type of a scope expression to a fully-qualified
     * class name by interrogating the symbol solver.
     * Works for {@link NameExpr}, {@link FieldAccessExpr}, and {@link MethodCallExpr}.
     * Returns null on any failure.
     */
    public static String resolveScopeTypeFq(Expression scope) {
        try {
            com.github.javaparser.resolution.types.ResolvedType rt;
            if (scope instanceof NameExpr ne)           rt = ne.resolve().getType();
            else if (scope instanceof FieldAccessExpr f) rt = f.resolve().getType();
            else if (scope instanceof MethodCallExpr m)  rt = m.resolve().getReturnType();
            else return null;
            if (rt.isReferenceType()) return rt.asReferenceType().getQualifiedName();
        } catch (Throwable ignored) {}
        return null;
    }

    /**
     * Textual type-name → original FQ lookup against the classMap.
     * Tries exact/suffix match on keys (original FQs), then match on values (obfuscated simple names).
     * Generics are stripped before matching.
     */
    public static String textualToOrigFq(String textual, Map<String, String> classMap) {
        if (textual == null) return null;
        String t = textual.strip();
        int lt = t.indexOf('<');
        if (lt > 0) t = t.substring(0, lt);
        final String qt = t;
        Optional<String> byOrig = classMap.keySet().stream()
                .filter(fq -> fq.equals(qt) || fq.endsWith("." + qt))
                .findFirst();
        if (byOrig.isPresent()) return byOrig.get();
        return classMap.entrySet().stream()
                .filter(e -> e.getValue().equals(qt))
                .map(Map.Entry::getKey)
                .findFirst().orElse(null);
    }

    /**
     * Resolves the owner FQ of a scope expression using symbol solver first,
     * then falls back to textual lookup of parameter / field declared types.
     *
     * @param scope     the scope expression of a method call or method reference
     * @param classMap  origFQ → newSimple mapping
     * @return original FQ of the owning type, or null if unresolvable
     */
    public static String resolveScopeOwnerFq(Expression scope, Map<String, String> classMap) {
        // Tier 1: symbol solver
        String fq = resolveScopeTypeFq(scope);
        if (fq != null) return fq;

        // Tier 2: textual — parameter in enclosing callable
        if (scope instanceof NameExpr ne) {
            String varName = ne.getNameAsString();
            Optional<CallableDeclaration<?>> enc = ne.findAncestor(CallableDeclaration.class);
            if (enc.isPresent()) {
                NodeList<Parameter> params = enc.get().getParameters();
                for (Parameter p : params) {
                    if (p.getNameAsString().equals(varName)) {
                        String textual = (p.getType() instanceof ClassOrInterfaceType cit)
                                ? cit.getNameWithScope() : p.getType().toString();
                        fq = textualToOrigFq(textual, classMap);
                        if (fq != null) return fq;
                    }
                }
            }
            // Tier 3: textual — field in enclosing class
            Optional<ClassOrInterfaceDeclaration> encClass = ne.findAncestor(ClassOrInterfaceDeclaration.class);
            if (encClass.isPresent()) {
                for (FieldDeclaration fd : encClass.get().getFields()) {
                    for (VariableDeclarator vd : fd.getVariables()) {
                        if (vd.getNameAsString().equals(varName)) {
                            String textual = (vd.getType() instanceof ClassOrInterfaceType cit)
                                    ? cit.getNameWithScope() : vd.getType().toString();
                            return textualToOrigFq(textual, classMap);
                        }
                    }
                }
            }
        }

        // Tier 4: FieldAccessExpr — look up the rightmost name as a field
        if (scope instanceof FieldAccessExpr fae) {
            String fieldName = fae.getNameAsString();
            Optional<TypeDeclaration<?>> tdOpt = fae.findAncestor(TypeDeclaration.class);
            if (tdOpt.isPresent()) {
                for (FieldDeclaration fd : tdOpt.get().getFields()) {
                    for (VariableDeclarator vd : fd.getVariables()) {
                        if (vd.getNameAsString().equals(fieldName)) {
                            String textual = (vd.getType() instanceof ClassOrInterfaceType cit)
                                    ? cit.getNameWithScope() : vd.getType().toString();
                            return textualToOrigFq(textual, classMap);
                        }
                    }
                }
            }
        }
        return null;
    }

    // ── Local / parameter guard ───────────────────────────────────────────────────

    /**
     * Returns true when the given name is declared as a parameter or local variable
     * in the enclosing callable — preventing accidental rename of locals whose names
     * collide with a renamed field name.
     */
    public static boolean isDeclaredAsLocalOrParameter(NameExpr ne, String name) {
        Optional<CallableDeclaration<?>> enc = ne.findAncestor(CallableDeclaration.class);
        if (enc.isPresent()) {
            CallableDeclaration<?> cd = enc.get();
            NodeList<Parameter> params = cd.getParameters();
            for (Parameter p : params)
                if (p.getNameAsString().equals(name)) return true;
            for (VariableDeclarator vd : cd.findAll(VariableDeclarator.class))
                if (vd.getNameAsString().equals(name)) return true;
        }
        Optional<BlockStmt> blockOpt = ne.findAncestor(BlockStmt.class);
        if (blockOpt.isPresent())
            for (VariableDeclarator vd : blockOpt.get().findAll(VariableDeclarator.class))
                if (vd.getNameAsString().equals(name)) return true;
        return false;
    }

    // ── MRE scope name extraction ─────────────────────────────────────────────────

    /**
     * Textual type-name → obfuscated FQ lookup used by the deobfuscator.
     *
     * <p>Unlike {@link #textualToOrigFq}, this variant must handle two states:
     * <ul>
     *   <li>Before Phase 1a: the type name is still the obfuscated simple name
     *       (e.g. {@code IrisSparrow7Dto}) → match against {@code obfFqToOrig} keys.</li>
     *   <li>After Phase 1a: the type name has been restored to the original simple name
     *       (e.g. {@code FruitSearchCriteriaDto}) → match against {@code obfFqToOrig} values.</li>
     * </ul>
     * Always returns the <em>obfuscated</em> FQ (a key in {@code obfFqToOrig}) so that
     * downstream {@code fieldByObfFq} lookups continue to work correctly.
     *
     * @param typeName    textual type name, possibly generic (generics are stripped)
     * @param obfFqToOrig obfFQ → origFQ map from the deobfuscation context
     * @return the obfuscated FQ, or null if not found
     */
    public static String textualToObfFq(String typeName, Map<String, String> obfFqToOrig) {
        if (typeName == null || typeName.isBlank()) return null;
        String t = typeName.strip();
        int lt = t.indexOf('<');
        if (lt > 0) t = t.substring(0, lt);
        final String qt = t;
        // Phase: type name still obfuscated — match against obfFq keys
        Optional<String> byObf = obfFqToOrig.keySet().stream()
                .filter(fq -> fq.equals(qt) || fq.endsWith("." + qt))
                .findFirst();
        if (byObf.isPresent()) return byObf.get();
        // Phase: type name already restored — match against origFq values, return obfFq key
        return obfFqToOrig.entrySet().stream()
                .filter(e -> e.getValue().equals(qt) || e.getValue().endsWith("." + qt))
                .map(Map.Entry::getKey)
                .findFirst().orElse(null);
    }

    /**
     * Extracts the simple candidate name from a method reference scope expression,
     * regardless of whether it is a {@link NameExpr} or {@link TypeExpr}.
     * Returns null for other node types (e.g. method calls as scope).
     */
    public static String mreSimpleScopeName(Expression sc) {
        if (sc instanceof NameExpr ne) return ne.getNameAsString();
        if (sc instanceof TypeExpr te) {
            String raw = te.getType().toString();
            int lt = raw.indexOf('<');
            if (lt > 0) raw = raw.substring(0, lt);
            int dot = raw.lastIndexOf('.');
            return dot >= 0 ? raw.substring(dot + 1) : raw;
        }
        return null;
    }
}
