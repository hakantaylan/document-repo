package com.example.obfuscator.obf;

import com.example.obfuscator.AstUtils;
import com.example.obfuscator.RenameContext;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.Visitable;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;

import java.util.Optional;

/**
 * V3b — renames all field <em>usage</em> sites:
 * {@link FieldAccessExpr}, bare {@link NameExpr} identifiers, and
 * the scope of {@link MethodReferenceExpr} nodes.
 *
 * <p>This visitor runs after {@link FieldDeclVisitor} (V3a) — declarations are
 * already renamed in memory — but the symbol solver still reads the <em>original</em>
 * source files from disk, so {@code ne.resolve()} still returns the original
 * declaring-type FQ that matches our {@code fieldMap} keys.
 *
 * <p>Three-tier lookup for every name:
 * <ol>
 *   <li>Symbol resolution → exact {@code declaringType|fieldName} key.</li>
 *   <li>Name is in {@code allRenamedOrigFieldNames} → enclosing-type lookup then
 *       globally-unique flat map.</li>
 *   <li>Metamodel / class-name simple fallback.</li>
 * </ol>
 *
 * <p><strong>Method-reference scopes</strong> (e.g. {@code fruitMapper} in
 * {@code fruitMapper::toDtoBase}) are handled by an explicit
 * {@link #visit(MethodReferenceExpr, Void)} override that works regardless of
 * whether the scope is a {@link NameExpr} or a {@link TypeExpr} (the node type
 * JavaParser uses for interface-typed fields such as MapStruct mappers).
 */
public class FieldUsageVisitor extends ModifierVisitor<Void> {

    private final RenameContext                   ctx;
    private final Map<TypeDeclaration<?>, String> typeOrigFq;

    public FieldUsageVisitor(RenameContext ctx, Map<TypeDeclaration<?>, String> typeOrigFq) {
        this.ctx       = ctx;
        this.typeOrigFq = typeOrigFq;
    }

    // ── FieldAccessExpr ───────────────────────────────────────────────────────────

    @Override
    public Visitable visit(FieldAccessExpr fae, Void arg) {
        String s = fae.getNameAsString();

        // Tier 1: symbol resolution
        try {
            ResolvedValueDeclaration rvd = fae.resolve();
            if (rvd.isField()) {
                String key = rvd.asField().declaringType().getQualifiedName() + "|" + s;
                if (ctx.fieldMap.containsKey(key)) { fae.setName(ctx.fieldMap.get(key)); return super.visit(fae, arg); }
            }
        } catch (Throwable ignored) {}

        // Tier 2: flat fallback (globally-unique renamed fields)
        String n = ctx.flatFieldRenames.get(s);
        if (n != null) { fae.setName(n); return super.visit(fae, arg); }

        // Tier 3: JPA static metamodel  e.g.  Fruit_.name  →  ObfFruit_.fRose3
        renameMetamodelAccess(fae, s);

        return super.visit(fae, arg);
    }

    // ── NameExpr ─────────────────────────────────────────────────────────────────

    @Override
    public Visitable visit(NameExpr ne, Void arg) {
        String s = ne.getNameAsString();

        // Metamodel class reference (e.g. Fruit_ → ObfFruit_)
        if (ctx.metamodelMap.containsKey(s)) { ne.setName(ctx.metamodelMap.get(s)); return super.visit(ne, arg); }

        // Tier 1: symbol resolution → field
        try {
            ResolvedValueDeclaration rvd = ne.resolve();
            if (rvd.isField()) {
                String key = rvd.asField().declaringType().getQualifiedName() + "|" + s;
                if (ctx.fieldMap.containsKey(key)) { ne.setName(ctx.fieldMap.get(key)); return super.visit(ne, arg); }
            }
        } catch (Throwable ignored) {}

        // Guard: skip locals / parameters
        if (AstUtils.isDeclaredAsLocalOrParameter(ne, s)) return super.visit(ne, arg);

        // Tier 2: known renamed field name → enclosing-type then flat map
        if (ctx.allRenamedOrigFieldNames.contains(s)) {
            String mapped = ne.findAncestor(TypeDeclaration.class)
                    .map(td -> typeOrigFq.get(td))
                    .map(fq -> ctx.fieldMap.get(fq + "|" + s))
                    .orElse(null);
            if (mapped == null) mapped = ctx.flatFieldRenames.get(s);
            if (mapped != null) { ne.setName(mapped); return super.visit(ne, arg); }
        }

        // Class simple-name fallback
        ctx.classMap.entrySet().stream()
                .filter(e -> e.getKey().endsWith("." + s))
                .findFirst()
                .ifPresent(e -> ne.setName(e.getValue()));
        return super.visit(ne, arg);
    }

    // ── MethodReferenceExpr scope ─────────────────────────────────────────────────

    /**
     * Renames the scope of a method reference (e.g. {@code fruitMapper} in
     * {@code fruitMapper::toDtoBase}).
     *
     * <p>Called after children are visited via {@code super.visit}, so any child
     * NameExpr visitor already ran.  This override acts as a safety net for cases
     * where JavaParser represents the scope as a {@link TypeExpr} (common for
     * interface-typed fields such as MapStruct mappers) which the generic
     * {@link #visit(NameExpr, Void)} never touches.
     */
    @Override
    public Visitable visit(MethodReferenceExpr mre, Void arg) {
        Visitable result = super.visit(mre, arg); // children first
        if (!(result instanceof MethodReferenceExpr mre2)) return result;

        Expression sc = mre2.getScope();
        String scopeName = AstUtils.mreSimpleScopeName(sc);
        if (scopeName == null || !ctx.allRenamedOrigFieldNames.contains(scopeName)) return result;
        if (sc instanceof NameExpr ne3 && AstUtils.isDeclaredAsLocalOrParameter(ne3, scopeName)) return result;

        // Enclosing-type lookup then flat map
        String mapped = mre2.findAncestor(TypeDeclaration.class)
                .map(td -> typeOrigFq.get(td))
                .map(fq -> ctx.fieldMap.get(fq + "|" + scopeName))
                .orElse(null);
        if (mapped == null) mapped = ctx.flatFieldRenames.get(scopeName);

        if (mapped != null) {
            if (sc instanceof NameExpr ne4)  ne4.setName(mapped);
            else if (sc instanceof TypeExpr) mre2.setScope(new NameExpr(mapped));
        }
        return result;
    }

    // ── Metamodel helper ──────────────────────────────────────────────────────────

    private void renameMetamodelAccess(FieldAccessExpr fae, String attrName) {
        Expression scope = fae.getScope();
        String scopeSimple = extractMetamodelScopeName(scope);
        if (scopeSimple == null || !scopeSimple.endsWith("_")) return;

        String base = scopeSimple.substring(0, scopeSimple.length() - 1);
        Optional<String> maybeOrigEntity = ctx.classMap.keySet().stream()
                .filter(k -> k.equals(base) || k.endsWith("." + base)).findFirst();
        if (maybeOrigEntity.isEmpty())
            maybeOrigEntity = ctx.classMap.entrySet().stream()
                    .filter(e -> e.getValue().equals(base)).map(Map.Entry::getKey).findFirst();
        if (maybeOrigEntity.isEmpty()) return;

        String origEntityFq = maybeOrigEntity.get();
        String metaKey = origEntityFq + "|" + attrName;
        if (fieldMap.containsKey(metaKey)) fae.setName(ctx.fieldMap.get(metaKey));

        String obfSimple = ctx.classMap.get(origEntityFq);
        if (obfSimple != null) renameMetamodelScopeNode(scope, obfSimple + "_");
    }

    private static String extractMetamodelScopeName(Expression scope) {
        if (scope instanceof NameExpr sne) return sne.getNameAsString();
        if (scope instanceof FieldAccessExpr fscope) {
            FieldAccessExpr cur = fscope;
            while (true) {
                if (cur.getNameAsString().endsWith("_")) return cur.getNameAsString();
                Expression sc = cur.getScope();
                if (sc instanceof FieldAccessExpr fa) { cur = fa; continue; }
                if (sc instanceof NameExpr ne && ne.getNameAsString().endsWith("_")) return ne.getNameAsString();
                break;
            }
        }
        return null;
    }

    private static void renameMetamodelScopeNode(Expression scope, String obfMeta) {
        if (scope instanceof NameExpr sne) { sne.setName(obfMeta); return; }
        if (scope instanceof FieldAccessExpr fscope) {
            FieldAccessExpr cur = fscope;
            while (true) {
                if (cur.getNameAsString().endsWith("_")) { cur.setName(obfMeta); return; }
                Expression sc = cur.getScope();
                if (sc instanceof FieldAccessExpr fa) { cur = fa; continue; }
                if (sc instanceof NameExpr ne && ne.getNameAsString().endsWith("_")) { ne.setName(obfMeta); return; }
                break;
            }
            if (fscope.getScope() instanceof NameExpr ne2 && ne2.getNameAsString().endsWith("_"))
                ne2.setName(obfMeta);
        }
    }
}
