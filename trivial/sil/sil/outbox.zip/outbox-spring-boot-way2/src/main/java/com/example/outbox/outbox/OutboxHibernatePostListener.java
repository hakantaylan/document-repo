//package com.example.outbox.outbox;
//
//
//import org.hibernate.event.spi.*;
//import org.hibernate.persister.entity.EntityPersister;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.Objects;
//import java.util.Set;
//import java.util.stream.Collectors;
//import java.util.stream.IntStream;
//
//public class OutboxHibernatePostListener implements PostInsertEventListener,
//                                                    PostUpdateEventListener,
//                                                    PostDeleteEventListener {
//    private static final Logger logger = LoggerFactory.getLogger(OutboxHibernatePostListener.class);
//
//    @Override
//    public void onPostInsert(PostInsertEvent event) {
//        handle(event.getEntity(), "CREATED");
//    }
//
//    @Override
//    public void onPostUpdate(PostUpdateEvent event) {
//        printChanges(event);
//        handle(event.getEntity(), "UPDATED");
//    }
//    @Override
//    public void onPostDelete(PostDeleteEvent event) {
//        handle(event.getEntity(), "DELETED");
//    }
//
//    private void handle(Object entity, String type) {
//        if (entity instanceof OutboxAggregate aggregate) {
//            OutboxCollector.collect(aggregate, type);
//        }
//    }
//
//    private static void printChanges(PostUpdateEvent event) {
//        StringBuilder sb = new StringBuilder();
//// replace typeName(event) and entityIdentifier(...) with your own helpers or compute inline
//        sb.append("Hibernate ")
//                .append(event.getEntity().getClass().getName())
//                .append(" for ")
//                .append(event.getId())
//                .append(System.lineSeparator());
//
//        String[] propertyNames = event.getPersister().getPropertyNames();
//        int[] dirtyProperties = event.getDirtyProperties();
//
//        Set<Integer> dirtySet = (dirtyProperties == null)
//                ? Set.of()
//                : IntStream.of(dirtyProperties).boxed().collect(Collectors.toSet());
//
//        Object[] oldState = event.getOldState();
//        Object[] state = event.getState();
//
//        for (int i = 0; i < propertyNames.length; i++) {
//            sb.append("• ").append(propertyNames[i]);
//            if (dirtySet.contains(i)) {
//                sb.append(" changed from '")
//                        .append(Objects.toString(oldState == null ? null : oldState[i], "null"))
//                        .append("' to '")
//                        .append(Objects.toString(state == null ? null : state[i], "null"))
//                        .append("'");
//            } else {
//                sb.append(" kept value '")
//                        .append(Objects.toString(state == null ? null : state[i], "null"))
//                        .append("'");
//            }
//            sb.append(System.lineSeparator());
//        }
//
//        logger.debug(sb.toString());
////        System.out.println(sb);
//    }
//
////    @Override
////    public boolean requiresPostCommitHandling(EntityPersister persister) {
////        return false;
////    }
//}
//
