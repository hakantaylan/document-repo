//package com.example.outbox.domain;
//
//
//import com.example.outbox.outbox.OutboxAggregate;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import org.hibernate.annotations.UuidGenerator;
//
//import java.util.UUID;
//
//@Entity
//public class MyOrder extends BaseEntity implements OutboxAggregate {
//
//
//
//    private String status;
//
//    public MyOrder() {
//        this.status = "NEW";
//    }
//
//    public void ship() {
//        this.status = "SHIPPED";
//    }
//
////    @Override
////    public UUID getId() {
////        return id;
////    }
//
//    public String getStatus() {
//        return status;
//    }
//}
//
