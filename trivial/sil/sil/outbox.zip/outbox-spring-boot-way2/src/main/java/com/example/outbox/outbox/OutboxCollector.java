package com.example.outbox.outbox;


import com.example.outbox.config.SpringContext;
import com.example.outbox.domain.BaseEntity;
import tools.jackson.databind.json.JsonMapper;

import java.util.ArrayList;
import java.util.List;

//public final class OutboxCollector {
//
//    private static final ThreadLocal<List<OutboxEntity>> EVENTS = ThreadLocal.withInitial(ArrayList::new);
//
//    private static final JsonMapper OBJECT_MAPPER = new JsonMapper();
//
//    private static Logger logger = LoggerFactory.getLogger(OutboxCollector.class);
//
//    private OutboxCollector() {
//    }
//
//    public static void collect(OutboxAggregate aggregate, String eventType) {
//        OutboxEntity event = new OutboxEntity(aggregate.getClass().getSimpleName(), aggregate.getId(), eventType, "");
////        event.setAggregateId(aggregate.getId());
////        event.setAggregateType(aggregate.getClass().getSimpleName());
////        event.setOperation(eventType);
//        event.setPayload(OBJECT_MAPPER.writeValueAsString(aggregate));
//        logger.debug(event.getPayload());
//        EVENTS.get().add(event);
//    }
//
//    public static List<OutboxEntity> drain() {
//        List<OutboxEntity> events = new ArrayList<>(EVENTS.get());
//        EVENTS.remove();
//        return events;
//    }
//}


public final class OutboxCollector {
    private static final ThreadLocal<List<OutboxEvent>> THREAD_EVENTS = ThreadLocal.withInitial(ArrayList::new);
    private static final JsonMapper OBJECT_MAPPER = new JsonMapper();

    public static void add(OutboxEvent ev) {
        THREAD_EVENTS.get().add(ev);
    }

    public static java.util.List<OutboxEvent> drain() {
        java.util.List<OutboxEvent> result = new ArrayList<>(THREAD_EVENTS.get());
        THREAD_EVENTS.get().clear();
        return result;
    }

    public static boolean isEmpty() {
        return THREAD_EVENTS.get().isEmpty();
    }

    public static void collect(BaseEntity entity, String operation) {
        OutboxEvent event = new OutboxEvent(entity.getClass().getSimpleName(), entity.getId(), operation, "");
        event.setPayload(OBJECT_MAPPER.writeValueAsString(entity));
        THREAD_EVENTS.get().add(event);
        SpringContext.getBean(OutboxSynchronizationService.class).ensureSynchronizationRegistered();
    }
}
