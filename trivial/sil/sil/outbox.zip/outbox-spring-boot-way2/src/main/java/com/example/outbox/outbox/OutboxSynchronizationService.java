package com.example.outbox.outbox;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.UUID;

/**
 * Responsible for ensuring a TransactionSynchronization is registered and performing the actual
 * JDBC insert of outbox rows in beforeCommit using the transaction-bound Connection.
 */
@Component
@Slf4j
public class OutboxSynchronizationService {

    private static final Object SYNC_KEY = OutboxSynchronizationService.class;

    private final DataSource dataSource;

    public OutboxSynchronizationService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Ensure a TransactionSynchronization is registered for the current transaction.
     * Call this when you add any OutboxEvent (e.g. from the Hibernate listener).
     */
    public void ensureSynchronizationRegistered() {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            // Not inside a Spring transaction - nothing to do
            return;
        }
        if (TransactionSynchronizationManager.getResource(SYNC_KEY) != null) {
            return; // already registered for this tx
        }

        // mark as registered
        TransactionSynchronizationManager.bindResource(SYNC_KEY, Boolean.TRUE);

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void beforeCommit(boolean readOnly) {
                List<OutboxEvent> events = OutboxCollector.drain();
                if (events.isEmpty())
                    return;
                log.debug("Outbox tablosuna yazma işlemi başladı");
                Connection con = DataSourceUtils.getConnection(dataSource);
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO outbox_event (id, aggregate_type, aggregate_id, operation, payload) VALUES (?, ?, ?, ?, ?)")) {

                    for (OutboxEvent ev : events) {
                        ps.setString(1, UUID.randomUUID().toString());
                        ps.setString(2, ev.getAggregateType());
                        ps.setObject(3, ev.getAggregateId());
                        ps.setString(4, ev.getOperation());
                        ps.setString(5, ev.getPayload());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                } catch (Exception ex) {
                    // failing to write outbox should fail the transaction
                    throw new RuntimeException("Failed to write outbox events", ex);
                } finally {
                    DataSourceUtils.releaseConnection(con, dataSource);
                }
            }

            @Override
            public void afterCompletion(int status) {
                try {
                    TransactionSynchronizationManager.unbindResource(SYNC_KEY);
                } catch (IllegalStateException ignored) { }
                // clean up collector if anything remains
                OutboxCollector.drain();
            }
        });
    }
}
