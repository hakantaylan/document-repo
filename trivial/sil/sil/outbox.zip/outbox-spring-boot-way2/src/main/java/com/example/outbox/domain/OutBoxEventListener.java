package com.example.outbox.domain;

import com.example.outbox.outbox.OutboxCollector;
import jakarta.persistence.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OutBoxEventListener {

    Logger logger = LoggerFactory.getLogger(OutBoxEventListener.class);

    @PrePersist
    public void prePersist(BaseEntity instance) {
        logger.debug("PrePersist is called");
        OutboxCollector.collect(instance, "CREATED");
    }

    @PreUpdate
    public void preUpdate(BaseEntity instance) {
        logger.debug("PreUpdate is called");
        OutboxCollector.collect(instance, "UPDATED");
    }

    @PreRemove
    public void preRemove(BaseEntity instance) {
        logger.debug("preRemove is called");
        OutboxCollector.collect(instance, "DELETED");
    }

//    @PostPersist
//    public void postPersist(BaseEntity instance) {
//        logger.debug("postPersist is called");
//        OutboxCollector.collect(instance, "CREATED");
//    }
//
//    @PostUpdate
//    public void postUpdate(BaseEntity instance) {
//        logger.debug("postUpdate is called");
//        OutboxCollector.collect(instance, "UPDATED");
//    }
//
//    @PostRemove
//    public void postRemove(BaseEntity instance) {
//        logger.debug("postRemove is called");
//        OutboxCollector.collect(instance, "DELETED");
//    }
}
