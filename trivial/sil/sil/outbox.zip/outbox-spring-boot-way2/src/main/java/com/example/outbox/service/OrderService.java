package com.example.outbox.service;

import com.example.outbox.domain.OrderEntity;
import com.example.outbox.domain.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final OrderRepository repo;

    public OrderService(OrderRepository repo) {
        this.repo = repo;
    }

    @Transactional
    public OrderEntity createOrder(String name) {
        OrderEntity o = new OrderEntity(name);
        // save and flush to ensure ID is assigned (IDENTITY)
        o = repo.save(o);
        o.setName(o. getName() + " updated");
        return o;
    }

    @Transactional
    public void createOrderAndFail(String name) {
        OrderEntity o = new OrderEntity(name);
        o = repo.save(o);
        // simulate error -> transaction will roll back
        throw new RuntimeException("simulated failure");
    }
}
