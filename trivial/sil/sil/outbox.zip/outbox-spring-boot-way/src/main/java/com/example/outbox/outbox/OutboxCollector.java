package com.example.outbox.outbox;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tools.jackson.databind.json.JsonMapper;

import java.util.ArrayList;
import java.util.List;

//public final class OutboxCollector {
//
//    private static final ThreadLocal<List<OutboxEntity>> EVENTS = ThreadLocal.withInitial(ArrayList::new);
//
//    private static final JsonMapper OBJECT_MAPPER = new JsonMapper();
//
//    private static Logger logger = LoggerFactory.getLogger(OutboxCollector.class);
//
//    private OutboxCollector() {
//    }
//
//    public static void collect(OutboxAggregate aggregate, String eventType) {
//        OutboxEntity event = new OutboxEntity(aggregate.getClass().getSimpleName(), aggregate.getId(), eventType, "");
////        event.setAggregateId(aggregate.getId());
////        event.setAggregateType(aggregate.getClass().getSimpleName());
////        event.setOperation(eventType);
//        event.setPayload(OBJECT_MAPPER.writeValueAsString(aggregate));
//        logger.debug(event.getPayload());
//        EVENTS.get().add(event);
//    }
//
//    public static List<OutboxEntity> drain() {
//        List<OutboxEntity> events = new ArrayList<>(EVENTS.get());
//        EVENTS.remove();
//        return events;
//    }
//}

import java.util.ArrayList;
import java.util.List;

public final class OutboxCollector {
    private static final ThreadLocal<List<OutboxEntity>> THREAD_EVENTS = ThreadLocal.withInitial(ArrayList::new);

    public static void add(OutboxEntity ev) {
        THREAD_EVENTS.get().add(ev);
    }

    public static java.util.List<OutboxEntity> drain() {
        java.util.List<OutboxEntity> result = new ArrayList<>(THREAD_EVENTS.get());
        THREAD_EVENTS.get().clear();
        return result;
    }

    public static boolean isEmpty() {
        return THREAD_EVENTS.get().isEmpty();
    }
}
