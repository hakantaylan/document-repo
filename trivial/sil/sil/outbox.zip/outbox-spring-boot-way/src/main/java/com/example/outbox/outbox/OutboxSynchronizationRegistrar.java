package com.example.outbox.outbox;

import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.UUID;

@Component
public class OutboxSynchronizationRegistrar {

    private static final Object SYNCHRONIZATION_BOUND_KEY = OutboxSynchronizationRegistrar.class;

    private final DataSource dataSource;

    public OutboxSynchronizationRegistrar(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Ensure a TransactionSynchronization is registered for the current transaction.
     * Call this when you enqueue an outbox event (e.g. OutboxCollector.add()).
     */
    public void ensureRegistered() {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            // Not inside a Spring-managed transaction -> nothing to do here
            return;
        }
        if (TransactionSynchronizationManager.getResource(SYNCHRONIZATION_BOUND_KEY) != null) {
            return; // already registered for this tx
        }

        // mark as registered for this tx
        TransactionSynchronizationManager.bindResource(SYNCHRONIZATION_BOUND_KEY, Boolean.TRUE);

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void beforeCommit(boolean readOnly) {
                List<OutboxEntity> events = OutboxCollector.drain();
                if (events.isEmpty()) {
                    return;
                }

                Connection con = DataSourceUtils.getConnection(dataSource);
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO outbox_entity (id, aggregate_type, aggregate_id, operation, payload) VALUES (?, ?, ?, ?, ?)")) {
                    for (OutboxEntity ev : events) {
                        ps.setString(1, UUID.randomUUID().toString());
                        ps.setString(2, ev.getAggregateType());
                        ps.setObject(3, ev.getAggregateId());
                        ps.setString(4, ev.getOperation());
                        ps.setString(5, ev.getPayload());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                } catch (Exception ex) {
                    throw new RuntimeException("Failed to write outbox events", ex);
                } finally {
                    DataSourceUtils.releaseConnection(con, dataSource);
                }
            }

            @Override
            public void afterCompletion(int status) {
                try {
                    TransactionSynchronizationManager.unbindResource(SYNCHRONIZATION_BOUND_KEY);
                } catch (IllegalStateException ignored) { }
                // ensure collector cleared
                OutboxCollector.drain();
            }
        });
    }
}