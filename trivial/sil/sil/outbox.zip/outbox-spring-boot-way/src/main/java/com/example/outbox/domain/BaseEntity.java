//package com.example.outbox.domain;
//
//import com.example.outbox.outbox.OutboxAggregate;
//import com.example.outbox.outbox.OutboxCollector;
//import jakarta.persistence.*;
//import org.hibernate.annotations.UuidGenerator;
//
//import java.util.UUID;
//
//@MappedSuperclass
////@EntityListeners(MyEventListener.class)
//public abstract class BaseEntity implements OutboxAggregate {
//
//    @Id
//    @UuidGenerator(style = UuidGenerator.Style.VERSION_7)
//    @GeneratedValue(strategy = GenerationType.UUID)
//    private UUID id;
//
//    public UUID getId() {
//        return id;
//    }
//}
