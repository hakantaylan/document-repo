package com.example.outbox.service;

import com.example.outbox.domain.OrderEntity;
import com.example.outbox.domain.OrderRepository;
import com.example.outbox.outbox.OutboxCollector;
import com.example.outbox.outbox.OutboxEntity;
import com.example.outbox.outbox.OutboxSynchronizationRegistrar;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final OrderRepository repo;
    private final OutboxSynchronizationRegistrar registrar;

    public OrderService(OrderRepository repo, OutboxSynchronizationRegistrar registrar) {
        this.repo = repo;
        this.registrar = registrar;
    }

    @Transactional
    public OrderEntity createOrder(String name) {
        OrderEntity o = new OrderEntity(name);
        // save and flush to ensure ID is assigned (IDENTITY)
        o = repo.saveAndFlush(o);

        // enqueue outbox event and register synchronization
        OutboxCollector.add(new OutboxEntity("Order", o.getId(), "CREATED", "{\"name\":\"" + name + "\"}"));
        registrar.ensureRegistered();

        return o;
    }

    @Transactional
    public void createOrderAndFail(String name) {
        OrderEntity o = new OrderEntity(name);
        o = repo.saveAndFlush(o);
        OutboxCollector.add(new OutboxEntity("Order", o.getId(), "CREATED", "{\"name\":\"" + name + "\"}"));
        registrar.ensureRegistered();
        // simulate error -> transaction will roll back
        throw new RuntimeException("simulated failure");
    }
}
