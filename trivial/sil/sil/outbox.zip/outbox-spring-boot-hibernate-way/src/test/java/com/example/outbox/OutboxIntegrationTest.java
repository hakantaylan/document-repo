package com.example.outbox;

import com.example.outbox.outbox.OutboxEntity;
import com.example.outbox.outbox.OutboxRepository;
import com.example.outbox.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
class OutboxIntegrationTest {

    @Autowired
    private OutboxRepository outboxRepository;
    @Autowired
    private OrderService orderService;

    @Test
    void outbox_written_in_same_transaction() {
        orderService.createAndShip();

        List<OutboxEntity> events = outboxRepository.findAll();

        assertThat(events).hasSize(2);
        assertThat(events)
                .extracting(OutboxEntity::getOperation)
                .containsExactly("CREATED", "UPDATED");
    }

    @Test
    void outbox_rolled_back_with_transaction() {

        assertThrows(
                RuntimeException.class,
                () -> orderService.rollback()
        );

        List<OutboxEntity> events = outboxRepository.findAll();

        assertThat(events).isEmpty();
    }
}


