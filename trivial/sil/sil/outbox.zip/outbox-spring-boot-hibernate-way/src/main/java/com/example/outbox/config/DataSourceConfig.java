//package com.example.outbox.config;
//
//import net.ttddyy.dsproxy.listener.logging.SLF4JQueryLoggingListener;
//import net.ttddyy.dsproxy.support.ProxyDataSourceBuilder;
//import org.springframework.boot.jdbc.autoconfigure.DataSourceProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.sql.DataSource;
//
//@Configuration(proxyBeanMethods = false)
//public class DataSourceConfig {
//    @Bean
//    public DataSource dataSource(DataSourceProperties properties) {
//        DataSource real = properties.initializeDataSourceBuilder().build();
//
//        SLF4JQueryLoggingListener queryListener = new SLF4JQueryLoggingListener();        // logs queries
//        SLF4JJdbcEventListener jdbcListener = new SLF4JJdbcEventListener();              // logs commit/rollback and connection events
//
//        return ProxyDataSourceBuilder
//                .create(real)
//                .name("ProxyDataSource")
//                .listener(queryListener)
//                .listener(jdbcListener)
//                .build();
//    }
//}
