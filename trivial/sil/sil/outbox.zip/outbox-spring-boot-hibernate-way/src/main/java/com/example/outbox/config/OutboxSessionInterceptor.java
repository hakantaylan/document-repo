package com.example.outbox.config;

import com.example.outbox.outbox.OutboxCollector;
import com.example.outbox.outbox.OutboxEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Interceptor;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class OutboxSessionInterceptor implements Interceptor {

    @PersistenceContext
    private EntityManager em;

    @Override
    public void beforeTransactionCompletion(Transaction tx) {

        // Get the SessionFactory's current session (must be thread-bound current session)
        Session session = em.unwrap(Session.class);

        List<OutboxEntity> events = OutboxCollector.drain();
        if (events.isEmpty())
            return;
        log.debug("Outbox tablosuna yazma işlemi başladı");
        // Use plain JDBC on the same physical connection via doWork to avoid re-entrance
        session.doWork(connection -> {
            try (PreparedStatement ps = connection.prepareStatement("INSERT INTO outbox_entity (aggregate_type, aggregate_id, operation, payload, id) VALUES (?, ?, ?, ?, ?)")) {
                for (OutboxEntity e : events) {
                    ps.setString(1, e.getAggregateType());
                    ps.setObject(2, e.getId());
                    ps.setString(3, e.getOperation());
                    ps.setString(4, e.getPayload());
                    ps.setObject(5, UUID.randomUUID());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
        });
//        for (OutboxEntity entity : events) {
//            if(entity.getOperation().equals("CREATED"))
//                session.persist(e);
//            if(entity.getOperation().equals("UPDATED"))
//                session.merge(e);
//            if(entity.getOperation().equals("DELETED"))
//                session.merge(e);
//            em.persist(entity);
//        }
        log.debug("Outbox flushed {}", tx);
        log.debug("Transaction isComplete: {}, wasstarted: {}", tx.isComplete(), tx.wasStarted());
    }

    @Override
    public void afterTransactionBegin(Transaction tx) {
        log.debug("Transaction has begun {}", tx);
        log.debug("Transaction isComplete: {}, wasstarted: {}", tx.isComplete(), tx.wasStarted());
    }

    @Override
    public void afterTransactionCompletion(Transaction tx) {
        log.debug("Transaction has just completed {}", tx);
        log.debug("Transaction isComplete: {}, wasstarted: {}", tx.isComplete(), tx.wasStarted());
    }
}