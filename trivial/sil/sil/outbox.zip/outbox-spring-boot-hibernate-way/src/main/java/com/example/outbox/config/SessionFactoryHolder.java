package com.example.outbox.config;

public final class SessionFactoryHolder {
    private static volatile org.hibernate.SessionFactory sessionFactory;

    public static void set(org.hibernate.SessionFactory sf) {
        sessionFactory = sf;
    }

    public static org.hibernate.SessionFactory get() {
        return sessionFactory;
    }
}