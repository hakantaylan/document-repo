package com.example.outbox.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public final class InterceptorHolder {

    @Autowired
    @Lazy
    OutboxSessionInterceptor interceptor;

    public OutboxSessionInterceptor getInterceptor() {
        return interceptor;
    }
}