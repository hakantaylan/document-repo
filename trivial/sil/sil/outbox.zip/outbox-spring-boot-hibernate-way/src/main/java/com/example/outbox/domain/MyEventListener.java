package com.example.outbox.domain;

import com.example.outbox.outbox.OutboxCollector;
import jakarta.persistence.PostPersist;
import jakarta.persistence.PostRemove;
import jakarta.persistence.PostUpdate;

public class MyEventListener {

    @PostPersist
    public void posPersist(BaseEntity instance) {
        OutboxCollector.collect(instance, "CREATED");
    }

    @PostUpdate
    public void postUpdate(BaseEntity instance) {
        OutboxCollector.collect(instance, "UPDATED");
    }

    @PostRemove
    public void postRemove(BaseEntity instance) {
        OutboxCollector.collect(instance, "DELETED");
    }
}
