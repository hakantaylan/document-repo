package com.example.outbox.outbox;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
public class OutboxEntity {

    @Id
    @UuidGenerator(style = UuidGenerator.Style.VERSION_7)
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    private String aggregateType;
    private UUID aggregateId;
    private String operation;

    @Column(columnDefinition = "jsonb")
    private String payload;

//    private long sequence;
    private Instant createdAt;

    protected OutboxEntity() {}

    public OutboxEntity(
            String aggregateType,
            UUID aggregateId,
            String operation,
            String payload
    ) {
        this.aggregateType = aggregateType;
        this.aggregateId = aggregateId;
        this.operation = operation;
        this.payload = payload;
//        this.sequence = sequence;
        this.createdAt = Instant.now();
    }
}
