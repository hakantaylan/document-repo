package com.example.outbox.config;


import com.example.outbox.outbox.OutboxHibernatePostListener;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.spi.BootstrapContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.hibernate.integrator.spi.Integrator;

public class HibernateIntegrator implements Integrator {

    @Override
    public void integrate(Metadata metadata, BootstrapContext bootstrapContext, SessionFactoryImplementor sessionFactory) {
        Integrator.super.integrate(metadata, bootstrapContext, sessionFactory);
        SessionFactoryHolder.set(sessionFactory);
        OutboxHibernatePostListener outboxHibernateListener = new OutboxHibernatePostListener();
        EventListenerRegistry registry = sessionFactory.getServiceRegistry().getService(EventListenerRegistry.class);

        registry.getEventListenerGroup(EventType.POST_INSERT)
                .appendListener(outboxHibernateListener);
        registry.getEventListenerGroup(EventType.POST_UPDATE)
                .appendListener(outboxHibernateListener);
        registry.getEventListenerGroup(EventType.POST_DELETE)
                .appendListener(outboxHibernateListener);

//        registry.getEventListenerGroup(EventType.FLUSH)
//                .appendListener(new OutboxFlushListener());
    }
}


