package com.example.outbox.service;

import com.example.outbox.domain.MyOrder;
import com.example.outbox.domain.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final OrderRepository repository;

    public OrderService(OrderRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public void createAndShip() {
        MyOrder myOrder = new MyOrder();
        repository.save(myOrder);
        myOrder.ship();
    }

    @Transactional
    public void rollback() {
        MyOrder myOrder = new MyOrder();
        repository.save(myOrder);
        throw new RuntimeException("boom");
    }
}
