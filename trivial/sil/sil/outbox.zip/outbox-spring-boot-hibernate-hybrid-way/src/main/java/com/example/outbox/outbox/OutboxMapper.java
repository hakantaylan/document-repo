package com.example.outbox.outbox;

public interface OutboxMapper {
    /**
     * Return the aggregate type name for the given entity (default: entity class simple name)
     */
    String aggregateType(Object entity);

    /**
     * Convert an entity to the JSON payload string
     */
    String toPayload(Object entity) throws Exception;

    /**
     * Convert identifier object to string key used in outbox row
     */
    String idToString(Object id);
}
