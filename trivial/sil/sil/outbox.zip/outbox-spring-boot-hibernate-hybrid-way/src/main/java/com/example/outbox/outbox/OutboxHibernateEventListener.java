package com.example.outbox.outbox;

import org.hibernate.event.spi.*;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * A single listener implementing PostInsert/Update/Delete. It only collects events into OutboxCollector
 * and asks OutboxSynchronizationService to register a synchronization.
 */
@Component
public class OutboxHibernateEventListener implements PostInsertEventListener,
        PostUpdateEventListener, PostDeleteEventListener {

    private final OutboxMapper mapper;
    private final OutboxSynchronizationService syncService;

    public OutboxHibernateEventListener(OutboxMapper mapper, OutboxSynchronizationService syncService) {
        this.mapper = mapper;
        this.syncService = syncService;
    }

    @Override
    public void onPostInsert(PostInsertEvent event) {
        handleEvent(event.getEntity(), event.getId(), "INSERT");
    }

    @Override
    public void onPostUpdate(PostUpdateEvent event) {
        handleEvent(event.getEntity(), event.getId(), "UPDATE");
    }

    @Override
    public void onPostDelete(PostDeleteEvent event) {
        handleEvent(event.getEntity(), event.getId(), "DELETE");
    }

    private void handleEvent(Object entity, Object id, String operation) {
        try {
            String payload = mapper.toPayload(entity);
            OutboxCollector.add(new OutboxEvent(mapper.aggregateType(entity), (UUID) id, operation, payload));
            syncService.ensureSynchronizationRegistered();
        } catch (Exception ex) {
            // If mapping fails, fail fast: throw runtime to interrupt the flush/transaction
            throw new RuntimeException("Failed to map entity to outbox payload", ex);
        }
    }
}
