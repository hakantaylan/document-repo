package com.example.outbox.outbox;

import org.springframework.stereotype.Component;
import tools.jackson.databind.ObjectMapper;

@Component
public class DefaultOutboxMapper implements OutboxMapper {

    private final ObjectMapper objectMapper;

    public DefaultOutboxMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public String aggregateType(Object entity) {
        return entity.getClass().getSimpleName();
    }

    @Override
    public String toPayload(Object entity) throws Exception {
        // customize to avoid serializing lazy associations if you want
        return objectMapper.writeValueAsString(entity);
    }

    @Override
    public String idToString(Object id) {
        return id == null ? null : id.toString();
    }
}

