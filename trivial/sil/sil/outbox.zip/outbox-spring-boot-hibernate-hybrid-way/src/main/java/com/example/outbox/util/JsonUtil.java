package com.example.outbox.util;

import org.hibernate.Hibernate;
import tools.jackson.databind.json.JsonMapper;

public final class JsonUtil {

    private static final JsonMapper MAPPER = new JsonMapper();

    public static String toJson(Object entity) {
        try {
            Hibernate.initialize(entity);
            return MAPPER.writeValueAsString(entity);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String extractId(Object entity) {
        try {
            var field = entity.getClass().getDeclaredField("id");
            field.setAccessible(true);
            Object id = field.get(entity);
            return String.valueOf(id);
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }
}
