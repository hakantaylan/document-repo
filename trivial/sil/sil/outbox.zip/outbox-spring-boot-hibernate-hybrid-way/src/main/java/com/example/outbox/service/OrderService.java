package com.example.outbox.service;

import com.example.outbox.domain.OrderEntity;
import com.example.outbox.domain.OrderRepository;
import com.example.outbox.outbox.OutboxCollector;
import com.example.outbox.outbox.OutboxEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final OrderRepository repo;

    public OrderService(OrderRepository repo) {
        this.repo = repo;
    }

    @Transactional
    public OrderEntity createOrder(String name) {
        OrderEntity o = new OrderEntity(name);
        // save and flush to ensure ID is assigned (IDENTITY)
        o = repo.save(o);
        o.setName(o.getName() + " updated");
        // enqueue outbox event and register synchronization
//        OutboxCollector.add(new OutboxEvent("Order", o.getId(), "CREATED", "{\"name\":\"" + name + "\"}"));
        return o;
    }

    @Transactional
    public void createOrderAndFail(String name) {
        OrderEntity o = new OrderEntity(name);
        o = repo.save(o);
//        OutboxCollector.add(new OutboxEvent("Order", o.getId(), "CREATED", "{\"name\":\"" + name + "\"}"));
        // simulate error -> transaction will roll back
        throw new RuntimeException("simulated failure");
    }
}
