//package com.example.outbox.outbox;
//
//import java.util.UUID;
//
//public interface OutboxAggregate {
//    UUID getId();
//}
