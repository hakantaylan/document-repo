package com.example.outbox.config;

import com.example.outbox.outbox.OutboxHibernateEventListener;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.springframework.stereotype.Component;

@Component
public class HibernateOutboxRegistrar {

    private final EntityManagerFactory emf;
    private final OutboxHibernateEventListener listener;

    public HibernateOutboxRegistrar(EntityManagerFactory emf, OutboxHibernateEventListener listener) {
        this.emf = emf;
        this.listener = listener;
    }

    @PostConstruct
    public void register() {
        SessionFactoryImplementor sfi = emf.unwrap(SessionFactoryImplementor.class);
        EventListenerRegistry registry = sfi.getServiceRegistry().getService(EventListenerRegistry.class);

        // append to post-insert/update/delete events
        registry.appendListeners(EventType.POST_INSERT, listener);
        registry.appendListeners(EventType.POST_UPDATE, listener);
        registry.appendListeners(EventType.POST_DELETE, listener);
    }
}

