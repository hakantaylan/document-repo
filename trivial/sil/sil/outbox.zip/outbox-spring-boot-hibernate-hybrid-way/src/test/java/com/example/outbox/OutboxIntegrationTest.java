package com.example.outbox;

import com.example.outbox.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.example.outbox.domain.OrderEntity;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
public class OutboxIntegrationTest {

    @Autowired
    private OrderService orderService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    void outboxInsertedOnCommit() {
        OrderEntity o = orderService.createOrder("Alice");

        Integer count = jdbcTemplate.queryForObject("SELECT count(*) FROM outbox_event WHERE aggregate_id = ?", Integer.class, o.getId());
        assertThat(count).isEqualTo(1);
    }

    @Test
    void outboxNotInsertedOnRollback() {
        assertThrows(RuntimeException.class, () -> orderService.createOrderAndFail("Bob"));

        Integer count = jdbcTemplate.queryForObject("SELECT count(*) FROM outbox_event WHERE aggregate_type = 'Order' AND payload LIKE '%Bob%'", Integer.class);
        assertThat(count).isEqualTo(0);
    }
}

