package ch.frankel.blog.catalog;

public record ProductDTO(Long id, String name, String description) {
}
