package ch.frankel.blog.pricing;

public record PricingDTO(Long productId, Double price) {
}
