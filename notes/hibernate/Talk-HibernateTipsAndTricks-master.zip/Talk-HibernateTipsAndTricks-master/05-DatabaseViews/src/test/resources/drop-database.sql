drop table if exists BookAuthor cascade
drop table if exists Author cascade
drop table if exists Book cascade
drop table if exists Publisher cascade