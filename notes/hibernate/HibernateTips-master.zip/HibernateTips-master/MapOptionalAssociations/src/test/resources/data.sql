INSERT INTO publisher(id, name, version) VALUES (1, 'Manning Publications', 0)

INSERT INTO book (id, publishingdate, title, publisherid, version) VALUES (1, '2015-10-01', 'Java Persistence with Hibernate', 1, 0);
INSERT INTO book (id, publishingdate, title, version) VALUES (2, '2017-02-01', 'Hibernate Tips', 0);