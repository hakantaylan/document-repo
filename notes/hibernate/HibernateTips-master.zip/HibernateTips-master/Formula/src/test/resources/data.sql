INSERT INTO author (id, firstname, lastname, dateOfBirth, version) VALUES (1, 'John', 'Doe', '12-4-1973', 0);
