INSERT INTO publisher(id, name, version) VALUES (1, 'Thoughts on Java', 0);

INSERT INTO book (id, publishingdate, title, publisherid, version) VALUES (1, '2017-04-04', 'Hibernate Tips', 1, 0);