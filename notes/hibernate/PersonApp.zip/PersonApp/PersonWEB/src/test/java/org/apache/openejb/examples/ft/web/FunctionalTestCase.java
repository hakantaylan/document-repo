package org.apache.openejb.examples.ft.web;

import com.thoughtworks.selenium.DefaultSelenium;
import junit.framework.TestCase;

public abstract class FunctionalTestCase extends TestCase {
    protected DefaultSelenium selenium;

    protected void setUp() throws Exception {
        super.setUp();
        EmbeddedServer.getInstance();
        selenium = new DefaultSelenium("localhost", 4444, "*iexplore", "http://localhost:9091/");
        selenium.start();
    }

    protected void tearDown() throws Exception {
        selenium.stop();
    }
}
