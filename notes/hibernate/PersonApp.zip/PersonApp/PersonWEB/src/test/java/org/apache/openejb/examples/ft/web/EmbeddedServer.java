package org.apache.openejb.examples.ft.web;

import org.apache.openejb.assembler.classic.EnterpriseBeanInfo;
import org.apache.openejb.jee.EjbRef;
import org.apache.openejb.jee.JaxbJavaee;
import org.apache.openejb.jee.WebApp;
import org.apache.openejb.examples.ft.interfaces.PeopleFacade;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.webapp.WebAppContext;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.LinkRef;
import javax.naming.NamingException;
import java.io.FileInputStream;
import java.io.File;
import java.util.Collection;
import java.util.Properties;
import java.util.Arrays;

public class EmbeddedServer {
    private static EmbeddedServer instance = new EmbeddedServer();
    private Server server;

    private EmbeddedServer() {
        try {
            // initialize OpenEJB & add some test data
            Properties properties = new Properties();
            properties.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");
            InitialContext ic = new InitialContext(properties);
            PeopleFacade facade = (PeopleFacade) ic.lookup("PeopleFacadeEJBRemote");
            new TestFixture(facade).addTestData();

            // setup web app
            WebAppContext context = new WebAppContext();
            context.setWar(computeWarPath());
            InitialContext initialContext = setupJndi(context);

            // start the server
            context.setServletHandler(new EmbeddedServerServletHandler(initialContext));
            context.setContextPath("/");
            server = new Server(9091);
            server.addHandler(context);

            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private InitialContext setupJndi(WebAppContext context) throws NamingException {
        // setup local JNDI
        InitialContext initialContext = new InitialContext();
        WebApp webApp = getWebApp(context);
        Collection<EjbRef> refs = webApp.getEjbRef();
        for (EjbRef ref : refs) {
            String ejbLink = ref.getEjbLink();

            // get enterprise bean info
            EnterpriseBeanInfo beanInfo = new EJBHelper().getEJBInfo(ejbLink);
            if (beanInfo.jndiNames != null && beanInfo.jndiNames.size() > 0) {
                String jndiName = "java:openejb/ejb/" + beanInfo.jndiNames.get(0);
                initialContext.bind("java:comp/env/" + ref.getEjbRefName(), new LinkRef(jndiName));
            }
        }
        return initialContext;
    }

    private String computeWarPath() {
        String currentPath = new File(".").getAbsolutePath();
        String warPath;

        String[] pathParts = currentPath.split("(\\\\|/)+");

        int webPart = Arrays.asList(pathParts).indexOf("PersonWEB");
        if (webPart == -1) {
            warPath = "PersonWEB/src/main/webapp";
        } else {
            StringBuffer buffer = new StringBuffer();

            for (int i = 0; i < webPart; i++) {
                buffer.append(pathParts[i]);
                buffer.append(File.separator);
            }

            buffer.append("PersonWEB/src/main/webapp");
            warPath = buffer.toString();
        }
        return warPath;
    }

    public static EmbeddedServer getInstance() {
        return instance;
    }

    public Server getServer() {
        return server;
    }

    public static void main(String[] args) {
        try {
            EmbeddedServer.getInstance().getServer().join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private WebApp getWebApp(WebAppContext context) {
        WebApp webApp = null;

        try {
            FileInputStream is = new FileInputStream(new File(context.getWar() + "/WEB-INF/web.xml").getAbsolutePath());
            webApp = (WebApp) JaxbJavaee.unmarshal(WebApp.class, is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return webApp;
    }
}
