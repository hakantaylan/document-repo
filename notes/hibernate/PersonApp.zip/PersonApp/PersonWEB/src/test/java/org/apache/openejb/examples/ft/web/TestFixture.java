package org.apache.openejb.examples.ft.web;

import org.apache.openejb.examples.ft.interfaces.PeopleFacade;

public class TestFixture {
    private PeopleFacade facade;

    public TestFixture(PeopleFacade facade) {
        this.facade = facade;
    }

    public void addTestData() {
        facade.addPerson("Eula", "Dull");
        facade.addPerson("Ronny", "Bode");
        facade.addPerson("Sylvia", "Foster");
        facade.addPerson("Cecily", "Perkins");
        facade.addPerson("Lyndsey", "Van");
        facade.addPerson("Polly", "Wallick");
        facade.addPerson("Christobel", "Unk");
        facade.addPerson("Greta", "Garry");
        facade.addPerson("Justina", "Dimsdale");
        facade.addPerson("Lloyd", "Lane");
        facade.addPerson("Pierce", "Mcelroy");
        facade.addPerson("Bryant", "Kistler");
        facade.addPerson("Daria", "Stephenson");
        facade.addPerson("Desdemona", "Kettlewell");
        facade.addPerson("Ellis", "Armstrong");
        facade.addPerson("Rufus", "Bowman");
        facade.addPerson("Maitland", "Kepplinger");
        facade.addPerson("Jemmy", "Gertraht");
        facade.addPerson("Kent", "Day");
        facade.addPerson("Careen", "Lacon");
        facade.addPerson("Callie", "Robinson");
        facade.addPerson("Cleo", "Tomco");
        facade.addPerson("Channing", "Barth");
        facade.addPerson("Aletha", "Faast");
        facade.addPerson("Milburn", "Whitten");
        facade.addPerson("Ulysses", "Knight");
        facade.addPerson("Makayla", "Foster");
        facade.addPerson("Dayna", "Pawle");
        facade.addPerson("Albertina", "Kifer");
        facade.addPerson("Payton", "Thomas");
        facade.addPerson("Nell", "Napier");
        facade.addPerson("Tilda", "Mcdonald");
        facade.addPerson("Sharyn", "Richards");
        facade.addPerson("Shelby", "Wise");
        facade.addPerson("Marlon", "Hatcher");
        facade.addPerson("Estelle", "Putnam");
        facade.addPerson("Geoffrey", "Jyllian");
        facade.addPerson("Tara", "Noton");
        facade.addPerson("Kerr", "Stall");
        facade.addPerson("Lacey", "Mcmichaels");
        facade.addPerson("Louis", "Quirin");
        facade.addPerson("Cosmo", "Veith");
        facade.addPerson("Victoria", "Basinger");
        facade.addPerson("Kristy", "Ewing");
        facade.addPerson("Reina", "Peters");
        facade.addPerson("Dustin", "Monahan");
        facade.addPerson("Ashley", "Herrold");
        facade.addPerson("Yasmin", "Eckert");
        facade.addPerson("Lashawn", "Sullivan");
        facade.addPerson("Ghislain", "Higgens");
    }
}
