package org.apache.openejb.examples.ft.web;

public class AddPersonTest extends FunctionalTestCase {
    public void testShouldAddAPerson() throws Exception {
        selenium.open("/People");
        selenium.type("firstname", "Jonathan");
        selenium.type("lastname", "Gallimore");
        selenium.click("//input[@name='add' and @value='Add']");
        selenium.waitForPageToLoad("30000");
        selenium.type("filter", "gallimore");
        selenium.click("submit");
        selenium.waitForPageToLoad("30000");
        assertEquals(1, selenium.getXpathCount("//div[@id='people']/ul/li").intValue());
        assertEquals("Jonathan Gallimore", selenium.getText("//div[@id='people']/ul/li[1]"));

    }
}
