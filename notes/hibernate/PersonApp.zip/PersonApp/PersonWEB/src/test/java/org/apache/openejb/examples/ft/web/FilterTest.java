package org.apache.openejb.examples.ft.web;

public class FilterTest extends FunctionalTestCase {
    public void testShouldShowAllNames() throws Exception {
        selenium.open("/People");
        assertTrue(selenium.isTextPresent("Eula Dull"));
        assertTrue(selenium.isTextPresent("Ronny Bode"));
        assertTrue(selenium.isTextPresent("Sylvia Foster"));
        assertTrue(selenium.isTextPresent("Cecily Perkins"));
        assertTrue(selenium.isTextPresent("Lyndsey Van"));
        assertTrue(selenium.isTextPresent("Polly Wallick"));
        assertTrue(selenium.isTextPresent("Christobel Unk"));
        assertTrue(selenium.isTextPresent("Greta Garry"));
        assertTrue(selenium.isTextPresent("Justina Dimsdale"));
        assertTrue(selenium.isTextPresent("Lloyd Lane"));
        assertTrue(selenium.isTextPresent("Pierce Mcelroy"));
        assertTrue(selenium.isTextPresent("Bryant Kistler"));
        assertTrue(selenium.isTextPresent("Daria Stephenson"));
        assertTrue(selenium.isTextPresent("Desdemona Kettlewell"));
        assertTrue(selenium.isTextPresent("Ellis Armstrong"));
        assertTrue(selenium.isTextPresent("Rufus Bowman"));
        assertTrue(selenium.isTextPresent("Maitland Kepplinger"));
        assertTrue(selenium.isTextPresent("Jemmy Gertraht"));
        assertTrue(selenium.isTextPresent("Kent Day"));
        assertTrue(selenium.isTextPresent("Careen Lacon"));
        assertTrue(selenium.isTextPresent("Callie Robinson"));
        assertTrue(selenium.isTextPresent("Cleo Tomco"));
        assertTrue(selenium.isTextPresent("Channing Barth"));
        assertTrue(selenium.isTextPresent("Aletha Faast"));
        assertTrue(selenium.isTextPresent("Milburn Whitten"));
        assertTrue(selenium.isTextPresent("Ulysses Knight"));
        assertTrue(selenium.isTextPresent("Makayla Foster"));
        assertTrue(selenium.isTextPresent("Dayna Pawle"));
        assertTrue(selenium.isTextPresent("Albertina Kifer"));
        assertTrue(selenium.isTextPresent("Payton Thomas"));
        assertTrue(selenium.isTextPresent("Nell Napier"));
        assertTrue(selenium.isTextPresent("Tilda Mcdonald"));
        assertTrue(selenium.isTextPresent("Sharyn Richards"));
        assertTrue(selenium.isTextPresent("Shelby Wise"));
        assertTrue(selenium.isTextPresent("Marlon Hatcher"));
        assertTrue(selenium.isTextPresent("Estelle Putnam"));
        assertTrue(selenium.isTextPresent("Geoffrey Jyllian"));
        assertTrue(selenium.isTextPresent("Tara Noton"));
        assertTrue(selenium.isTextPresent("Kerr Stall"));
        assertTrue(selenium.isTextPresent("Lacey Mcmichaels"));
        assertTrue(selenium.isTextPresent("Louis Quirin"));
        assertTrue(selenium.isTextPresent("Cosmo Veith"));
        assertTrue(selenium.isTextPresent("Victoria Basinger"));
        assertTrue(selenium.isTextPresent("Kristy Ewing"));
        assertTrue(selenium.isTextPresent("Reina Peters"));
        assertTrue(selenium.isTextPresent("Dustin Monahan"));
        assertTrue(selenium.isTextPresent("Ashley Herrold"));
        assertTrue(selenium.isTextPresent("Yasmin Eckert"));
        assertTrue(selenium.isTextPresent("Lashawn Sullivan"));
        assertTrue(selenium.isTextPresent("Ghislain Higgens"));
    }

    public void testShouldShowOnlyPeopleWithSurnameBeginningWithA() throws Exception {
        selenium.open("/People");
        selenium.type("filter", "a");
        selenium.click("submit");
        selenium.waitForPageToLoad("30000");

        assertEquals(1, selenium.getXpathCount("//div[@id='people']/ul/li").intValue());
        assertEquals("Ellis Armstrong", selenium.getText("//div[@id='people']/ul/li"));
    }

    public void testShouldShowOnlyPeopleWithSurnameBeginningWithKe() throws Exception {
        selenium.open("/People");
        selenium.type("filter", "ke");
        selenium.click("submit");
        selenium.waitForPageToLoad("30000");

        assertEquals(2, selenium.getXpathCount("//div[@id='people']/ul/li").intValue());
        assertEquals("Maitland Kepplinger", selenium.getText("//div[@id='people']/ul/li[1]"));
        assertEquals("Desdemona Kettlewell", selenium.getText("//div[@id='people']/ul/li[2]"));
    }

    public void testShouldShowMessageIfNoMatchingEntriesFound() throws Exception {
        selenium.open("/People");
        selenium.type("filter", "test");
        selenium.click("submit");
        selenium.waitForPageToLoad("30000");

        assertEquals(0, selenium.getXpathCount("//div[@id='people']/ul/li").intValue());
        assertEquals("No entries found.", selenium.getText("//div[@id='people']/ul"));
    }

}
