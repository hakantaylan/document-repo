package org.apache.openejb.examples.ft.web;

import org.apache.openejb.examples.ft.interfaces.PeopleFacade;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;


public class PeopleServlet extends javax.servlet.http.HttpServlet {

    @EJB
    private PeopleFacade facade;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        boolean add = request.getParameter("add") != null;
        if (add) {
            String firstname = request.getParameter("firstname");
            String lastname  = request.getParameter("lastname");

            if (firstname != null && firstname.length() > 0 && lastname != null && lastname.length() > 0) {
                facade.addPerson(firstname, lastname);
            }
        }

        boolean ajax = request.getParameter("ajax") != null;
        String filter = request.getParameter("filter");
        if (filter == null) {
            filter = "";
        }

        Collection people = facade.searchSurname(filter);
        request.setAttribute("people", people);
        request.setAttribute("filter", filter);
        String forwardTo = ajax ? "/WEB-INF/peoplePartial.jsp" : "/WEB-INF/people.jsp";
        request.getRequestDispatcher(forwardTo).forward(request, response);
    }
}
