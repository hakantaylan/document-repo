package org.apache.openejb.examples.ft.ejb;

import org.apache.openejb.examples.ft.interfaces.PeopleFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import java.util.Collection;

@Stateless(name = "PeopleFacadeEJB")
public class PeopleFacadeBean implements PeopleFacade {

    @PersistenceUnit(name="PeoplePU")
    private EntityManagerFactory emf;

    public PeopleFacadeBean() {
    }

    public void addPerson(String firstname, String lastname) {
        EntityManager entityManager = emf.createEntityManager();
        PersonBean person = new PersonBean();
        person.setFirstname(firstname);
        person.setLastname(lastname);
        entityManager.persist(person);
    }

    public Collection searchSurname(String input) {
        EntityManager entityManager = emf.createEntityManager();
        Query query = entityManager.createQuery("select p from Person p where UPPER(p.lastname) LIKE ?1 order by p.lastname");
        query.setParameter(1, input.toUpperCase() + "%");
        return query.getResultList();
    }
}
