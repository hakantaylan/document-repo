package org.apache.openejb.examples.ft.interfaces;

import javax.ejb.Remote;
import java.util.Collection;

@Remote
public interface PeopleFacade {
    void addPerson(String firstname, String lastname);

    Collection searchSurname(String s);
}
