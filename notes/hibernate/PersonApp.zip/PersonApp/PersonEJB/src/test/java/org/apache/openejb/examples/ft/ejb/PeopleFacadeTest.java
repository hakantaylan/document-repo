package org.apache.openejb.examples.ft.ejb;

import junit.framework.TestCase;
import org.apache.openejb.examples.ft.interfaces.PeopleFacade;

import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.Collection;
import java.util.Properties;

public class PeopleFacadeTest extends TestCase {
    public void testShouldFindPeopleWithSurnameStartingWithG() throws Exception {
        Properties properties = new Properties();
        properties.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

        InitialContext context = new InitialContext(properties);

        PeopleFacade facade = (PeopleFacade) context.lookup("PeopleFacadeEJBRemote");
        facade.addPerson("Jonathan", "Gallimore");
        facade.addPerson("David", "Blevins");

        Collection people = facade.searchSurname("G");
        assertEquals(1, people.size());
    }
}
