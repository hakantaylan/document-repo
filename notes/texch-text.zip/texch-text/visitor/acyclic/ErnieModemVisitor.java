public interface ErnieModemVisitor
{
   public void visit(ErnieModem m);
}