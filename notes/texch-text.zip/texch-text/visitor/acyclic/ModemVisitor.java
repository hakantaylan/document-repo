public interface ModemVisitor
{
}