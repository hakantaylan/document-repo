public interface HayesModemVisitor
{
   public void visit(HayesModem m);
}