public interface ZoomModemVisitor
{
   public void visit(ZoomModem m);
}